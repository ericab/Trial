//
//  main.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/11/08.
//  Copyright GetAuto.com 2008. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "appDelegate.h"


int main(int argc, char *argv[]) {
	
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([appDelegate class]));
        return retVal;
    }
}

