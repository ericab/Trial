//
//  DetailsCell.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/4/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "DetailsCell.h"
#import "NetImageView.h"
#import <QuartzCore/QuartzCore.h>

#define DetailCellContentWidth 280.0f

@implementation DetailsCell

@synthesize netImage;
@synthesize lbl_MakeModel;
@synthesize lbl_price;
@synthesize lbl_Engine;
@synthesize lbl_Stock;
@synthesize lbl_Miles;
@synthesize lbl_ExtColor;
@synthesize lbl_IntColor;
@synthesize lbl_VIN;
@synthesize certifiedLogo;
@synthesize btn_linkPictures;
@synthesize btn_slideShow;
@synthesize btn_modify;
@synthesize seg_sort;


//- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier {
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
	if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        // Initialization code
		float yOffset = 10.0;
		CGSize imgSize = CGSizeMake(145.0f, 100.0f);
		float rightWidth = DetailCellContentWidth - imgSize.width - 5.0f;		
		UIFont *defont = [UIFont fontWithName:kDefaultFont size:kDefaultFontSize];
		NSString *stst = @"1Aq";
		float defontHeight = [stst sizeWithFont:defont].height;
		
		self.contentView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		self.selectionStyle = UITableViewCellSelectionStyleNone;
//		self.backgroundColor = [UIColor colorWithRed:RedMake(kResultBackground) green:GreenMake(kResultBackground) blue:BlueMake(kResultBackground) alpha:1.0];
		
		lbl_MakeModel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, DetailCellContentWidth, 30.0f)];
		lbl_MakeModel.numberOfLines = 2;
		lbl_MakeModel.lineBreakMode = UILineBreakModeTailTruncation;
		yOffset += lbl_MakeModel.frame.size.height;
		netImage = [[NetImageView alloc] initWithFrame:CGRectMake(10.0f, yOffset, 145.0f, 100.0f) andUrl:nil andCache:nil];
		netImage.contentMode = UIViewContentModeScaleAspectFit;
		yOffset += 5.0f;
		lbl_price = [[UILabel alloc] initWithFrame:CGRectMake(imgSize.width + 15.0f, yOffset, rightWidth, 
															  [stst sizeWithFont:[UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0]].height)];
		yOffset += lbl_price.frame.size.height + 1.0f;
		lbl_Miles = [[UILabel alloc] initWithFrame:CGRectMake(imgSize.width + 15.0f, yOffset, rightWidth, defontHeight)];
//		yOffset += defontHeight + 1.0f;
//		lbl_Stock = [[UILabel alloc] initWithFrame:CGRectMake(imgSize.width + 15.0f, yOffset, rightWidth, defontHeight)];
		yOffset += 2*defontHeight;
		lbl_IntColor = [[UILabel alloc] initWithFrame:CGRectMake(imgSize.width + 15.0f, yOffset, rightWidth, defontHeight)];
		yOffset += 2*defontHeight;
		lbl_ExtColor = [[UILabel alloc] initWithFrame:CGRectMake(imgSize.width + 15.0f, yOffset, rightWidth, defontHeight)];
//		yOffset += defontHeight + 1.0f;
//		lbl_distance = [[UILabel alloc] initWithFrame:CGRectMake(imgSize.width + 15.0f, yOffset, rightWidth, defontHeight)];
//		lbl_distance.textAlignment = UITextAlignmentRight;
		yOffset = netImage.frame.origin.y + netImage.frame.size.height + 5.0f;
		lbl_VIN = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 280.0f, defontHeight)];
		yOffset += defontHeight + 1.0f;
		lbl_Stock = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 170.0f, defontHeight)];
//		lbl_dealer = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 170.0f, defontHeight)];
//		lbl_dealer.lineBreakMode = UILineBreakModeTailTruncation;
		certifiedLogo = [[NetImageView alloc] initWithFrame:CGRectMake(180.0f, yOffset, 115.0f, 70.0f) andUrl:nil andCache:nil];
		certifiedLogo.contentMode = UIViewContentModeTop | UIViewContentModeScaleAspectFit;
		certifiedLogo.noImage = nil;
//		certifiedLogo.loadingImage = nil;
		certifiedLogo.image = nil;
		
		btn_modify = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//		[btn_modify setBackgroundImage:[UIImage imageNamed:@"folder.png"] forState:UIControlStateNormal];
		[btn_modify setTitle:@"Modify" forState:UIControlStateNormal];
		btn_modify.frame = CGRectMake(200.0f, yOffset - 20.0f, 80.0f, 35.0f);
		btn_modify.backgroundColor = [UIColor lightGrayColor];
		
		
		yOffset = 190.0f;
//		yOffset = 185.0f;
		
		btn_slideShow = [UIButton buttonWithType:UIButtonTypeCustom];
		btn_slideShow.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight; 
		[btn_slideShow setBackgroundImage:[UIImage imageNamed:@"Images.png"] forState:UIControlStateNormal];
//		[btn_slideShow setImage:[UIImage imageNamed:@"photoalbum.png"] forState:UIControlStateNormal];
//		[btn_slideShow setTitle:@"  0 Photos" forState:UIControlStateNormal];
		[btn_slideShow setTitle:@"0 Photo     " forState:UIControlStateNormal];
		[btn_slideShow setTitleColor:[UIColor colorWithRed:RedMake(kButtonNormal)  green:GreenMake(kButtonNormal) blue:BlueMake(kButtonNormal) alpha:1.0] forState:UIControlStateNormal];
		[btn_slideShow setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted)  green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		[btn_slideShow setTitleColor:[UIColor lightGrayColor] forState:UIControlStateDisabled];
//		btn_slideShow.frame = CGRectMake(10.0f, yOffset, 95.0f, 32.0f);
		btn_slideShow.frame = CGRectMake(15.0f, yOffset, 135.0f, 35.0f);
//		btn_slideShow.layer.borderColor = [UIColor grayColor].CGColor;
//		btn_slideShow.layer.borderWidth = 3.0;
//		btn_slideShow.layer.cornerRadius = 6.0;
		
		btn_linkPictures = [UIButton buttonWithType:UIButtonTypeCustom];
		btn_linkPictures.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft; 
		[btn_linkPictures setBackgroundImage:[UIImage imageNamed:@"Upload.png"] forState:UIControlStateNormal];
//		[btn_linkPictures setImage:[UIImage imageNamed:@"photoalbum.png"] forState:UIControlStateNormal];
//		[btn_linkPictures setTitle:@"  Upload" forState:UIControlStateNormal];
		[btn_linkPictures setTitle:@"     Upload" forState:UIControlStateNormal];
		[btn_linkPictures setTitleColor:[UIColor colorWithRed:RedMake(kButtonNormal)  green:GreenMake(kButtonNormal) blue:BlueMake(kButtonNormal) alpha:1.0] forState:UIControlStateNormal];
		[btn_linkPictures setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted)  green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		[btn_linkPictures setTitleColor:[UIColor lightGrayColor] forState:UIControlStateDisabled];
//		btn_linkPictures.frame = CGRectMake(180.0f, yOffset, 95.0f, 32.0f);
		btn_linkPictures.frame = CGRectMake(150.0f, yOffset, 135.0f, 35.0f);
//		btn_linkPictures.layer.borderColor = [UIColor grayColor].CGColor;
//		btn_linkPictures.layer.borderWidth = 1.0;
//		btn_linkPictures.layer.cornerRadius = 6.0;

//		[self.contentView addSubview:btnTemp];
//		[btnTemp release];
		

		NSArray *sorts = [NSArray arrayWithObjects:@"Photos", @"Modify", @"Upload Photo", nil];
		seg_sort = [[UISegmentedControl alloc] initWithItems:sorts];
		seg_sort.frame = CGRectMake(10.0f, yOffset, 280.0f, 30.0f);
		seg_sort.segmentedControlStyle = UISegmentedControlStyleBar;
		seg_sort.tintColor = [UIColor darkGrayColor];
		seg_sort.momentary = YES;
		
		
		//Set up fonts and colors
		lbl_MakeModel.font = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 3.0];
		lbl_MakeModel.textColor = [UIColor colorWithRed:RedMake(kSCAddressRGB)  green:GreenMake(kSCAddressRGB) blue:BlueMake(kSCAddressRGB) alpha:1.0];
		lbl_MakeModel.backgroundColor = [UIColor clearColor];
		lbl_price.font = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0];
		lbl_price.textColor = [UIColor colorWithRed:RedMake(kSCPriceRGB)  green:GreenMake(kSCPriceRGB) blue:BlueMake(kSCPriceRGB) alpha:1.0];
		lbl_price.backgroundColor = [UIColor clearColor];
		lbl_VIN.font = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize];
		lbl_VIN.backgroundColor = [UIColor clearColor];
		lbl_Stock.font = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize];	
		lbl_Stock.backgroundColor = [UIColor clearColor];
		lbl_Miles.font = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize];
		lbl_Miles.backgroundColor = [UIColor clearColor];
		lbl_ExtColor.font = defont;
		lbl_ExtColor.backgroundColor = [UIColor clearColor];
		lbl_IntColor.font = defont;
		lbl_IntColor.backgroundColor = [UIColor clearColor];
//		btn_slideShow.titleLabel.font = defont;
//		btn_linkPictures.titleLabel.font = defont;
		btn_slideShow.titleLabel.font = [UIFont fontWithName:kDefaultFont size:kDefaultFontSize + 4.0];
		btn_linkPictures.titleLabel.font = [UIFont fontWithName:kDefaultFont size:kDefaultFontSize + 4.0];
		
		[self.contentView addSubview:lbl_MakeModel];
		[self.contentView addSubview:netImage];
		[self.contentView addSubview:lbl_price];
		[self.contentView addSubview:lbl_VIN];
		[self.contentView addSubview:lbl_Stock];
		[self.contentView addSubview:lbl_Miles];
		[self.contentView addSubview:lbl_ExtColor];
		[self.contentView addSubview:lbl_IntColor];
		[self.contentView addSubview:certifiedLogo];
		
		[self.contentView addSubview:seg_sort];
//		[self.contentView addSubview:btn_modify];
//		[self.contentView addSubview:btn_slideShow];
//		[self.contentView addSubview:btn_linkPictures];
    }
    return self;
}

- (void) touchesEnded: (NSSet *) touches withEvent: (UIEvent *) event 
{   
    UITouch *touch = [[event allTouches] anyObject];
    if (CGRectContainsPoint([self.netImage frame], [touch locationInView:self])) {
        // Image Touched
        [btn_slideShow sendActionsForControlEvents: UIControlEventTouchUpInside];
    }
}

- (void)dealloc {

#if CONFIG_Debug
//	NSLog(@"Details Cell Dealloced");
#endif
}

@end
