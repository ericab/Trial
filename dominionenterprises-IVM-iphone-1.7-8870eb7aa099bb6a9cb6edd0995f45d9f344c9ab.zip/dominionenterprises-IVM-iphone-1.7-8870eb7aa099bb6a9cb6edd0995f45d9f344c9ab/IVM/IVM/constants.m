//
//  constants.m
//  iHomes
//
//  Created by Rakesh on 12/17/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "constants.h"


@implementation constants

@end
