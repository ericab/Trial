//
//  IVMMobileServices.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/18/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//
//  Modified by Raja Sekhar Nerella on 04/12/12.
//  Changes: 1. Twitter & Video actResult was exchanged. Issue is fixed.
#import <objc/message.h>
#import "IVMMobileServices.h"
#import "VehicleResult.h"
#import "VehicleSearchResults.h"
#import "VehicleDetails.h"
#import "VehicleSearchObject.h"
#import "Dealer.h"
#import "MakesAndModels.h"
#import "Reachability.h"
#import "appDelegate.h"
#import "SearchValues.h"
#import "SearchValuesResults.h"
#import "DecodeData.h"
#import "Photo.h"
#import "DetailActions.h"
#import "AppraisalDetails.h"
#import "GDataXMLNode.h"
#define GDATAXMLNODE_DEFINE_GLOBALS 1
#import "GDataXMLNode.h"
#import <UIKit/UIKit.h>
#import "DealerVehicleHistory.h"
#import "JSON.h"
@class GDataXMLElement, GDataXMLDocument;
static const int kGDataXMLParseOptions = (XML_PARSE_NOCDATA | XML_PARSE_NOBLANKS);

NSString *getautoURL = @"http://iphone.vehicledata.com/iphone.asmx";

NSString *baseURL = @"http://api.vehicledata.com/cvdapi/2.0/cvdapi.asmx";
NSString *imvBaseURL = @"http://api.vehicledata.com/ivmapi/2.0/ivmApi.asmx";
NSString *tokenURL = @"http://api.vehicledata.com/token/IvmApiAuthentication.asmx/token";
//NSString *baseURL = @"http://pwstest.vehicledata.com/cvdapi/2.0/cvdapi.asmx";
//NSString *imvBaseURL = @"http://pwstest.vehicledata.com/ivmapi/2.0/IvmApi.asmx";
//NSString *tokenURL = @"http://pwstest.vehicledata.com/token/IvmApiAuthentication.asmx/token";




//NSString *appraisalIdURL = @"http://api.dev.vehicledata.com/api/Appraisals/";
//NSString *providerURL = @"http://api.dev.vehicledata.com/api/providers/";
//NSString *appraisalURL = @"http://api.dev.vehicledata.com/api/Appraisal/";
//NSString *providerdetailsURL = @"http://api.dev.vehicledata.com/api/provider/";
//NSString *addAppraisalDetails = @"http://api.dev.vehicledata.com/api/Appraisals";
//NSString *dealerURL = @"http://api.dev.vehicledata.com/api/Dealer/";
//NSString *httpHeaderField=@"api.dev.vehicledata.com";


NSString *appraisalIdURL = @"https://api.vehicledata.com/4.0/api/Appraisals/";
NSString *providerURL = @"https://api.vehicledata.com/4.0/api/providers/";
NSString *appraisalURL = @"https://api.vehicledata.com/4.0/api/Appraisal/";
NSString *providerdetailsURL = @"https://api.vehicledata.com/4.0/api/provider/";

NSString *addAppraisalDetails = @"https://api.vehicledata.com/4.0/api/Appraisals";
NSString *dealerURL = @"https://api.vehicledata.com/4.0/api/Dealer/";
NSString *httpHeaderField=@"api.vehicledata.com";


@interface IVMMobileServices()

- (void) vehicleSearchComplete;
- (void) vehicleDetailsComplete;
- (void) makesAndModelsComplete;
- (void) getDealersByTokenComplete;
- (BOOL) clearConnection;
- (void) actionWebServicesComplete;
- (NSString*) fOFP:(NSString*)path fromNode:(CXMLNode*)node withNameSpace:(NSDictionary*)ns andDefault:(NSString*)sdefault;

@end

@implementation IVMMobileServices

@synthesize delegate, baseResults;

- (NSString *)xmlSimpleUnescapeString:(NSMutableString*)_unescapeStr
{
    [_unescapeStr replaceOccurrencesOfString:@"&amp;"  withString:@"&"  options:NSLiteralSearch range:NSMakeRange(0, [_unescapeStr length])];
    [_unescapeStr replaceOccurrencesOfString:@"&quot;" withString:@"\"" options:NSLiteralSearch range:NSMakeRange(0, [_unescapeStr length])];
    [_unescapeStr replaceOccurrencesOfString:@"&#x27;" withString:@"'"  options:NSLiteralSearch range:NSMakeRange(0, [_unescapeStr length])];
    [_unescapeStr replaceOccurrencesOfString:@"&#x39;" withString:@"'"  options:NSLiteralSearch range:NSMakeRange(0, [_unescapeStr length])];
    [_unescapeStr replaceOccurrencesOfString:@"&#x92;" withString:@"'"  options:NSLiteralSearch range:NSMakeRange(0, [_unescapeStr length])];
    [_unescapeStr replaceOccurrencesOfString:@"&#x96;" withString:@"'"  options:NSLiteralSearch range:NSMakeRange(0, [_unescapeStr length])];
    [_unescapeStr replaceOccurrencesOfString:@"&gt;"   withString:@">"  options:NSLiteralSearch range:NSMakeRange(0, [_unescapeStr length])];
    [_unescapeStr replaceOccurrencesOfString:@"&lt;"   withString:@"<"  options:NSLiteralSearch range:NSMakeRange(0, [_unescapeStr length])];

    return _unescapeStr;
}

- (NSString *)xmlSimpleEscapeString:(NSMutableString*)_escapeStr
{
    [_escapeStr replaceOccurrencesOfString:@"&"  withString:@"&amp;"  options:NSLiteralSearch range:NSMakeRange(0, [_escapeStr length])];
    [_escapeStr replaceOccurrencesOfString:@"\"" withString:@"&quot;" options:NSLiteralSearch range:NSMakeRange(0, [_escapeStr length])];
    [_escapeStr replaceOccurrencesOfString:@"'"  withString:@"&#x27;" options:NSLiteralSearch range:NSMakeRange(0, [_escapeStr length])];
    [_escapeStr replaceOccurrencesOfString:@">"  withString:@"&gt;"   options:NSLiteralSearch range:NSMakeRange(0, [_escapeStr length])];
    [_escapeStr replaceOccurrencesOfString:@"<"  withString:@"&lt;"   options:NSLiteralSearch range:NSMakeRange(0, [_escapeStr length])];
    
    return _escapeStr;
}


- (id) init
{
	self = [super init];
	if (self != nil) {
		mData = [NSMutableData data];
		conn = nil;
        
	}
    
	return self;
}

- (void) actionWebServices:(DetailActions*)actionData {

	_actCode = actionData.actionNumber;
	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:imvBaseURL]];

	switch (_actCode) {
		case _BROCHURE:
			[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
			[postData appendString:@"<soap:Body>\n"];
			[postData appendString:@"<SendBrochure xmlns=\"http://DealerSpecialties.com/\">\n"];
			[postData appendFormat:@"<Token>%@</Token>\n", actionData.usrToken];
			[postData appendFormat:@"<VehicleKey>%d</VehicleKey>\n", actionData.vehicleKey];
			[postData appendFormat:@"<CustomerEmailAddress>%@</CustomerEmailAddress>\n", actionData.email];
			[postData appendFormat:@"<CustomerNote>%@</CustomerNote>\n", actionData.comments];
			[postData appendString:@"</SendBrochure>\n"];
			[postData appendString:@"</soap:Body>\n"];
			[postData appendString:@"</soap:Envelope>"];
			
			[request setHTTPMethod:@"POST"];
			[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
			[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
			[request setValue:@"\"http://DealerSpecialties.com/SendBrochure\"" forHTTPHeaderField:@"SOAPAction"];
			[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
			
			break;
		case _VIDEO:
			[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
			[postData appendString:@"<soap:Body>\n"];
			[postData appendString:@"<SendVevo xmlns=\"http://DealerSpecialties.com/\">\n"];
			[postData appendFormat:@"<Token>%@</Token>\n", actionData.usrToken];
			[postData appendFormat:@"<VehicleKey>%d</VehicleKey>\n", actionData.vehicleKey];
			[postData appendFormat:@"<CustomerEmailAddress>%@</CustomerEmailAddress>\n", actionData.email];
			[postData appendString:@"</SendVevo>\n"];
			[postData appendString:@"</soap:Body>\n"];
			[postData appendString:@"</soap:Envelope>"];
			
			[request setHTTPMethod:@"POST"];
			[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
			[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
			[request setValue:@"\"http://DealerSpecialties.com/SendVevo\"" forHTTPHeaderField:@"SOAPAction"];
			[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
            
			break;
		case _TWITTER:
			[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
			[postData appendString:@"<soap:Body>\n"];
			[postData appendString:@"<SendToTwitter xmlns=\"http://DealerSpecialties.com/\">\n"];
			[postData appendFormat:@"<Token>%@</Token>\n", actionData.usrToken];
			[postData appendFormat:@"<VehicleKey>%d</VehicleKey>\n", actionData.vehicleKey];
			[postData appendFormat:@"<Message>%@</Message>\n", actionData.comments];
			[postData appendString:@"</SendToTwitter>\n"];
			[postData appendString:@"</soap:Body>\n"];
			[postData appendString:@"</soap:Envelope>"];
			
			[request setHTTPMethod:@"POST"];
			[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
			[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
			[request setValue:@"\"http://DealerSpecialties.com/SendToTwitter\"" forHTTPHeaderField:@"SOAPAction"];
			[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];

			break;
		default:
			break;
	}

	complete = @selector(actionWebServicesComplete);
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn){
        objc_msgSend(self, complete);
	}
}

- (void) updateStatusByToken:(int)vehicleKey withToken:(NSString*)inToken
{

	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
	[postData appendString:@"<soap:Body>\n"];
	[postData appendString:@"<UpdateVehicleStatusByToken xmlns=\"http://DealerSpecialties.com/\">\n"];
	[postData appendFormat:@"<Token>%@</Token>\n", inToken];
	[postData appendFormat:@"<VehicleKey>%d</VehicleKey>\n", vehicleKey];
	[postData appendString:@"<Status>Sold</Status>\n"];		//Fixed Status as "Sold"
	[postData appendString:@"</UpdateVehicleStatusByToken>\n"];
	[postData appendString:@"</soap:Body>\n"];
	[postData appendString:@"</soap:Envelope>"];
	
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:baseURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://DealerSpecialties.com/UpdateVehicleStatusByToken\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
	
	complete = @selector(vehicleDetailsComplete);
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn){
        objc_msgSend(self, complete);
	}
}

- (void) updatePriceByToken:(int)vehicleKey withToken:(NSString*)inToken withValue:(int)priceValue
{
	
	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
	[postData appendString:@"<soap:Body>\n"];
	[postData appendString:@"<UpdateVehiclePriceByToken xmlns=\"http://DealerSpecialties.com/\">\n"];
	[postData appendFormat:@"<Token>%@</Token>\n", inToken];
	[postData appendFormat:@"<VehicleKey>%d</VehicleKey>\n", vehicleKey];
	[postData appendFormat:@"<Price>%d</Price>\n", priceValue];
	[postData appendString:@"<PriceType>Price</PriceType>\n"];		//Fixed PriceType as "Price"
	[postData appendString:@"</UpdateVehiclePriceByToken>\n"];
	[postData appendString:@"</soap:Body>\n"];
	[postData appendString:@"</soap:Envelope>"];
	

	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:baseURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://DealerSpecialties.com/UpdateVehiclePriceByToken\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
	
	complete = @selector(vehicleDetailsComplete);
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn){
        objc_msgSend(self, complete);
	}
}

- (void) addVehiclePhotoByToken:(int)vehicleKey withToken:(NSString*)inToken inImage:(NSString*)photoData
{

	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
	[postData appendString:@"<soap:Body>\n"];
	[postData appendString:@"<AddVehiclePhotoByToken xmlns=\"http://DealerSpecialties.com/\">\n"];
	[postData appendFormat:@"<Token>%@</Token>\n", inToken];
	[postData appendFormat:@"<VehicleKey>%d</VehicleKey>\n", vehicleKey];
	[postData appendFormat:@"<Fs>%@</Fs>\n", photoData];
	[postData appendString:@"</AddVehiclePhotoByToken>\n"];
	[postData appendString:@"</soap:Body>\n"];
	[postData appendString:@"</soap:Envelope>"];
	
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:baseURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://DealerSpecialties.com/AddVehiclePhotoByToken\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
	
	complete = @selector(addVehiclePhotoComplete);
	
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn){
        objc_msgSend(self, complete);
	}
}

- (void) generateToken:(NSString*)userId withPwd:(NSString*)userPwd andCheck:(NSString*)checkString {

	NSString *post =[NSString stringWithFormat:@"id=%@&pwd=%@&check=%@", userId, userPwd, checkString];
	NSData *postData = [post dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
	NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
	
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:tokenURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
	[request setHTTPBody:postData];
	
	NSError *error;
	NSURLResponse *response;
	NSData *urlData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
	NSMutableString *data=[[NSMutableString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    NSString *str = [self xmlSimpleUnescapeString:data];
	NSData* nData=[str dataUsingEncoding:NSUTF8StringEncoding];
	[mData setLength:0];
    [mData appendData:nData];

	complete = @selector(generateTokenComplete);
	
    objc_msgSend(self, complete);
}

- (void) validateToken:(NSString*)tokenString andCheck:(NSString*)checkString {

	NSMutableString	*urlString = [NSString stringWithFormat:@"%@?token=%@&check=%@", tokenURL, tokenString, checkString];
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString]];
	[request setHTTPMethod:@"GET"];
    

	NSError *error;
	NSURLResponse *response;
	NSData *urlData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];


	NSMutableString *data=[[NSMutableString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
	

    NSString *str = [self xmlSimpleUnescapeString:data];


	NSData* nData=[str dataUsingEncoding:NSUTF8StringEncoding];

	
	[mData setLength:0];
    [mData appendData:nData];
 
	complete = @selector(validateTokenComplete);
    objc_msgSend(self, complete);
}


- (void) addVehicleByToken:(VehicleDetails*)vehicleData withToken:(NSString*)inToken
{
	
	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
	[postData appendString:@"<soap:Body>\n"];
	[postData appendString:@"<AddVehicleByToken xmlns=\"http://DealerSpecialties.com/\">\n"];
	[postData appendFormat:@"<Token>%@</Token>\n", inToken];
	[postData appendFormat:@"<Vehicle>\n"];

	NSDateFormatter *format = [[NSDateFormatter alloc] init];
	[format setDateFormat:@"YYYY-MM-dd'T'HH:mm:ss"];
	
	[postData appendFormat:@"<DateCreated>%@</DateCreated>\n", [format stringFromDate:vehicleData.time_created]];
	[postData appendFormat:@"<DealerLotKey>%d</DealerLotKey>\n", vehicleData.dealerLotKey];
	[postData appendFormat:@"<Make>%@</Make>\n", (vehicleData.make) ? vehicleData.make : @""];
	[postData appendFormat:@"<Mileage>\n"];
		[postData appendFormat:@"<HasValue>%@</HasValue>\n", vehicleData.mileage == 0 ? @"false":@"true"];
		[postData appendFormat:@"<Value>%d</Value>\n", vehicleData.mileage];
	[postData appendFormat:@"</Mileage>\n"];
	[postData appendFormat:@"<Model>%@</Model>\n", (vehicleData.model) ? vehicleData.model : @""];
	[postData appendFormat:@"<Prices>\n"];
		[postData appendFormat:@"<PriceInfo>\n"];
			[postData appendFormat:@"<PriceType>%@</PriceType>\n", @"Price"];
			[postData appendFormat:@"<Price>%d</Price>\n", vehicleData.price];
		[postData appendFormat:@"</PriceInfo>\n"];
	[postData appendFormat:@"</Prices>\n"];
	[postData appendFormat:@"<Status>%@</Status>\n", vehicleData.status];
	[postData appendFormat:@"<Trim>%@</Trim>\n", vehicleData.trimLevel];
	[postData appendFormat:@"<VehicleType>%@</VehicleType>\n", vehicleData.type];
	[postData appendFormat:@"<Vin>%@</Vin>\n", vehicleData.vin];
	[postData appendFormat:@"<Year>%d</Year>\n", vehicleData.year];
	[postData appendFormat:@"</Vehicle>\n"];
	[postData appendString:@"</AddVehicleByToken>\n"];
	[postData appendString:@"</soap:Body>\n"];
	[postData appendString:@"</soap:Envelope>"];
	
	
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:baseURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://DealerSpecialties.com/AddVehicleByToken\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
	
	complete = @selector(vehicleDetailsComplete);
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn) {
        objc_msgSend(self, complete);
    }
}

- (void) getDecodeDataByToken:(NSString*)vinCode  withToken:(NSString*)inToken
{
	
	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
	[postData appendString:@"<soap:Body>\n"];
	[postData appendString:@"<GetDecodeDataByToken xmlns=\"http://DealerSpecialties.com/\">\n"];
	[postData appendFormat:@"<Token>%@</Token>\n", inToken];
	[postData appendFormat:@"<Vin>%@</Vin>\n", vinCode];
	[postData appendString:@"</GetDecodeDataByToken>\n"];
	[postData appendString:@"</soap:Body>\n"];
	[postData appendString:@"</soap:Envelope>"];
	
	
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:baseURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://DealerSpecialties.com/GetDecodeDataByToken\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
	
	
	complete = @selector(getDecodeDataComplete);
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn){
        objc_msgSend(self, complete);
	}
}

- (void) getSearchValuesByToken:(int)dealerLotKey withToken:(NSString*)inToken
{
	
	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
	[postData appendString:@"<soap:Body>\n"];
	[postData appendString:@"<GetSearchValuesByToken xmlns=\"http://DealerSpecialties.com/\">\n"];
	[postData appendFormat:@"<Token>%@</Token>\n", inToken];
	[postData appendFormat:@"<DealerLotKey>%d</DealerLotKey>\n", dealerLotKey];
	[postData appendString:@"</GetSearchValuesByToken>\n"];
	[postData appendString:@"</soap:Body>\n"];
	[postData appendString:@"</soap:Envelope>"];
	
	
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:baseURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://DealerSpecialties.com/GetSearchValuesByToken\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
	
	complete = @selector(searchValuesComplete);
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn){
        objc_msgSend(self, complete);
	}
}

- (void) getDealersByToken:(NSString*)inToken {

	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
	[postData appendString:@"<soap:Body>\n"];
	[postData appendString:@"<GetDealersByToken xmlns=\"http://DealerSpecialties.com/\">\n"];
	[postData appendFormat:@"<Token>%@</Token>\n", inToken];
	[postData appendString:@"</GetDealersByToken>\n"];
	[postData appendString:@"</soap:Body>\n"];
	[postData appendString:@"</soap:Envelope>"];
	
	
	
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:baseURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://DealerSpecialties.com/GetDealersByToken\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
	
	complete = @selector(getDealersByTokenComplete);
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn){
        objc_msgSend(self, complete);
	}
}

- (void) makesAndModels{
	if(![self.delegate respondsToSelector:@selector(MakesAndModelsComplete:)]) return;
	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
	[postData appendString:@"<soap:Body>\n"];
	[postData appendString:@"<RequestMakeModelList xmlns=\"http://DealerSpecialties.com/\">\n"];
	[postData appendString:@"<sUserName><![CDATA[ASWuser]]></sUserName>\n"];
	[postData appendString:@"<sPassword><![CDATA[yMxtArcjikl/jUID77/Aj9/OjQg=]]></sPassword>\n"];
	[postData appendString:@"</RequestMakeModelList>\n"];
	[postData appendString:@"</soap:Body>\n"];
	[postData appendString:@"</soap:Envelope>"];
	
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:baseURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://asws.vehicledata.com/RequestMakeModelList\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
	
	complete = @selector(makesAndModelsComplete);
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn) {
        objc_msgSend(self, complete);
	}
}

- (void) searchVehiclesByToken:(VehicleSearchObject*)search withToken:(NSString*)inToken
{

	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
	[postData appendString:@"<soap:Body>\n"];
	[postData appendString:@"<GetActiveVehiclesBySearchByToken xmlns=\"http://DealerSpecialties.com/\">\n"];
	[postData appendFormat:@"<Token>%@</Token>\n", inToken];
	[postData appendFormat:@"<DealerLotKey>%d</DealerLotKey>\n", search.dealerLot];
	[postData appendFormat:@"<Year>\n"];
		[postData appendFormat:@"<HasValue>%@</HasValue>\n", search.year == 0 ? @"false":@"true"];
		if (search.year) {
			[postData appendFormat:@"<Value>%d</Value>\n", search.year];
		}
	[postData appendFormat:@"</Year>\n"];
	[postData appendFormat:@"<Make>%@</Make>\n", (search.make && ![search.make isEqualToString:@"All"]) ? search.make : @""];
	[postData appendFormat:@"<Model>%@</Model>\n", (search.model && ![search.model isEqualToString:@"All"]) ? search.model : @""];

	[postData appendFormat:@"<PriceMin>\n"];
		[postData appendFormat:@"<HasValue>%@</HasValue>\n", search.minPrice == 0 ? @"false":@"true"];
	if (search.minPrice) {
		[postData appendFormat:@"<Value>%d</Value>\n", search.minPrice];
	}
	[postData appendFormat:@"</PriceMin>\n"];
	[postData appendFormat:@"<PriceMax>\n"];
		[postData appendFormat:@"<HasValue>%@</HasValue>\n", search.maxPrice == 0 ? @"false":@"true"];
	if (search.maxPrice) {
		[postData appendFormat:@"<Value>%d</Value>\n", search.maxPrice];
	}
	[postData appendFormat:@"</PriceMax>\n"];

	[postData appendFormat:@"<MileageMin>\n"];
		[postData appendFormat:@"<HasValue>%@</HasValue>\n", search.minMileage == 0 ? @"false":@"true"];
	if (search.minMileage) {
		[postData appendFormat:@"<Value>%d</Value>\n", search.minMileage];
	}
	[postData appendFormat:@"</MileageMin>\n"];
	[postData appendFormat:@"<MileageMax>\n"];
		[postData appendFormat:@"<HasValue>%@</HasValue>\n", search.maxMileage == 0 ? @"false":@"true"];
	if (search.maxMileage) {
		[postData appendFormat:@"<Value>%d</Value>\n", search.maxMileage];
	}
	[postData appendFormat:@"</MileageMax>\n"];
	
    [postData appendFormat:@"<StartIndex>%d</StartIndex>\n", search.firstListing];
	[postData appendFormat:@"<PageSize>%d</PageSize>\n", kMaxPageResults];
	[postData appendString:@"</GetActiveVehiclesBySearchByToken>\n"];
	[postData appendString:@"</soap:Body>\n"];
	[postData appendString:@"</soap:Envelope>"];
	
	
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:baseURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://DealerSpecialties.com/GetActiveVehiclesBySearchByToken\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];

	complete = @selector(vehicleSearchComplete);
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn) {
        objc_msgSend(self, complete);
    }
}

- (void) getVehicleDetailsByToken:(int)key withToken:(NSString*)inToken
{
	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
	[postData appendString:@"<soap:Body>\n"];
	[postData appendString:@"<GetVehicleByToken xmlns=\"http://DealerSpecialties.com/\">\n"];
	[postData appendFormat:@"<Token>%@</Token>\n", inToken];
	[postData appendFormat:@"<VehicleKey>%d</VehicleKey>\n", key];
	[postData appendString:@"</GetVehicleByToken>\n"];
	[postData appendString:@"</soap:Body>\n"];
	[postData appendString:@"</soap:Envelope>"];
	
	
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:baseURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://DealerSpecialties.com/GetVehicleByToken\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
	
	complete = @selector(vehicleDetailsComplete);
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn) {
        objc_msgSend(self, complete);
    }
}

- (void) requestDealerByLocation:(CLLocationCoordinate2D)LatLon radius:(double)radius andManufacturers:(NSString*)manufacturers andSort:(NSString*)sort{
	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
	[postData appendString:@"<soap:Body>\n"];
	[postData appendString:@"<RequestDealerResultsListByLocation xmlns=\"http://DealerSpecialties.com/\">\n"];
	[postData appendString:@"<sUserName>ASWuser</sUserName>\n"];
	[postData appendString:@"<sPassword>yMxtArcjikl/jUID77/Aj9/OjQg=</sPassword>\n"];
	[postData appendFormat:@"<dLatitude>%f</dLatitude>\n", LatLon.latitude];
	[postData appendFormat:@"<dLongitude>%f</dLongitude>\n", LatLon.longitude];
	[postData appendFormat:@"<iRadius>%.0f</iRadius>\n", radius];
	if(manufacturers)
		[postData appendFormat:@"<sManufacturers><![CDATA[%@]]></sManufacturers>\n", manufacturers];
	[postData appendFormat:@"<ssortby>%@</ssortby>\n", sort ? sort : @""];
	[postData appendString:@"</RequestDealerResultsListByLocation>\n"];
	[postData appendString:@"</soap:Body>\n"];
	[postData appendString:@"</soap:Envelope>"];
	
	
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:baseURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://asws.vehicledata.com/RequestDealerResultsListByLocation\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
	
	complete =  @selector(dealersComplete);
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn) {
        objc_msgSend(self, complete);
    }
}

- (void) requestDealerByZipCode:(NSString*)zipCode radius:(double)radius andManufacturers:(NSString*)manufacturers andSort:(NSString*)sort{
	NSMutableString *postData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"];
	[postData appendString:@"<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\n"];
	[postData appendString:@"<soap:Body>\n"];
	[postData appendString:@"<RequestDealerResultsListByZipCode xmlns=\"http://DealerSpecialties.com/\">\n"];
	[postData appendString:@"<sUserName>ASWuser</sUserName>\n"];
	[postData appendString:@"<sPassword>yMxtArcjikl/jUID77/Aj9/OjQg=</sPassword>\n"];
	[postData appendFormat:@"<iZipCode>%@</iZipCode>\n", zipCode];
	[postData appendFormat:@"<iRadius>%.0f</iRadius>\n", radius];
	if(manufacturers)
		[postData appendFormat:@"<sManufacturers><![CDATA[%@]]></sManufacturers>\n", manufacturers];
	[postData appendFormat:@"<ssortby>%@</ssortby>\n", sort ? sort : @""];
	[postData appendString:@"</RequestDealerResultsListByZipCode>\n"];
	[postData appendString:@"</soap:Body>\n"];
	[postData appendString:@"</soap:Envelope>"];
	
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:baseURL]];
	[request setHTTPMethod:@"POST"];
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://asws.vehicledata.com/RequestDealerResultsListByZipCode\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
	
	complete = @selector(dealersComplete);
	
	if(![self clearConnection]) return;
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if(!conn) {
        objc_msgSend(self, complete);
    }
}

- (void) actionWebServicesComplete{
	
	NSString	*actResult = nil;
	
	NSError *xerror = nil;
	CXMLDocument *xdoc = [[CXMLDocument alloc] initWithData:mData options:0 error:&xerror];
#if CONFIG_Debug
	if([xerror code] > 0)
	{
		NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
		
	}
#endif
	
	NSDictionary *ns = [NSDictionary dictionaryWithObject:@"http://DealerSpecialties.com/" forKey:@"DealerSpecialties"];
	
	switch (_actCode) {
		case _BROCHURE:
			actResult = [self fOFP:@"//DealerSpecialties:SendBrochureResult" fromNode:xdoc withNameSpace:ns andDefault:nil];
			break;
		case _VIDEO:
			actResult = [self fOFP:@"//DealerSpecialties:SendVevoResult" fromNode:xdoc withNameSpace:ns andDefault:nil];
			break;
		case _TWITTER:
			actResult = [self fOFP:@"//DealerSpecialties:SendToTwitterResult" fromNode:xdoc withNameSpace:ns andDefault:nil];
			break;
		default:
			break;
	}
	
	[self.delegate ActionWebServicesComplete:actResult];
	
	if(![self clearConnection]) return;
}

- (void) generateTokenComplete {
	
	NSString	*inToken = [[NSString alloc] init];
	
	NSError *xerror = nil;
	CXMLDocument *xdoc = [[CXMLDocument alloc] initWithData:mData options:0 error:&xerror];
#if CONFIG_Debug
	if([xerror code] > 0)
	{
		NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
		
	}
#endif
	
	NSDictionary *ns = [NSDictionary dictionaryWithObject:@"http://DealerSpecialties.com/" forKey:@"DealerSpecialties"];
	
	int resultCode = [[self fOFP:@"//DealerSpecialties:code" fromNode:xdoc withNameSpace:ns andDefault:@"-1"] intValue];
	if( resultCode == 201 ) {
		for(CXMLNode *t in [xdoc nodesForXPath:@"//DealerSpecialties:tokens" namespaceMappings:ns error:nil])
		{
			inToken = [self fOFP:@"DealerSpecialties:token" fromNode:t withNameSpace:ns andDefault:nil];
		}
	}
	
		
	[self.delegate GenerateTokenComplete:inToken andResult:resultCode];
	
	if(![self clearConnection]) return;
}

- (void) validateTokenComplete {
	
	NSError *xerror = nil;
	CXMLDocument *xdoc = [[CXMLDocument alloc] initWithData:mData options:0 error:&xerror];
#if CONFIG_Debug
	if([xerror code] > 0)
	{
		NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
		
	}
#endif
	
	NSDictionary *ns = [NSDictionary dictionaryWithObject:@"http://DealerSpecialties.com/" forKey:@"DealerSpecialties"];
	
	int resultCode = [[self fOFP:@"//DealerSpecialties:code" fromNode:xdoc withNameSpace:ns andDefault:@"-1"] intValue];
	
	

	[self.delegate ValidateTokenComplete:resultCode];
	
	if(![self clearConnection]) return;
}


- (void) addVehiclePhotoComplete {
	
	Photo *ph = [Photo new];
	
	NSError *xerror = nil;
	CXMLDocument *xdoc = [[CXMLDocument alloc] initWithData:mData options:0 error:&xerror];
#if CONFIG_Debug
	if([xerror code] > 0)
	{
		NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
		
	}
#endif
	
	NSDictionary *ns = [NSDictionary dictionaryWithObject:@"http://DealerSpecialties.com/" forKey:@"DealerSpecialties"];
	
	NSString *resultString = [self fOFP:@"//DealerSpecialties:Result" fromNode:xdoc withNameSpace:ns andDefault:nil];

	ph.lotKey = [[self fOFP:@"//DealerSpecialties:DealerLotKey" fromNode:xdoc withNameSpace:ns andDefault:@"-1"] intValue];
	ph.vehicleKey = [[self fOFP:@"//DealerSpecialties:VehicleKey" fromNode:xdoc withNameSpace:ns andDefault:@"-1"] intValue];
		
	for(CXMLNode *p in [xdoc nodesForXPath:@"//DealerSpecialties:Photo" namespaceMappings:ns error:nil])
	{
		ph.c640Image = [self fOFP:@"DealerSpecialties:c640" fromNode:p withNameSpace:ns andDefault:nil];
		ph.m200Image = [self fOFP:@"DealerSpecialties:m200" fromNode:p withNameSpace:ns andDefault:nil];
		ph.s1024Image = [self fOFP:@"DealerSpecialties:s1024" fromNode:p withNameSpace:ns andDefault:nil];
		ph.t100Image = [self fOFP:@"DealerSpecialties:t100" fromNode:p withNameSpace:ns andDefault:nil];
	}
	
	[self.delegate AddVehiclePhotoComplete:ph inResult:resultString];
	
	if(![self clearConnection]) return;
}

- (void) getDecodeDataComplete {
	
	DecodeData *ded = [DecodeData new];

	NSError *xerror = nil;
	CXMLDocument *xdoc = [[CXMLDocument alloc] initWithData:mData options:0 error:&xerror];
#if CONFIG_Debug
	if([xerror code] > 0)
	{
		NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
		
	}
#endif

	NSDictionary *ns = [NSDictionary dictionaryWithObject:@"http://DealerSpecialties.com/" forKey:@"DealerSpecialties"];
	
	NSString *dResult = [self fOFP:@"//DealerSpecialties:Result" fromNode:xdoc withNameSpace:ns andDefault:nil];
	if ([dResult isEqualToString:@"Success" ])
	{
		for(CXMLNode *v in [xdoc nodesForXPath:@"//DealerSpecialties:GetDecodeDataByTokenResult" namespaceMappings:ns error:nil])
		{
			ded.year = [[self fOFP:@"DealerSpecialties:Year" fromNode:v withNameSpace:ns andDefault:@"-1"] intValue];
			ded.make = [self fOFP:@"DealerSpecialties:Make" fromNode:v withNameSpace:ns andDefault:nil];
			ded.model = [self fOFP:@"DealerSpecialties:Model" fromNode:v withNameSpace:ns andDefault:nil];

			NSMutableArray *trims = [NSMutableArray array];	
			for(CXMLNode *tr in [xdoc nodesForXPath:@"//DealerSpecialties:Trim" namespaceMappings:ns error:nil])
			{
				for (CXMLNode *tt in [tr children]) {
					NSString *trim = [[tt stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
					if(trim == nil || [trim isEqualToString:@""]) continue;
					[trims addObject:trim];
				}
			}

			ded.trims = trims;

			ded.vin = [self fOFP:@"DealerSpecialties:Vin" fromNode:v withNameSpace:ns andDefault:nil];

		}	
	}
	
	[self.delegate GetDecodeDataComplete:ded  dResult:dResult];
	
	if(![self clearConnection]) return;
}

- (void) searchValuesComplete{
	
	SearchValuesResults *svr = [SearchValuesResults new];
	
	NSError *xerror = nil;
	CXMLDocument *xdoc = [[CXMLDocument alloc] initWithData:mData options:0 error:&xerror];
#if CONFIG_Debug
	if([xerror code] > 0)
	{
		NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
		
	}
#endif
	
	NSDictionary *ns = [NSDictionary dictionaryWithObject:@"http://DealerSpecialties.com/" forKey:@"DealerSpecialties"];
	
	
	svr.totalCount = 0;
	
	NSString *dResult = [self fOFP:@"//DealerSpecialties:Result" fromNode:xdoc withNameSpace:ns andDefault:nil];
	if ([dResult isEqualToString:@"Success" ])
	{
		for(CXMLNode *v in [xdoc nodesForXPath:@"//DealerSpecialties:SearchValueInfo" namespaceMappings:ns error:nil])
		{
			SearchValues	*sv = [SearchValues new];
			sv.year = [[self fOFP:@"DealerSpecialties:Year" fromNode:v withNameSpace:ns andDefault:@"-1"] intValue];
			sv.make = [self fOFP:@"DealerSpecialties:Make" fromNode:v withNameSpace:ns andDefault:nil];
			sv.model = [self fOFP:@"DealerSpecialties:Model" fromNode:v withNameSpace:ns andDefault:nil];
			[svr.listings addObject:sv];
			svr.totalCount++;
		}	
	}
	[self.delegate SearchValuesComplete:svr withStatus:dResult];
	if(![self clearConnection]) return;
}

- (void) makesAndModelsComplete{
	if(![self.delegate respondsToSelector:@selector(MakesAndModelsComplete:)]) return;
	NSMutableArray *makes = [NSMutableArray array];
	NSMutableArray *models = [NSMutableArray array];
	
	NSError *xerror = nil;
	CXMLDocument *xdoc = [[CXMLDocument alloc] initWithData:mData options:0 error:&xerror];
#if CONFIG_Debug
	if([xerror code] > 0)
	{
		NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
	}
#endif
		
	for(CXMLNode *mm in [xdoc nodesForXPath:@"//MAKES" namespaceMappings:nil error:nil])
	{
		[makes addObject:[self fOFP:@"@Name" fromNode:mm withNameSpace:nil andDefault:@""]];
		
		NSMutableArray *tmp_models = [NSMutableArray array];
		[tmp_models addObject:@"All Models"];
		for(CXMLNode *mdls in [mm nodesForXPath:@"model" namespaceMappings:nil error:nil])
		{
			NSString *mdl_txt = [mdls stringValue];
			if(mdl_txt == nil) continue;
			[tmp_models addObject:mdl_txt];
		}
		[models addObject:tmp_models];
	}
	[self.delegate MakesAndModelsComplete:[[MakesAndModels alloc] initWithMakes:makes andModels:models]];
	if(![self clearConnection]) return;
}

- (void) vehicleSearchComplete {	

	VehicleSearchResults *vsr = baseResults ? baseResults : [VehicleSearchResults new];
	NSError *xerror = nil;
	CXMLDocument *xdoc = [[CXMLDocument alloc] initWithData:mData options:0 error:&xerror];
#if CONFIG_Debug
	if([xerror code] > 0)
	{
		NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
	}
#endif

	NSDictionary *ns = [NSDictionary dictionaryWithObject:@"http://DealerSpecialties.com/" forKey:@"DealerSpecialties"];
	
	NSString *dResult = [self fOFP:@"//DealerSpecialties:Result" fromNode:xdoc withNameSpace:ns andDefault:nil];
	if ([dResult isEqualToString:@"Success" ])
	{
		for(CXMLNode *v in [xdoc nodesForXPath:@"//DealerSpecialties:ActiveVehicleInfo" namespaceMappings:ns error:nil])
		{
			VehicleResult *vehicle = [VehicleResult new];
			
			vehicle.externalColor =	[self fOFP:@"DealerSpecialties:ExternalColor" fromNode:v withNameSpace:ns andDefault:nil];
			vehicle.vehicle_key =	[[self fOFP:@"DealerSpecialties:VehicleKey" fromNode:v withNameSpace:ns andDefault:@"-1"] intValue];
			vehicle.vin =			[self fOFP:@"DealerSpecialties:Vin" fromNode:v withNameSpace:ns andDefault:nil];
			vehicle.stockNumber =	[self fOFP:@"DealerSpecialties:StockNumber" fromNode:v withNameSpace:ns andDefault:nil];
			vehicle.make =			[self fOFP:@"DealerSpecialties:Make" fromNode:v withNameSpace:ns andDefault:nil];
			vehicle.model =			[self fOFP:@"DealerSpecialties:Model" fromNode:v withNameSpace:ns andDefault:nil];
			vehicle.year =			[[self fOFP:@"DealerSpecialties:Year" fromNode:v withNameSpace:ns andDefault:@"-1"] intValue];
			
			
			for (CXMLNode *pr in [v nodesForXPath:@"DealerSpecialties:Price" namespaceMappings:ns error:nil])
			{
				NSString *temp = [self fOFP:@"DealerSpecialties:HasValue" fromNode:pr withNameSpace:ns andDefault:nil];
				if ([temp isEqualToString:@"true"]) {
					vehicle.price =	[[self fOFP:@"DealerSpecialties:Value" fromNode:pr withNameSpace:ns andDefault:@"-1"] intValue];
				} else {
					vehicle.price =	0;
				}
			}
			
			for(CXMLNode *mi in [v nodesForXPath:@"DealerSpecialties:Mileage" namespaceMappings:ns error:nil])
			{
				NSString *temp = [self fOFP:@"DealerSpecialties:HasValue" fromNode:mi withNameSpace:ns andDefault:nil];
				if ([temp isEqualToString:@"true"]) {
					vehicle.mileage = [[self fOFP:@"DealerSpecialties:Value" fromNode:mi withNameSpace:ns andDefault:@"-1"] intValue];
				} else {
					vehicle.mileage = 0;
				}
			}
			
			vehicle.trimLevel =		[self fOFP:@"DealerSpecialties:Trim" fromNode:v withNameSpace:ns andDefault:nil];
			
			for(CXMLNode *ph in [v nodesForXPath:@"DealerSpecialties:Photo" namespaceMappings:ns error:nil])
			{
				vehicle.image =	[self fOFP:@"DealerSpecialties:t100" fromNode:ph withNameSpace:ns andDefault:nil];
			}
			[vsr.listings addObject:vehicle];
            vsr.totalCount++;
		}	
	}

	[self.delegate VehicleSearchComplete:vsr withStatus:dResult];
	
	if(![self clearConnection]) return;
}

- (void) vehicleDetailsComplete{
	VehicleDetails *vehicle = [VehicleDetails new];
	NSError *xerror = nil;
	CXMLDocument *xdoc = [[CXMLDocument alloc] initWithData:mData options:0 error:&xerror];
	
#if CONFIG_Debug
	if([xerror code] > 0)
	{
		NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
	}
#endif

	NSDictionary *ns = [NSDictionary dictionaryWithObject:@"http://DealerSpecialties.com/" forKey:@"DealerSpecialties"];
	
	NSString *dResult = [self fOFP:@"//DealerSpecialties:Result" fromNode:xdoc withNameSpace:ns andDefault:nil];
	if ([dResult isEqualToString:@"Success" ])
	{
		vehicle.dealerLotKey =	[[self fOFP:@"//DealerSpecialties:DealerLotKey" fromNode:xdoc withNameSpace:ns andDefault:@"-1"] intValue];
		vehicle.vin =			[self fOFP:@"//DealerSpecialties:Vin" fromNode:xdoc withNameSpace:ns andDefault:nil];
		vehicle.vehicle_key =	[[self fOFP:@"//DealerSpecialties:VehicleKey" fromNode:xdoc withNameSpace:ns andDefault:@"-1"] intValue];
		vehicle.stockNumber =	[self fOFP:@"//DealerSpecialties:StockNumber" fromNode:xdoc withNameSpace:ns andDefault:@"N/A"];
		vehicle.titaniumID =	[self fOFP:@"//DealerSpecialties:TitaniumID" fromNode:xdoc withNameSpace:ns andDefault:@"N/A"];
		vehicle.status =		[self fOFP:@"//DealerSpecialties:Status" fromNode:xdoc withNameSpace:ns andDefault:@"N/A"];
		vehicle.year =			[[self fOFP:@"//DealerSpecialties:Year" fromNode:xdoc withNameSpace:ns andDefault:@"-1"] intValue];

		for(CXMLNode *mi in [xdoc nodesForXPath:@"//DealerSpecialties:Mileage" namespaceMappings:ns error:nil])
		{
			NSString *temp = [self fOFP:@"DealerSpecialties:HasValue" fromNode:mi withNameSpace:ns andDefault:nil];
			if ([temp isEqualToString:@"true"]) {
				vehicle.mileage = [[self fOFP:@"DealerSpecialties:Value" fromNode:mi withNameSpace:ns andDefault:@"-1"] intValue];
			} else {
				vehicle.mileage = 0;
			}
		}
	
		for(CXMLNode *prs in [xdoc nodesForXPath:@"//DealerSpecialties:Prices" namespaceMappings:ns error:nil])
		{
			for(CXMLNode *pi in [prs nodesForXPath:@"DealerSpecialties:PriceInfo" namespaceMappings:ns error:nil])
			{
				NSString *temp = [self fOFP:@"DealerSpecialties:PriceType" fromNode:pi withNameSpace:ns andDefault:nil];
				if ([temp isEqualToString:@"Price"]) {
					vehicle.price = [[self fOFP:@"DealerSpecialties:Price" fromNode:pi withNameSpace:ns andDefault:@"-1"] intValue];
					break;
				} else {
					vehicle.price = 0;
				}
			}
		}
		
		NSString *temp =		[self fOFP:@"//DealerSpecialties:IsNew" fromNode:xdoc withNameSpace:ns andDefault:nil];
		vehicle.isNew =	[temp isEqualToString:@"true"];
		vehicle.make =			[self fOFP:@"//DealerSpecialties:Make" fromNode:xdoc withNameSpace:ns andDefault:nil];
		vehicle.model =			[self fOFP:@"//DealerSpecialties:Model" fromNode:xdoc withNameSpace:ns andDefault:nil];
		vehicle.transmission =	[self fOFP:@"//DealerSpecialties:Transmission" fromNode:xdoc withNameSpace:ns andDefault:nil];

		for(CXMLNode *eng in [xdoc nodesForXPath:@"//DealerSpecialties:EngineSize" namespaceMappings:ns error:nil])
		{
			NSString *temp = [self fOFP:@"DealerSpecialties:HasValue" fromNode:eng withNameSpace:ns andDefault:nil];
			if ([temp isEqualToString:@"true"]) {
				vehicle.engine = [self fOFP:@"DealerSpecialties:Value" fromNode:eng withNameSpace:ns andDefault:nil];
			} else {
				vehicle.engine = @"";
			}
		}
	
		NSMutableArray *options = [NSMutableArray array];	
		for(CXMLNode *optns in [xdoc nodesForXPath:@"//DealerSpecialties:Options" namespaceMappings:ns error:nil])
		{
			for(CXMLNode *optn in [optns children]){
				NSString *option = [[optn stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
				if(option == nil || [option isEqualToString:@""]) continue;
				[options addObject:option];
			}
		}

		vehicle.options = options;
	
		vehicle.trimLevel = [self fOFP:@"//DealerSpecialties:Trim" fromNode:xdoc withNameSpace:ns andDefault:nil];
		vehicle.externalColor = [self fOFP:@"//DealerSpecialties:ExternalColor" fromNode:xdoc withNameSpace:ns andDefault:nil];
		vehicle.internalColor = [self fOFP:@"//DealerSpecialties:InternalColor" fromNode:xdoc withNameSpace:ns andDefault:nil];

		NSMutableArray *cphotos = [NSMutableArray array];
		NSMutableArray *tphotos = [NSMutableArray array];
		for(CXMLNode *pi in [xdoc nodesForXPath:@"//DealerSpecialties:Photos" namespaceMappings:ns error:nil])
		{
			for(CXMLNode *ui in [pi nodesForXPath:@"DealerSpecialties:PhotoUrl" namespaceMappings:ns error:nil])
			{
				NSString *cimage = [self fOFP:@"DealerSpecialties:c640" fromNode:ui withNameSpace:ns andDefault:nil];
				if(cimage == nil || [cimage isEqualToString:@""]) continue;
				[cphotos addObject:cimage];
			
				NSString *timage = [self fOFP:@"DealerSpecialties:t100" fromNode:ui withNameSpace:ns andDefault:nil];
				if(timage == nil || [timage isEqualToString:@""]) continue;
				[tphotos addObject:timage];

			}
		}

		vehicle.regularPhotos = cphotos;
		vehicle.thumbPhotos = tphotos;

	}
	
	
	[self.delegate VehicleDetailsComplete:vehicle withStatus:dResult];
	if(![self clearConnection]) return;
}

- (void) getDealersByTokenComplete {
	
	NSMutableArray *dealers = [NSMutableArray array];
	NSError *xerror = nil;
	CXMLDocument *xdoc = [[CXMLDocument alloc] initWithData:mData options:0 error:&xerror];
	
    
#if CONFIG_Debug
	if([xerror code] > 0)
	{
		NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
	}
#endif

	NSDictionary *ns = [NSDictionary dictionaryWithObject:@"http://DealerSpecialties.com/" forKey:@"DealerSpecialties"];

	NSString *dResult = [self fOFP:@"//DealerSpecialties:Result" fromNode:xdoc withNameSpace:ns andDefault:nil];
	if ([dResult isEqualToString:@"Success" ])
	{
		for(CXMLNode *dlr in [xdoc nodesForXPath:@"//DealerSpecialties:DealerBasicInfo" namespaceMappings:ns error:nil])
		{
			Dealer *dealer = [Dealer new];
		
			dealer.lotKey = [[self fOFP:@"DealerSpecialties:DealerLotKey" fromNode:dlr withNameSpace:ns andDefault:@"0"] intValue];
			dealer.name = [self fOFP:@"DealerSpecialties:DealerName" fromNode:dlr withNameSpace:ns andDefault:nil];

			[dealers addObject:dealer];
		}	
	} 

	[self.delegate GetDealersByTokenComplete:dealers dResult:dResult];
	if(![self clearConnection]) return;
}

//First Object For Path
- (NSString*) fOFP:(NSString*)path fromNode:(CXMLNode*)node withNameSpace:(NSDictionary*)ns andDefault:(NSString*)sdefault{
	NSArray* nodes = [node nodesForXPath:path namespaceMappings:ns error:nil];
	if([nodes count] > 0){
		NSString *value = [[[nodes objectAtIndex:0] stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
		if(value == nil || [value isEqualToString:@""]) 
			return sdefault;
		return value;
	}
	return sdefault;
}

- (void) cancel{
	if(conn){
		[conn cancel];
	}
}

- (BOOL) clearConnection{
	if(conn){
		[conn cancel];
		conn = nil;
	}
	
	Reachability *curReach = [Reachability reachabilityForInternetConnection];
	NetworkStatus netStatus = [curReach currentReachabilityStatus];
	
	if(netStatus == NotReachable)
	{
		[(appDelegate*)[UIApplication sharedApplication].delegate alertNoNetwork];
		return NO;
	}
	return YES;
}

#pragma mark NSURLConnection delegate methods
- (void) connection:(NSURLConnection *)urlconn didReceiveResponse:(NSURLResponse *)response {
    
	[mData setLength:0];
    statusCode = [((NSHTTPURLResponse *)response) statusCode];
    responseString=[[((NSHTTPURLResponse *)response) allHeaderFields] objectForKey:@"Response"] ;
}

- (void) connection:(NSURLConnection *)urlconn didReceiveData:(NSData *)data {
    [mData appendData:data];
}

- (void) connectionDidFinishLoading:(NSURLConnection *)urlconn {
     
    [UIApplication sharedApplication].idleTimerDisabled=NO;
    
    NSInteger reqValue=  [[requestRest objectForKey:@"reqtype"] intValue];
    
    
    if ((reqValue == 1)||(reqValue == 2)||(reqValue == 3)||(reqValue == 4)||(reqValue == 5)||(reqValue == 6)||(reqValue == 7)||(reqValue == 8)||(reqValue == 9) ||(reqValue == 11)||(reqValue == 12) ||(reqValue == 13)||(reqValue == 14) ||(reqValue == 15) ||(reqValue == 16) ||(reqValue == 19) ||(reqValue == 21)||(reqValue == 24) ||(reqValue == 26) ||(reqValue == 20)) {
        
        if (statusCode >= 400)
        {
            [urlconn cancel];  // stop connecting; no more delegate messages
           
            if(responseString)
            {
                [delegate alertUser:responseString title:@"Error"];
            }
            else
            [delegate alertUser:[NSString stringWithFormat:@"Server returned status code %d.",statusCode] title:@""@"Error"];
        }
        
        else
        {
        NSMutableDictionary *parsedDict = [self parseRecievedData];
         if(reqValue ==20)
            [delegate GetDealersVehicleHistoryByTokenComplete:dealerVehicleHistoryNew];
        else
        {
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:parsedDict,@"response",  self,@"WSHandler", 
       [requestRest objectForKey:@"reqtype"],@"resptype", nil];

      
        [delegate handleResponseForQuery:dic];
        }
        }
    }
    else if(reqValue == 10 ||(reqValue == 17)||(reqValue == 18) ||(reqValue == 23) ) {  // add new appraisal
        if (statusCode >= 400)
        {
            [urlconn cancel];  // stop connecting; no more delegate messages
            if(responseString)
            {
                [delegate alertUser:responseString title:@"Error"];
            }
            else
            [delegate alertUser:[NSString stringWithFormat:@"Server returned status code %d.",statusCode] title:@"Error"];
        }
        else
        {
        NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:contents,@"responseString",[requestRest objectForKey:@"reqtype"],@"resptype", nil];
         [delegate handleResponseForQuery:dic];
        }
    }
    else if((reqValue == 22) || (reqValue==25) )
    {
        if (statusCode >= 400)
        {
            [urlconn cancel];  // stop connecting; no more delegate messages
            if(responseString)
            {
                [delegate alertUser:responseString title:@"Error"];
            }
            else
            [delegate alertUser:[NSString stringWithFormat:@"Server returned status code %d.",statusCode] title:@""@"Error"];
        }
        else
        {
            NSMutableDictionary *parsedDict = [self parseRecievedJSONData];
   
            
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:parsedDict,@"response",  self,@"WSHandler", 
                                        [requestRest objectForKey:@"reqtype"],@"resptype", nil];
            [delegate handleResponseForQuery:dic];
        }
    }
    else if(reqValue == 27)
    {
        if (statusCode == 200)
        {
            NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:contents,@"responseString",[requestRest objectForKey:@"reqtype"],@"resptype", nil];
            [delegate handleResponseForQuery:dic];
        }
        else
        {
            [urlconn cancel];  // stop connecting; no more delegate messages
            if(responseString)
            {
                [delegate alertUser:responseString title:@"Error"];
            }
            else
                [delegate alertUser:[NSString stringWithFormat:@"Server returned status code %d.",statusCode] title:@""@"Error"];
        }
    }
    else if(reqValue == 28) // To check whether dealer has acccess to the Apprasial
    {
        if (statusCode == 200 || statusCode == 401)
        {
            NSString *contents ;
            if(statusCode == 200)
            {
                contents=@"Permission";
            }
            else
            {
                contents=@"NoPermission";
            }
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:contents,@"responseString",[requestRest objectForKey:@"reqtype"],@"resptype", nil];
            [delegate handleResponseForQuery:dic];
        }
        else
        {
            [urlconn cancel];  // stop connecting; no more delegate messages
            if(responseString)
            {
                [delegate alertUser:responseString title:@"Error"];
            }
            else
                [delegate alertUser:[NSString stringWithFormat:@"Server returned status code %d.",statusCode] title:@""@"Error"];
        }
    }
    else
    {
       objc_msgSend(self, complete);
    }
}

- (void) connection:(NSURLConnection*)urlconn didFailWithError:(NSError*)error{
    NSInteger reqValue=  [[requestRest objectForKey:@"reqtype"] intValue];
    if(reqValue)
         [delegate alertUser:[error localizedDescription]  title:@"Error"];
    else
        objc_msgSend(self, complete);
}

- (void) dealloc
{
	if(conn){
		[conn cancel];
		conn = nil;
	}

	mData = nil;
	
}


#pragma mark Rest Services implementation

-(void) initialize:(NSMutableDictionary*)sent {
    requestRest = [[NSMutableDictionary alloc] initWithDictionary:sent];
    delegate = [sent objectForKey:@"delegate"];
}

-(void) callWSWithQuery:(NSMutableDictionary *)req {

    [UIApplication sharedApplication].idleTimerDisabled=YES;
    NSString *dealerToken= [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];
   // NSString *dealerToken= @"d987272d-9309-49c5-943b-ff113254b967";
    
    NSString *dealerLotKey = [NSString stringWithFormat:@"%d",[[NSUserDefaults standardUserDefaults] integerForKey:kDefaultDealerLot] ];
    
    //NSString *dealerLotKey = @"162551";
    
    NSMutableURLRequest *theReq;
    
     NSInteger reqNum = [[requestRest objectForKey:@"reqtype"] intValue];
    switch (reqNum) {
        case 1:
        {
            NSDate *today=[[NSDate alloc]init];
            NSDate *lastMonth=[today dateByAddingTimeInterval:-(30 * 24 * 60 * 60)];
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            NSLocale *uslocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
            [formatter setLocale:uslocale];
            [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]];
            [formatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.ss"];
            NSURL *url = 
            [NSURL URLWithString:
             [[NSString stringWithFormat:
               @"%@%@?$filter=(Status eq 1) and (CreateDate ge datetime'%@') &$orderby=CreateDate desc",appraisalIdURL,dealerLotKey,[formatter stringFromDate:lastMonth]]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0"; 
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 2:
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerURL];
            szURL = [szURL stringByAppendingFormat:@"%@/%@",dealerLotKey,[requestRest objectForKey:@"appraisalid"]];
            NSURL *url = [NSURL URLWithString:szURL];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 3:
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerdetailsURL];
            szURL = [szURL stringByAppendingFormat:@"%@%@",@"Nada/Details/",[requestRest objectForKey:@"appraisalid"]];
            NSURL *url = [NSURL URLWithString:szURL];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 4:
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerdetailsURL];
            szURL = [szURL stringByAppendingFormat:@"%@/Details/%@",[requestRest objectForKey:@"providerType"],[requestRest objectForKey:@"appraisalid"]];
            NSURL *url = [NSURL URLWithString:szURL];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 5:
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerdetailsURL];
            szURL = [szURL stringByAppendingFormat:@"%@%@",@"Edmunds/Details/",[requestRest objectForKey:@"appraisalid"]];
            NSURL *url = [NSURL URLWithString:szURL];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 6:
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerdetailsURL];
            szURL = [szURL stringByAppendingFormat:@"%@%@",@"Galves/Details/",[requestRest objectForKey:@"appraisalid"]];
            NSURL *url = [NSURL URLWithString:szURL ];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 7:
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerdetailsURL];
            szURL = [szURL stringByAppendingFormat:@"%@%@",@"KelleyBlueBook/Details/",[requestRest objectForKey:@"appraisalid"]];
            NSURL *url = [NSURL URLWithString:szURL];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 8:   
         {
            NSString *szURL  = appraisalURL;
            szURL = [szURL stringByAppendingFormat:@"%@",[requestRest objectForKey:@"appraisalid"]];
             NSURL *url = [NSURL URLWithString:szURL ];
                          //[NSString stringWithFormat:szURL]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
             NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 9:  //competitive information 
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",appraisalURL];
             szURL = [szURL stringByAppendingFormat:@"%@/CompetitiveData/%@/%@",[requestRest objectForKey:@"appraisalid"],[requestRest objectForKey:@"marketradius"],[requestRest objectForKey:@"filtertype"]];
            NSURL *url = [NSURL URLWithString:
                          [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break; 
            case 10: //Add Appraisal
                {
                    NSInteger  AppraisalId = [[requestRest objectForKey:@"appraisalid"]intValue];
                    NSString *Status =[requestRest objectForKey:@"status"];
                    
                    NSString *Vin= [requestRest objectForKey:@"vin"];//@"1D4RD4GG0BC731974";
                    NSInteger Year= [[requestRest objectForKey:@"year"] intValue];//@"2000";
                    NSString *Make= [requestRest objectForKey:@"make"];//@"Honda";
                    NSString *Model= [requestRest objectForKey:@"model"];//@"Accord";
                    NSString *Trim= [requestRest objectForKey:@"trim"];//@"EX V6";
                    NSString *Style= [requestRest objectForKey:@"style"];//@"4 Dr EX V6 Sedan";
                    NSInteger Mileage=[[requestRest objectForKey:@"mileage"] intValue];//@"25000";
                    NSInteger TitianiumId= [[requestRest objectForKey:@"titaniumid"]intValue];//@"3261";
                    NSString *ColorExterior=[requestRest objectForKey:@"exteriorcolor"];//@"Blue";
                    NSString *ColorInterior= [requestRest objectForKey:@"interiorcolor"];//@"Grey";
                    NSString *Action =[requestRest objectForKey:@"action"];
                    NSMutableDictionary *jsonObject;
                    if([Action isEqualToString:@"add"]) {
                        jsonObject = [NSMutableDictionary dictionary];
                        [jsonObject setObject:[NSNumber numberWithInt:AppraisalId] forKey:@"AppraisalId"];
                        [jsonObject setObject:Status forKey:@"Status"];
                        [jsonObject setObject:Vin forKey:@"Vin"];
                        [jsonObject setObject:[NSNumber numberWithInt:Year] forKey:@"Year"];
                        [jsonObject setObject:Make forKey:@"Make"];
                        [jsonObject setObject:Model forKey:@"Model"];
                        [jsonObject setObject:Trim forKey:@"Trim"];
                        [jsonObject setObject:Style forKey:@"Style"];
                        [jsonObject setObject:[NSNumber numberWithInt:Mileage] forKey:@"Mileage"];
                        [jsonObject setObject:[NSNumber numberWithInt:TitianiumId] forKey:@"TitianiumKey"];
                        [jsonObject setObject:ColorExterior forKey:@"ColorExterior"];
                        [jsonObject setObject:ColorInterior forKey:@"ColorInterior"];
                    }
                    else
                    {
                        NSString *CustomerName=  [requestRest objectForKey:@"customer"];//@"First Save";
                        NSString *CustomerAddress= [requestRest objectForKey:@"customeraddress"];//@"1234 Somewhere";
                        NSString *CustomerCity= [requestRest objectForKey:@"city"];//@"Someplace";
                        NSString *CustomerState = [requestRest objectForKey:@"state"];//@"OH";
                        NSString *CustomerPostalCode= [requestRest objectForKey:@"zip"];//@"45036";
                        NSString *CustomerPhone= [requestRest objectForKey:@"phone"];//@"111-222-3333";
                        NSString *CustomerMobile= [requestRest objectForKey:@"mobile"];//@"444-555-6666";
                        NSString *CustomerEmail= [requestRest objectForKey:@"email"];//@"someone@somedomain.com";
                        NSInteger    AppraisedValue= [[requestRest objectForKey:@"appraisedvalue"]intValue];//@"12000";
                        NSInteger    ExpectedSalePrice=[[requestRest objectForKey:@"expectedsaleprice"]intValue];// @"13500";
                         NSString *   Notes=  [requestRest objectForKey:@"notes"];//@"Some note on this new appraisal.";
                         NSInteger   ProfitObjective= [[requestRest objectForKey:@"profitobjective"]intValue];//@"1000";
                        NSInteger    Reconditioning=[[ requestRest objectForKey:@"reconditioning"]intValue];//@"500";
                         NSString *SalesPerson= [requestRest objectForKey:@"salesperson"];//@"Some Salesperson";
                     
                        NSInteger DaysSupply= [[requestRest objectForKey:@"dayssupply"] intValue];//@"5";
                        NSInteger MarketAverageMilesage = [[requestRest objectForKey:@"marketaveragemileage"] intValue];//@"18500";
                        NSInteger MarketAveragePrice= [[requestRest objectForKey:@"marketaverageprice"] intValue];//@"11500";
                        NSInteger MarketSize= [ [requestRest objectForKey:@"marketsize"] intValue];//@"6";
                        NSInteger PriceRank= [[requestRest objectForKey:@"pricerank"] intValue];//@"2";
                        NSInteger RecommendedPrice= [[requestRest objectForKey:@"recommendedprice"]intValue];//@"2250";
                        
                   jsonObject = [NSMutableDictionary dictionary];
                    [jsonObject setObject:[NSNumber numberWithInt:AppraisalId] forKey:@"AppraisalId"];
                    [jsonObject setObject:Status forKey:@"Status"];
                    [jsonObject setObject:CustomerName forKey:@"CustomerName"];
                    [jsonObject setObject:CustomerAddress forKey:@"CustomerAddress"];
                    [jsonObject setObject:CustomerCity forKey:@"CustomerCity"];
                    [jsonObject setObject:CustomerState forKey:@"CustomerState"];
                    [jsonObject setObject:CustomerPostalCode forKey:@"CustomerPostalCode"];
                    [jsonObject setObject:CustomerPhone forKey:@"CustomerPhone"];
                    [jsonObject setObject:CustomerMobile forKey:@"CustomerMobile"];
                    [jsonObject setObject:CustomerEmail forKey:@"CustomerEmail"];
                    [jsonObject setObject:Vin forKey:@"Vin"];
                    [jsonObject setObject:[NSNumber numberWithInt:Year] forKey:@"Year"];
                    [jsonObject setObject:Make forKey:@"Make"];
                    [jsonObject setObject:Model forKey:@"Model"];
                    [jsonObject setObject:Trim forKey:@"Trim"];
                    [jsonObject setObject:Style forKey:@"Style"];
                    [jsonObject setObject:[NSNumber numberWithInt:Mileage] forKey:@"Mileage"];
                    [jsonObject setObject:[NSNumber numberWithInt:TitianiumId] forKey:@"TitianiumKey"];
                    [jsonObject setObject:ColorExterior forKey:@"ColorExterior"];
                    [jsonObject setObject:ColorInterior forKey:@"ColorInterior"];
                    [jsonObject setObject:[NSNumber numberWithInt:AppraisedValue]  forKey:@"AppraisedValue"];
                    [jsonObject setObject:[NSNumber numberWithInt:ExpectedSalePrice]  forKey:@"ExpectedSalePrice"];
                    [jsonObject setObject:Notes forKey:@"Notes"];
                    [jsonObject setObject:[NSNumber numberWithInt:ProfitObjective]  forKey:@"ProfitObjective"];
                    [jsonObject setObject:[NSNumber numberWithInt:Reconditioning]  forKey:@"Reconditioning"];
                    [jsonObject setObject:SalesPerson forKey:@"SalesPerson"];
                    [jsonObject setObject:[NSNumber numberWithInt:DaysSupply]  forKey:@"DaysSupply"];
                    [jsonObject setObject:[NSNumber numberWithInt:MarketAverageMilesage]  forKey:@"MarketAverageMilesage"];
                    [jsonObject setObject:[NSNumber numberWithInt:MarketAveragePrice]  forKey:@"MarketAveragePrice"];
                    [jsonObject setObject:[NSNumber numberWithInt:MarketSize]  forKey:@"MarketSize"];
                    [jsonObject setObject:[NSNumber numberWithInt:PriceRank]  forKey:@"PriceRank"];
                    [jsonObject setObject:[NSNumber numberWithInt:RecommendedPrice]  forKey:@"RecommendedPrice"];
                    }
                    NSString *jsonRequest = [jsonObject JSONRepresentation];
                    NSData *data = [NSData dataWithBytes:[jsonRequest UTF8String] length:[jsonRequest length]];
                    NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
                    NSString *strUrl=appraisalURL;
                    strUrl = [strUrl stringByAppendingFormat:@"%d/%@",AppraisalId,dealerLotKey];
                    NSURL *url = [NSURL URLWithString:strUrl];
                    theReq = [NSMutableURLRequest requestWithURL:url
                                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
                    [theReq setHTTPMethod:@"POST"];
                    [theReq setValue:@"application/text" forHTTPHeaderField:@"Accept"];
                    [theReq setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
                    [theReq setValue:[NSString stringWithFormat:@"%d", [data length]] forHTTPHeaderField:@"Content-Length"];
                    [theReq setValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
                    [theReq setValue:httpHeaderField forHTTPHeaderField:@"Host"];
                    [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
                    [theReq setHTTPBody:data];
                }
            break;
        case 11:
        {
            
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerURL];
            szURL = [szURL stringByAppendingFormat:@"%@/%@",dealerLotKey,[requestRest objectForKey:@"appraisalid"]];
            NSURL *url = [NSURL URLWithString:
                          [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 12:
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerdetailsURL];
            szURL = [szURL stringByAppendingFormat:@"%@/Years",[requestRest objectForKey:@"providerType"]];
            NSURL *url = [NSURL URLWithString:
                          [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;  
        case 13:
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerdetailsURL];
            szURL = [szURL stringByAppendingFormat:@"%@/Makes/",[requestRest objectForKey:@"providerType"]];
            szURL = [szURL stringByAppendingFormat:@"%@",[requestRest objectForKey:@"year"]];
            NSURL *url = [NSURL URLWithString:
                          [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;  
        case 14:
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerdetailsURL];
            szURL = [szURL stringByAppendingFormat:@"%@/Models/",[requestRest objectForKey:@"providerType"]];
            szURL = [szURL stringByAppendingFormat:@"%@/",[requestRest objectForKey:@"year"]];
            szURL = [szURL stringByAppendingFormat:@"%@",[requestRest objectForKey:@"make"]];
            NSURL *url = [NSURL URLWithString:[szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 15:
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerdetailsURL];
            szURL = [szURL stringByAppendingFormat:@"%@/Trims/",[requestRest objectForKey:@"providerType"]];
            szURL = [szURL stringByAppendingFormat:@"%@/",[requestRest objectForKey:@"year"]];
             szURL = [szURL stringByAppendingFormat:@"%@/",[requestRest objectForKey:@"make"]];
             szURL = [szURL stringByAppendingFormat:@"%@",[requestRest objectForKey:@"model"]];
            NSURL *url = [NSURL URLWithString:
                          [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 16: // To get List of Styles for the particular provider 
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerdetailsURL];
            szURL = [szURL stringByAppendingFormat:@"%@/Styles/",[requestRest objectForKey:@"providerType"]];
            szURL = [szURL stringByAppendingFormat:@"%@/",[requestRest objectForKey:@"year"]];
            szURL = [szURL stringByAppendingFormat:@"%@/",[[requestRest objectForKey:@"make"] stringByReplacingOccurrencesOfString:@"/" withString:@"|"]];
            szURL = [szURL stringByAppendingFormat:@"%@/",[[requestRest objectForKey:@"model"] stringByReplacingOccurrencesOfString:@"/" withString:@"|"]];
            szURL = [szURL stringByAppendingFormat:@"%@",[[requestRest objectForKey:@"trim"] stringByReplacingOccurrencesOfString:@"/" withString:@"|"]];
            NSURL *url = [NSURL URLWithString:
                          [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 17:
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",appraisalURL];
            szURL = [szURL stringByAppendingFormat:@"%@/CarFax",[requestRest objectForKey:@"appraisalid"]];
            NSURL *url = [NSURL URLWithString:szURL];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break; 
        case 18:
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",appraisalURL];
            szURL = [szURL stringByAppendingFormat:@"%@/AutoCheck",[requestRest objectForKey:@"appraisalid"]];
            NSURL *url = [NSURL URLWithString:szURL ];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;  
        case 19:
        {
            NSDate *today=[[NSDate alloc]init];
            NSDate *lastMonth=[today dateByAddingTimeInterval:-(30 * 24 * 60 * 60)];
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            NSLocale *uslocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
            [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]];
            [formatter setLocale:uslocale];
            [formatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.ss"];
            NSString * szURL  = appraisalIdURL;
           szURL = [szURL stringByAppendingFormat:@"%@?$filter=(((CustomerName ne null) and (substringof('%@',tolower(CustomerName)) eq true )) || (substringof('%@',tolower(Make)) eq true)) and (Status eq 1) and (CreateDate ge datetime'%@') &$orderby=CreateDate desc",dealerLotKey,[[requestRest objectForKey:@"filter"] lowercaseString],[[requestRest objectForKey:@"filter"] lowercaseString],[formatter stringFromDate:lastMonth]];
            NSURL *url = 
            [NSURL URLWithString:
             [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0"; 
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 20:
        {
            NSString * szURL  = dealerURL;
            szURL = [szURL stringByAppendingFormat:@"%@",dealerLotKey];
            NSURL *url = 
            [NSURL URLWithString:
             [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
             complete = @selector(parseRecievedData);
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0"; 
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 21:
        {
            NSString * szURL  = providerdetailsURL;
            szURL = [szURL stringByAppendingFormat:@"%@/%@",[requestRest objectForKey:@"providerType"],[requestRest objectForKey:@"vin"]];
            NSURL *url = 
            [NSURL URLWithString:
             [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0"; 
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 22:
        {
            NSString *VehicleValuationCondition= [requestRest objectForKey:@"vehicleValuationCondition"];//@"1234 Somewhere";
            if([VehicleValuationCondition isEqualToString:@"Extra Clean"])
                VehicleValuationCondition=@"ExtraClean";
            NSArray *selectedOptionNames=[req objectForKey:@"selectedOptionNames"];
            NSMutableDictionary *jsonObject;
            jsonObject = [NSMutableDictionary dictionary];
                NSString *optionNames=@"";
               if([selectedOptionNames count]>0)
               {
                   optionNames=[selectedOptionNames objectAtIndex:0];
                for(int optionNameIndex=1;optionNameIndex<[selectedOptionNames count];optionNameIndex++)
                {
                    optionNames=[NSString stringWithFormat:@"%@,%@",optionNames,[selectedOptionNames objectAtIndex:optionNameIndex]];
                 }
               }
                [jsonObject setObject:optionNames forKey:@"selectedOptionNames"];
             [jsonObject setObject:VehicleValuationCondition forKey:@"VehicleValuationCondition"];
     
            NSString *jsonRequest = [jsonObject JSONRepresentation];
            NSData *data = [NSData dataWithBytes:[jsonRequest UTF8String] length:[jsonRequest length]];
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            NSString * szURL  = providerdetailsURL;
            szURL = [szURL stringByAppendingFormat:@"%@/Details/%@/%@",[requestRest objectForKey:@"providerType"],[requestRest objectForKey:@"appraisalid"],[requestRest objectForKey:@"providerCode"]];
            NSURL *url = 
            [NSURL URLWithString:
             [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url
                                             cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
            [theReq setHTTPMethod:@"POST"];
            [theReq setValue:@"application/text" forHTTPHeaderField:@"Accept"];
            [theReq setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq setValue:[NSString stringWithFormat:@"%d", [data length]] forHTTPHeaderField:@"Content-Length"];
            [theReq setValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq setValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPBody:data];
        }
            break;
        case 23:
        {
            NSString * szURL  = appraisalURL;
            szURL = [szURL stringByAppendingFormat:@"%@/Vehicle",[requestRest objectForKey:@"appraisalid"]];
            NSURL *url = 
            [NSURL URLWithString:
             [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            NSString *msgLength = @"0";
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            theReq = [NSMutableURLRequest requestWithURL:url
                                             cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
            
            [theReq setHTTPMethod:@"POST"];
            [theReq setValue:@"application/text" forHTTPHeaderField:@"Accept"];
            [theReq setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq setValue: msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq setValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq setValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
        }
            break;  
        case 24: // To get Provider code for the particular provider vehicle
        {
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerdetailsURL];
            if([[requestRest objectForKey:@"providerType"] isEqualToString:@"BlackBook"] || [[requestRest objectForKey:@"providerType"] isEqualToString:@"Titanium"])
            {
            szURL = [szURL stringByAppendingFormat:@"%@/ProviderCode/%@/%@/%@/%@/%@/%@",[requestRest objectForKey:@"providerType"],dealerLotKey,[requestRest objectForKey:@"year"],[[requestRest objectForKey:@"make"] stringByReplacingOccurrencesOfString:@"/" withString:@"|"],[[requestRest objectForKey:@"model"] stringByReplacingOccurrencesOfString:@"/" withString:@"|"],[[requestRest objectForKey:@"trim"] stringByReplacingOccurrencesOfString:@"/" withString:@"|"],[[requestRest objectForKey:@"style"] stringByReplacingOccurrencesOfString:@"/" withString:@"|"]];
            }
            else
            {
               szURL = [szURL stringByAppendingFormat:@"%@/ProviderCode/%@/%@/%@/%@/%@",[requestRest objectForKey:@"providerType"],dealerLotKey,[requestRest objectForKey:@"year"],[[requestRest objectForKey:@"make"] stringByReplacingOccurrencesOfString:@"/" withString:@"|"],[[requestRest objectForKey:@"model"] stringByReplacingOccurrencesOfString:@"/" withString:@"|"],[[requestRest objectForKey:@"trim"] stringByReplacingOccurrencesOfString:@"/" withString:@"|"]]; 
            }
            NSURL *url = [NSURL URLWithString:[szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";    
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 25:
        {
            NSString * szURL  = appraisalURL;
            szURL = [szURL stringByAppendingFormat:@"%@/MarketInventory/%@/%@",[requestRest objectForKey:@"appraisalid"],[requestRest objectForKey:@"marketradius"],[requestRest objectForKey:@"filtertype"]];
            NSURL *url = 
            [NSURL URLWithString:
             [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            theReq = [NSMutableURLRequest requestWithURL:url
                                             cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
            NSData* data1=[[NSData alloc]init];
            [theReq setHTTPMethod:@"POST"];
            [theReq setValue:@"application/text" forHTTPHeaderField:@"Accept"];
            [theReq setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq setValue:[NSString stringWithFormat:@"%d", [data1 length]] forHTTPHeaderField:@"Content-Length"];
            [theReq setValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq setValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPBody:data1];            
        }
            break;
        case 26: // get providerCode and respective appraisalKey
        {
            lastVehicleMappedDate=[[NSDate alloc]init];
           vehicleMappingformatter = [[NSDateFormatter alloc] init];
            NSLocale *uslocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
            [vehicleMappingformatter setLocale:uslocale];
            [vehicleMappingformatter setTimeZone:[NSTimeZone timeZoneWithName:@"EST"]];
            [vehicleMappingformatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss.ss"];
            NSURL *url ;
            if(![[NSUserDefaults standardUserDefaults] stringForKey:kVehicleMappedDate])
            {
            url= 
            [NSURL URLWithString:
             [[NSString stringWithFormat:
               @"%@%@?$filter=(Status eq 1) and (CreateDate le datetime'%@')",appraisalIdURL,dealerLotKey,[vehicleMappingformatter stringFromDate:lastVehicleMappedDate]]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            }
            else
            {
                url = 
                [NSURL URLWithString:
                [[NSString stringWithFormat:
                @"%@%@?$filter=(Status eq 1) and (CreateDate ge datetime'%@') &$orderby=CreateDate desc",appraisalIdURL,dealerLotKey,[[NSUserDefaults standardUserDefaults] stringForKey:kVehicleMappedDate]]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            }
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0"; 
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
        case 27: // Change the status of an appraisal from Active to Deleted
        {
            NSString * szURL  = appraisalURL;
            szURL = [szURL stringByAppendingFormat:@"%@/Status/Deleted",[requestRest objectForKey:@"appraisalid"]];
            NSURL *url =
            [NSURL URLWithString:
             [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            NSMutableDictionary *jsonObject;
            jsonObject = [NSMutableDictionary dictionary];
            NSString *jsonRequest = [jsonObject JSONRepresentation];
            NSData *data = [NSData dataWithBytes:[jsonRequest UTF8String] length:[jsonRequest length]];
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            theReq = [NSMutableURLRequest requestWithURL:url
                                             cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:30.0];
            
            [theReq setHTTPMethod:@"POST"];
            [theReq setValue:@"application/text" forHTTPHeaderField:@"Accept"];
            [theReq setValue:@"application/json; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq setValue:[NSString stringWithFormat:@"%d", [data length]] forHTTPHeaderField:@"Content-Length"];
            [theReq setValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq setValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPBody:data];
        }
            break;
        case 28: // To check whether dealer has apprasial permission or not.
        {
            
            NSString * szURL  = @"";
            szURL = [szURL stringByAppendingFormat:@"%@",providerURL];
            szURL = [szURL stringByAppendingFormat:@"%@",dealerLotKey];
            NSURL *url = [NSURL URLWithString:
                          [szURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
            theReq = [NSMutableURLRequest requestWithURL:url];
            NSString *msgLength = @"0";
            NSString *userToken=[NSString stringWithFormat:@"Token %@",dealerToken];
            [theReq addValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
            [theReq addValue:@"Fiddler" forHTTPHeaderField:@"User-Agent"];
            [theReq addValue:httpHeaderField forHTTPHeaderField:@"Host"];
            [theReq addValue:msgLength forHTTPHeaderField:@"Content-Length"];
            [theReq addValue:userToken forHTTPHeaderField:@"Authorization"];
            [theReq setHTTPMethod:@"GET"];
        }
            break;
           default:
            break;
    }
    con = [[NSURLConnection alloc] initWithRequest:theReq delegate:self startImmediately:YES];
    if (con) {
        receivedData = [NSMutableData data];
    }
    else {
        NSLog(@"Connection Error!");
    }
}
/* Sehaswaran Mayilerum Changed the parseRecievedData method
 Appraisal Api EndPoints  Version: 201206081617
  a) AppraisalId to AppraisalKey
  b) TitianiumId to TitianiumKey
 */
-(NSMutableDictionary *) parseRecievedData 
{
   
    NSMutableDictionary *t = [[NSMutableDictionary alloc] init];
    NSError *error;
    GDataXMLDocument *doc = [[GDataXMLDocument alloc] initWithData:mData options:0 error:&error];
    if (doc == nil) {
        [delegate alertUser:@"Bad Response, Parse Error! Please try again." title:@"Error"];
        return nil; 
    }
    NSInteger reqValue=  [[requestRest objectForKey:@"reqtype"] intValue];
    switch (reqValue) {
        case 26:
        case 19:
        case 1:  // Appraisal List
        {    
                NSArray *appraisallist = [doc nodesForXPath:@"//ArrayOfAppraisal/Appraisal" error:nil];
                    NSMutableArray *data = [[NSMutableArray alloc] init];
                    
                    for (GDataXMLElement *n in appraisallist) {
                        
                        
                        NSDictionary *elem = [[NSDictionary alloc] initWithObjectsAndKeys:[[n elementsForName:@"AppraisalKey"] count] ?                                                             [[[n elementsForName:@"AppraisalKey"] objectAtIndex:0] stringValue]:@"",@"appraisalid", 
                                              [[n elementsForName:@"Status"] count] ? [[[n elementsForName:@"Status"] objectAtIndex:0] stringValue]:@"",@"status", 
                                              [[n elementsForName:@"Year"] count] ? [[[n elementsForName:@"Year"] objectAtIndex:0] stringValue]:@"",@"year", 
                                              [[n elementsForName:@"Make"] count] ? [[[n elementsForName:@"Make"] objectAtIndex:0] stringValue]:@"",@"make", 
                                              [[n elementsForName:@"Model"] count] ? [[[n elementsForName:@"Model"] objectAtIndex:0] stringValue]:@"",@"model", 
                                              [[n elementsForName:@"Style"] count] ? [[[n elementsForName:@"Style"] objectAtIndex:0] stringValue]:@"",@"style", 
                                              [[n elementsForName:@"Mileage"] count] ? [[[n elementsForName:@"Mileage"] objectAtIndex:0] stringValue]:@"",@"mileage", 
                                              [[n elementsForName:@"TitianiumKey"] count] ? [[[n elementsForName:@"TitianiumKey"] objectAtIndex:0] stringValue]:@"",@"titianiumid", 
                                              [[n elementsForName:@"AppraisedValue"] count] ? [[[n elementsForName:@"AppraisedValue"] objectAtIndex:0] stringValue]:@"",@"appraisedvalue",
                                              [[n elementsForName:@"Notes"] count] ? [[[n elementsForName:@"Notes"] objectAtIndex:0] stringValue]:@"",@"notes",
                                              [[n elementsForName:@"SalesPerson"] count] ? [[[n elementsForName:@"SalesPerson"] objectAtIndex:0] stringValue]:@"",@"salesperson",
                                              [[n elementsForName:@"ExpectedSalePrice"] count] ? [[[n elementsForName:@"ExpectedSalePrice"] objectAtIndex:0] stringValue]:@"",@"expectedsaleprice", 
                                              [[n elementsForName:@"Vin"] count] ? [[[n elementsForName:@"Vin"] objectAtIndex:0] stringValue]:@"",@"vin", 
                                              [[n elementsForName:@"ProfitObjective"] count] ? [[[n elementsForName:@"ProfitObjective"] objectAtIndex:0] stringValue]:@"",@"profitobjective", 
                                              [[n elementsForName:@"Reconditioning"] count] ? [[[n elementsForName:@"Reconditioning"] objectAtIndex:0] stringValue]:@"",@"reconditioning", 
                                              [[n elementsForName:@"DaysSupply"] count] ? [[[n elementsForName:@"DaysSupply"] objectAtIndex:0] stringValue]:@"",@"dayssupply", 
                                              [[n elementsForName:@"MarketAverageMilesage"] count] ? [[[n elementsForName:@"MarketAverageMilesage"] objectAtIndex:0] stringValue]:@"",@"marketaveragemilesage", 
                                              [[n elementsForName:@"MarketAveragePrice"] count] ? [[[n elementsForName:@"MarketAveragePrice"] objectAtIndex:0] stringValue]:@"",@"marketaverageprice", 
                                              [[n elementsForName:@"MarketSize"] count] ? [[[n elementsForName:@"MarketSize"] objectAtIndex:0] stringValue]:@"",@"marketsize", 
                                              [[n elementsForName:@"PriceRank"] count] ? [[[n elementsForName:@"PriceRank"] objectAtIndex:0] stringValue]:@"",@"pricerank", 
                                              [[n elementsForName:@"RecommendedPrice"] count] ? [[[n elementsForName:@"RecommendedPrice"] objectAtIndex:0] stringValue]:@"",@"recommendedprice",
                                              [[n elementsForName:@"CustomerName"] count] ? [[[n elementsForName:@"CustomerName"] objectAtIndex:0] stringValue]:@"",@"customername",
                                              [[n elementsForName:@"CustomerAddress"] count] ? [[[n elementsForName:@"CustomerAddress"] objectAtIndex:0] stringValue]:@"",@"address", 
                                              [[n elementsForName:@"CustomerCity"] count] ? [[[n elementsForName:@"CustomerCity"] objectAtIndex:0] stringValue]:@"",@"city",
                                              [[n elementsForName:@"CustomerState"] count] ? [[[n elementsForName:@"CustomerState"] objectAtIndex:0] stringValue]:@"",@"state",
                                              [[n elementsForName:@"CustomerPostalCode"] count] ? [[[n elementsForName:@"CustomerPostalCode"] objectAtIndex:0] stringValue]:@"",@"zip",
                                              [[n elementsForName:@"CustomerPhone"] count] ? [[[n elementsForName:@"CustomerPhone"] objectAtIndex:0] stringValue]:@"",@"phone",
                                              [[n elementsForName:@"CustomerMobile"] count] ? [[[n elementsForName:@"CustomerMobile"] objectAtIndex:0] stringValue]:@"",@"mobile",
                                              [[n elementsForName:@"CustomerEmail"] count] ? [[[n elementsForName:@"CustomerEmail"] objectAtIndex:0] stringValue]:@"",@"email",
                                              [[n elementsForName:@"ColorExterior"] count] ? [[[n elementsForName:@"ColorExterior"] objectAtIndex:0] stringValue]:@"",@"colorexterior",
                                              [[n elementsForName:@"ColorInterior"] count] ? [[[n elementsForName:@"ColorInterior"] objectAtIndex:0] stringValue]:@"",@"colorinterior",
                                              [[n elementsForName:@"Trim"] count] ? [[[n elementsForName:@"Trim"] objectAtIndex:0] stringValue]:@"",@"trim",
                                             
                                              nil];
                          [data addObject:elem]; 
                }
                [t setObject:data forKey:@"appraisals"];
                if(reqValue==26)
                {
                    [[NSUserDefaults standardUserDefaults] setObject:[vehicleMappingformatter stringFromDate:lastVehicleMappedDate] forKey:kVehicleMappedDate];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
        }       
            break;
            case 2:  //Providers
             {
            
                    NSArray *providerList = [doc nodesForXPath:@"//ArrayOfProviderSummary/ProviderSummary" error:nil];
                 
                    NSMutableArray *data = [[NSMutableArray alloc] init];
                    
                    
                    for (GDataXMLElement *n in providerList) {
                        NSDictionary *elem = [[NSDictionary alloc]init];
                        NSString *providertype=
                                              [[[n elementsForName:@"ProviderType"] objectAtIndex:0] stringValue];
                                              
                        NSArray *appraisalPricingList =  [n nodesForXPath:@"AppraisalPricing"error:nil];                        
                        for (GDataXMLElement *p in appraisalPricingList) {
                            
                            NSArray *pricingTypeList = [p nodesForXPath:@"PricingType"error:nil];    
                            for (GDataXMLElement *pT in pricingTypeList) {
                                
                                
                                NSString *priceDataName=                       [[pT elementsForName:@"PriceDataName"] count] ? [[[pT elementsForName:@"PriceDataName"] objectAtIndex:0] stringValue]:@"" ;
                                
                                NSString *basePrice=                      [[pT elementsForName:@"BasePrice"] count] ? [[[pT elementsForName:@"BasePrice"] objectAtIndex:0] stringValue]:@"" ;
                                
                             if([priceDataName isEqualToString:@"Retail"])
                                      elem = [NSDictionary dictionaryWithObjectsAndKeys:basePrice,@"basePrice",providertype,@"providerType",nil];
                                else if([priceDataName isEqualToString:@"Galves Trade In"] && [providertype isEqualToString:@"Galves"])
                                    elem = [NSDictionary dictionaryWithObjectsAndKeys:basePrice,@"basePrice",providertype,@"providerType",nil];

                                    
                            }

                        }
                        if(!([elem count]==0))
                        [data addObject:elem]; 
                    }
                    [t setObject:data forKey:@"dataproviders"];
                 break;
            } 
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        {     
            NSArray *providerList = [doc nodesForXPath:@"//ProviderDetail" error:nil];
            NSMutableArray *data = [[NSMutableArray alloc] init];
            
            for (GDataXMLElement *n in providerList) {
                NSDictionary *elem = [[NSDictionary alloc] initWithObjectsAndKeys:
                                      [[n elementsForName:@"ProviderType"] count] ? [[[n elementsForName:@"ProviderType"] objectAtIndex:0] stringValue]:@"",@"providertype",
                                      [[n elementsForName:@"Year"] count] ? [[[n elementsForName:@"Year"] objectAtIndex:0] stringValue]:@"",@"year",
                                      [[n elementsForName:@"Make"] count] ? [[[n elementsForName:@"Make"] objectAtIndex:0] stringValue]:@"",@"make", 
                                      [[n elementsForName:@"Model"] count] ? [[[n elementsForName:@"Model"] objectAtIndex:0] stringValue]:@"",@"model",
                                      [[n elementsForName:@"Style"] count] ? [[[n elementsForName:@"Style"] objectAtIndex:0] stringValue]:@"",@"style",
                                     [[n elementsForName:@"Trim"] count] ? [[[n elementsForName:@"Trim"] objectAtIndex:0] stringValue]:@"",@"trim",
                                      [[n elementsForName:@"Mileage"] count] ? [[[n elementsForName:@"Mileage"] objectAtIndex:0] stringValue]:@"",@"mileage",
                                       [[n elementsForName:@"ProviderCode"] count] ? [[[n elementsForName:@"ProviderCode"] objectAtIndex:0] stringValue]:@"",@"providercode", 
                                      [[n elementsForName:@"VehicleAppraisalProviderKey"] count] ? [[[n elementsForName:@"VehicleAppraisalProviderKey"] objectAtIndex:0] stringValue]:@"",@"vehicleappraisalproviderkey",
                                      [[n elementsForName:@"VehicleAppraisalKey"] count] ? [[[n elementsForName:@"VehicleAppraisalKey"] objectAtIndex:0] stringValue]:@"",@"vehicleappraisalkey",
                                       [[n elementsForName:@"VehicleValuationCondition"] count] ? [[[n elementsForName:@"VehicleValuationCondition"] objectAtIndex:0] stringValue]:@"",@"vehiclevaluationcondition",
                                      
                                      nil];
                [data addObject:elem]; 
                
            }
            NSArray *providerList1 = [doc nodesForXPath:@"//ProviderDetail/VehicleOptions/VehicleOptionType" error:nil];
             NSMutableArray *data1 = [[NSMutableArray alloc] init];
            
            for (GDataXMLElement *n in providerList1) {
                NSDictionary *elem = [[NSDictionary alloc] initWithObjectsAndKeys:
                                      [[n elementsForName:@"OptionName"] count] ? [[[n elementsForName:@"OptionName"] objectAtIndex:0] stringValue]:@"",@"optionname",
                                      [[n elementsForName:@"IsIncluded"] count] ? [[[n elementsForName:@"IsIncluded"] objectAtIndex:0] stringValue]:@"",@"isincluded",
                                      
                                      
                                      nil];
                [data1 addObject:elem]; 
            }
            NSArray *vehicleConditionsList = [doc nodesForXPath:@"//ProviderDetail/VehicleConditions/VehicleValuationConditionType" error:nil];
            NSMutableArray *datavehicleConditions = [[NSMutableArray alloc] init];
            
            if(![vehicleConditionsList count]==0)
            {
                for (GDataXMLElement *n in vehicleConditionsList) {
                    
                    if([n.stringValue isEqualToString:@"ExtraClean"])
                        n.stringValue=@"Extra Clean";
                    [datavehicleConditions addObject:n.stringValue];
                    
                }
            }
            else {
                [datavehicleConditions addObject:@"n/a"];
            }

            [t setObject:datavehicleConditions forKey:@"dataproviderdetailnada2"];
            [t setObject:data1 forKey:@"dataproviderdetailnada1"];
           
                     [t setObject:data forKey:@"dataproviderdetailnada"];
            
        }
        break;
            
       case 8:
        {
            NSArray *appraisallist = [doc nodesForXPath:@"//Appraisal" error:nil];
            NSMutableArray *data = [[NSMutableArray alloc] init];
            
            for (GDataXMLElement *n in appraisallist) {
                NSDictionary *elem = [[NSDictionary alloc] initWithObjectsAndKeys:
                                      [[n elementsForName:@"AppraisalKey"] count] ?                                                             [[[n elementsForName:@"AppraisalKey"] objectAtIndex:0] stringValue]:@"",@"appraisalid", 
                                      [[n elementsForName:@"Status"] count] ? [[[n elementsForName:@"Status"] objectAtIndex:0] stringValue]:@"",@"status", 
                                      [[n elementsForName:@"Year"] count] ? [[[n elementsForName:@"Year"] objectAtIndex:0] stringValue]:@"",@"year", 
                                      [[n elementsForName:@"Make"] count] ? [[[n elementsForName:@"Make"] objectAtIndex:0] stringValue]:@"",@"make", 
                                      [[n elementsForName:@"Model"] count] ? [[[n elementsForName:@"Model"] objectAtIndex:0] stringValue]:@"",@"model", 
                                      [[n elementsForName:@"Style"] count] ? [[[n elementsForName:@"Style"] objectAtIndex:0] stringValue]:@"",@"style", 
                                      [[n elementsForName:@"Mileage"] count] ? [[[n elementsForName:@"Mileage"] objectAtIndex:0] stringValue]:@"",@"mileage", 
                                      [[n elementsForName:@"TitianiumKey"] count] ? [[[n elementsForName:@"TitianiumKey"] objectAtIndex:0] stringValue]:@"",@"titianiumid", 
                                      [[n elementsForName:@"AppraisedValue"] count] ? [[[n elementsForName:@"AppraisedValue"] objectAtIndex:0] stringValue]:@"",@"appraisedvalue",
                                      [[n elementsForName:@"Notes"] count] ? [[[n elementsForName:@"Notes"] objectAtIndex:0] stringValue]:@"",@"notes",
                                      [[n elementsForName:@"SalesPerson"] count] ? [[[n elementsForName:@"SalesPerson"] objectAtIndex:0] stringValue]:@"",@"salesperson",
                                      [[n elementsForName:@"ExpectedSalePrice"] count] ? [[[n elementsForName:@"ExpectedSalePrice"] objectAtIndex:0] stringValue]:@"",@"expectedsaleprice", 
                                      [[n elementsForName:@"Vin"] count] ? [[[n elementsForName:@"Vin"] objectAtIndex:0] stringValue]:@"",@"vin", 
                                      [[n elementsForName:@"ProfitObjective"] count] ? [[[n elementsForName:@"ProfitObjective"] objectAtIndex:0] stringValue]:@"",@"profitobjective", 
                                      [[n elementsForName:@"Reconditioning"] count] ? [[[n elementsForName:@"Reconditioning"] objectAtIndex:0] stringValue]:@"",@"reconditioning", 
                                      [[n elementsForName:@"DaysSupply"] count] ? [[[n elementsForName:@"DaysSupply"] objectAtIndex:0] stringValue]:@"",@"dayssupply", 
                                      [[n elementsForName:@"MarketAverageMilesage"] count] ? [[[n elementsForName:@"MarketAverageMilesage"] objectAtIndex:0] stringValue]:@"",@"marketaveragemilesage", 
                                      [[n elementsForName:@"MarketAveragePrice"] count] ? [[[n elementsForName:@"MarketAveragePrice"] objectAtIndex:0] stringValue]:@"",@"marketaverageprice", 
                                      [[n elementsForName:@"MarketSize"] count] ? [[[n elementsForName:@"MarketSize"] objectAtIndex:0] stringValue]:@"",@"marketsize", 
                                      [[n elementsForName:@"PriceRank"] count] ? [[[n elementsForName:@"PriceRank"] objectAtIndex:0] stringValue]:@"",@"pricerank", 
                                      [[n elementsForName:@"RecommendedPrice"] count] ? [[[n elementsForName:@"RecommendedPrice"] objectAtIndex:0] stringValue]:@"",@"recommendedprice",
                                      [[n elementsForName:@"CustomerName"] count] ? [[[n elementsForName:@"CustomerName"] objectAtIndex:0] stringValue]:@"",@"customername",
                                      [[n elementsForName:@"CustomerAddress"] count] ? [[[n elementsForName:@"CustomerAddress"] objectAtIndex:0] stringValue]:@"",@"address", 
                                      [[n elementsForName:@"CustomerCity"] count] ? [[[n elementsForName:@"CustomerCity"] objectAtIndex:0] stringValue]:@"",@"city",
                                      [[n elementsForName:@"CustomerState"] count] ? [[[n elementsForName:@"CustomerState"] objectAtIndex:0] stringValue]:@"",@"state",
                                      [[n elementsForName:@"CustomerPostalCode"] count] ? [[[n elementsForName:@"CustomerPostalCode"] objectAtIndex:0] stringValue]:@"",@"zip",
                                      [[n elementsForName:@"CustomerPhone"] count] ? [[[n elementsForName:@"CustomerPhone"] objectAtIndex:0] stringValue]:@"",@"phone",
                                      [[n elementsForName:@"CustomerMobile"] count] ? [[[n elementsForName:@"CustomerMobile"] objectAtIndex:0] stringValue]:@"",@"mobile",
                                      [[n elementsForName:@"CustomerEmail"] count] ? [[[n elementsForName:@"CustomerEmail"] objectAtIndex:0] stringValue]:@"",@"email",
                                      [[n elementsForName:@"ColorExterior"] count] ? [[[n elementsForName:@"ColorExterior"] objectAtIndex:0] stringValue]:@"",@"colorexterior",
                                      [[n elementsForName:@"ColorInterior"] count] ? [[[n elementsForName:@"ColorInterior"] objectAtIndex:0] stringValue]:@"",@"colorinterior",
                                      [[n elementsForName:@"Trim"] count] ? [[[n elementsForName:@"Trim"] objectAtIndex:0] stringValue]:@"",@"trim",
                                      
                                      nil];
                [data addObject:elem]; 
            }
            [t setObject:data forKey:@"appraisals"];
    }
            
            break;
        case 9:  //competitive information 
        {
            NSArray *appraisallist = [doc nodesForXPath:@"//ArrayOfCompetitiveData/CompetitiveData" error:nil];
            NSMutableArray *data = [[NSMutableArray alloc] init];
            
            for (GDataXMLElement *n in appraisallist) {
                NSDictionary *elem = [[NSDictionary alloc] initWithObjectsAndKeys:
                                     
                                  
                                      [[n elementsForName:@"Year"] count] ?  [[[n elementsForName:@"Year"] objectAtIndex:0] stringValue]:@"",@"year", 
                                      [[n elementsForName:@"Year"] count] ? [[[n elementsForName:@"Make"] objectAtIndex:0] stringValue]:@"",@"make", 
                                      [[n elementsForName:@"Model"] count] ? [[[n elementsForName:@"Model"] objectAtIndex:0] stringValue]:@"",@"model", 
                                      [[n elementsForName:@"Trim"] count] ? [[[n elementsForName:@"Trim"] objectAtIndex:0] stringValue]:@"",@"trim",
                                      [[n elementsForName:@"Age"] count] ? [[[n elementsForName:@"Age"] objectAtIndex:0] stringValue]:@"",@"age", 
                                      [[n elementsForName:@"DealerName"] count] ? [[[n elementsForName:@"DealerName"] objectAtIndex:0] stringValue]:@"",@"dealername", 
                                      [[n elementsForName:@"Distance"] count] ? [[[n elementsForName:@"Distance"] objectAtIndex:0] stringValue]:@"",@"distance", 
                                      [[n elementsForName:@"Mileage"] count] ?  [[[n elementsForName:@"Mileage"] objectAtIndex:0] stringValue]:@"",@"mileage",
                                      [[n elementsForName:@"Price"] count] ? [[[n elementsForName:@"Price"] objectAtIndex:0] stringValue]:@"",@"price",
                                      [[n elementsForName:@"Vin"] count] ? [[[n elementsForName:@"Vin"] objectAtIndex:0] stringValue]:@"",@"vin", 
                                    
                                                                            
                                      nil];
                
                [data addObject:elem]; 
            }
            [t setObject:data forKey:@"competitiveinfo"];
           }       
            break;   
            
        case 10:  //Add Appraisal  
            
          {
            NSArray *appraisallist = [doc nodesForXPath:@"//ArrayOfAppraisal/Appraisal" error:nil];
            NSMutableArray *data = [[NSMutableArray alloc] init];
            

            for (GDataXMLElement *n in appraisallist) {
            }
                 [t setObject:data forKey:@"appraisals"];
            }
            break;    
        case  11:  //Providers
        {
            
            NSArray *providerList = [doc nodesForXPath:@"//ArrayOfProviderSummary/ProviderSummary" error:nil];
            NSMutableArray *data = [[NSMutableArray alloc] init];
            
            for (GDataXMLElement *n in providerList) {
                NSDictionary *elem = [[NSDictionary alloc] initWithObjectsAndKeys:
                                      [[n elementsForName:@"ProviderType"] count] ? [[[n elementsForName:@"ProviderType"] objectAtIndex:0] stringValue]:@"",@"providertype",
                                      [[n elementsForName:@"Year"] count] ? [[[n elementsForName:@"Year"] objectAtIndex:0] stringValue]:@"",@"year", 
                                      [[n elementsForName:@"IsMapped"] count] ? [[[n elementsForName:@"IsMapped"] objectAtIndex:0] stringValue]:@"NO",@"ismapped",  
                                      
                                      nil];
                [data addObject:elem]; 
            }
            [t setObject:data forKey:@"dataproviders"];
            break;
        } 
        case 12:
        {
            NSArray *providerList = [doc nodesForXPath:@"//ArrayOfInt/int" error:nil];
            NSMutableArray *data = [[NSMutableArray alloc] init];
            if(![providerList count]==0)
            {
              
            for (GDataXMLElement *n in providerList) {
                               
                [data addObject:n.stringValue];
            }
             }

            NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:NO selector:@selector(localizedCompare:)];
            NSArray* sortedArray = [data sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            data=[[NSMutableArray alloc]initWithArray:sortedArray];
            
            [t setObject:data forKey:@"years"];
            
            break;
        } 
        case 13:
        {
            
            NSArray *providerList = [doc nodesForXPath:@"//ArrayOfString/string" error:nil];
            NSMutableArray *data = [[NSMutableArray alloc] init];
             if(![providerList count]==0)
            {
            for (GDataXMLElement *n in providerList) {
                
                 [data addObject:n.stringValue];
            }
           }
 
            NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
            NSArray* sortedArray = [data sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            data=[[NSMutableArray alloc]initWithArray:sortedArray];
            [t setObject:data forKey:@"makes"];
            break;
        } 
        case 14:
        {
            
            NSArray *providerList = [doc nodesForXPath:@"//ArrayOfString/string" error:nil];
            NSMutableArray *data = [[NSMutableArray alloc] init];
             if(![providerList count]==0)
            {
            for (GDataXMLElement *n in providerList) {
                
                [data addObject:n.stringValue];
            }
            }
            NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
            NSArray* sortedArray = [data sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            data=[[NSMutableArray alloc]initWithArray:sortedArray];
            [t setObject:data forKey:@"models"];
            break;
        } 
        case 15:
        {
            
            NSArray *providerList = [doc nodesForXPath:@"//ArrayOfString/string" error:nil];
            NSMutableArray *data = [[NSMutableArray alloc] init];
             if(![providerList count]==0)
            {
            for (GDataXMLElement *n in providerList) {
                
                [data addObject:n.stringValue];
            }
            }
            NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
            NSArray* sortedArray = [data sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            data=[[NSMutableArray alloc]initWithArray:sortedArray];
            [t setObject:data forKey:@"trims"];
            break;
        } 
        case 16:
        {
            NSArray *providerList = [doc nodesForXPath:@"//ArrayOfString/string" error:nil];
            NSMutableArray *data = [[NSMutableArray alloc] init];
            
             if(![providerList count]==0)
             {
            for (GDataXMLElement *n in providerList) {
                
                [data addObject:n.stringValue];
            }
            }
            NSSortDescriptor* sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES selector:@selector(localizedCompare:)];
            NSArray* sortedArray = [data sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
            data=[[NSMutableArray alloc]initWithArray:sortedArray];
            [t setObject:data forKey:@"styles"];
            break;
        } 
        case 20:
        {
            NSMutableArray *data = [[NSMutableArray alloc] init];
            
            NSArray *providerList = [doc nodesForXPath:@"//Dealer/hasCarFax" error:nil];
            
            dealerVehicleHistoryNew=[DealerVehicleHistory new];
            if(![providerList count]==0)
            {
                for (GDataXMLElement *n in providerList) {
                    
                    [data addObject:n.stringValue];
                    dealerVehicleHistoryNew.hasCarfax=[n.stringValue  boolValue];
                }
            }
            else {
                [data addObject:@"n/a"];
            }
            
            NSArray *providerList1 = [doc nodesForXPath:@"//Dealer/hasAutoCheck" error:nil];
            
            
            if(![providerList1 count]==0)
            {
                for (GDataXMLElement *n in providerList1) {
                    
                    [data addObject:n.stringValue];
                    dealerVehicleHistoryNew.hasAutoCheck=[n.stringValue  boolValue];
                }
            }
            else {
                [data addObject:@"n/a"];
            }

            
            [t setObject:data forKey:@"vehicleHistory"];
            break;

        }
        case 21:  //Providers
        {
            
            NSArray *providerList = [doc nodesForXPath:@"//ProviderSummary" error:nil];
            
            NSMutableArray *data = [[NSMutableArray alloc] init];
            
            
            for (GDataXMLElement *n in providerList) {
                NSDictionary *elem = [[NSDictionary alloc] initWithObjectsAndKeys:
                                      [[n elementsForName:@"ProviderType"] count] ?  [[[n elementsForName:@"ProviderType"] objectAtIndex:0] stringValue]:@"",@"providertype",
                                      [[n elementsForName:@"Year"] count] ? [[[n elementsForName:@"Year"] objectAtIndex:0] stringValue]:@"",@"year",
                                      [[n elementsForName:@"IsMapped"] count] ?  [[[n elementsForName:@"IsMapped"] objectAtIndex:0] stringValue]:@"",@"ismapped" ,
                                      [[n elementsForName:@"Make"] count] ? [[[n elementsForName:@"Make"] objectAtIndex:0] stringValue]:@"",@"make",
                                      [[n elementsForName:@"Model"] count] ? [[[n elementsForName:@"Model"] objectAtIndex:0] stringValue]:@"",@"model" ,
                                       [[n elementsForName:@"Trim"] count] ? [[[n elementsForName:@"Trim"] objectAtIndex:0] stringValue]:@"",@"trim" ,
                                      [[n elementsForName:@"Style"] count] ? [[[n elementsForName:@"Style"] objectAtIndex:0] stringValue]:@"",@"style" ,
                                      [[n elementsForName:@"ProviderCode"] count] ? [[[n elementsForName:@"ProviderCode"] objectAtIndex:0] stringValue]:@"" ,@"providercode",nil];
                
                               
                    [data addObject:elem]; 
            }
            [t setObject:data forKey:@"dataproviders"];
            break;
        } 
        case 24:
        {
            
            NSArray *providerList = [doc nodesForXPath:@"/int" error:nil];
            NSMutableArray *data = [[NSMutableArray alloc] init];
            if(![providerList count]==0)
            {
                for (GDataXMLElement *n in providerList) {
                    [data addObject:n.stringValue];
                }
            }
            else {
                [data addObject:@"n/a"];
            }
            [t setObject:data forKey:@"providerCodes"];
            break;
        } 
        default:
            break;
      } //switch case end

  return t;
}

-(NSMutableDictionary*) parseRecievedJSONData
{
    
    NSDictionary  *vehicleValuationConditionType = [NSDictionary dictionaryWithObjectsAndKeys:@"Extra Clean"
                                                    ,@"0",@"Clean",@"1",
                                                    @"Average",@"2",
                                                    @"Rough",@"3",
                                                    nil];
    
    NSDictionary  *providerType = [NSDictionary dictionaryWithObjectsAndKeys:@"BlackBook"
                                                    ,@"1",@"Edmunds",@"256",
                                                    @"Galves",@"1024",
                                                    @"KelleyBlueBook",@"2048",
                                   @"Nada",@"8",
                                   @"Titanium",@"32",
                                                    nil];
    
    
    NSMutableDictionary *t = [[NSMutableDictionary alloc] init];
  
    NSString *responseJSONString = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];  
      
    
    NSDictionary *json = [responseJSONString JSONValue];  
    
    NSMutableArray *data = [[NSMutableArray alloc] init];
    
    
    NSInteger reqValue=  [[requestRest objectForKey:@"reqtype"] intValue];


    switch (reqValue) {
        case 22:
        {
            NSDictionary *elem = [[NSDictionary alloc] initWithObjectsAndKeys:
                                  [providerType objectForKey:[[json objectForKey:@"ProviderType"] stringValue]],@"providertype",
                                  [[json objectForKey:@"Year"] stringValue],@"year",
                                  [json objectForKey:@"Make"]== [NSNull null] ? @"":[json objectForKey:@"Make"],@"make",
                                  [json objectForKey:@"Model"] == [NSNull null] ? @"":[json objectForKey:@"Model"],@"model" ,
                                  [json objectForKey:@"Style"]== [NSNull null] ? @"":[json objectForKey:@"Style"],@"style",
                                  [[json objectForKey:@"Mileage"] stringValue],@"mileage",
                                  [json objectForKey:@"ProviderCode"]== [NSNull null] ? @"":[json objectForKey:@"ProviderCode"],@"providercode", 
                                  [[json objectForKey:@"VehicleAppraisalProviderKey"] stringValue],@"vehicleappraisalproviderkey",
                                  [[json objectForKey:@"VehicleAppraisalKey"] stringValue],@"vehicleappraisalkey",
                                  [vehicleValuationConditionType objectForKey:[[json objectForKey:@"VehicleValuationCondition"] stringValue]] ,@"vehiclevaluationcondition",
                                   [json objectForKey:@"Trim"] == [NSNull null] ? @"":[json objectForKey:@"Trim"],@"trim",
                                nil];
            
            
            [data addObject:elem]; 
            
            NSArray *vehicleConditionlist=[json objectForKey:@"VehicleConditions"];
            NSMutableArray *datavehicleConditions = [[NSMutableArray alloc] init];
            if(![vehicleConditionlist count]==0)
            {
            for(int i=0;i<[vehicleConditionlist count];i++)
            {
                [datavehicleConditions addObject:[vehicleValuationConditionType objectForKey:[[vehicleConditionlist objectAtIndex:i] stringValue]]];
            }
            }
            else
                [datavehicleConditions addObject:@"n/a"];
            
             NSMutableArray *data1 = [[NSMutableArray alloc] init];
            
            NSArray *vehicleOptionlist=[json objectForKey:@"VehicleOptions"];
            

                for(int i=0;i<[vehicleOptionlist count];i++)
                {
                    NSDictionary *vehicleOption=[vehicleOptionlist objectAtIndex:i];
                                            
                    NSDictionary *elem = [[NSDictionary alloc] initWithObjectsAndKeys:
                                              [vehicleOption objectForKey:@"OptionName"] == [NSNull null] ? @"":[vehicleOption objectForKey:@"OptionName"] ,@"optionname",
                                              [[vehicleOption objectForKey:@"IsIncluded"] stringValue],@"isincluded",
                                               nil];
                        [data1 addObject:elem]; 
                }
            [t setObject:datavehicleConditions forKey:@"dataproviderdetailnada2"];
            [t setObject:data1 forKey:@"dataproviderdetailnada1"];
            
            [t setObject:data forKey:@"dataproviderdetailnada"];
            
        }
            break;
        case 25:
        {
    NSDictionary *elem = [[NSDictionary alloc] initWithObjectsAndKeys:[[json objectForKey:@"AppraisalKey"] stringValue] ,@"appraisalid",[json objectForKey:@"Status"] == [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"Status"]] ,@"status",[[json objectForKey:@"Year"] stringValue],@"year",[json objectForKey:@"Make"]== [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"Make"]],@"make",[json objectForKey:@"Model"] == [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"Model"]],@"model" ,[json objectForKey:@"Style"]== [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"Style"]],@"style",[[json objectForKey:@"Mileage"] stringValue],@"mileage",[[json objectForKey:@"TitianiumKey"] stringValue],@"titianiumid", [[json objectForKey:@"AppraisedValue"] stringValue],@"appraisedvalue",
                          [json objectForKey:@"Notes"] == [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"Notes"]],@"notes",
                          [json objectForKey:@"SalesPerson"]== [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"SalesPerson"]],@"salesperson",
                          [[json objectForKey:@"ExpectedSalePrice"] stringValue],@"expectedsaleprice", 
                          [json objectForKey:@"Vin"]== [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"Vin"]],@"vin", 
                          [[json objectForKey:@"ProfitObjective"] stringValue],@"profitobjective", 
                          [[json objectForKey:@"Reconditioning"] stringValue],@"reconditioning", 
                          [[json objectForKey:@"DaysSupply"] stringValue],@"dayssupply", 
                          [[json objectForKey:@"MarketAverageMilesage"] stringValue],@"marketaveragemilesage", 
                          [[json objectForKey:@"MarketAveragePrice"] stringValue],@"marketaverageprice", 
                          [[json objectForKey:@"MarketSize"] stringValue],@"marketsize", 
                          [[json objectForKey:@"PriceRank"] stringValue],@"pricerank", 
                          [[json objectForKey:@"RecommendedPrice"] stringValue],@"recommendedprice",
                          [json objectForKey:@"CustomerName"]== [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"CustomerName"]],@"customername",
                          [json objectForKey:@"CustomerAddress"] == [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"CustomerAddress"]],@"address", 
                          [json objectForKey:@"CustomerCity"] == [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"CustomerCity"]],@"city",
                          [json objectForKey:@"CustomerState"] == [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"CustomerState"]],@"state",
                          [json objectForKey:@"CustomerPostalCode"]== [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"CustomerPostalCode"]],@"zip",
                          [json objectForKey:@"CustomerPhone"]== [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"CustomerPhone"]],@"phone",
                          [json objectForKey:@"CustomerMobile"]== [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"CustomerMobile"]],@"mobile",
                          [json objectForKey:@"CustomerEmail"]== [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"CustomerEmail"]],@"email",
                          [json objectForKey:@"ColorExterior"]== [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"ColorExterior"]],@"colorexterior",
                          [json objectForKey:@"ColorInterior"]== [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"ColorInterior"]],@"colorinterior",
                          [json objectForKey:@"Trim"]== [NSNull null] ? @"":[NSString stringWithFormat:@"%@",[json objectForKey:@"Trim"]],@"trim",
                          nil];
    
    
         [data addObject:elem]; 
    
    [t setObject:data forKey:@"appraisals"];
        }
        break;
            
        default:
            break;
    } //switch case end

    return t;
}
//---when the start of an element is found---
-(void) parser:(NSXMLParser *) parser didStartElement:(NSString *) elementName
  namespaceURI:(NSString *) namespaceURI qualifiedName:(NSString *) qName
    attributes:(NSDictionary *) attributeDict {
    if ([elementName isEqualToString:matchingElement])
    { if (!soapResults) {
        soapResults = [[NSMutableString alloc] init]; elementFound = YES;
    }
    }
}
        //---when the text of an element is found---
        
-(void)parser:(NSXMLParser *) parser foundCharacters:(NSString *)string {
      if (elementFound) 
      {
        [soapResults appendString: string];
      }
}

//---when the end of element is found---
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName
 namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    
}
- (void)parserDidEndDocument:(NSXMLParser *)parser {
    if (soapResults) {
        soapResults = nil;
    }
    
}
- (void)	parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError {
    
   
    if (soapResults) { 
        soapResults = nil;
    }

}
@end
