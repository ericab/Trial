//
//  AppraisalVehicleDetailsController.h
//  IVM
//
//  Created by Raja Sekhar Nerella on 16/05/12.
//  
//

#import <UIKit/UIKit.h>

@interface AppraisalVehicleDetailsController : UIViewController<UITextFieldDelegate>
{
     UIScrollView		*scrollView;
     UITextField        *txt_vin;
     UITextField        *txt_year;
     UITextField        *txt_make;
     UITextField        *txt_model;
    UITextField        *txt_trim;
     UITextField        *txt_style;
     UITextField        *txt_mileage;
     UITextField        *txt_exteriorcolor;
     UITextField        *txt_interiorcolor;
    
     @public NSString        *str_vin;
     @public NSString        *str_year;
     @public NSString        *str_make;
     @public NSString        *str_model;
    @public NSString        *str_trim;
     @public NSString        *str_style;
     @public NSString        *str_mileage;
     @public NSString        *str_exteriorcolor;
     @public NSString        *str_interiorcolor;
}
@end
