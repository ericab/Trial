//
//  AnalyzerController.h
//  GetAuto.com
//
//  Created by Shaofeng Tu on 06/09/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"

@interface AnalyzerController : UIViewController<UITextFieldDelegate, UIPickerViewDelegate, ItemRestore> {
}

- (void)analyzerError:(id)sender;

@end
