//
//  DecodeData.h
//  GetAuto.com
//
//  Created by Shaofeng Tu on 7/12/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface DecodeData : NSObject {
	int			year;
	NSString	*make;
	NSString	*model;
	NSArray		*trims;
	NSString	*vin;
}

@property(assign)	int			year;
@property(copy)		NSString	*make;
@property(copy)		NSString	*model;
@property(strong)	NSArray		*trims;
@property(copy)		NSString	*vin;

@end
