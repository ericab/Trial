//
//  Dealer.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/19/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "Dealer.h"


@implementation Dealer

@synthesize		lotKey;
@synthesize		name;
/*
@synthesize		address;
@synthesize		address2;
@synthesize		city;
@synthesize		comments;
@synthesize		contactName;
@synthesize		state;
@synthesize		zip;
@synthesize		fax;
@synthesize		photos;
@synthesize		email;
@synthesize		phone;
@synthesize		webSite;
*/
//@synthesize		result;
//@synthesize		execeptionText;


@end
