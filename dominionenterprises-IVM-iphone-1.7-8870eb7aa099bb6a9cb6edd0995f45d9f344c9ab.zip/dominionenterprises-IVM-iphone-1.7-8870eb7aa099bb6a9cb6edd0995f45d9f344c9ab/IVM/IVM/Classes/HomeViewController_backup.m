//
//  HomeViewController.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 1/28/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "HomeViewController.h"
#import "SearchResultsController.h"
#import "AdvancedSearchController.h"
#import <QuartzCore/CoreAnimation.h>
#import "appDelegate.h"
#import <objc/runtime.h>
#import "IVM.h"
#import "AddToInventoryController.h"
#import "AnalyzerController.h"
#import "LoginViewController.h"

@implementation HomeViewController

- (id) init
{
	self = [super init];
	if (self != nil) {
		[appDelegate track:@"Home"];

//		checkboxSelected = [[NSUserDefaults standardUserDefaults] boolForKey:kKeepLoggedIn];

//		self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Logout" style:UIBarButtonItemStyleBordered  target:self action:@selector(logoutButton:)] autorelease];
//		self.navigationItem.rightBarButtonItem.enabled = YES;
	}
	return self;
}


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	float yOffset = 150.0f;
	
	UIView *vw = [[UIView alloc] initWithFrame:CGRectZero];
//	vw.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
	vw.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
	self.view = vw;

	//Create header image
	UIImageView *header = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"logo.png"]];
	header.frame = CGRectMake(0.0f, 0.0f, 300.0f, yOffset);
	header.contentMode = UIViewContentModeScaleAspectFit;
//	CGRect cframe = CGRectMake(0.0f, 0.0f, 300.0f, yOffset);
//	cframe.origin.x = [UIScreen mainScreen].bounds.size.width / 2.0f - cframe.size.width / 2.0f;
//	header.frame = cframe;
	[self.view addSubview:header];
	
	//Create container for image to center
//	UIView *headerContainer = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, [UIScreen mainScreen].bounds.size.width, cframe.size.height)];
//	headerContainer.autoresizingMask =  UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
//	headerContainer.contentMode = UIViewContentModeCenter;
//	[headerContainer addSubview:header];
//	[self.view addSubview:headerContainer];


//	yOffset += 50.0f;

	UIButton	*tmpButton = [UIButton buttonWithType:UIButtonTypeCustom];
	tmpButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft; 
	tmpButton.layer.borderColor = [UIColor grayColor].CGColor;
	tmpButton.layer.borderWidth = 1.0;
	tmpButton.layer.cornerRadius = 10.0;
	[tmpButton setContentEdgeInsets:UIEdgeInsetsMake(0.0, 10.0, 0.0, 0.0)];
	[tmpButton setImage:[UIImage imageNamed:@"add_record.png"] forState:UIControlStateNormal];
	[tmpButton setTitle:@"Add to Inventory" forState:UIControlStateNormal];
	[tmpButton setTitleEdgeInsets:UIEdgeInsetsMake(0.0, 20.0, 0.0, 0.0)];
	[tmpButton setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
	[tmpButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	tmpButton.titleLabel.font = [UIFont systemFontOfSize: 20];
	[tmpButton setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted)  green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
	tmpButton.frame = CGRectMake(20.0f, yOffset, 280.0f, 40.0f);
	[tmpButton addTarget:self action:@selector(doFunctions:) forControlEvents:UIControlEventTouchUpInside];
	[tmpButton setTag:1];
	[self.view addSubview:tmpButton];
	
	yOffset += 60.0f;
	
	tmpButton = [UIButton buttonWithType:UIButtonTypeCustom];
	tmpButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft; 
	tmpButton.layer.borderColor = [UIColor grayColor].CGColor;
	tmpButton.layer.borderWidth = 1.0;
	tmpButton.layer.cornerRadius = 10.0;
	[tmpButton setContentEdgeInsets:UIEdgeInsetsMake(0.0, 10.0, 0.0, 0.0)];
	[tmpButton setImage:[UIImage imageNamed:@"find.png"] forState:UIControlStateNormal];
//	[tmpButton setTitle:@"Search Inventory" forState:UIControlStateNormal];
	[tmpButton setTitle:@"Search By Category" forState:UIControlStateNormal];
	[tmpButton setTitleEdgeInsets:UIEdgeInsetsMake(0.0, 20.0, 0.0, 0.0)];
	[tmpButton setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
	[tmpButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	tmpButton.titleLabel.font = [UIFont systemFontOfSize: 20];
	[tmpButton setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted)  green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
	tmpButton.frame = CGRectMake(20.0f, yOffset, 280.0f, 40.0f);
	[tmpButton addTarget:self action:@selector(doFunctions:) forControlEvents:UIControlEventTouchUpInside];
	[tmpButton setTag:2];
	[self.view addSubview:tmpButton];
/*
	yOffset += 50.0f;
	
	tmpButton = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
	tmpButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft; 
	tmpButton.layer.borderColor = [UIColor grayColor].CGColor;
	tmpButton.layer.borderWidth = 1.0;
	tmpButton.layer.cornerRadius = 10.0;
	[tmpButton setContentEdgeInsets:UIEdgeInsetsMake(0.0, 10.0, 0.0, 0.0)];
	[tmpButton setImage:[UIImage imageNamed:@"pricing-a-car.png"] forState:UIControlStateNormal];
	[tmpButton setTitle:@"Analyzer" forState:UIControlStateNormal];
	[tmpButton setTitleEdgeInsets:UIEdgeInsetsMake(0.0, 20.0, 0.0, 0.0)];
	[tmpButton setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
	[tmpButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	tmpButton.titleLabel.font = [UIFont systemFontOfSize: 20];
	[tmpButton setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted)  green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
	tmpButton.frame = CGRectMake(20.0f, yOffset, 280.0f, 40.0f);
	[tmpButton addTarget:self action:@selector(doFunctions:) forControlEvents:UIControlEventTouchUpInside];
	[tmpButton setTag:3];
	[self.view addSubview:tmpButton];
	[tmpButton release];
*/
//	[self.view addSubview:tbl];
//	[tbl release];
/*	
	settingsLayout = [[UIView alloc] initWithFrame:CGRectZero];
	settingsLayout.frame = CGRectMake(0.0f, -40.0f, 320.0f, 40.0f);
//	settingsLayout.backgroundColor = [UIColor clearColor];
	settingsLayout.backgroundColor = [UIColor lightGrayColor];
	[self.view addSubview:settingsLayout];
	
	btn_checkbox = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
	[btn_checkbox setBackgroundImage:[UIImage imageNamed:@"checkbox.png"] forState:UIControlStateNormal];
	[btn_checkbox setBackgroundImage:[UIImage imageNamed:@"checkbox-pressed.png"] forState:UIControlStateHighlighted];
	[btn_checkbox setBackgroundImage:[UIImage imageNamed:@"checkbox-checked.png"] forState:UIControlStateSelected];
	btn_checkbox.frame = CGRectMake(20.0f, 10.0f, 20.0f, 20.0f);
	[btn_checkbox addTarget:self action:@selector(checkboxButton:) forControlEvents:UIControlEventTouchUpInside];
	[settingsLayout addSubview:btn_checkbox];
	
	UILabel *tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(50.0f, 10.0f, 150.0f, 20.0)];
	tmpLabel.textColor = [UIColor blackColor];
	tmpLabel.backgroundColor = [UIColor clearColor];
	tmpLabel.text = @"Log me out";
	[settingsLayout addSubview:tmpLabel];
	[tmpLabel release];
	
	
	UIButton	*btn_close = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
	[btn_close setBackgroundImage:[UIImage imageNamed:@"close.png"] forState:UIControlStateNormal];
	btn_close.frame = CGRectMake(280.0f, 10.0f, 25.0f, 25.0f);
	[btn_close addTarget:self action:@selector(settingsClose:) forControlEvents:UIControlEventTouchUpInside];
	[settingsLayout addSubview:btn_close];
	[btn_close release];

	if (checkboxSelected) {
		[btn_checkbox setSelected:NO];
	} else {
		[btn_checkbox setSelected:YES];
	}
*/
	
	self.navigationItem.title = @"Home";
}


- (void)viewWillAppear:(BOOL)animated
{
	//Enable the Right Navigator Button
	checkboxSelected = [[NSUserDefaults standardUserDefaults] boolForKey:kKeepLoggedIn];
	if (checkboxSelected) {
		if (self.navigationItem.rightBarButtonItem == nil) {
			self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Logout" style:UIBarButtonItemStyleBordered  target:self action:@selector(logoutButton:)];
		}
	}
}


- (void) performSearch:(VehicleSearchObject*)vso{
	SearchResultsController *searchController = [SearchResultsController new];
	[[self navigationController] pushViewController:searchController animated:YES];
	[searchController startSearch:vso];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (NSArray*)getRestoreData{
	//Create an array of child view controllers
	NSMutableArray *children = [NSMutableArray array];
	for(int i = [self.navigationController.viewControllers indexOfObject:self] + 1; i < [self.navigationController.viewControllers count]; i++)
	{
		UIViewController *vc = [self.navigationController.viewControllers objectAtIndex:i];
		//Store the information for the child in the array
		if([vc conformsToProtocol:@protocol(ItemRestore)])
			[children addObject:[NSDictionary dictionaryWithObject:[vc performSelector:@selector(getRestoreData)] forKey:NSStringFromClass([vc class])]];
	}
	return children;
}

- (void)restore:(NSArray*)data{
	//Loop through child data
	for(NSDictionary* child_data in data)
	{
		if([[child_data allKeys] count] < 1) continue;
		NSString *clss = [[child_data allKeys] objectAtIndex:0];
		//Create a class from the key
		Class controller = [[NSBundle mainBundle] classNamed:clss];
		//Make sure the class is the correct type
		if(class_conformsToProtocol(controller, @protocol(ItemRestore)))
		{
			id<ItemRestore> tmp = [[controller alloc] initWithRestore:[child_data objectForKey:clss]];
			if([tmp isKindOfClass:[UIViewController class]])
				[self.navigationController pushViewController:(UIViewController*)tmp animated:NO];
		}
	}
}

- (void)doFunctions:(id)sender{
	AdvancedSearchController *advancedSearch = nil;
	AddToInventoryController *addinventory = nil;
	AnalyzerController *analyzer = nil;

    int t = [sender tag];  // not getTag
	
	switch (t) {
		case 1:
			addinventory = [AddToInventoryController new];
			[self.navigationController pushViewController:addinventory animated:YES];
			break;
		case 2:
			advancedSearch = [AdvancedSearchController new];
			[[self navigationController] pushViewController:advancedSearch animated:YES];
			break;
		case 3:
			analyzer = [AnalyzerController new];
//			[[self navigationController] pushViewController:analyzer animated:YES];
			
			;UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil
																 message:@"Coming Soon ..."
																delegate:nil
													   cancelButtonTitle:@"Ok"
													   otherButtonTitles:nil];
			
			[alertView show];
			
			break;
	}
}


- (void)logoutButton:(id)sender{
/*	self.navigationItem.rightBarButtonItem.enabled = NO;

	[UIView beginAnimations:nil context:NULL];
	settingsLayout.transform = CGAffineTransformTranslate(settingsLayout.transform, 0.0, 40.0);
	[UIView commitAnimations];
*/

	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Confirm Logout"
														message:@"Are you sure want to logout?"
													   delegate:self
											  cancelButtonTitle:@"NO"
											  otherButtonTitles:nil];
	
	[alertView addButtonWithTitle:@"YES"];
	[alertView show];

/*
	//Reset the KeepLoggedIn setting
	checkboxSelected = NO;
	[[NSUserDefaults standardUserDefaults] setBool:checkboxSelected forKey:kKeepLoggedIn];
	[[NSUserDefaults standardUserDefaults] synchronize];

	LoginViewController* lvc = [LoginViewController new];

	[self presentModalViewController:lvc animated:NO];
*/
}

#pragma mark -
#pragma mark alertView methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex != alertView.cancelButtonIndex){

		//Delete the Current User Token
		[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserToken];
		[[NSUserDefaults standardUserDefaults] synchronize];
		
		//Display LoginView
		LoginViewController* lvc = [LoginViewController new];
		lvc.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
		
		[self presentModalViewController:lvc animated:YES];
    }
}  


@end
