//
//  NetImage.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/26/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//
/*
#import <UIKit/UIKit.h>

@class NetDataOperation;

@interface NetImageView : UIImageView  {
	NSURL				*imageURL;
	NSMutableDictionary	*cache;
	UIImage				*loadingImage;
	UIImage				*noImage;
@private	
	NSURL				*_realUrl;
	NetDataOperation	*_ndo;
}

@property(retain)	NSURL				*imageURL;
//Cache used to store images
@property(retain)	NSMutableDictionary	*cache;
@property(retain)	UIImage				*loadingImage;
@property(retain)	UIImage				*noImage;
//Statics
+ (id) netImageWithStringUrl:(NSString *)url andCache:(NSMutableDictionary*)inCache;
+ (UIImage*) imageForURL:(NSURL *)inURL withSize:(CGSize)inSize inCache:(NSDictionary*)inCache;
//Instance
- (id) initWithFrame:(CGRect)inFrame andUrl:(NSURL *)url andCache:(NSMutableDictionary*)inCache;

@end*/

#import <UIKit/UIKit.h>

@interface NetImageView : UIImageView  {
	NSURL				*imageURL;
	NSMutableDictionary	*cache;
	UIImage				*loadingImage;
	UIImage				*noImage;
@private	
	NSURL				*_realUrl;
	NSMutableData		*_imageData;
	NSURLConnection		*_con;
}

@property(strong)	NSURL				*imageURL;
//Cache used to store images
@property(strong)	NSMutableDictionary	*cache;
@property(strong)	UIImage				*loadingImage;
@property(strong)	UIImage				*noImage;
//Statics
+ (id) netImageWithStringUrl:(NSString *)url andCache:(NSMutableDictionary*)inCache;
+ (UIImage*) imageForURL:(NSURL *)inURL withSize:(CGSize)inSize inCache:(NSDictionary*)inCache;
//Instance
- (id) initWithFrame:(CGRect)inFrame andUrl:(NSURL *)url andCache:(NSMutableDictionary*)inCache;

@end