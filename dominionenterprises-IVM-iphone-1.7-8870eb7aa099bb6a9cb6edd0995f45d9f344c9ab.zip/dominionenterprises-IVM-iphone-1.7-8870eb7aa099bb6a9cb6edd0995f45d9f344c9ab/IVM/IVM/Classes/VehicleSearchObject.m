//
//  VehicleSearchObject.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/18/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "VehicleSearchObject.h"

@implementation VehicleSearchObject

@synthesize pk;
//@synthesize type;
//@synthesize	latitude;
//@synthesize	longitude;
//@synthesize zip;
//@synthesize	radius;
@synthesize	firstListing;
@synthesize	listingsPerPage;
@synthesize	make;
@synthesize	model;
@synthesize	dealerLot;
@synthesize	year;
@synthesize	minPrice;
@synthesize	maxPrice;
@synthesize	minMileage;
@synthesize	maxMileage;
@synthesize sortBy;

- (id) init
{
	self = [super init];
	if (self != nil) {
//		type = 1;//Default to vehicle
		firstListing = 1;
		listingsPerPage = 25;
//		radius = 10;
	}
	return self;
}

#pragma mark NSCoding Methods
- (id)initWithCoder:(NSCoder *)decoder{
	self = [super init];
	if(self != nil){
//		latitude = [[decoder decodeObjectForKey:@"lat"] floatValue];
//		longitude = [[decoder decodeObjectForKey:@"lon"] floatValue];
//		zip = [[decoder decodeObjectForKey:@"zip"] retain];
//		radius = [[decoder decodeObjectForKey:@"rad"] intValue];
		firstListing = [[decoder decodeObjectForKey:@"fl"] intValue];
		listingsPerPage = [[decoder decodeObjectForKey:@"lpp"] intValue];
		make = [decoder decodeObjectForKey:@"make"];
		model = [decoder decodeObjectForKey:@"model"];
		dealerLot = [[decoder decodeObjectForKey:@"dealerLot"] intValue];
		year = [[decoder decodeObjectForKey:@"year"] intValue];
		minPrice = [[decoder decodeObjectForKey:@"minP"] intValue];
		maxPrice = [[decoder decodeObjectForKey:@"maxP"] intValue];
		minMileage = [[decoder decodeObjectForKey:@"minM"] intValue];
		maxMileage = [[decoder decodeObjectForKey:@"maxM"] intValue];
		sortBy = [decoder decodeObjectForKey:@"sb"];
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder{
//	[encoder encodeObject:[NSNumber numberWithFloat:latitude]forKey:@"lat"];
//	[encoder encodeObject:[NSNumber numberWithFloat:longitude] forKey:@"lon"];
//	[encoder encodeObject:zip forKey:@"zip"];
//	[encoder encodeObject:[NSNumber numberWithInt:radius] forKey:@"rad"];
	[encoder encodeObject:[NSNumber numberWithInt:firstListing] forKey:@"fl"];
	[encoder encodeObject:[NSNumber numberWithInt:listingsPerPage] forKey:@"lpp"];
	[encoder encodeObject:make forKey:@"make"];
	[encoder encodeObject:model forKey:@"model"];
	[encoder encodeObject:[NSNumber numberWithInt:dealerLot] forKey:@"dealerLot"];
	[encoder encodeObject:[NSNumber numberWithInt:year] forKey:@"year"];
	[encoder encodeObject:[NSNumber numberWithInt:minPrice] forKey:@"minP"];
	[encoder encodeObject:[NSNumber numberWithInt:maxPrice] forKey:@"maxP"];
	[encoder encodeObject:[NSNumber numberWithInt:minMileage] forKey:@"minM"];
	[encoder encodeObject:[NSNumber numberWithInt:maxMileage] forKey:@"maxM"];
	[encoder encodeObject:sortBy forKey:@"sb"];
}

@end
