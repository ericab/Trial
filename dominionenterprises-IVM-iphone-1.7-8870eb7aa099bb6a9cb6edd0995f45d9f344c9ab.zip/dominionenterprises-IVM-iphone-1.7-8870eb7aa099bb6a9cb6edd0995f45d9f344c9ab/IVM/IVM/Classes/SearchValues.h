//
//  SearchValues.h
//  GetAuto.com
//
//  Created by Shaofeng Tu on 6/30/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SearchValues : NSObject {
	int			year;
	NSString	*make;
	NSString	*model;
}

@property(assign)	int			year;
@property(copy)		NSString	*make;
@property(copy)		NSString	*model;

@end
