//
//  SlideViewController.h
//  Dealerships
//
//  Created by GetAuto on 9/23/11.

//

#import <UIKit/UIKit.h>
#import "VehicleDetails.h"
#import "LoadingView.h"

@interface SlideViewController : UIViewController < UIScrollViewDelegate >

@property (strong, nonatomic) IBOutlet UIScrollView *photoScrollView;
@property (strong, nonatomic) IBOutlet UIPageControl *slidePageControl;

@property (assign) BOOL pageControlIsChangingPage;

@property (strong, nonatomic)   VehicleDetails		*listing;
@property (strong, nonatomic)   LoadingView			*loadingView;
@property (assign)   CGRect     orgFrame;
@property (assign)   CGRect     orgPageFrame;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil data:(VehicleDetails *)vehicleDetails;
- (void) buildScrollImages;

@end
