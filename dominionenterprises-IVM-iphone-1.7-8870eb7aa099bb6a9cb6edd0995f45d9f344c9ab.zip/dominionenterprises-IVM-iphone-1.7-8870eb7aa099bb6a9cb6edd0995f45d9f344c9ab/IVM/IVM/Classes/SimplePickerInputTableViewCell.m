//
//  SimplePickerInputTableViewCell.m
//  PickerCellDemo
//
//  Created by Tom Fewster on 10/11/2011.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//
#import "SimplePickerInputTableViewCell.h"
#import "appDelegate.h"
#import "HomeViewController.h"
@implementation SimplePickerInputTableViewCell

@synthesize delegate;
@synthesize value;
@synthesize homeViewController;
NSMutableArray *values = nil;

+ (void)initialize {
    values=[NSMutableArray arrayWithArray:[[appDelegate currentInstance]getDealerList]];
    [values insertObject:@"-Dealer-" atIndex:0];
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
		self.picker.delegate = self;
		self.picker.dataSource = self;
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        // Initialization code
		self.picker.delegate = self;
		self.picker.dataSource = self;
    }
    return self;
}

- (void)setValue:(NSString *)v {
	value = v;
	self.detailTextLabel.text = value;
     if(![value isEqualToString:@""] && [values count] > 1)
	  [self.picker selectRow:[self checkIndexOfDealerArray] inComponent:0 animated:YES];
}

- (UIView *)inputAccessoryView {
    if (!inputAccessoryView) {
        inputAccessoryView = [UIToolbar new];
        [inputAccessoryView sizeToFit];
        inputAccessoryView.frame = CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 215.0f - 42.0f, [UIScreen mainScreen].applicationFrame.size.width, inputAccessoryView.frame.size.height);
        inputAccessoryView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
        inputAccessoryView.barStyle = UIBarStyleBlack;
        inputAccessoryView.contentMode = UIViewContentModeRight;      
        
        UIBarButtonItem *doneBtn =[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(done:)];
        UIBarButtonItem *flexibleSpaceLeft = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        NSArray *array = [NSArray arrayWithObjects:flexibleSpaceLeft, doneBtn, nil];
        [inputAccessoryView setItems:array];
    }
    return inputAccessoryView;
}

- (void)done:(id)sender {
    
	[self resignFirstResponder];
    //[homeViewController.homeTable reloadData];
    int newdealerLot = [[NSUserDefaults standardUserDefaults] integerForKey:kDefaultDealerLot];
    if(newdealerLot > 0)
    {
        
            
      homeViewController.reqType=28;
             NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:homeViewController.reqType],@"reqtype",homeViewController,@"delegate", nil];
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        [ws initialize:dic];
        [ws callWSWithQuery:dic];

    if (homeViewController.loadingView == nil) {
        homeViewController.loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
    }
    }
    else
    {
        [homeViewController.homeTable scrollsToTop];
        [homeViewController.homeTable reloadData];
    }
}
#pragma mark -
#pragma mark UIPickerViewDataSource

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
	return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
	return [values count];
}

#pragma mark -
#pragma mark UIPickerViewDelegate

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if(row)
	return ((Dealer*)[values objectAtIndex:row]).name;
    return [values objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if(row)
    {
	self.value = ((Dealer*)[values objectAtIndex:row]).name;
    dealerLot = ((Dealer*)[values objectAtIndex:row]).lotKey;
	if (delegate && [delegate respondsToSelector:@selector(tableViewCell:didEndEditingWithValue:)]) {
        [[appDelegate currentInstance] clearVehicleMapping];
        //Delete the Vehicle Mapped Date
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:kVehicleMappedDate];
        [[NSUserDefaults standardUserDefaults] setInteger:dealerLot forKey:kDefaultDealerLot];
        [[NSUserDefaults standardUserDefaults] synchronize];       
		[delegate tableViewCell:self didEndEditingWithValue:self.value];
	}
    }
    else
    {
        if (delegate && [delegate respondsToSelector:@selector(tableViewCell:didEndEditingWithValue:)]) {
            [[appDelegate currentInstance] clearVehicleMapping];
            //Delete the Vehicle Mapped Date
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:kVehicleMappedDate];
            [[NSUserDefaults standardUserDefaults] setInteger:dealerLot forKey:kDefaultDealerLot];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [delegate tableViewCell:self didEndEditingWithValue:@"Select Dealer"];
        }
    }
}

-(int)checkIndexOfDealerArray{
    int returnIndexofMatched=0;
    for (int dealerArrayIndex=1; dealerArrayIndex<[values count]   ; dealerArrayIndex++){
            if([((Dealer*)[values objectAtIndex:dealerArrayIndex ]).name isEqualToString:self.value]){
                // Do not add
                returnIndexofMatched=dealerArrayIndex;
                break;
            }
    }
    return returnIndexofMatched;
}
@end
