//
//  HomeViewController.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 1/28/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"
#import "IVMMobileServices.h"
#import "LoadingView.h"
#import "SimplePickerInputTableViewCell.h"

@class VehicleSearchObject,DealerVehicleHistory;

@interface HomeViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate, UIAlertViewDelegate, AppRestore,UIPickerViewDelegate,UIPickerViewDataSource,SimplePickerInputTableViewCellDelegate> {
	BOOL	checkboxSelected;
    LoadingView *loadingView;
    NSMutableArray	*dealerList;
    SimplePickerInputTableViewCell *cell;
    BOOL selectedDealerHasAccessAppraisal;
}

@property(nonatomic, strong) UITableView    *homeTable;
@property(nonatomic, strong) NSArray    *listings;
@property(nonatomic,assign) int reqType;
@property(nonatomic,strong) LoadingView *loadingView;

-(void) performSearch:(VehicleSearchObject*)vso;
-(void) refreshData;
-(void) stopLoadingView;
@end
