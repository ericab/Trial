//
//  SettingsViewController.m
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//


#import "HomeViewController.h"
#import "SearchResultsController.h"
//#import "AdvancedSearchController.h"
#import <QuartzCore/CoreAnimation.h>
#import "appDelegate.h"
#import <objc/runtime.h>
#import "IVM.h"
//#import "AddToInventoryController.h"
//#import "AnalyzerController.h"
#import "LoginViewController.h"
#import "AppraisalSearchResultsController.h"
#import "SettingsController.h"
#import "DataProviderViewController.h"
#import "MarketControlAnalysisController.h"
#import "BlackBookController.h"
#import "KellyBlueBookController.h"
#import "EdmundsController.h"
#import "GalvesController.h"
#import "NADAController.h"
#import "CompetitiveController.h"
#import "AppraisalDetailsController.h"


@implementation DataProviderViewController

@synthesize dataproviderTable;
@synthesize listings;


- (id) init
{
	self = [super init];
	if (self != nil) {
		[appDelegate track:@"Data Providers"];
	}
    
    self.listings = [NSArray arrayWithObjects: @"Market Pricing", @"Black Book", @"KBB", @"Edmunds", @"Galves", @"NADA", @"Competitive Information", @"Details", nil ];
	return self;
}


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	float yOffset = 20.0f;
	
	UIView *vw = [[UIView alloc] initWithFrame:CGRectZero];
	vw.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
//	vw.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
	self.view = vw;
   
	dataproviderTable = [[UITableView alloc] initWithFrame:CGRectMake(10.0f, yOffset - 10.0, 300.0f, 330.0f) style:UITableViewStyleGrouped];
	dataproviderTable.backgroundColor = [UIColor clearColor];
//	homeTable.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	dataproviderTable.delegate = self;
	dataproviderTable.dataSource = self;
	[self.view addSubview:dataproviderTable];

	self.navigationItem.title = @"Data Providers";
}


- (void)viewWillAppear:(BOOL)animated
{
}


- (void) performSearch:(VehicleSearchObject*)vso{
	SearchResultsController *searchController = [SearchResultsController new];
	[[self navigationController] pushViewController:searchController animated:YES];
	[searchController startSearch:vso];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (NSArray*)getRestoreData{
	//Create an array of child view controllers
	NSMutableArray *children = [NSMutableArray array];
	for(int i = [self.navigationController.viewControllers indexOfObject:self] + 1; i < [self.navigationController.viewControllers count]; i++)
	{
		UIViewController *vc = [self.navigationController.viewControllers objectAtIndex:i];
		//Store the information for the child in the array
		if([vc conformsToProtocol:@protocol(ItemRestore)])
			[children addObject:[NSDictionary dictionaryWithObject:[vc performSelector:@selector(getRestoreData)] forKey:NSStringFromClass([vc class])]];
	}
	return children;
}

- (void)restore:(NSArray*)data{
	//Loop through child data
	for(NSDictionary* child_data in data)
	{
		if([[child_data allKeys] count] < 1) continue;
		NSString *clss = [[child_data allKeys] objectAtIndex:0];
		//Create a class from the key
		Class controller = [[NSBundle mainBundle] classNamed:clss];
		//Make sure the class is the correct type
		if(class_conformsToProtocol(controller, @protocol(ItemRestore)))
		{
			id<ItemRestore> tmp = [[controller alloc] initWithRestore:[child_data objectForKey:clss]];
			if([tmp isKindOfClass:[UIViewController class]])
				[self.navigationController pushViewController:(UIViewController*)tmp animated:NO];
		}
	}
}

- (void)doFunctions:(id)sender{
	MarketControlAnalysisController *marketcontrolanalysis = nil;
	BlackBookController *blackbook = nil;
	KellyBlueBookController *kellybluebook = nil; 
    EdmundsController *edmunds = nil;
    GalvesController *galves = nil;
    NADAController *nada = nil;
    CompetitiveController *competitive = nil;
    AppraisalDetailsController *appraisaldetails = nil;

    int t = [sender tag];  // not getTag
	
	switch (t) {
		case 1:
			marketcontrolanalysis = [MarketControlAnalysisController new];
			[[self navigationController] pushViewController:marketcontrolanalysis animated:YES];            
			break;
		case 2:
			blackbook = [BlackBookController new];
			[self.navigationController pushViewController:blackbook animated:YES];
			break;
		case 3:
			kellybluebook = [KellyBlueBookController new];
			[[self navigationController] pushViewController:kellybluebook animated:YES];
			break; 
        case 4:
			edmunds = [EdmundsController new];
			[[self navigationController] pushViewController:edmunds animated:YES];            
			break;              
        case 5:
			galves = [GalvesController new];
			[[self navigationController] pushViewController:galves animated:YES];
			break;
        case 6:
            nada = [NADAController new];
            [[self navigationController] pushViewController:nada animated:YES];
            break;
        case 7:
            competitive = [CompetitiveController new];
            [[self navigationController] pushViewController:competitive animated:YES];
            break;
        case 8:
            appraisaldetails = [AppraisalDetailsController new];
            [[self navigationController] pushViewController:appraisaldetails animated:YES];
            break;
		case 9:
//			analyzer = [AnalyzerController new];
//			[[self navigationController] pushViewController:analyzer animated:YES];
			
			;UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil
																 message:@"Coming Soon ..."
																delegate:nil
													   cancelButtonTitle:@"Ok"
													   otherButtonTitles:nil];
			
			[alertView show];
			
			break;
	}
}

#pragma mark -
#pragma mark alertView methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex != alertView.cancelButtonIndex) {

		//Delete the Current User Token
		[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserToken];
		[[NSUserDefaults standardUserDefaults] synchronize];
		
		//Display LoginView
		LoginViewController* lvc = [LoginViewController new];
		lvc.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
		
		[self presentModalViewController:lvc animated:YES];
    }
}  


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [self.listings count];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	MarketControlAnalysisController *marketcontrolanalysis = nil;
	BlackBookController *blackbook = nil;
    KellyBlueBookController *kellybluebook = nil;
    EdmundsController *edmunds = nil;
    GalvesController *galves = nil;
	NADAController *nada = nil;
    CompetitiveController *competitive = nil;
    AppraisalDetailsController *appraisaldetails = nil;
    
	switch (indexPath.row) {
		case 0:
			marketcontrolanalysis = [MarketControlAnalysisController new];
			[[self navigationController] pushViewController:marketcontrolanalysis animated:YES];
			break;
		case 1:
			blackbook = [BlackBookController new];
			[self.navigationController pushViewController:blackbook animated:YES];
			break;
		case 2:
            kellybluebook = [KellyBlueBookController new];
			[[self navigationController] pushViewController:kellybluebook animated:YES];
			break;
 		case 3:
            edmunds = [EdmundsController new];
			[[self navigationController] pushViewController:edmunds animated:YES];            
			break; 
 		case 4:
            galves = [GalvesController new];
			[[self navigationController] pushViewController:galves animated:YES];
			break;
        case 5:
            nada = [NADAController new];
            [[self navigationController] pushViewController:nada animated:YES];
            break;
        case 6:
            competitive = [CompetitiveController new];
            [[self navigationController] pushViewController:competitive animated:YES];
            break;
        case 7:
            appraisaldetails = [AppraisalDetailsController new];
            [[self navigationController] pushViewController:appraisaldetails animated:YES];
            break;
        case 8:
//			analyzer = [AnalyzerController new];
//			[[self navigationController] pushViewController:analyzer animated:YES];
/*			
			;UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil
																 message:@"Coming Soon ..."
																delegate:nil
													   cancelButtonTitle:@"Ok"
													   otherButtonTitles:nil];
			
			[alertView show];
*/			
			break;
        default:
            break;
	}
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:nil];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@", [self.listings objectAtIndex:indexPath.row]];
    
//    cell.textLabel.font = [UIFont boldSystemFontOfSize:16.0];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
	return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 40.0;
}


@end
