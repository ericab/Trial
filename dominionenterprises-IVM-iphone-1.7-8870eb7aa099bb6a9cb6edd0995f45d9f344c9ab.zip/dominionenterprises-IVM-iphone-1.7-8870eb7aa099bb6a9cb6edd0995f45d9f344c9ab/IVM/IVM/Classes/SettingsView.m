//
//  SettingsView.m
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//


#import "IVM.h"
#import "appDelegate.h"
#import "SearchResultsController.h"
#import "IVMMobileServices.h"
#import "SearchValues.h"
#import "SearchValuesResults.h"
#import "SearchResultsView.h"
#import "SettingsView.h"
#import "SettingsController.h"

@interface SettingsView()

- (void)registerForKeyboardNotifications;
- (void)unregisterForKeyboardNotifications;
@end

enum{
	MODE_MAKEMODEL = 1,
	MODE_PRICE = 2,
	MODE_YEAR = 3,
	MODE_MILES = 4,
	MODE_DEALERLOT = 5
};

@implementation SettingsView

@synthesize searchObject, target, btn_Search;
@synthesize dealerList;


- (id)initWithFrame:(CGRect)frame {
    return [self initWithFrame:frame searchObject:nil filterMode:NO];
}

- (id)initWithFrame:(CGRect)frame searchObject:(VehicleSearchObject*)searchObj filterMode:(BOOL)filter {
	self = [super initWithFrame:frame];
	if(self != nil)
	{
		[UIView setAnimationsEnabled:NO];
		frm_money = [NSNumberFormatter new];	
		[frm_money setNumberStyle:NSNumberFormatterCurrencyStyle];
		[frm_money setMaximumFractionDigits:0];
		
		frm_decimal = [NSNumberFormatter new];
		[frm_decimal setNumberStyle:NSNumberFormatterDecimalStyle];
		[frm_decimal setMaximumFractionDigits:0];
		
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		
		self.searchObject = searchObj == nil ? [VehicleSearchObject new] : searchObj;
	
		scrollView = [[UIScrollView alloc] initWithFrame:frame];
		scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		[self addSubview:scrollView];
		
	
		float yOffset = 5.0f;
        
        /*btn_Sort = [UIButton buttonWithType:UIButtonTypeCustom];
		[btn_Sort setTitle:@"Sort" forState:UIControlStateNormal];
		[btn_Sort setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
		[btn_Sort setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btn_Sort.titleLabel.font = [UIFont boldSystemFontOfSize:20];
		[btn_Sort setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		btn_Sort.frame = CGRectMake(0.0f, yOffset, 320.0f, 30.0f);
		[scrollView addSubview:btn_Sort]; 
        
		yOffset += 35.0f;  */  
        
		// Column Label
		columnLabel = [[UILabel alloc] initWithFrame:CGRectMake(80.0f, yOffset, 70.0f, 20.0f)];
		columnLabel.backgroundColor = [UIColor clearColor];
		columnLabel.textColor = [UIColor blackColor];
		columnLabel.font = [UIFont boldSystemFontOfSize:kDefaultFontSize + 3.0];
		columnLabel.text = @"Column";
		[self addSubview:columnLabel];      
        
		// Order Label
		orderLabel = [[UILabel alloc] initWithFrame:CGRectMake(190.0f, yOffset, 70.0f, 20.0f)];
		orderLabel.backgroundColor = [UIColor clearColor];
		orderLabel.textColor = [UIColor blackColor];
		orderLabel.font = [UIFont boldSystemFontOfSize:kDefaultFontSize + 3.0];
		orderLabel.text = @"Order";
		[self addSubview:orderLabel];      
        
        yOffset += 30.0f;
        
        // Sort by Label
		sortbyLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 70.0f, 20.0f)];
		sortbyLabel.backgroundColor = [UIColor clearColor];
		sortbyLabel.textColor = [UIColor blackColor];
		sortbyLabel.font = [UIFont boldSystemFontOfSize:kDefaultFontSize + 1.0];
		sortbyLabel.text = @"Sort by:";
		[self addSubview:sortbyLabel]; 
        
		btn_DealerLot = [[UITextField alloc] initWithFrame:CGRectMake(80.0f, yOffset, 105.0f, 25.0)];
		btn_DealerLot.borderStyle = UITextBorderStyleRoundedRect;
		btn_DealerLot.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_DealerLot.placeholder = @"Customer Name";
		btn_DealerLot.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_DealerLot.delegate = self;
        btn_DealerLot.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
		[scrollView addSubview:btn_DealerLot];

		btn_Year = [[UITextField alloc] initWithFrame:CGRectMake(190.0f, yOffset, 105.0f, 25.0)];
		btn_Year.borderStyle = UITextBorderStyleRoundedRect;
		btn_Year.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Year.placeholder = @"desc";
 		btn_Year.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_Year.delegate = self;
        btn_Year.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;

		[scrollView addSubview:btn_Year];
		
		yOffset += 30.0f;
		
        // Then by Label
		thenby1Label = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 70.0f, 20.0f)];
		thenby1Label.backgroundColor = [UIColor clearColor];
		thenby1Label.textColor = [UIColor blackColor];
		thenby1Label.font = [UIFont boldSystemFontOfSize:kDefaultFontSize + 1.0];
		thenby1Label.text = @"Then by:";
		[self addSubview:thenby1Label];         
		
		btn_MakeModel = [[UITextField alloc] initWithFrame:CGRectMake(80.0f, yOffset, 105.0f, 25.0)];
		btn_MakeModel.borderStyle = UITextBorderStyleRoundedRect;
		btn_MakeModel.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_MakeModel.placeholder = @"Year";
 		btn_MakeModel.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_MakeModel.delegate = self;
        btn_MakeModel.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_MakeModel];

		
		btn_Price = [[UITextField alloc] initWithFrame:CGRectMake(190.0f, yOffset, 105.0f, 25.0)];
		btn_Price.borderStyle = UITextBorderStyleRoundedRect;
		btn_Price.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Price.placeholder = @"desc";
 		btn_Price.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_Price.delegate = self;
        btn_Price.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_Price];
		
		yOffset += 30.0f;

        // Then by Label
		thenby1Label = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 70.0f, 20.0f)];
		thenby1Label.backgroundColor = [UIColor clearColor];
		thenby1Label.textColor = [UIColor blackColor];
		thenby1Label.font = [UIFont boldSystemFontOfSize:kDefaultFontSize + 1.0];
		thenby1Label.text = @"Then by:";
		[self addSubview:thenby1Label];
		
		btn_Mileage = [[UITextField alloc] initWithFrame:CGRectMake(80.0f, yOffset, 105.0f, 25.0)];
		btn_Mileage.borderStyle = UITextBorderStyleRoundedRect;
		btn_Mileage.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Mileage.placeholder = @"Make";
 		btn_Mileage.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_Mileage.delegate = self;
        btn_Mileage.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_Mileage];
        
        
		btn_Mileage = [[UITextField alloc] initWithFrame:CGRectMake(190.0f, yOffset, 105.0f, 25.0)];
		btn_Mileage.borderStyle = UITextBorderStyleRoundedRect;
		btn_Mileage.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Mileage.placeholder = @"desc";
 		btn_Mileage.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_Mileage.delegate = self;
        btn_Mileage.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_Mileage];
        
		yOffset += 40.0f;
        
        /*
		//Record Display
        btn_RecordsDisplay = [UIButton buttonWithType:UIButtonTypeCustom];
		[btn_RecordsDisplay setTitle:@"Record Display" forState:UIControlStateNormal];
		[btn_RecordsDisplay setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
		[btn_RecordsDisplay setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btn_RecordsDisplay.titleLabel.font = [UIFont boldSystemFontOfSize:20];
		[btn_RecordsDisplay setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		btn_RecordsDisplay.frame = CGRectMake(0.0f, yOffset, 320.0f, 30.0f);
		[scrollView addSubview:btn_RecordsDisplay]; 
		
		yOffset += 35.0f;
        
        NSArray *segmentTextContent = [NSArray arrayWithObjects: @"5", @"10", @"15", @"20", nil];
#pragma mark UISegmentControlStyleBar
        UISegmentedControl *segmentedControl = [[UISegmentedControl alloc] initWithItems:segmentTextContent];
        frame = CGRectMake(	10.0f, yOffset, 300.f, 25.0);
        segmentedControl.frame = frame;
        [segmentedControl addTarget:self action:@selector(segmentAction:) forControlEvents:UIControlEventValueChanged];
        segmentedControl.segmentedControlStyle = UISegmentedControlStyleBar;
        segmentedControl.selectedSegmentIndex = 1;
        
        [scrollView addSubview:segmentedControl];
#pragma mark -
        
        //Add the segemented UI
		yOffset += 30.0f;
        
        
		//Filter
        btn_Filter = [UIButton buttonWithType:UIButtonTypeCustom];
		[btn_Filter setTitle:@"Filter" forState:UIControlStateNormal];
		[btn_Filter setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
		[btn_Filter setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btn_Filter.titleLabel.font = [UIFont boldSystemFontOfSize:20];
		[btn_Filter setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		btn_Filter.frame = CGRectMake(0.0f, yOffset, 320.0f, 30.0f);
		[scrollView addSubview:btn_Filter]; 
		
		yOffset += 35.0f;
        
        NSArray *segmentTextContent = [NSArray arrayWithObjects: @"Active", @"Archived", nil];
#pragma mark UISegmentControlStyleBar
        UISegmentedControl *segmentedControl = [[UISegmentedControl alloc] initWithItems:segmentTextContent];
        frame = CGRectMake(	10.0f, yOffset, 300.f, 25.0);
        segmentedControl.frame = frame;
        [segmentedControl addTarget:self action:@selector(segmentAction:) forControlEvents:UIControlEventValueChanged];
        segmentedControl.segmentedControlStyle = UISegmentedControlStyleBar;
        segmentedControl.selectedSegmentIndex =0;
        
        [scrollView addSubview:segmentedControl];
#pragma mark -
        
		yOffset += 30.0f;  */ 
        
        
        //Save
        btn_clearSort = [UIButton buttonWithType:UIButtonTypeCustom];
		[btn_clearSort setTitle:@"Clear Sort" forState:UIControlStateNormal];
		[btn_clearSort setBackgroundImage:[UIImage imageNamed:@"btn_background-old.png"] forState:UIControlStateNormal];
		[btn_clearSort setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btn_clearSort.titleLabel.font = [UIFont boldSystemFontOfSize:15];
		[btn_clearSort setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		btn_clearSort.frame = CGRectMake(5.0f, yOffset, 155.0f, 30.0f);
		[scrollView addSubview:btn_clearSort]; 
        
        yOffset += 60.0f;
        
        // Then by Label
		thenby1Label = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 70.0f, 20.0f)];
		thenby1Label.backgroundColor = [UIColor clearColor];
		thenby1Label.textColor = [UIColor blackColor];
		thenby1Label.font = [UIFont boldSystemFontOfSize:kDefaultFontSize + 1.0];
		thenby1Label.text = @"Filter:";
		[self addSubview:thenby1Label];
		
		btn_Mileage = [[UITextField alloc] initWithFrame:CGRectMake(100.0f, yOffset, 195.0f, 25.0)];
		btn_Mileage.borderStyle = UITextBorderStyleRoundedRect;
		btn_Mileage.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Mileage.placeholder = @"Active";
 		btn_Mileage.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_Mileage.delegate = self;
        btn_Mileage.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_Mileage];
        
               
		yOffset += 40.0f;
        
		//Date Range
        /*btn_Filter = [UIButton buttonWithType:UIButtonTypeCustom];
		[btn_Filter setTitle:@"Date Range" forState:UIControlStateNormal];
		[btn_Filter setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
		[btn_Filter setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btn_Filter.titleLabel.font = [UIFont boldSystemFontOfSize:20];
		[btn_Filter setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		btn_Filter.frame = CGRectMake(0.0f, yOffset, 320.0f, 30.0f);
		[scrollView addSubview:btn_Filter]; 
		
		yOffset += 35.0f;   */   
        
        // Then by Label
		thenby1Label = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 100.0f, 20.0f)];
		thenby1Label.backgroundColor = [UIColor clearColor];
		thenby1Label.textColor = [UIColor blackColor];
		thenby1Label.font = [UIFont boldSystemFontOfSize:kDefaultFontSize + 1.0];
		thenby1Label.text = @"Date Range:";
		[self addSubview:thenby1Label];
        
		btn_fromdate = [[UITextField alloc] initWithFrame:CGRectMake(100.0f, yOffset, 195.0f, 25.0)];
		btn_fromdate.borderStyle = UITextBorderStyleRoundedRect;
		btn_fromdate.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_fromdate.placeholder = @"Select Date";
 		btn_fromdate.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_fromdate.delegate = self;
        btn_fromdate.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_fromdate];
        
        yOffset += 30.0f;
        
		btn_todate = [[UITextField alloc] initWithFrame:CGRectMake(100.0f, yOffset, 195.0f, 25.0)];
		btn_todate.borderStyle = UITextBorderStyleRoundedRect;
		btn_todate.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_todate.placeholder = @"Select Date";
 		btn_todate.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_todate.delegate = self;
        btn_todate.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_todate];
        
		yOffset += 40.0f;
        
  
		//Save
        btn_Save = [UIButton buttonWithType:UIButtonTypeCustom];
		[btn_Save setTitle:@"Save" forState:UIControlStateNormal];
		[btn_Save setBackgroundImage:[UIImage imageNamed:@"btn_background-old.png"] forState:UIControlStateNormal];
		[btn_Save setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btn_Save.titleLabel.font = [UIFont boldSystemFontOfSize:15];
		[btn_Save setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		btn_Save.frame = CGRectMake(5.0f, yOffset, 150.0f, 30.0f);
		[scrollView addSubview:btn_Save]; 
        
		//Clear
        btn_Clear = [UIButton buttonWithType:UIButtonTypeCustom];
		[btn_Clear setTitle:@"Clear" forState:UIControlStateNormal];
		[btn_Clear setBackgroundImage:[UIImage imageNamed:@"btn_background-old.png"] forState:UIControlStateNormal];
		[btn_Clear setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btn_Clear.titleLabel.font = [UIFont boldSystemFontOfSize:15];
		[btn_Clear setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		btn_Clear.frame = CGRectMake(160.0f, yOffset, 155.0f, 30.0f);
		[scrollView addSubview:btn_Clear];         
        
		//Picker View Creation		
		_pickerDone = [UIToolbar new];
		[_pickerDone sizeToFit];
//		_pickerDone.frame = CGRectMake(0.0f, frame.size.height - 215.0f - 42.0f, frame.size.width, _pickerDone.frame.size.height);
		_pickerDone.frame = CGRectMake(0.0f, 480.0, frame.size.width, _pickerDone.frame.size.height);
		//[[UIToolbar alloc] initWithFrame:CGRectMake(0.0f, frame.size.height - 215.0f - 40.0f, frame.size.width, 44.0f)];
		_pickerDone.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
		_pickerDone.barStyle = UIBarStyleBlack;
		_pickerDone.contentMode = UIViewContentModeRight;
		UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(pickerDone:)];
		UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
		[_pickerDone setItems:[NSArray arrayWithObjects:spacer, done, nil] animated:NO];
		

		scrollView.contentSize = CGSizeMake(320.0f, yOffset);

		
        [UIView setAnimationsEnabled:YES];

		_userToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];
		
		years = [NSMutableArray array];
		makes = [NSMutableArray array];
		models = [NSMutableArray array];
		
        self.dealerList = [[appDelegate currentInstance] getDealerList];
        dealerLots = [NSMutableArray array];
        dealerNameKeys = [NSMutableArray array];
        
        for(int i = 0; i < [self.dealerList count]; i++) {
            [dealerLots addObject:[NSString stringWithFormat:@"%d", ((Dealer*)[self.dealerList objectAtIndex:i]).lotKey]];
            [dealerNameKeys addObject:[NSString stringWithFormat:@"%@", ((Dealer*)[self.dealerList objectAtIndex:i]).name]];
        }
	}

	return self;
}


- (void)alertView:(UIAlertView *)inAlertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
//	[target performSelector:errorCallback withObject:self];
    [target advSearchError:nil];
}


#pragma mark UITextField delegate methods

- (BOOL)textFieldShouldClear:(UITextField *)textField {
	return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
	//[self showPicker:textField];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    latsetTextField = textField;
}

/*
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{

}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = self.frame;
    viewFrame.origin.y += animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self setFrame:viewFrame];
    
    [UIView commitAnimations];
}
*/
- (void)registerForKeyboardNotifications 
{ 
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(keyboardWasShown:) 
												 name:UIKeyboardDidShowNotification object:nil]; 
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(keyboardWasHidden:) 
												 name:UIKeyboardDidHideNotification object:nil]; 
}

- (void)unregisterForKeyboardNotifications
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark UIPickerView delegate methods

// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
	if([pickerView isEqual: pickerOne]) {
		return 1;
	} else if([pickerView isEqual: pickerTwo]) {
		return 2;
	}
	
	return 0;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
	if([pickerView isEqual: pickerOne]) {
		return [(NSArray*)[oneDataSource objectAtIndex:component] count];
	} else if([pickerView isEqual: pickerTwo]) {
		return [(NSArray*)[twoDataSource objectAtIndex:component] count];
	}

	return 0;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
	if([pickerView isEqual: pickerOne]) {
		return [(NSArray*)[oneDataSource objectAtIndex:component] objectAtIndex:row];
	} else if([pickerView isEqual: pickerTwo]) {
		return [(NSArray*)[twoDataSource objectAtIndex:component] objectAtIndex:row];
	}
	
	return 0;
}


- (void) MakesAndModelsComplete:(MakesAndModels*)makesModels{
	if(makesModels == nil)
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Unable to update Makes"
															message:@"Please ensure you have a network connection and try again."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}
	mAndm = makesModels;
//	_priorityView.hidden = YES;
//	[loadingView removeFromSuperview];
//	[loadingView release];
//	loadingView = nil;
}

- (void) SearchValuesComplete:(SearchValuesResults*)svResults withStatus:dResult{
	if(![dResult isEqualToString:@"Success"])
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"The Web Services Failed"
															message:dResult 
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		
		return;
	}
	
	if(svResults == nil)
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Unable to get Makes/Models"
															message:@"Please ensure you have a network connection and try again."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}

	searchValuesResults = svResults;
	
	[searchView.activityIndicator stopAnimating];
	searchView.activityLabel.hidden = YES;
	[searchView removeFromSuperview];
	
}

- (void)dealloc {
	[self unregisterForKeyboardNotifications];
//	[[appDelegate currentInstance] cancelMakesAndModels];
	
	
//	[loadingView release];
	
}

@end
