//
//  BlackBookController.m
//
//  Created by Raja Sekhar Nerella on 3/23/12.

//

#import "SearchResultsController.h"
#import "appDelegate.h"
#import <QuartzCore/CoreAnimation.h>
#import "BlackBookController.h"
#import "BlackBookView.h"

#define kAdvancedSearchSearcher @"searcher"

@implementation BlackBookController
@synthesize providerType;
@synthesize reqType;
@synthesize isMapped;
@synthesize str_appraisalid;
@synthesize appraisalDetailsController;
@synthesize isAppraisal,alpickerView;

static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;
static const CGFloat LANDSCAPE_KEYBOARD_HEIGHT = 162;

- (id) init
{
	self = [super init];
	if (self != nil) {
		[appDelegate track:@"Black Book"];
	}
	return self;
}
- (id)initWithRestore:(NSDictionary*)data{
	self = [self init];
	if (self != nil)
	{
		searchObj = [data objectForKey:kAdvancedSearchSearcher];
		[self.view class];//Ensure that the view gets loaded
	}
	return self;
}
- (NSDictionary*)getRestoreData{
	NSMutableDictionary* dict = [NSMutableDictionary dictionaryWithCapacity:1];
	if(searchObj == nil)
	{
		//Attempt to get it
		searchObj = ((BlackBookView*)self.view).searchObject;
	}
	if(searchObj != nil)
	{
		searchObj.firstListing = 1;
		[dict setValue:searchObj forKey:kAdvancedSearchSearcher];
	}
	return dict;
}

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
    arrayOfdataProviderYears=[NSMutableArray array];
    arrayOfdataProviderMakes=[NSMutableArray array];
    arrayOfdataProviderModels=[NSMutableArray array];
    arrayOfdataProviderTrims=[NSMutableArray array];
    arrayOfdataProviderStyles=[NSMutableArray array];
    arrayOfdataProviderClean=[NSMutableArray array];
    arrayOfdataProviderExtra=[NSMutableArray array];
    arrayOfdataProviderCodes=[NSMutableArray array];
    entries=[NSMutableArray array];
    selectionStates = [[NSMutableDictionary alloc] init];

    providerCode=[[NSString alloc]init];
    vehicleappraisalkey=[[NSString alloc]init];
    
    UIView *view = [[UIView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    [view setAutoresizingMask:UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth];
    [view setBackgroundColor:[UIColor whiteColor]];
    UIImageView *backgroundImage=  [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];;
    [view addSubview:backgroundImage];
    [view sendSubviewToBack:backgroundImage];
    
    scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [view addSubview:scrollView];
   
    UIColor *textColor = [UIColor blackColor];
    UIFont *lblFont = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0];
    
    float yOffset = 10.0f;
    UILabel *tmpLabel;
    
    if(!isMapped && isAppraisal)
    {
    //Vehicle Type
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 300.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = [NSString stringWithFormat:@"%@ %@ %@ %@ %@",self.appraisalDetailsController->asv->str_year,self.appraisalDetailsController->asv->str_make,self.appraisalDetailsController->asv->str_model,self.appraisalDetailsController->asv->str_trim,self.appraisalDetailsController->asv->str_style];
    tmpLabel.tag=10;
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    }
    //Year
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Year";
    tmpLabel.tag=1;
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_Year = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_Year.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_Year.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_Year.placeholder = @"Year";
    txt_Year.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_Year.delegate = self;
    txt_Year.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [scrollView addSubview:txt_Year];
    
    yOffset += 30.0f;
    
    //Make
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 135.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Make";
    tmpLabel.tag=2;
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_make = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_make.borderStyle = UITextBorderStyleRoundedRect;
    txt_make.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_make.placeholder = @"Make";
    txt_make.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_make.delegate = self;
    txt_make.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_make];
    
    yOffset += 30.0f;

    //Model
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 155.0f, 20.0f)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Model";
    tmpLabel.tag=3;
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_model = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_model.borderStyle = UITextBorderStyleRoundedRect;
    txt_model.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_model.placeholder = @"Model";
    txt_model.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_model.delegate = self;
    txt_model.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_model];
    
    yOffset += 30.0f;
    
    //Trim
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 130.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Trim";
    tmpLabel.tag=4;
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_trim = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_trim.borderStyle = UITextBorderStyleRoundedRect;
    txt_trim.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_trim.placeholder = @"Trim";
    txt_trim.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_trim.delegate = self;
    txt_trim.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_trim];
    
    yOffset += 30.0f;
	if([self.title isEqualToString:@"Black Book"])
    {
    //Style
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 90.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Style";
    tmpLabel.tag=5;
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_style = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_style.borderStyle = UITextBorderStyleRoundedRect;
    txt_style.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_style.placeholder = @"Style";
    txt_style.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_style.delegate = self;
    txt_style.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_style];
    
    yOffset += 30.0f;
    }
    //NADA Options
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 300.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    //if(providerType
    tmpLabel.text =[NSString stringWithFormat:@"%@ Condition",self.title];
    tmpLabel.tag=6;
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_blackbookoptions = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_blackbookoptions.borderStyle = UITextBorderStyleRoundedRect;
    txt_blackbookoptions.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_blackbookoptions.placeholder = @"No condition selected.";
    txt_blackbookoptions.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_blackbookoptions.delegate = self;
    txt_blackbookoptions.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_blackbookoptions];
    
    yOffset += 30.0f;
    
    if(!isMapped || [self.title isEqualToString:@"Galves"])
    {
        txt_blackbookoptions.hidden=YES;
        tmpLabel.hidden=YES;
    }
    //NADA More Options
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 300.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = [NSString stringWithFormat:@"%@ Options",self.title];
    tmpLabel.tag=7;
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_blackbookmoreoptions = [[UITextView alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 35.0)];
    //txt_blackbookmoreoptions.borderStyle = UITextBorderStyleRoundedRect;
    //The rounded corner part, where you specify your view's corner radius:
    txt_blackbookmoreoptions.layer.cornerRadius = 5;
    txt_blackbookmoreoptions.clipsToBounds = YES;
   
    txt_blackbookmoreoptions.font = [UIFont systemFontOfSize:kDefaultFontSize];
    //txt_blackbookmoreoptions.placeholder = @"No options selected.";
    txt_blackbookmoreoptions.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_blackbookmoreoptions.delegate = self;
   // txt_blackbookmoreoptions.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_blackbookmoreoptions];

    if(!isMapped || [self.title isEqualToString:@"Galves"])
    {
        tmpLabel.hidden=YES;
       txt_blackbookmoreoptions.hidden=YES;
    }
    //Picker View Creation		
    _pickerYearDone = [UIToolbar new];
    [_pickerYearDone sizeToFit];
    _pickerYearDone.frame = CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 215.0f - 42.0f, [UIScreen mainScreen].applicationFrame.size.width, _pickerYearDone.frame.size.height);
    _pickerYearDone.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
    _pickerYearDone.barStyle = UIBarStyleBlack;
    _pickerYearDone.contentMode = UIViewContentModeRight;
    UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(pickerDone:)];
    UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [_pickerYearDone setItems:[NSArray arrayWithObjects:spacer, done, nil] animated:NO];
    
     conditionPicker= [UIToolbar new];
    [conditionPicker sizeToFit];
    conditionPicker.frame = CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 215.0f - 42.0f, [UIScreen mainScreen].applicationFrame.size.width, _pickerYearDone.frame.size.height);
    conditionPicker.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
    conditionPicker.barStyle = UIBarStyleBlack;
    conditionPicker.contentMode = UIViewContentModeRight;
    done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(pickerDone:)];
    spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    
    UIBarButtonItem *cancel = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(pickerCancel:)];
    [conditionPicker setItems:[NSArray arrayWithObjects:cancel,spacer, done, nil] animated:NO];
    
    //DealerLot/Year Picker
    pickerYear = [[UIPickerView alloc] initWithFrame:CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 215.0f, [UIScreen mainScreen].applicationFrame.size.width, 0.0f)];
    pickerYear.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    pickerYear.showsSelectionIndicator = YES;
    pickerYear.delegate = self;
    pickerYear.dataSource = self;
    
    //Picker View Creation		
    _pickerDone = [UIToolbar new];
    [_pickerDone sizeToFit];
    _pickerDone.frame = CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 125.0f - 42.0f, [UIScreen mainScreen].applicationFrame.size.width, _pickerDone.frame.size.height);
    _pickerDone.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
    _pickerDone.barStyle = UIBarStyleBlackTranslucent;
    _pickerDone.contentMode = UIViewContentModeRight;
    
    cancel = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(pickerTableCancel:)];
    done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(pickerTableDone:)];
    spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [_pickerDone setItems:[NSArray arrayWithObjects:cancel,spacer, done, nil] animated:NO];
    
    _pickerDone.alpha = 0.0;
    _pickerDone.hidden = YES;
    [view addSubview:_pickerDone];
    txt_Year.inputView = pickerYear;
    txt_Year.inputAccessoryView = _pickerYearDone;
    txt_make.inputView = pickerYear;
    txt_make.inputAccessoryView = _pickerYearDone;
    txt_model.inputView = pickerYear;
    txt_model.inputAccessoryView = _pickerYearDone;
    txt_style.inputView = pickerYear;
    txt_style.inputAccessoryView = _pickerYearDone;
    txt_trim.inputView = pickerYear;
    txt_trim.inputAccessoryView = _pickerYearDone;
    txt_blackbookoptions.inputView = pickerYear;
    txt_blackbookoptions.inputAccessoryView = conditionPicker;
    txt_blackbookmoreoptions.inputView = alpickerView;
     txt_blackbookmoreoptions.inputAccessoryView = conditionPicker;
	
	// Init picker and add it to view
	alpickerView = [[ALPickerView alloc] initWithFrame:CGRectMake(0, 244, 0, 0)];
	alpickerView.delegate = self;
    alpickerView.hidden=YES;
	[view addSubview:alpickerView];
    
    self.view = view;
    
    if(isAppraisal)
    {
    UIBarButtonItem *editBtn = [[UIBarButtonItem alloc] initWithTitle:@"Select Style" style:UIBarButtonItemStyleBordered target:self action:@selector(editDetail)];
    editBtn.style = UIBarButtonItemStyleBordered;
    if(isMapped)
        [editBtn setTitle:@"Change Style"];
    self.navigationItem.rightBarButtonItem = editBtn;
    }
    if(!isMapped && isAppraisal)
    {
        txt_Year.text=self.appraisalDetailsController->asv->str_year;
        txt_make.text=self.appraisalDetailsController->asv->str_make;
        txt_model.text=self.appraisalDetailsController->asv->str_model;
        txt_trim.text=self.appraisalDetailsController->asv->str_trim;
        txt_style.text=self.appraisalDetailsController->asv->str_style;
    }
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Data Providers" style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
    
    [self loadingView];
    if([self.navigationItem.rightBarButtonItem.title isEqualToString:@"Save"])
    {
        if([self checkMandatory])
        {
            [self.navigationItem.rightBarButtonItem setStyle:UIBarButtonSystemItemSave];
            [self.navigationItem.rightBarButtonItem setEnabled:YES];
        }
        else 
        {
            [self.navigationItem.rightBarButtonItem setStyle:UIBarButtonItemStylePlain];
            [self.navigationItem.rightBarButtonItem setEnabled:NO];    
        }
    }
   
}
-(void) loadingView
{
    if (loadingView == nil) {
        //loadingView = [LoadingView loadingViewInView:self.view];
        loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
    }

}
/*- (void)buildStatesList
{
    // static arrays of clean options
    if([self.title isEqualToString:@"KBB"])
       {
           arrayOfdataProviderClean = [NSMutableArray arrayWithObjects:@"Extra Clean",  
                                       @"Clean",  
                                       @"Average",  
                                       nil];
       }
       else if([self.title isEqualToString:@"Galves"])
       {
           arrayOfdataProviderClean = [NSMutableArray arrayWithObjects:@"w/o AUTO TRANS",  
                                       @"SPORT",  
                                       @"TITANIUM SPORT",  
                                       @"NAVIGATION",  
                                       @"QUATTRO",  
                                       @"AUDI DRIVE SELECT",  
                                       @"S-LINE",
                                       @"ADAPTIVE CRUISE CONTROL",
                                       nil];
       }
               else if([self.title isEqualToString:@"NADA"])
                       {
                           arrayOfdataProviderClean = [NSMutableArray arrayWithObjects:  
                                                       @"Clean",  
                                                       @"Average",  
                                                       @"Rough",  
                                                       nil];
                       }
               else
               {
    arrayOfdataProviderClean = [NSMutableArray arrayWithObjects:@"Extra Clean",  
                  @"Clean",  
                  @"Average",  
                  @"Rough",  
                  nil];
       }
    arrayOfdataProviderExtra = [NSMutableArray arrayWithObjects:@"w/o AUTO TRANS",  
                                @"SPORT",  
                                @"TITANIUM SPORT",  
                                @"NAVIGATION",  
                                @"QUATTRO",  
                                @"AUDI DRIVE SELECT",  
                                @"S-LINE",
                                @"ADAPTIVE CRUISE CONTROL",
                                nil];
}
*/
-(void) stopLoadingView
{
    if (loadingView != nil)
    {
        
        [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
        loadingView = nil;
    }
}
- (void)advSearchError:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}

-(void) handleResponseForQuery:(NSMutableDictionary *)response
{
    reqType=0;
    if([[response objectForKey:@"response"] objectForKey:@"update"])
    {
        [self stopLoadingView];
    }
    else if([[response objectForKey:@"response"] objectForKey:@"providerCodes"])
    {
        arrayOfdataProviderCodes = [[response objectForKey:@"response"] objectForKey:@"providerCodes"];
        if([arrayOfdataProviderCodes count]>0 )
        {
            providerCode=[arrayOfdataProviderCodes objectAtIndex:0];
            isMapped=TRUE;
            if(![self.title isEqualToString:@"Galves"])
            {
            UILabel *labelOne=(UILabel*)[scrollView viewWithTag:6];
            labelOne.hidden=NO;
            txt_blackbookoptions.hidden=NO;
                labelOne=(UILabel*)[scrollView viewWithTag:7];
                labelOne.hidden=NO;
                txt_blackbookmoreoptions.hidden=NO;
            }
        }
        NSMutableArray *array=[[NSMutableArray alloc]init];
        NSMutableDictionary *dic ;
        if([self.title isEqualToString:@"Galves"])
        {
        dic= [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:22],@"reqtype", self.providerType,@"providerType",  str_appraisalid,@"appraisalid",providerCode,@"providerCode",@"",@"vehicleValuationCondition",[NSArray arrayWithObjects:array, nil],@"selectedOptionNames" , self,@"delegate", nil];
        }
        else if([txt_blackbookoptions.text length] > 0)
        {
            for (int optionIndex=0; optionIndex<[entries count]; optionIndex++) {
                if([[selectionStates objectForKey:[entries objectAtIndex:optionIndex] ] boolValue])
                {
                    [array addObject:[entries objectAtIndex:optionIndex]];
                }
            }
            dic= [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:22],@"reqtype", self.providerType,@"providerType",  str_appraisalid,@"appraisalid",providerCode,@"providerCode",txt_blackbookoptions.text,@"vehicleValuationCondition",[NSArray arrayWithObjects:array, nil],@"selectedOptionNames" , self,@"delegate", nil];
        }
        else
        {
            dic= [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:22],@"reqtype", self.providerType,@"providerType",  str_appraisalid,@"appraisalid",providerCode,@"providerCode",@"",@"vehicleValuationCondition",[NSArray arrayWithObjects:array, nil],@"selectedOptionNames" , self,@"delegate", nil];
        }
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        [ws initialize:dic];
        [ws callWSWithQuery:dic];

    }
    else if([[response objectForKey:@"response"] objectForKey:@"years"])
       {
            arrayOfdataProviderYears = [[response objectForKey:@"response"] objectForKey:@"years"];
           if(!isMapped)
           {
               if([arrayOfdataProviderYears count]>0)
               {
                   if (NSNotFound==[arrayOfdataProviderYears indexOfObjectPassingTest:^(id obj, NSUInteger idx, BOOL *stop)
                                    {
                                        if (NSOrderedSame==[(NSString *)obj caseInsensitiveCompare:txt_Year.text])
                                        {
                                            return YES;
                                        }
                                        return NO;
                                    }])
                   {
                       txt_Year.text=@"";
                       txt_make.text=@"";
                       txt_model.text=@"";
                       txt_trim.text=@"";
                       if([self.title isEqualToString:@"Black Book"])
                           txt_style.text=@"";
                   }
               }
           }
           if (![txt_Year.text isEqualToString:@""])
           {
               NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:13],@"reqtype", self.providerType,@"providerType",txt_Year.text,@"year", self,@"delegate", nil];
               
               IVMMobileServices *ws = [[IVMMobileServices alloc] init];
               
               [ws initialize:dic];
               [ws callWSWithQuery:dic];
           }
           else
           [self stopLoadingView];
       }
    else if([[response objectForKey:@"response"] objectForKey:@"makes"])
    {
        arrayOfdataProviderMakes = [[response objectForKey:@"response"] objectForKey:@"makes"];
        if(!isMapped)
        {
            if([arrayOfdataProviderMakes count]>0)
            {
                if (NSNotFound==[arrayOfdataProviderMakes indexOfObjectPassingTest:^(id obj, NSUInteger idx, BOOL *stop)
                                 {
                                     if (NSOrderedSame==[(NSString *)obj caseInsensitiveCompare:txt_make.text])
                                     {
                                         return YES;
                                     }
                                     return NO;
                                 }])
                {
                    txt_make.text=@"";
                    txt_model.text=@"";
                    txt_trim.text=@"";
                    if([self.title isEqualToString:@"Black Book"])
                        txt_style.text=@"";
                }
            }
        }

        if (![txt_make.text isEqualToString:@""])
        {
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:14],@"reqtype", self.providerType,@"providerType",txt_Year.text,@"year",txt_make.text,@"make", self,@"delegate", nil];
            
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            [ws initialize:dic];
            [ws callWSWithQuery:dic];
        }
        else
            [self stopLoadingView];
    }
    else if([[response objectForKey:@"response"] objectForKey:@"models"])
    {
        arrayOfdataProviderModels = [[response objectForKey:@"response"] objectForKey:@"models"];
        if(!isMapped)
        {
            if([arrayOfdataProviderModels count]>0)
            {
                if (NSNotFound==[arrayOfdataProviderModels indexOfObjectPassingTest:^(id obj, NSUInteger idx, BOOL *stop)
                                 {
                                     if (NSOrderedSame==[(NSString *)obj caseInsensitiveCompare:txt_model.text])
                                     {
                                         return YES;
                                     }
                                     return NO;
                                 }])
                {
                    txt_model.text=@"";
                    txt_trim.text=@"";
                    if([self.title isEqualToString:@"Black Book"])
                        txt_style.text=@"";
                }
            }
        }
        if (![txt_model.text isEqualToString:@""])
        {
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:15],@"reqtype", self.providerType,@"providerType",txt_Year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", self,@"delegate", nil];
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            [ws initialize:dic];
            [ws callWSWithQuery:dic];
        }
        else
        [self stopLoadingView];
    }
    else if([[response objectForKey:@"response"] objectForKey:@"trims"])
    {
        arrayOfdataProviderTrims = [[response objectForKey:@"response"] objectForKey:@"trims"];
        if(!isMapped)
        {
            if([arrayOfdataProviderTrims count]>0)
            {
                if (NSNotFound==[arrayOfdataProviderTrims indexOfObjectPassingTest:^(id obj, NSUInteger idx, BOOL *stop)
                                 {
                                     if (NSOrderedSame==[(NSString *)obj caseInsensitiveCompare:txt_trim.text])
                                     {
                                         return YES;
                                     }
                                     return NO;
                                 }])

                {
                    txt_trim.text=@"";
                    if([self.title isEqualToString:@"Black Book"])
                        txt_style.text=@"";
                }
            }
        }
        if (![txt_trim.text isEqualToString:@""] && [self.title isEqualToString:@"Black Book"])
        {
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:16],@"reqtype", self.providerType,@"providerType",txt_Year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", txt_trim.text,@"trim",self,@"delegate", nil];
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            [ws initialize:dic];
            [ws callWSWithQuery:dic];
        }
        else
        [self stopLoadingView];
    }
    else if([[response objectForKey:@"response"] objectForKey:@"styles"])
    {
        arrayOfdataProviderStyles = [[response objectForKey:@"response"] objectForKey:@"styles"];
        if (NSNotFound==[arrayOfdataProviderStyles indexOfObjectPassingTest:^(id obj, NSUInteger idx, BOOL *stop)
                         {
                             if (NSOrderedSame==[(NSString *)obj caseInsensitiveCompare:txt_style.text])
                             {
                                 return YES;
                             }
                             return NO;
                         }])
        {
            txt_style.text=@"";
            
        }
         [self stopLoadingView];
  
    }
     else
       {
           NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
           [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
           
           NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
           [numberFormatter setLocale:usLocale];
           
    arrayOfdataProvidersDetails = [[response objectForKey:@"response"] objectForKey:@"dataproviderdetailnada"];
    arrayOfdataProvidersDetailsOptions = [[response objectForKey:@"response"] objectForKey:@"dataproviderdetailnada1"];
           arrayOfdataProviderClean=[[response objectForKey:@"response"] objectForKey:@"dataproviderdetailnada2"];
    
           if([arrayOfdataProvidersDetailsOptions count] >0)
           {
               txt_blackbookmoreoptions.text=@"";
               arrayOfdataProviderExtra = [[NSMutableArray alloc]init];
               selectionStates = [[NSMutableDictionary alloc] init];
               entries = [[NSMutableArray alloc] init];
               for(int i=0;i<[arrayOfdataProvidersDetailsOptions count];i++)
               {
              dataProviderDetailsOptions = [arrayOfdataProvidersDetailsOptions objectAtIndex:i];
               // Create some sample data
                   [arrayOfdataProviderExtra addObject:[dataProviderDetailsOptions objectForKey:@"optionname"]];
                   [entries addObject:[dataProviderDetailsOptions objectForKey:@"optionname"]];
                  if([[dataProviderDetailsOptions objectForKey:@"isincluded"] boolValue])
                  {
                      NSString *string;
                      if([txt_blackbookmoreoptions.text length] > 0)
                          string =[ NSString stringWithFormat:@"%@ | %@",txt_blackbookmoreoptions.text ,[dataProviderDetailsOptions objectForKey:@"optionname"]];
                      else
                          string = [dataProviderDetailsOptions objectForKey:@"optionname"]; 
                      txt_blackbookmoreoptions.text=string;
                  }
                  [selectionStates setObject:[NSNumber numberWithBool:[[dataProviderDetailsOptions objectForKey:@"isincluded"] boolValue] ? YES:NO] forKey:[dataProviderDetailsOptions objectForKey:@"optionname"]];
               }
           }
           [alpickerView reloadAllComponents];
           if([arrayOfdataProvidersDetails count]>0)
           {
               dataProviderDetails = [arrayOfdataProvidersDetails objectAtIndex:0];
    NSString *szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"providertype"]];
    if ([szTemp length]>0) {
        self.providerType=szTemp;
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"year"]];
    if ([szTemp length]>0) {
        [txt_Year setText:szTemp];
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"make"]];
    if ([szTemp length]>0) {
        [txt_make setText:szTemp];
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"model"]];
    if ([szTemp length]>0) {
        [txt_model setText:szTemp];
    }
    if([self.title isEqualToString:@"Black Book"])
       {
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"style"]];
    if ([szTemp length]>0) {
        [txt_style setText:szTemp];
    }
       }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"mileage"]];
    if ([szTemp length]>0) {
        [txt_mileage setText:[NSString stringWithFormat:@"%@ mi",[numberFormatter stringFromNumber:[NSNumber numberWithInt:[szTemp intValue]]]]];
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"providercode"]];
    if ([szTemp length]>0) {
        providerCode=szTemp;
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"vehicleappraisalproviderkey"]];
    if ([szTemp length]>0) {
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"vehicleappraisalkey"]];
    if ([szTemp length]>0) {
        vehicleappraisalkey=szTemp;
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"vehiclevaluationcondition"]];
    if ([szTemp length]>0) {
        if([szTemp isEqualToString:@"ExtraClean"])
            szTemp=@"Extra Clean";
        [txt_blackbookoptions setText: szTemp];
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"trim"]];
    if ([szTemp length]>0) {
        [txt_trim setText: szTemp];
    }
    
    for (int i=0; i<[arrayOfdataProvidersDetailsOptions count]; i++) {
        dataProviderDetailsOptions = [arrayOfdataProvidersDetailsOptions objectAtIndex:i];
        szTemp =   [ NSString stringWithString: [dataProviderDetailsOptions objectForKey:@"optionname"]];
        if ([szTemp length]>0) {
        }
        
    }}
           if(refreshDataOn)
           {
               self.appraisalDetailsController.refreshDataOn=YES;
               [self stopLoadingView];
               [self.navigationController popToViewController:self.appraisalDetailsController animated:YES];
           }
           else if(isAppraisal)
           {
               if([[self.navigationItem.rightBarButtonItem title] isEqualToString:@"Change Style"])
               {
               NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:12],@"reqtype", self.providerType,@"providerType", self,@"delegate", nil];
           
               IVMMobileServices *ws = [[IVMMobileServices alloc] init];
               [ws initialize:dic];
               [ws callWSWithQuery:dic];    
               }
               else
               {
                   [self stopLoadingView];
                   UIBarButtonItem *editBtn = [[UIBarButtonItem alloc] initWithTitle:@"Change Style" style:UIBarButtonItemStyleDone target:self action:@selector(editDetail)];
                   editBtn.style = UIBarButtonItemStyleBordered;
                   self.navigationItem.rightBarButtonItem = editBtn;
               }
           }
           else
           {
               [self stopLoadingView];
           }
       }
   }

// To load the Scroll View
- (void)viewWillAppear:(BOOL)animated {
   	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter] addObserver: self 
											 selector: @selector(keyboardWasShown:)
												 name: UIKeyboardDidShowNotification 
											   object: nil];
	
    [[NSNotificationCenter defaultCenter] addObserver: self
											 selector: @selector(keyboardWasHidden:)
												 name: UIKeyboardDidHideNotification 
											   object: nil];
   	scrollView.frame = CGRectMake(0, 0, 320, 460);
	scrollView.contentSize = CGSizeMake(320, 500);
}

-(void) viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]
	 removeObserver:self];
}

-(void) keyboardWasShown: (NSNotification *)notif {
    return;
}

-(void) keyboardWasHidden: (NSNotification *)notif {
    return;
}

- (void)search:(id)sender{
	searchObj = ((BlackBookView*)self.view).searchObject;
	if (searchObj.dealerLot == 0) {
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Invalid DealerLot"
															message:@"Please Pick a Dealer Lot."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}
   	[[appDelegate currentInstance] saveSearch:searchObj];
	SearchResultsController *src = [SearchResultsController new];
	[self.navigationController pushViewController:src animated:YES];
	[src startSearch:searchObj];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [latsetTextField resignFirstResponder];
    latsetTextField=nil;
    selectedRow=0;
	return YES;
}

-(void) editDetail
{
    UIBarButtonItem *saveBtn = [[UIBarButtonItem alloc] initWithTitle:@"Save" style:UIBarButtonItemStyleDone target:self action:@selector(saveDetail)];
    saveBtn.style = UIBarButtonItemStyleBordered;
    
    self.navigationItem.rightBarButtonItem = saveBtn;
    
    if([self.navigationItem.rightBarButtonItem.title isEqualToString:@"Save"])
    {
        if([self checkMandatory])
        {
            [self.navigationItem.rightBarButtonItem setStyle:UIBarButtonSystemItemSave];
            [self.navigationItem.rightBarButtonItem setEnabled:YES];
        }
        else 
        {
            [self.navigationItem.rightBarButtonItem setStyle:UIBarButtonItemStylePlain];
            [self.navigationItem.rightBarButtonItem setEnabled:NO];    
        }
    }
}
-(void) saveDetail
{
    isRefreshBookValuesDataOnDetails=YES;
    [self loadingView];
    NSMutableDictionary *dic;
    if([self.title isEqualToString:@"Black Book"])
            dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:24],@"reqtype", providerType,@"providerType",txt_Year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", txt_trim.text,@"trim",txt_style.text,@"style",self,@"delegate", nil];
    else
        dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:24],@"reqtype", providerType,@"providerType",txt_Year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", txt_trim.text,@"trim",self,@"delegate", nil]; 
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
}
- (void)dealloc {
	searchObj = nil;
}
#pragma mark UIPickerView delegate methods
// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
     if([pickerView isEqual: pickerYear]) {  
    return 1;
     }
    return 0;
}
// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
   if([pickerView isEqual: pickerYear]) { 
    //if((UITextField*)latsetTextField == txt_blackbookmoreoptions)
       // return entries.count;
    return oneDataSource.count ;
   }
    return 0;
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if([pickerView isEqual: pickerYear]) {
    return [oneDataSource objectAtIndex:row] ;
    }
    return 0;
}
- (void)pickerView:(UIPickerView *)thePickerView 
      didSelectRow:(NSInteger)row 
       inComponent:(NSInteger)component {
    selectedRow=row;
    if((UITextField*)latsetTextField == txt_style || ((UITextField*)latsetTextField == txt_trim && ![self.title isEqualToString:@"Black Book"]))
    {
        if(row > 0)
            [latsetTextField  setText:[oneDataSource objectAtIndex:row]] ;
        else
            [latsetTextField setText:@""];
    }
}
- (void)showPicker:(id)sender{
    int row1 = 0;
	if(sender == txt_Year)
	{
        oneDataSource = [NSMutableArray arrayWithArray:arrayOfdataProviderYears] ;
        [oneDataSource insertObject:@"-year-"atIndex:0];
        if([txt_Year.text length] > 0)
            row1=[arrayOfdataProviderYears indexOfObject:txt_Year.text]+1;
    }  
    else if(sender == txt_make)
    {
        oneDataSource = [NSMutableArray arrayWithArray:arrayOfdataProviderMakes] ; 
        [oneDataSource insertObject:@"-make-"atIndex:0];
        if([txt_make.text length] > 0)
            row1=[arrayOfdataProviderMakes indexOfObject:txt_make.text]+1;
    }
    else if(sender == txt_model)
    {
        oneDataSource = [NSMutableArray arrayWithArray:arrayOfdataProviderModels] ;
        [oneDataSource insertObject:@"-model-"atIndex:0];
        if([txt_model.text length] > 0)
            row1=[arrayOfdataProviderModels indexOfObject:txt_model.text]+1;
    }
    else if(sender == txt_trim)
    {
        oneDataSource = [NSMutableArray arrayWithArray:arrayOfdataProviderTrims] ;
        [oneDataSource insertObject:@"-trim-"atIndex:0];
        if([txt_trim.text length] > 0)
            row1=[arrayOfdataProviderTrims indexOfObject:txt_trim.text]+1;
    }
    else if(sender == txt_style)
    {
        oneDataSource = [NSMutableArray arrayWithArray:arrayOfdataProviderStyles] ;
        [oneDataSource insertObject:@"-style-"atIndex:0];
        if([txt_style.text length] > 0)
            row1=[arrayOfdataProviderStyles indexOfObject:txt_style.text]+1;
    }
    else if(sender == txt_blackbookoptions)
    {
        oneDataSource = [NSMutableArray arrayWithArray:arrayOfdataProviderClean] ;
        [oneDataSource insertObject:@"-Condition-"atIndex:0];
        if([txt_blackbookoptions.text length] > 0)
            row1=[arrayOfdataProviderClean indexOfObject:txt_blackbookoptions.text]+1;
    }
    else if(sender == txt_blackbookmoreoptions)
    {
        oneDataSource = [NSMutableArray arrayWithArray:arrayOfdataProviderExtra] ;
        [oneDataSource insertObject:@"-More Condition-"atIndex:0];
        if([txt_blackbookmoreoptions.text length] > 0)
            row1=[arrayOfdataProviderExtra indexOfObject:txt_blackbookmoreoptions.text]+1;
    }
		[pickerYear reloadComponent:0];
		[pickerYear selectRow:row1 inComponent:0 animated:NO];
		
		[UIView beginAnimations:@"FadeIn" context:nil];
		[UIView setAnimationDuration:0.7];
		_pickerYearDone.alpha = 1.0;
        conditionPicker.alpha=1.0;
		pickerYear.alpha = 1.0;
		[UIView commitAnimations];
       selectedRow = row1;
}
- (void)pickerCancel:(id)sender{
    [latsetTextField resignFirstResponder];
    latsetTextField=nil;
    selectedRow=0;
}
- (void)pickerDone:(id)sender{
    if((UITextField*)latsetTextField == txt_blackbookoptions )
    {
        isRefreshBookValuesDataOnDetails=YES;
        if(selectedRow >0)
        {
            [latsetTextField  setText:[oneDataSource objectAtIndex:selectedRow]] ;
        }
        else
            [latsetTextField setText:@""];
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Confirm"
                                                            message:@"Do you want to check options?"
                                                           delegate:self
                                                  cancelButtonTitle:@"No"
                                                  otherButtonTitles:@"Yes",nil];
        [alertView show];
    }
    if((UITextField*)latsetTextField == txt_Year)
    {
        txt_make.text=@"";
        txt_model.text=@"";
        txt_trim.text=@"";
        txt_style.text=@"";
        if(selectedRow >0)
        {
            [latsetTextField  setText:[oneDataSource objectAtIndex:selectedRow]] ;
            [self loadingView];
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:13],@"reqtype", self.providerType,@"providerType",txt_Year.text,@"year", self,@"delegate", nil];
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            [ws initialize:dic];
            [ws callWSWithQuery:dic];
        }
        else
            [latsetTextField setText:@""];
        [arrayOfdataProviderMakes removeAllObjects];
        [arrayOfdataProviderModels removeAllObjects];
        [arrayOfdataProviderTrims removeAllObjects];
        [arrayOfdataProviderStyles removeAllObjects];
    }
    else if((UITextField*)latsetTextField == txt_make)
    {
        txt_model.text=@"";
        txt_trim.text=@"";
        txt_style.text=@"";
        if(selectedRow>0)
        {
             [latsetTextField  setText:[oneDataSource objectAtIndex:selectedRow]] ;
            [self loadingView];
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:14],@"reqtype", self.providerType,@"providerType",txt_Year.text,@"year",txt_make.text,@"make", self,@"delegate", nil];
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            [ws initialize:dic];
            [ws callWSWithQuery:dic];
        }
        else
            [latsetTextField setText:@""];
        [arrayOfdataProviderModels removeAllObjects];
        [arrayOfdataProviderTrims removeAllObjects];
        [arrayOfdataProviderStyles removeAllObjects];
    }
    else if((UITextField*)latsetTextField == txt_model)
    {
        txt_trim.text=@"";
        txt_style.text=@"";
        if(selectedRow>0)
        {
             [latsetTextField  setText:[oneDataSource objectAtIndex:selectedRow]] ;
            [self loadingView];
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:15],@"reqtype", self.providerType,@"providerType",txt_Year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", self,@"delegate", nil];
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            [ws initialize:dic];
            [ws callWSWithQuery:dic];
        }
        else
            [latsetTextField setText:@""];
        [arrayOfdataProviderTrims removeAllObjects];
        [arrayOfdataProviderStyles removeAllObjects];
    }
    else if((UITextField*)latsetTextField == txt_trim && [self.title isEqualToString:@"Black Book"])
    {
        txt_style.text=@"";
        if(selectedRow >0)
        {
             [latsetTextField  setText:[oneDataSource objectAtIndex:selectedRow]] ;
            [self loadingView];
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:16],@"reqtype", self.providerType,@"providerType",txt_Year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", txt_trim.text,@"trim",self,@"delegate", nil];
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            [ws initialize:dic];
            [ws callWSWithQuery:dic];
        }
        else
            [latsetTextField setText:@""];
        [arrayOfdataProviderStyles removeAllObjects];
    }
    [latsetTextField resignFirstResponder];
    latsetTextField = nil;
    selectedRow=0;
    if([self.navigationItem.rightBarButtonItem.title isEqualToString:@"Save"])
    {
        if([self checkMandatory])
        {
            [self.navigationItem.rightBarButtonItem setStyle:UIBarButtonSystemItemSave];
            [self.navigationItem.rightBarButtonItem setEnabled:YES];
        }
        else
        {
            [self.navigationItem.rightBarButtonItem setStyle:UIBarButtonItemStylePlain];
            [self.navigationItem.rightBarButtonItem setEnabled:NO];
        }
    }
}
- (void)showTableView:(id)sender{
    if(alpickerView.hidden)
    {
    CGRect textFieldRect = [scrollView convertRect:((UITextField*)latsetTextField).bounds fromView:latsetTextField];
    CGRect viewRect = [scrollView convertRect:scrollView.bounds fromView:scrollView];
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
	midline - viewRect.origin.y
	- MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
	(MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
	* viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    UIInterfaceOrientation orientation =
	[[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationPortrait ||
        orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    }
    else
    {
        animatedDistance = floor(LANDSCAPE_KEYBOARD_HEIGHT * heightFraction);
    }
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [scrollView setFrame:viewFrame];
    [UIView commitAnimations];
    alpickerView.hidden = NO;
    _pickerDone.hidden=NO;
    [self.view bringSubviewToFront:alpickerView];
    [self.view bringSubviewToFront:_pickerDone];
    [UIView beginAnimations:@"FadeIn" context:nil];
    [UIView setAnimationDuration:0.7];
    alpickerView.alpha = 1.0;
    _pickerDone.alpha = 1.0;
    [UIView commitAnimations];
    }
}
- (void)pickerTableCancel:(id)sender{
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y += animatedDistance;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [scrollView setFrame:viewFrame];
    [UIView commitAnimations];
    
    alpickerView.hidden=YES;
    _pickerDone.hidden=YES;
    [UIView beginAnimations:@"FadeOut" context:nil];
	[UIView setAnimationDuration:0.7];
	_pickerDone.alpha = 0.0;
	alpickerView.alpha = 0.0;
	[UIView commitAnimations];
    latsetTextField=nil;
    selectedRow=0;
    
    NSString *string=@"";
    txt_blackbookmoreoptions.text=@"";
    for (int optionIndex=0; optionIndex<[entries count]; optionIndex++) {
        if([[selectionStates objectForKey:[entries objectAtIndex:optionIndex] ] boolValue])
        {
            if([txt_blackbookmoreoptions.text length] > 0)
                string = [string stringByAppendingString:[NSString stringWithFormat:@" | %@",[entries objectAtIndex:optionIndex]]];
            else
                string = [entries objectAtIndex:optionIndex];
        }
        txt_blackbookmoreoptions.text=string;
    }
}
- (void)pickerTableDone:(id)sender{
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y += animatedDistance;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [scrollView setFrame:viewFrame];
    [UIView commitAnimations];
    alpickerView.hidden=YES;
    _pickerDone.hidden=YES;
    [UIView beginAnimations:@"FadeOut" context:nil];
	[UIView setAnimationDuration:0.7];
	_pickerDone.alpha = 0.0;
	alpickerView.alpha = 0.0;
	[UIView commitAnimations];
    
    isRefreshBookValuesDataOnDetails=YES;
     NSString *string=@"";
    txt_blackbookmoreoptions.text=@"";
    for (int optionIndex=0; optionIndex<[entries count]; optionIndex++) {
        if([[selectionStates objectForKey:[entries objectAtIndex:optionIndex] ] boolValue])
        {
            if([txt_blackbookmoreoptions.text length] > 0)
                string = [string stringByAppendingString:[NSString stringWithFormat:@" | %@",[entries objectAtIndex:optionIndex]]];
            else
                string = [entries objectAtIndex:optionIndex];
        }
        txt_blackbookmoreoptions.text=string;
    }
    if((UITextView*)latsetTextField == txt_blackbookmoreoptions)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Confirm"
                                                            message:@"Do you want to check condition?"
                                                           delegate:self
                                                  cancelButtonTitle:@"No"
                                                  otherButtonTitles:@"Yes",nil];
        [alertView show];
    }
    latsetTextField=nil;
    selectedRow=0;
}
#pragma mark UITextField delegate methods

- (BOOL)textFieldShouldClear:(UITextField *)textField {
	return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if(isAppraisal)
    {
    if([self.navigationItem.rightBarButtonItem.title isEqualToString:@"Save"])
    {
        if (textField == txt_Year || textField == txt_make || textField == txt_model || textField == txt_trim || textField == txt_style ) {
            [self showPicker:textField];
            return YES;
        }
    }
    else    
    {
        if (textField == txt_blackbookoptions ) {
           if(!alpickerView.hidden)
           {
            CGRect viewFrame = scrollView.frame;
            viewFrame.origin.y += animatedDistance;
            [UIView beginAnimations:nil context:NULL];
            [UIView setAnimationBeginsFromCurrentState:YES];
            [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
            [scrollView setFrame:viewFrame];
            
            [UIView commitAnimations];
            
            alpickerView.hidden=YES;
            _pickerDone.hidden=YES;
            [UIView beginAnimations:@"FadeOut" context:nil];
            [UIView setAnimationDuration:0.7];
            _pickerDone.alpha = 0.0;
            alpickerView.alpha = 0.0;
            [UIView commitAnimations];
           }
            
        [self showPicker:textField];
        return YES;
        } 
        
    }
    }
    [textField resignFirstResponder]; 
    return NO;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    latsetTextField = textField;
    CGRect textFieldRect = [scrollView convertRect:textField.bounds fromView:textField];
    CGRect viewRect = [scrollView convertRect:scrollView.bounds fromView:scrollView];
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
	midline - viewRect.origin.y
	- MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
	(MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
	* viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    UIInterfaceOrientation orientation =
	[[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationPortrait ||
        orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    }
    else
    {
        animatedDistance = floor(LANDSCAPE_KEYBOARD_HEIGHT * heightFraction);
    }
	
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [scrollView setFrame:viewFrame];
    
    [UIView commitAnimations];
}

-(void) textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y += animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [scrollView setFrame:viewFrame];
    [UIView commitAnimations];
    
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
	BOOL result = NO; //default to reject
    
    if (textField == txt_Year || textField == txt_make || textField == txt_model || textField == txt_trim || textField == txt_style  || textField == txt_blackbookoptions ) {
        NSString* newText = [textField.text stringByReplacingCharactersInRange:range withString:string];
        if(textField == txt_Year)
        {
            if([arrayOfdataProviderYears containsObject:newText])
            {
                result = YES;
            }
        }
        else if(textField == txt_make)
        {
            if([arrayOfdataProviderMakes containsObject:newText])
            {
                result = YES;
            }
        }
        else if(textField == txt_model)
        {
            if([arrayOfdataProviderModels containsObject:newText])
            {
                result = YES;
            }
        }
        else if(textField == txt_trim)
        {
            if([arrayOfdataProviderTrims containsObject:newText])
            {
                result = YES;
            }
        }
        else if(textField == txt_style)
        {
            if([arrayOfdataProviderStyles containsObject:newText])
            {
                result = YES;
            }
        }
        else if(textField == txt_blackbookoptions)
        {
            if([arrayOfdataProviderClean containsObject:newText])
            {
                result = YES;
            }
        }
    }
    return result;
}
# pragma mark - UITextView Delegate

-(void) textViewDidBeginEditing:(UITextView *)textView
{
    latsetTextField = textView;
    CGRect textFieldRect = [scrollView convertRect:textView.bounds fromView:textView];
    CGRect viewRect = [scrollView convertRect:scrollView.bounds fromView:scrollView];
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
	midline - viewRect.origin.y
	- MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
	(MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
	* viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
    UIInterfaceOrientation orientation =
	[[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationPortrait ||
        orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    }
    else
    {
        animatedDistance = floor(LANDSCAPE_KEYBOARD_HEIGHT * heightFraction);
    }
	
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [scrollView setFrame:viewFrame];
    
    [UIView commitAnimations];
}

-(void) textViewDidEndEditing:(UITextView *)textView
{
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y += animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [scrollView setFrame:viewFrame];
    [UIView commitAnimations];

}

-(BOOL) textViewShouldBeginEditing:(UITextView *)textView
{
    if(isAppraisal)
    {
        if (textView == txt_blackbookmoreoptions ) {
            if(latsetTextField!=nil)
            {
                [latsetTextField resignFirstResponder];
                latsetTextField=nil;
                selectedRow=0;
            }
            latsetTextField = textView;
            [self showTableView:textView];
            return NO;
        }
    }
    [textView resignFirstResponder];
    return NO;
}
-(BOOL) textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    BOOL result = NO; //default to reject
    
    if (textView == txt_blackbookmoreoptions) {
        NSString* newText = [textView.text stringByReplacingCharactersInRange:range withString:text];
            if([entries containsObject:newText])
            {
                result = YES;
            }
    }
    return result;

}
- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:message
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}

#pragma mark alertview delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if([alertView.title isEqualToString:@"Confirm"])
    {
        if(buttonIndex==1)
        {
            if([alertView.message isEqualToString:@"Do you want to check options?"])
                [txt_blackbookmoreoptions becomeFirstResponder];
           else
               [txt_blackbookoptions becomeFirstResponder];
           [alertView dismissWithClickedButtonIndex:buttonIndex animated:YES];
        }
        else
        {
        [self loadingView];
        NSMutableArray *array=[[NSMutableArray alloc]init];
        for (int optionIndex=0; optionIndex<[entries count]; optionIndex++) {
            if([[selectionStates objectForKey:[entries objectAtIndex:optionIndex] ] boolValue])
            {
                [array addObject:[entries objectAtIndex:optionIndex]];
            }
        }
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:22],@"reqtype", self.providerType,@"providerType",  str_appraisalid,@"appraisalid",providerCode,@"providerCode",txt_blackbookoptions.text,@"vehicleValuationCondition",[NSArray arrayWithObjects:array, nil],@"selectedOptionNames" ,self,@"delegate", nil];
        
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
        refreshDataOn=YES;
        }
    }
    else {
    if(reqType==4 || reqType==12)
    {
        [self stopLoadingView];
        [[self navigationController] popViewControllerAnimated:YES];
    }
    else {
         [self stopLoadingView];
    }
    }
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}


-(BOOL) checkMandatory
{
    BOOL check=NO;
        if([txt_Year.text length]>0)
        {
            if([txt_make.text length] > 0)
            {
                if([txt_model.text length] > 0)
                {
                    if([txt_trim.text length] > 0)
                    {
                        if([self.title isEqualToString:@"Black Book"])
                        {
                        if([txt_style.text length] > 0)
                        {
                            check=YES;
                        }
                        }
                        else {
                            check=YES;
                        }
                    }
                }
            }
        }
    return check;
}

#pragma mark -
#pragma mark ALPickerView delegate methods

- (NSInteger)numberOfRowsForPickerView:(ALPickerView *)pickerView {
	return [entries count];
}

- (NSString *)pickerView:(ALPickerView *)pickerView textForRow:(NSInteger)row {
	return [entries objectAtIndex:row];
}

- (BOOL)pickerView:(ALPickerView *)pickerView selectionStateForRow:(NSInteger)row {
	return [[selectionStates objectForKey:[entries objectAtIndex:row]] boolValue];
}

- (void)pickerView:(ALPickerView *)pickerView didCheckRow:(NSInteger)row {
	// Check whether all rows are checked or only one
	if (row == -1)
		for (id key in [selectionStates allKeys])
			[selectionStates setObject:[NSNumber numberWithBool:YES] forKey:key];
	else
		[selectionStates setObject:[NSNumber numberWithBool:YES] forKey:[entries objectAtIndex:row]];
}
- (void)pickerView:(ALPickerView *)pickerView didUncheckRow:(NSInteger)row {
	// Check whether all rows are unchecked or only one
	if (row == -1)
		for (id key in [selectionStates allKeys])
			[selectionStates setObject:[NSNumber numberWithBool:NO] forKey:key];
	else
		[selectionStates setObject:[NSNumber numberWithBool:NO] forKey:[entries objectAtIndex:row]];
}
// remove part string
-(NSString*) stringByRemovingRange:(NSString*) theString theRange:(NSRange) theRange {
    NSString* part1 = [theString substringToIndex:theRange.location];
    NSString* part2 = [theString substringFromIndex:theRange.location+theRange.length];
    return [part1 stringByAppendingString:part2];
}

-(void) backAction
{
    if(isRefreshBookValuesDataOnDetails || refreshDataOn)
    {
        self.appraisalDetailsController.refreshDataOn=YES;
    }
    [self.navigationController popViewControllerAnimated:YES];
}
@end
