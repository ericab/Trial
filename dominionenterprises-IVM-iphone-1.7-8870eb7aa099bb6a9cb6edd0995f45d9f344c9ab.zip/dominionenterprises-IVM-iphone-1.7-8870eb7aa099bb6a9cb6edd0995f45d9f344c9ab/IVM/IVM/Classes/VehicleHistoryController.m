//
//  VehicleHistoryController.m
//  IVM
//
//  Created by evokemacmini on 6/18/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "VehicleHistoryController.h"
#import "appDelegate.h"
@interface VehicleHistoryController ()

@end

@implementation VehicleHistoryController

- (id) init
{
	self = [super init];
	if (self != nil) {
		self.title = @"Vehicle History";
		[appDelegate track:@"Vehicle History"];
	}
    
	return self;
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
-(void) handleResponseForQuery:(NSMutableDictionary *)response
{

}

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {


    crc = [[CarfaxReportController alloc] initWithNibName:@"CarfaxReportController_iPhone" bundle:nil];
    
	//asv.errorCallback = @selector(advSearchError:);
	
    

}
-(void) loadingView
{
    //Popup the loading view
    searchView = [[SearchResultsView alloc] initWithFrame:CGRectMake(100.0f, 50.0f, 0.0f, 0.0f)];
    //searchView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    [crc addSubview:searchView];
    
    [searchView.activityIndicator startAnimating];
}
@end
