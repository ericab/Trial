//
//  SearchResultCell.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/25/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>
@class NetImageView;

@interface SearchResultCell : UITableViewCell {
	NetImageView	*netImage;
//	UILabel		*distance;
	UILabel		*price;
	UILabel		*mileage;
	UILabel		*vehicle;
	UILabel		*bodytype;
	UILabel		*colors;
	UILabel		*mlsNumber;
	NetImageView *certifiedLogo;
}

@property(nonatomic, strong)	NetImageView	*netImage;
//@property(nonatomic, retain)	UILabel		*distance;
@property(nonatomic, strong)	UILabel		*price;
@property(nonatomic, strong)	UILabel		*mileage;
@property(nonatomic, strong)	UILabel		*vehicle;
@property(nonatomic, strong)	UILabel		*bodytype;
@property(nonatomic, strong)	UILabel		*colors;
@property(nonatomic, strong)	UILabel		*mlsNumber;
@property(nonatomic, strong)	NetImageView	*certifiedLogo;

@end
