//
//  AppraisalDetails.h
//  IVM
//
//  Created by Raja Sekhar Nerella on 28/05/12.

//

#import <Foundation/Foundation.h>

@interface AppraisalDetails : NSObject

    


    

@end
