//
//  VehicleResult.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/18/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <Foundation/Foundation.h>

/*<VEHICLE 
 Vehicle_Key="14975252"
 Latitude="36.7003000000"
 Longitude="-76.5916000000"
 Name="Mike Duman Auto Sales"
 Address="2300 Godwin Blvd."
 Address2=""
 City="Suffolk"
 State="VA"
 Postal_Code="23434"
 Vin="1HGCM56117A178844"
 StockNumber="36899"
 Make="Honda"
 Model="Accord Value Package"
 Year="2007"
 Price="16495"
 mileage="20034"
 ExternalColor="Alabaster Silver Metallic"
 InternalColor="Black"
 BodyType="4 Dr Sedan"
 TrimLevel="Value Package"
 Transmission="Automatic"
 Image="http://imgs.getauto.com/imgs/ag/ga/88/44/1t/1HGCM56117A178844-1t.jpg"
 Distance="23.32"
 CertifiedLogoUrl=""
 />"*/

@interface VehicleResult : NSObject {
	int			vehicle_key;
//	float		latitude;
//	float		longitude;
//	NSString	*name;
//	NSString	*address;
//	NSString	*address2;
//	NSString	*city;
//	NSString	*state;
//	NSString	*postal_code;
	NSString	*vin;
	NSString	*stockNumber;
	NSString	*make;
	NSString	*model;
	int			year;
	int			price;
	int			mileage;
	NSString	*externalColor;
	NSString	*internalColor;
	NSString	*bodyType;
	NSString	*trimLevel;
	NSString	*transmission;
	NSString	*image;
//	NSString	*certifiedLogoUrl;
//	double		distance;
}


//@property(assign)	float		latitude;
//@property(assign)	float		longitude;
//@property(copy)		NSString	*name;
//@property(copy)		NSString	*address;
//@property(copy)		NSString	*address2;
//@property(copy)		NSString	*city;
//@property(copy)		NSString	*state;
//@property(copy)		NSString	*postal_code;
@property(assign)	int			vehicle_key;
@property(copy)		NSString	*vin;
@property(copy)		NSString	*stockNumber;
@property(copy)		NSString	*make;
@property(copy)		NSString	*model;
@property(assign)	int			year;
@property(assign)	int			price;
@property(assign)	int			mileage;
@property(copy)		NSString	*externalColor;
@property(copy)		NSString	*internalColor;
@property(copy)		NSString	*bodyType;
@property(copy)		NSString	*trimLevel;
@property(copy)		NSString	*transmission;
@property(copy)		NSString	*image;
//@property(copy)		NSString	*certifiedLogoUrl;
//@property(assign)	double		distance;

@end
