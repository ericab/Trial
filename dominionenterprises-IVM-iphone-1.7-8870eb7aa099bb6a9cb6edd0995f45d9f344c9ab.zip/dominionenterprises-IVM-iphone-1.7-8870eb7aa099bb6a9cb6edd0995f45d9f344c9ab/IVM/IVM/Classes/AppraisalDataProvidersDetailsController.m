//
//  AppraisalDataProvidersDetailsController.m
//  IVM
//
//  Created by Raja Sekhar Nerella on 16/05/12.
//  
//

#import "AppraisalDataProvidersDetailsController.h"

#import "BlackBookController.h"
#import "NADAController.h"
#import "GalvesController.h"
#import "KellyBlueBookController.h"
#import "appDelegate.h"

@implementation AppraisalDataProvidersDetailsController
@synthesize reqType;
@synthesize appraisalDetailsController;
@synthesize isAppraisal;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
     dataProviders = [NSMutableArray array];
    dataProvider = @"";
    UIView *view = [[UIView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    [view setAutoresizingMask:UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth];
    [view setBackgroundColor:[UIColor whiteColor]];
    UIImageView *backgroundImage=  [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];;
    [view addSubview:backgroundImage];
    [view sendSubviewToBack:backgroundImage];
    
    scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    scrollView.scrollEnabled = YES;
    [view addSubview:scrollView];
    
    UIColor *textColor = [UIColor blackColor];
    UIFont *lblFont = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0];
    
    float yOffset = 10.0f;
    
    //Data Providers
   UILabel * tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Data Providers";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_dataproviders = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_dataproviders.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_dataproviders.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_dataproviders.placeholder = @"Data Providers";
    txt_dataproviders.returnKeyType = UIReturnKeyDone;
    txt_dataproviders.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_dataproviders.delegate = self;
    txt_dataproviders.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [scrollView addSubview:txt_dataproviders];
    
    //Picker View Creation		
    _pickerDone = [UIToolbar new];
    [_pickerDone sizeToFit];
    _pickerDone.frame = CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 215.0f - 42.0f, [UIScreen mainScreen].applicationFrame.size.width, _pickerDone.frame.size.height);
    _pickerDone.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
    _pickerDone.barStyle = UIBarStyleBlack;
    _pickerDone.contentMode = UIViewContentModeRight;
    UIBarButtonItem *cancel = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(pickerCancel:)];
    
    UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(pickerDone:)];
    UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [_pickerDone setItems:[NSArray arrayWithObjects:cancel,spacer, done, nil] animated:NO];

    //DealerLot/Year Picker
    pickerOne = [[UIPickerView alloc] initWithFrame:CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 215.0f, [UIScreen mainScreen].applicationFrame.size.width, 0.0f)];
    pickerOne.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    pickerOne.showsSelectionIndicator = YES;
    pickerOne.delegate = self;
    pickerOne.dataSource = self;
    txt_dataproviders.inputView = pickerOne;
    txt_dataproviders.inputAccessoryView = _pickerDone;
    self.view = view;
    
    if (loadingView == nil) {
        loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
    }

}
-(void) handleResponseForQuery:(NSMutableDictionary *)response
{
    reqType=0;
    arrayOfdataProviders = [[response objectForKey:@"response"] objectForKey:@"dataproviders"];
    dataProviders = [[NSMutableArray alloc]initWithCapacity:[arrayOfdataProviders count]];
    isMappedArray = [[NSMutableArray alloc]initWithCapacity:[arrayOfdataProviders count]];
    if ([arrayOfdataProviders count]>0) {
        for (int i=0; i< [arrayOfdataProviders count]; i++) {
            dataProviderDetails = [arrayOfdataProviders objectAtIndex:i];
                        [isMappedArray addObject:[ NSString stringWithString: [dataProviderDetails objectForKey:@"ismapped"]]];
            NSString *szdataprovider =[ NSString stringWithString: [dataProviderDetails objectForKey:@"providertype"]];
            if([szdataprovider isEqualToString:@"BlackBook"])
                szdataprovider=@"Black Book";
            else  if([szdataprovider isEqualToString:@"KelleyBlueBook"])
                szdataprovider=@"KBB";
            else  if([szdataprovider isEqualToString:@"Nada"])
                szdataprovider=@"NADA";
            [dataProviders addObject:szdataprovider];
        }
        
    }
    [txt_dataproviders becomeFirstResponder];
    if (loadingView != nil)
    {
        [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
        loadingView = nil;
    }
}
#pragma mark UIPickerView delegate methods
    
    // returns the number of 'columns' to display.
    - (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
        if([pickerView isEqual: pickerOne]) {
            return 1;
        }         
        return 0;
    }
    // returns the # of rows in each component..
    - (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
        if([pickerView isEqual: pickerOne]) {
            return [oneDataSource count];
        }         
        return 0;
    }
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
        if([pickerView isEqual: pickerOne]) {
            return [oneDataSource objectAtIndex:row];
        } 
        return 0;
    }
- (void)pickerView:(UIPickerView *)thePickerView 
didSelectRow:(NSInteger)row 
inComponent:(NSInteger)component {
    if(row>0)
    {
    txt_dataproviders.text = [oneDataSource objectAtIndex:row];
    dataProvider = [oneDataSource objectAtIndex:row];
                 isMapped  = [isMappedArray objectAtIndex:row-1];
    }
    else
    { 
        txt_dataproviders.text=@"";
        dataProvider = @"";
    }
}
// To load the Scroll View
- (void)viewWillAppear:(BOOL)animated {
   	[super viewWillAppear:animated];
	[[NSNotificationCenter defaultCenter] addObserver: self 
											 selector: @selector(keyboardWasShown:)
												 name: UIKeyboardDidShowNotification 
											   object: nil];
	
    [[NSNotificationCenter defaultCenter] addObserver: self
											 selector: @selector(keyboardWasHidden:)
												 name: UIKeyboardDidHideNotification 
											   object: nil];
	
   	scrollView.frame = CGRectMake(0, 0, 320, 460);
	scrollView.contentSize = CGSizeMake(320, 500);
}
-(void) viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]
	 removeObserver:self];
}

-(void) keyboardWasShown: (NSNotification *)notif {
    return;
}

-(void) keyboardWasHidden: (NSNotification *)notif {
    return;
}
#pragma mark UITextField delegate methods
- (BOOL)textFieldShouldClear:(UITextField *)textField {
	return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if (textField == txt_dataproviders) {
        [self showPicker:textField];
    }
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    latsetTextField = textField;
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
	BOOL result = NO; //default to reject
    
    if (textField == txt_dataproviders) {
        NSString* newText = [textField.text stringByReplacingCharactersInRange:range withString:string];
        if([dataProviders containsObject:newText])
        {
            result = YES;
        }
    }
    return result;
}
- (void)showPicker:(id)sender{
    int row1 = 0;
	if(sender == txt_dataproviders)
	{
        oneDataSource =[NSMutableArray arrayWithArray:dataProviders] ;
        [oneDataSource insertObject:@"-Data providers-" atIndex:0];
        if([dataProvider length] > 0)
            row1=[dataProviders indexOfObject:dataProvider]+1;
		[pickerOne reloadComponent:0];
		[pickerOne selectRow:row1 inComponent:0 animated:NO];
		[UIView beginAnimations:@"FadeIn" context:nil];
		[UIView setAnimationDuration:0.7];
		_pickerDone.alpha = 1.0;
		pickerOne.alpha = 1.0;
		[UIView commitAnimations];
	}
}
- (void)pickerCancel:(id)sender{
    ((UITextField*)latsetTextField).text=dataProvider;
    [latsetTextField resignFirstResponder];
    latsetTextField=nil;
}
- (void)pickerDone:(id)sender{
    ((UITextField*)latsetTextField).text=dataProvider;
    if(![dataProvider isEqualToString:@""])
    {
    BlackBookController *blackBookController = [[BlackBookController alloc]init];
    blackBookController.reqType=4;
    NSMutableDictionary *dic ;
    if([dataProvider isEqualToString:@"Black Book"])
        blackBookController.providerType=@"BlackBook";
    else  if([dataProvider isEqualToString:@"KBB"])
        blackBookController.providerType=@"KelleyBlueBook";
    else  if([dataProvider isEqualToString:@"NADA"])
        blackBookController.providerType=@"Nada";
    else 
        blackBookController.providerType=dataProvider;
    blackBookController.title=dataProvider;
    blackBookController.str_appraisalid=str_appraisalid;
    blackBookController.appraisalDetailsController=self.appraisalDetailsController;
    blackBookController.isAppraisal=isAppraisal;
    if(blackBookController.isAppraisal)
    {
        if ([isMapped isEqualToString:@"false"]) 
        {
            blackBookController.isMapped=NO;
           dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:12],@"reqtype", blackBookController.providerType,@"providerType", blackBookController,@"delegate", nil];
       }
        else
        {
            blackBookController.isMapped=YES;
        dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:4],@"reqtype", str_appraisalid,@"appraisalid",blackBookController.providerType,@"providerType", blackBookController,@"delegate", nil];
        }
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
        [self.navigationController pushViewController:blackBookController animated:YES];
    }
    else {
        if ([isMapped isEqualToString:@"false"]) 
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Status"
             message:@"No data currently available from this provider."
             delegate:nil
             cancelButtonTitle:@"Ok"
             otherButtonTitles:nil];
             [alertView show];
             return;
        }
        else
        {
            blackBookController.isMapped=YES;
            dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:4],@"reqtype", str_appraisalid,@"appraisalid",blackBookController.providerType,@"providerType" ,blackBookController,@"delegate", nil];
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            [ws initialize:dic];
            [ws callWSWithQuery:dic];
            [self.navigationController pushViewController:blackBookController animated:YES];
        }
    }
    }
    else
    {
        [latsetTextField resignFirstResponder];
        latsetTextField=nil;
    }
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:message
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}
#pragma mark alertview delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(reqType==11)
    {
        if (loadingView != nil)
        {
            [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
            loadingView = nil;
        }
        [[self navigationController] popViewControllerAnimated:YES];
    }
    else {
    if (loadingView != nil)
    {
        [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
        loadingView = nil;
    }   
    }  
}
@end
