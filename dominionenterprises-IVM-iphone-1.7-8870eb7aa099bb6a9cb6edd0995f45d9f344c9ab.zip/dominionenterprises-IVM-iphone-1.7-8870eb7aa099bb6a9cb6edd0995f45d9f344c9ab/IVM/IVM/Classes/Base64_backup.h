//
//  Base64.h
//  GetAuto.com
//
//  Created by Shaofeng Tu on 7/15/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Base64 : NSObject{
}

+ (NSString*) encode:(NSData*) rawBytes;
+ (NSData*) decode:(NSString*) string;
+ (NSString*) encode:(const uint8_t*) input length:(NSInteger) length;
+ (NSData*) decode:(const char*) string length:(NSInteger) inputLength;

@end
