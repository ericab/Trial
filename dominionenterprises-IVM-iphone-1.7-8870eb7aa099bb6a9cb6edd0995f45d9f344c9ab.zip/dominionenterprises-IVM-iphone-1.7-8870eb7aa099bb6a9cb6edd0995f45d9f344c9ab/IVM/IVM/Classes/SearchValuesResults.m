//
//  SearchValuesResults.m
//  GetAuto.com
//
//  Created by Shaofeng Tu on 6/30/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import "SearchValuesResults.h"


@implementation SearchValuesResults

@synthesize totalCount;
@synthesize listings;

- (id) init
{
	self = [super init];
	if (self != nil) {
		listings = [NSMutableArray new];
	}
	return self;
}


@end
