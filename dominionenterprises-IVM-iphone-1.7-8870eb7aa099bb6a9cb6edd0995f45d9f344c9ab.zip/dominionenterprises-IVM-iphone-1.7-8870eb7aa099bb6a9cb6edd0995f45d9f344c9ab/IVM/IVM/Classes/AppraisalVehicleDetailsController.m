//
//  AppraisalVehicleDetailsController.m
//  IVM
//
//  Created by Raja Sekhar Nerella on 16/05/12.
//  
//

#import "AppraisalVehicleDetailsController.h"

@implementation AppraisalVehicleDetailsController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
#pragma mark - View lifecycle
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    UIView *view = [[UIView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    [view setAutoresizingMask:UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth];
    [view setBackgroundColor:[UIColor whiteColor]];
    UIImageView *backgroundImage=  [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];;
    [view addSubview:backgroundImage];
    [view sendSubviewToBack:backgroundImage];
        
    scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    scrollView.scrollEnabled = YES;
    [view addSubview:scrollView];
    
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [numberFormatter setLocale:usLocale];
    UIColor *textColor = [UIColor blackColor];
    UIFont *lblFont = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0];
    float yOffset = 10.0f;
    
    //VIN
    UILabel *tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"VIN";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_vin = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_vin.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_vin.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_vin.placeholder = @"VIN";
    txt_vin.returnKeyType = UIReturnKeyDone;
    txt_vin.autocorrectionType = UITextAutocorrectionTypeNo;
     txt_vin.delegate = self;
    txt_vin.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_vin.text = str_vin;
    [scrollView addSubview:txt_vin];
    yOffset += 30.0f;
    
    //Year
     tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Year";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_year = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_year.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_year.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_year.placeholder = @"Year";
    txt_year.returnKeyType = UIReturnKeyDone;
    txt_year.autocorrectionType = UITextAutocorrectionTypeNo;
     txt_year.delegate = self;
    txt_year.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_year.text = str_year;
    [scrollView addSubview:txt_year];
    yOffset += 30.0f;
    
    //Make
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Make";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_make = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_make.borderStyle = UITextBorderStyleRoundedRect;
    txt_make.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_make.placeholder = @"Make";
    txt_make.returnKeyType = UIReturnKeyDone;
    txt_make.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_make.delegate = self;
    txt_make.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_make.text = str_make;
    [scrollView addSubview:txt_make];
    yOffset += 30.0f;
    
    //Model
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Model";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_model = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_model.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_model.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_model.placeholder = @"Model";
    txt_model.returnKeyType = UIReturnKeyDone;
    txt_model.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_model.delegate = self;
    txt_model.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_model.text = str_model;
    [scrollView addSubview:txt_model];
    yOffset += 30.0f;
    
    //Trim
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Trim";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_trim = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_trim.borderStyle = UITextBorderStyleRoundedRect;
    txt_trim.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_trim.placeholder = @"Trim";
    txt_trim.returnKeyType = UIReturnKeyDone;
    txt_trim.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_trim.delegate = self;
    txt_trim.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_trim.text = str_trim;
    [scrollView addSubview:txt_trim];
    yOffset += 30.0f;

    //Style
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Style";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_style = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_style.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_style.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_style.placeholder = @"Style";
    txt_style.returnKeyType = UIReturnKeyDone;
    txt_style.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_style.delegate = self;
    txt_style.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_style.text = str_style;
    [scrollView addSubview:txt_style];
    yOffset += 30.0f;

    //Mileage
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Mileage";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_mileage = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_mileage.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_mileage.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_mileage.placeholder = @"Mileage";
    txt_mileage.returnKeyType = UIReturnKeyDone;
    txt_mileage.autocorrectionType = UITextAutocorrectionTypeNo;
     txt_mileage.delegate = self;
    txt_mileage.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_mileage.text = [NSString stringWithFormat:@"%@ mi",[numberFormatter stringFromNumber:[NSNumber numberWithInt:[str_mileage intValue]]]];
    [scrollView addSubview:txt_mileage];
    yOffset += 30.0f;
    
    //Exterior Color
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Exterior Color";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_exteriorcolor = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_exteriorcolor.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_exteriorcolor.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_exteriorcolor.placeholder = @"Exterior Color";
    txt_exteriorcolor.returnKeyType = UIReturnKeyDone;
    txt_exteriorcolor.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_exteriorcolor.delegate = self;
    txt_exteriorcolor.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_exteriorcolor.text = str_exteriorcolor;
    [scrollView addSubview:txt_exteriorcolor];
    yOffset += 30.0f;
    
    //interior Color
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Interior Color";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_interiorcolor = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_interiorcolor.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_interiorcolor.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_interiorcolor.placeholder = @"Interior Color";
    txt_interiorcolor.returnKeyType = UIReturnKeyDone;
    txt_interiorcolor.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_interiorcolor.delegate = self;
    txt_interiorcolor.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_interiorcolor.text = str_interiorcolor;
    [scrollView addSubview:txt_interiorcolor];
    self.view = view;
}

// To load the Scroll View
- (void)viewWillAppear:(BOOL)animated {
   	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter] addObserver: self 
											 selector: @selector(keyboardWasShown:)
												 name: UIKeyboardDidShowNotification 
											   object: nil];
    [[NSNotificationCenter defaultCenter] addObserver: self
											 selector: @selector(keyboardWasHidden:)
												 name: UIKeyboardDidHideNotification 
											   object: nil];
   	scrollView.frame = CGRectMake(0, 0, 320, 460);
	scrollView.contentSize = CGSizeMake(320, 550);
}
-(void) viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]
	 removeObserver:self];
}
-(void) keyboardWasShown: (NSNotification *)notif {
    return;
}

-(void) keyboardWasHidden: (NSNotification *)notif {
    return;
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [textField resignFirstResponder];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
@end
