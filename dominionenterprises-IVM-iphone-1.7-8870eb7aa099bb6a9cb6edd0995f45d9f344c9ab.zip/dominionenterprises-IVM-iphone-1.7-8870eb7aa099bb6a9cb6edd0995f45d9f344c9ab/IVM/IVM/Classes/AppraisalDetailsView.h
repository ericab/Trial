//
//  AppraisalDetailsView.h
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//
#import <UIKit/UIKit.h>
#import "IVMMobileServices.h"

@class VehicleSearchObject, MakesAndModels, SearchValuesResults, SearchResultsView,AppraisalDetailsController;

@interface AppraisalDetailsView : UIView<
UITextFieldDelegate, 
UIPickerViewDelegate,
UIPickerViewDataSource,
IVMMobileServicesDelegate,
UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate> {
	
	VehicleSearchObject		*searchObject;
	MakesAndModels			*mAndm;
	SearchValuesResults		*searchValuesResults;
	SearchResultsView		*searchView;
	
	UIScrollView		*scrollView;
	@public UITextField			*txt_datasalesperson;
	@public UITextField			*txt_appraisedvalue;
    @public UITextField         *txt_expectedsaleprice;
    @public UITextField         *txt_recondtioning;
    @public UITextField         *txt_profitobective;
    @public  UITextField         *txt_marketsize;
    @public  UITextField         *txt_marketaverageprice;
    @public UITextField         *txt_marketaveragemileage;
    @public UITextField         *txt_recommendedprice;
    @public UITextField         *txt_daysupply;
    @public UITextField         *txt_pricerank;
	@public UITextField			*txt_customer;
	@public UITextField			*txt_vehicle;
	@public UITextField			*txt_notes;
    @public UITextField         *txt_action;
    UITextField         *txt_dataproviders;
	UISegmentedControl  *seg_sort;
	UIPickerView		*pickerOne;
	UIPickerView		*pickerTwo;
	UIToolbar			*_pickerDone;
    NSString			*str_appraisalid;
    NSString			*str_datasalesperson;
    NSString			*str_appraisedvalue;
    NSString         *str_expectedsaleprice;
    NSString         *str_recondtioning;
    NSString         *str_profitobective;
    NSString         *str_marketsize;
    NSString         *str_marketaverageprice;
    NSString         *str_marketaveragemileage;
    NSString         *str_recommendedprice;
    NSString         *str_daysupply;
    NSString         *str_pricerank;
	NSString			*str_customer;
	NSString			*str_vehicle;
	NSString			*str_notes;
    NSString         *str_action;
     NSString         *str_trim;
    /* Customer data  */
      NSString *str_customerAddress;
     NSString *str_city;
    NSString *str_state;
    NSString *str_zip;
     NSString *str_phone;
     NSString *str_mobile;
     NSString *str_email;
    /*  Vehicle data*/
    NSString        *str_vin;
    NSString        *str_year;
    NSString        *str_make;
    NSString        *str_model;
    NSString        *str_style;
    NSString        *str_mileage;
    NSString        *str_exteriorcolor;
    NSString        *str_interiorcolor;
    NSString         *str_titianiumKey; 
    
	NSMutableArray		*dealerNameKeys;
	NSMutableArray		*dealerLots;
	NSMutableArray		*years;
	NSMutableArray		*makes;
	NSMutableArray		*models;
	NSMutableArray		*prices;
	NSMutableArray		*mileages;
	NSNumberFormatter	*frm_money;
	NSNumberFormatter	*frm_decimal;
	NSMutableArray		*twoDataSource;
	NSMutableArray		*oneDataSource;
    NSDictionary      *appraisalData;
	BOOL				keyboardShown;
	id					__unsafe_unretained target;
    NSDictionary    *appraisalDetails;
    NSMutableArray		*appraisalMenu;
    UIView *modalView;
    UIPopoverController *popoverController; 
    
    NSNumberFormatter *frm;
    NSNumberFormatter *numberFormatter;
    id latsetTextField;
	NSString			*_userToken;
    UITableView *appraisalTableView;
    NSString        *str_vehicle_key;
}

@property(strong)			VehicleSearchObject		*searchObject;
@property(unsafe_unretained)			id				target;
@property (nonatomic, strong)   NSMutableArray	*dealerList;
@property (nonatomic, strong)   NSMutableArray	*vechicleTitleArray;
@property (nonatomic, strong)   NSMutableArray	*vechicleLabelArray;
@property (nonatomic, strong)   NSMutableArray	*dataProviderLabelArray;
@property (nonatomic, strong)   NSMutableArray	*dataProviderValueArray;
@property (nonatomic, strong)   NSMutableArray	*dataProviderTitleArray;
@property (nonatomic, strong)   NSMutableArray	*dataProviderConditionArray;
@property (nonatomic,strong) AppraisalDetailsController *appraisalDetailsController;

-(void)createCellUI;
- (id)initWithFrame:(CGRect)frame searchObject:(VehicleSearchObject*)searchObj filterMode:(BOOL)filter;
- (void)showPicker:(id)sender;
-(void)initalize;
@end
