//
//  AppraisalAppraisalDetailsController.h
//  IVM
//
//  Created by Raja Sekhar Nerella on 16/05/12.
//  
// Apprasisal Appraisal Detail View Controller

#import <UIKit/UIKit.h>
#import "LoadingView.h"
#import "AppraisalDetailsController.h"
@interface AppraisalAppraisalDetailsController : UIViewController<UITextFieldDelegate,UIAlertViewDelegate>
{
    UIScrollView		*scrollView;
   
    UITextField  * txt_expectedsaleprice;
    UITextField * txt_profitobective;
    UITextField * txt_datasalesperson;
    UITextField * txt_appraisedvalue;
    UITextField * txt_notes;
    UITextField * txt_recondtioning;
    
    @public NSString  * str_expectedsaleprice;
    @public NSString * str_profitobective;
    @public NSString * str_datasalesperson;
    @public NSString * str_appraisedvalue;
    @public NSString * str_notes;
    @public NSString * str_recondtioning;
     
    LoadingView	*loadingView;
    id latsetTextField;
    NSNumberFormatter   *frm;
    NSCharacterSet      *nonNumberSet;
    NSCharacterSet      *nonCharacterSet;
    
    UIButton *doneButton;
    
    CGFloat	animatedDistance;
}
@property(nonatomic,assign) BOOL isAppraisal;
@property (nonatomic,assign) AppraisalDetailsController *appraisalDetailsController;
@property(nonatomic,assign) int reqType;
@end
