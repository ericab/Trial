//
//  DecodeData.m
//  GetAuto.com
//
//  Created by Shaofeng Tu on 7/12/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import "DecodeData.h"

@implementation DecodeData

@synthesize	year;
@synthesize	make;
@synthesize	model;
@synthesize	trims;
@synthesize	vin;


@end
