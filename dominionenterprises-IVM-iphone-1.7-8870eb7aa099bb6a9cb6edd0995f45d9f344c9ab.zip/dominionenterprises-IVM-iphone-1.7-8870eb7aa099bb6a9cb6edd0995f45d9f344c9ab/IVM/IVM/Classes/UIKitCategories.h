//
//  UIKitCategories.h
//  IVM
//
//  Created by Raja Sekhar Nerella on 16/05/12.
//  
//

#import <Foundation/Foundation.h>

@interface UIView (FindUIViewController)
- (UIViewController *) firstAvailableUIViewController;
- (id) traverseResponderChainForUIViewController;
@end