//
//  ModifyViewController.m
//  GetAuto.com
//
//  Created by Shaofeng Tu on 11/5/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import "ModifyViewController.h"
#import <QuartzCore/CoreAnimation.h>
#import "appDelegate.h"
#import <objc/runtime.h>
#import "IVM.h"

static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.6;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.4;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;
static const CGFloat LANDSCAPE_KEYBOARD_HEIGHT = 162;

@implementation ModifyViewController

@synthesize	delegate;


- (id)initWithKey:(int)vehicleKey withValue:(int)price
{
	self = [super init];
	if (self != nil) {
		[appDelegate track:@"Modify"];

		arrayItems = [[NSMutableArray alloc] initWithObjects:@"Price", @"Status", nil] ;

		_price = 0;
		_vehicleKey = vehicleKey;
		_currentPrice = price;
		_selectedIndex = _preIndex = 0;
 
		currencyFormatter = [[NSNumberFormatter alloc] init];
		[currencyFormatter setFormatterBehavior:NSNumberFormatterBehavior10_4];
		[currencyFormatter setGeneratesDecimalNumbers:YES];
		[currencyFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
		[currencyFormatter setCurrencySymbol:@""];
		[currencyFormatter setMaximumFractionDigits:0];
		[currencyFormatter setLocale:[NSLocale currentLocale]];
		
        NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
        [currencyFormatter setLocale:usLocale];
        
		//set up the reject character set
		NSMutableCharacterSet *numberSet = [[NSCharacterSet decimalDigitCharacterSet] mutableCopy];
		[numberSet formUnionWithCharacterSet:[NSCharacterSet whitespaceCharacterSet]];
		nonNumberSet = [numberSet invertedSet];

	}
	
	return self;
}

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	UIView *vw = [[UIView alloc] initWithFrame:CGRectZero];
	[vw setFrame:[UIScreen mainScreen].applicationFrame];
	vw.backgroundColor = [UIColor blackColor];
	vw.alpha = 0.8;
	self.view = vw;

	UIView *uiLayout = [[UIView alloc] initWithFrame:CGRectMake(30.0f, 60.0f, 260.0f, 340.0f)];
	uiLayout.backgroundColor = [UIColor blackColor];
	uiLayout.layer.borderColor = [UIColor grayColor].CGColor;
	uiLayout.layer.borderWidth = 1.0;
	uiLayout.layer.cornerRadius = 10.0;
	
	float yOffset = 30.0f;
	UIColor *textColor = [UIColor whiteColor];
	UIFont *lblFont = [UIFont fontWithName:kDefaultFont size:kDefaultFontSize + 6.0];

	//Modify Title/Items
	UILabel *tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 240.0f, 30.0)];
	tmpLabel.font = lblFont;
	tmpLabel.textColor = textColor;
	tmpLabel.backgroundColor = [UIColor clearColor];
	tmpLabel.textAlignment = UITextAlignmentCenter;
	tmpLabel.text = @"Select Item to be Modified ...";
	[uiLayout addSubview:tmpLabel];
	
	yOffset += 30.0f;

	btn_items = [UIButton buttonWithType:UIButtonTypeCustom];
	btn_items.contentMode = UIViewContentModeCenter;
	btn_items.backgroundColor = [UIColor clearColor];
	btn_items.layer.borderColor = [UIColor grayColor].CGColor;
	btn_items.layer.borderWidth = 1.0;
	btn_items.layer.cornerRadius = 6.0;
	[btn_items setTitle:[NSString stringWithFormat:@"%@", [arrayItems objectAtIndex:0]] forState:UIControlStateNormal];
	btn_items.titleLabel.font = lblFont;
	btn_items.frame = CGRectMake(50.0f, yOffset, 160.0f, 35.0);
	[btn_items addTarget:self action:@selector(showPicker:) forControlEvents:UIControlEventTouchUpInside];
	[uiLayout addSubview:btn_items];

	CAGradientLayer	*shineLayer = [CAGradientLayer layer];
	shineLayer.cornerRadius = 6.0;
	shineLayer.frame = CGRectMake(0.0f, 0.0f, 160.0f, 35.0);
	shineLayer.colors = [NSArray arrayWithObjects:
						 (id)[UIColor colorWithWhite:1.0f alpha:0.4f].CGColor,
						 (id)[UIColor colorWithWhite:1.0f alpha:0.2f].CGColor,
						 (id)[UIColor colorWithWhite:0.75f alpha:0.2f].CGColor,
						 (id)[UIColor colorWithWhite:0.4f alpha:0.2f].CGColor,
						 (id)[UIColor colorWithWhite:1.0f alpha:0.4f].CGColor,
						 nil];
	shineLayer.locations = [NSArray arrayWithObjects:
							[NSNumber numberWithFloat:0.0f],
							[NSNumber numberWithFloat:0.2f],
							[NSNumber numberWithFloat:0.5f],
							[NSNumber numberWithFloat:0.8f],
							[NSNumber numberWithFloat:1.0f],
							nil];
	
	[btn_items.layer addSublayer:shineLayer];

	
	yOffset += 60.0f;
	
	priceLayout = [[UIView alloc] initWithFrame:CGRectMake(5.0f, yOffset, 250.0f, 80.0f)];
	priceLayout.backgroundColor = [UIColor blackColor];
	
	float syOffset = 0.0f;

	priceLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, syOffset, 230.0f, 30.0)];
	priceLabel.font = lblFont;
//	priceLabel.textColor = textColor;
	priceLabel.textColor = [UIColor colorWithRed:RedMake(kSCPriceRGB)  green:GreenMake(kSCPriceRGB) blue:BlueMake(kSCPriceRGB) alpha:1.0];
	priceLabel.backgroundColor = [UIColor clearColor];

	if (_currentPrice > 0) {
		NSString* localeSeparator = [[NSLocale currentLocale] objectForKey:NSLocaleGroupingSeparator];
		NSNumber* number = [currencyFormatter numberFromString:[[NSString stringWithFormat:@"%d", _currentPrice]
																stringByReplacingOccurrencesOfString:localeSeparator 
																withString:@""]];
		priceLabel.text = [NSString stringWithFormat:@"Current Price:  $ %@", [currencyFormatter stringFromNumber:number]];
	} else {
		priceLabel.text = [NSString stringWithFormat:@"Current Price:    N/A"];
	}

	[priceLayout addSubview:priceLabel];
	
	syOffset += 40.0f;

	newLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, syOffset, 100.0f, 30.0)];
	newLabel.font = lblFont;
	newLabel.textColor = textColor;
	newLabel.backgroundColor = [UIColor clearColor];
	newLabel.text = @"New Price: $";
	[priceLayout addSubview:newLabel];

	txt_price = [[UITextField alloc] initWithFrame:CGRectMake(110.0f, syOffset, 130.0f, 30.0)];
	txt_price.borderStyle = UITextBorderStyleRoundedRect;
	txt_price.returnKeyType = UIReturnKeyDone;
	txt_price.clearButtonMode = UITextFieldViewModeWhileEditing;
	txt_price.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
	[txt_price addTarget:self action:@selector(getValue:) forControlEvents:UIControlEventEditingDidEnd];
	txt_price.autocorrectionType = UITextAutocorrectionTypeNo;
	txt_price.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
	txt_price.delegate = self;
	txt_price.placeholder = [NSString stringWithFormat:@"%d", _price];
	[priceLayout addSubview:txt_price];

	
	stsLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 220.0f, 80.0)];
	stsLabel.font = lblFont;
	stsLabel.textColor = [UIColor colorWithRed:RedMake(kSCPriceRGB)  green:GreenMake(kSCPriceRGB) blue:BlueMake(kSCPriceRGB) alpha:1.0];
	stsLabel.backgroundColor = [UIColor clearColor];
	stsLabel.numberOfLines = 0;
	stsLabel.text = [NSString stringWithFormat:@"Mark as Sold?\n\n"];
	stsLabel.textAlignment = UITextAlignmentCenter;
	stsLabel.hidden = YES;
	stsLabel.alpha = 0.0;
	
	//Picker View Creation		
	_pickerDone = [UIToolbar new];
	[_pickerDone sizeToFit];
	_pickerDone.frame = CGRectMake(5.0f, uiLayout.frame.size.height - 170.0f - 42.0f, 250.0, _pickerDone.frame.size.height);
	_pickerDone.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
	_pickerDone.barStyle = UIBarStyleBlackTranslucent;
	_pickerDone.contentMode = UIViewContentModeRight;
	UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(pickerDone:)];
	UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
	[_pickerDone setItems:[NSArray arrayWithObjects:spacer, done, nil] animated:NO];
	_pickerDone.hidden = YES;
	_pickerDone.alpha = 0.0;
         //Added Apr-12-2011
       //Added Apr-12-2011

    pickerView = [[UIPickerView alloc] init];
	pickerView.frame = CGRectMake(5.0, uiLayout.frame.size.height - 170.0, 250.0, 162.0);
	pickerView.showsSelectionIndicator = YES;
	pickerView.delegate = self;
	pickerView.dataSource = self;
	pickerView.hidden = YES;
	pickerView.alpha = 0.0;

	yOffset += 100.0f;

	btn_modify = [UIButton buttonWithType:UIButtonTypeCustom];
	[btn_modify setTitle:@"Save" forState:UIControlStateNormal];
	[btn_modify setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
	[btn_modify setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	btn_modify.titleLabel.font = [UIFont systemFontOfSize: 20];
	[btn_modify setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
	btn_modify.frame = CGRectMake(50.0f, yOffset, 160.0f, 35.0f);
	[btn_modify addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
	[uiLayout addSubview:btn_modify];

	yOffset += 60.0f;

	UIButton	*btn_cancel = [UIButton buttonWithType:UIButtonTypeCustom];
	[btn_cancel setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
	[btn_cancel setTitle:@"Cancel" forState:UIControlStateNormal];
	btn_cancel.frame = CGRectMake(50.0f, yOffset, 160.0f, 35.0f);
	[btn_cancel addTarget:self action:@selector(dismissModal:) forControlEvents:UIControlEventTouchUpInside];
	[uiLayout addSubview:btn_cancel];
	
	[uiLayout addSubview:priceLayout];
	[uiLayout addSubview:stsLabel];
	[uiLayout addSubview:pickerView];
	[uiLayout addSubview:_pickerDone];
	[self.view addSubview:uiLayout];

}

// Implement viewDidLoad to do additional setup after loading the view.
- (void)viewDidLoad {
//	self.view.backgroundColor = [UIColor clearColor];
}


- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)thePickerView {
	return 1;
}

-(NSInteger)pickerView: (UIPickerView *)thePickerView numberOfRowsInComponent: (NSInteger)component {
	
	return [arrayItems count];
}	

- (NSString *)pickerView:(UIPickerView *)thePickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
	return [arrayItems objectAtIndex:row];
}

// UIPickerViewDelegate

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
	return	240;
}

- (void)pickerView:(UIPickerView *)thePickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {

	_selectedIndex = row;
	[btn_items setTitle: [NSString stringWithFormat:@"%@", [arrayItems objectAtIndex:_selectedIndex]] forState: UIControlStateNormal];
}


#pragma mark UITextField delegate methods
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    CGRect textFieldRect = [self.view.window convertRect:textField.bounds fromView:textField];
    CGRect viewRect = [self.view.window convertRect:self.view.bounds fromView:self.view];
	
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
	midline - viewRect.origin.y
	- MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
	(MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
	* viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
	
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
	
    UIInterfaceOrientation orientation =
	[[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationPortrait ||
        orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    }
    else
    {
        animatedDistance = floor(LANDSCAPE_KEYBOARD_HEIGHT * heightFraction);
    }
	
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = self.view.frame;
    viewFrame.origin.y += animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self.view setFrame:viewFrame];
    
    [UIView commitAnimations];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	return YES;
}

- (void)getValue:(id)sender {
	if( ((UITextField *)sender) == txt_price){
		_price = [[currencyFormatter numberFromString:((UITextField *)sender).text] intValue];
	}
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
	BOOL result = NO; //default to reject
	
	if (textField == txt_price) {
		
		if([string length] == 0){ //backspace
			result = YES;
		}else{
			if([string stringByTrimmingCharactersInSet:nonNumberSet].length > 0){
				result = YES;
			}
		}
		
		//here we deal with the UITextField on our own
		if(result){
			//grab a mutable copy of what's currently in the UITextField
			NSMutableString* mstring = [[textField text] mutableCopy];
			if([mstring length] == 0){
				//now append the replacement string
				[mstring appendString:string];
			}else{
				//adding a char or deleting?
				if([string length] > 0){
					[mstring insertString:string atIndex:range.location];
				}else {
					//delete case - the length of replacement string is zero for a delete
					[mstring deleteCharactersInRange:range];
				}
			}
			
			//to get the grouping separators properly placed
			//first convert the string into a number. The function
			//will ignore any grouping symbols already present -- NOT in iOS4!
			//fix added below - remove locale specific currency separators first
			NSString* localeSeparator = [[NSLocale currentLocale] 
										 objectForKey:NSLocaleGroupingSeparator];
			NSNumber* number = [currencyFormatter numberFromString:[mstring
																	stringByReplacingOccurrencesOfString:localeSeparator 
																	withString:@""]];
			
			//now format the number back to the proper currency string
			//and get the grouping separators added in and put it in the UITextField
            if([[number stringValue] length] <= 10)
                [textField setText:[currencyFormatter stringFromNumber:number]];
		}
	} else {
		return YES;
	}
	
	//always return no since we are manually changing the text field
	return NO;
}


- (void)dismissModal:(id)sender {
	[self hideModal:self.view];
}

- (void)hideModal:(UIView*) modalView {
	CGSize offSize = [UIScreen mainScreen].bounds.size;
	CGPoint offScreenCenter = CGPointMake(offSize.width / 2.0, offSize.height * 1.5);
	[UIView beginAnimations:nil context:(__bridge void*)modalView];
	[UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDidStopSelector:@selector(hideModalEnded:finished:context:)];
	modalView.center = offScreenCenter;
	[UIView commitAnimations];
}

- (void)hideModalEnded:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context {
	UIView* modalView = (__bridge UIView *)context;
	[modalView removeFromSuperview];
//	[modalView release];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)showPicker:(id)sender{
		
	pickerView.hidden = NO;
	_pickerDone.hidden = NO;
		
	[UIView beginAnimations:@"FadeIn" context:nil];
	[UIView setAnimationDuration:0.6];
	pickerView.alpha = 1.0;
	_pickerDone.alpha = 1.0;
	[UIView commitAnimations];

}

- (void)hiddenViews{
	
	pickerView.hidden = YES;
	_pickerDone.hidden = YES;
}

- (void)pickerDone:(id)sender{

	if (_selectedIndex != _preIndex) {
		[self switchModifyViews];

		_preIndex = _selectedIndex;
	}

	[UIView beginAnimations:@"FadeOut" context:nil];
	[UIView setAnimationDuration:0.6];
	[UIView setAnimationDidStopSelector:@selector(hiddenViews)];
	_pickerDone.alpha = 0.0;
	pickerView.alpha = 0.0;
	[UIView commitAnimations];
}

- (void)buttonClicked:(id)sender {
    
	[self dismissModal:sender];

	switch (_selectedIndex) {
		case 0:
            _price = [[currencyFormatter numberFromString:(txt_price).text] intValue];
			[self.delegate updateVehiclePrice:_price];
			break;
		case 1:
			[self.delegate updateVehicleStatus];
			break;
		case 2:
			break;
		default:
			break;
	}
}

- (void)switchModifyViews {
	switch (_selectedIndex) {
		case 0:
			newLabel.hidden = NO;
			priceLayout.hidden = NO;
			stsLabel.hidden = YES;
			break;
		case 1:
			priceLayout.hidden = YES;
			stsLabel.hidden = NO;
			break;
		default:
			break;
	}

	[UIView beginAnimations:@"FadeIn" context:nil];
	[UIView setAnimationDuration:2*KEYBOARD_ANIMATION_DURATION];
	
	switch (_selectedIndex) {
		case 0:
			newLabel.alpha = 1.0;
			txt_price.alpha = 1.0;
			priceLabel.alpha = 1.0;
			stsLabel.alpha = 0.0;
			break;
		case 1:
			newLabel.alpha = 0.0;
			txt_price.alpha = 0.0;
			priceLabel.alpha = 0.0;
			stsLabel.alpha = 1.0;
			break;
		default:
			break;
	}

	[UIView commitAnimations];
}


- (void)dealloc {	

    [arrayItems removeAllObjects];
	arrayItems = nil;
	
	currencyFormatter = nil;
	nonNumberSet = nil;

	pickerView = nil;
	_pickerDone = nil;
	 
	btn_modify = nil;
	btn_items = nil;
	
	newLabel = nil;
	stsLabel = nil;
	priceLabel = nil;
	txt_price = nil;
	priceLayout = nil;

}
@end
