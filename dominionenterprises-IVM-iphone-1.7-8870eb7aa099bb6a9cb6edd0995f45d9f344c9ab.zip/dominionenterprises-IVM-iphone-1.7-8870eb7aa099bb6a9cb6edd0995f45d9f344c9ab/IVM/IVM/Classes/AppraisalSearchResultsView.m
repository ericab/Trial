//
//  AppraisalSearchResultsController.m
//
//  Created by Raja Sekhar Nerella on 3/20/12.
//

#import "AppraisalSearchResultsController.h"
#import "VehicleSearchObject.h"
#import "AppraisalSearchResultsView.h"


@implementation AppraisalSearchResultsView

@synthesize filterButton, activityLabel, activityIndicator, searchTable, mainView;

/*- (void)viewWillAppear:(BOOL)animated
{
	//Enable the Right Navigator Button
    if (self.navigationItem.rightBarButtonItem == nil) {
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"+" style:UIBarButtonItemStyleBordered  target:self action:@selector(logoutButton:)];
    }
}*/

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self != nil) {
		// Initialization code
        
		searchTable = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
		searchTable.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		searchTable.backgroundColor = [UIColor clearColor];
		[self addSubview:searchTable];
              
		//filterButton = [[UIButton buttonWithType:UIButtonTypeInfoDark] retain];
		//filterButton.frame = CGRectMake(frame.size.width - 50.0f, frame.size.height - 40.0f, 50.0f, 40.0f);
		//filterButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleTopMargin;
		//[self addSubview:filterButton];
		
		activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
		activityIndicator.frame = CGRectMake(frame.size.width / 2.0f - activityIndicator.frame.size.width / 2.0f, 
											 frame.size.height / 2.0f - activityIndicator.frame.size.height / 2.0f + 1.0f,
											 activityIndicator.frame.size.width, activityIndicator.frame.size.height);
		activityIndicator.autoresizingMask = UIViewAutoresizingFlexibleTopMargin  | UIViewAutoresizingFlexibleBottomMargin | 
			UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
		
		activityLabel = [[UILabel alloc] initWithFrame:CGRectMake(frame.size.width / 2.0f,
																  frame.size.height / 2.0f - 11.0f, self.frame.size.width, 20.0f)];
		activityLabel.shadowOffset = CGSizeMake(2.0f, 3.0f);
		activityLabel.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | 
			UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleWidth;
		activityLabel.textColor = [UIColor whiteColor];
		activityLabel.backgroundColor = [UIColor clearColor];
		activityLabel.textAlignment = UITextAlignmentCenter;

		[self addSubview:activityIndicator];
		[self addSubview:activityLabel];
    }
    return self;
}

- (void) setFrame:(CGRect)frame{
	[super setFrame:frame];
}

- (void)createNewAppriasalButton:(id)sender{  
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Confirm Logout"
														message:@"Are you sure want to logout?"
													   delegate:self
											  cancelButtonTitle:@"NO"
											  otherButtonTitles:nil];
	
	[alertView addButtonWithTitle:@"YES"];
	[alertView show];

}


@end
