//
//  SearchValuesResults.h
//  GetAuto.com
//
//  Created by Shaofeng Tu on 6/30/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SearchValuesResults : NSObject {
	int				totalCount;
	NSMutableArray	*listings;
}

@property(assign)	int				totalCount;
@property(strong)	NSMutableArray	*listings;

@end
