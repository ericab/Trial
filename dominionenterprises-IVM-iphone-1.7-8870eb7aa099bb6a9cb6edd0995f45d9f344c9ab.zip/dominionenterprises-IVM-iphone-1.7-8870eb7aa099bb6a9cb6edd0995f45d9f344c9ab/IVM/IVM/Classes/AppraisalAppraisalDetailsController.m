//
//  AppraisalAppraisalDetailsController.m
//  IVM
//
//  Created by Raja Sekhar Nerella on 16/05/12.
// 
//

#import "AppraisalAppraisalDetailsController.h"

@implementation AppraisalAppraisalDetailsController
@synthesize isAppraisal;
@synthesize appraisalDetailsController;
@synthesize reqType;

static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;
static const CGFloat LANDSCAPE_KEYBOARD_HEIGHT = 162;

static const CGFloat PRICE_MAX_LENGTH = 10;
static const CGFloat NAME_MAX_LENGTH = 100;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    //set up the reject character set
    NSMutableCharacterSet *numberSet = [[NSCharacterSet decimalDigitCharacterSet] mutableCopy];
    [numberSet formUnionWithCharacterSet:[NSCharacterSet whitespaceCharacterSet]];
    nonNumberSet = [numberSet invertedSet];
    nonCharacterSet = [[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789 .,-"] invertedSet];
    
    UIView *view = [[UIView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    [view setAutoresizingMask:UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth];
    [view setBackgroundColor:[UIColor whiteColor]];
    UIImageView *backgroundImage=  [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];;
    [view addSubview:backgroundImage];
    [view sendSubviewToBack:backgroundImage];
    
    frm = [[NSNumberFormatter alloc] init];
    [frm setNumberStyle:NSNumberFormatterCurrencyStyle];
    [frm setMaximumFractionDigits:0];
    
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [frm setLocale:usLocale];
    
    scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    scrollView.scrollEnabled = YES;
    [view addSubview:scrollView];
    
    UIColor *textColor = [UIColor blackColor];
    UIFont *lblFont = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0];
    
    float yOffset = 10.0f;
    
    //Expected Sale Price
    UILabel *tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 150.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Expected Sale Price";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_expectedsaleprice = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_expectedsaleprice.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_expectedsaleprice.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_expectedsaleprice.placeholder = @"Expected Sale Price";
    txt_expectedsaleprice.returnKeyType = UIReturnKeyDone;
    txt_expectedsaleprice.keyboardType=UIKeyboardTypeNumberPad;
    txt_expectedsaleprice.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_expectedsaleprice.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_expectedsaleprice.delegate = self;
    txt_expectedsaleprice.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_expectedsaleprice];
    yOffset += 30.0f;
    
    //Recondtioning
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Reconditioning";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_recondtioning = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_recondtioning.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_recondtioning.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_recondtioning.placeholder = @"Reconditioning";
    txt_recondtioning.returnKeyType = UIReturnKeyDone;
    txt_recondtioning.keyboardType=UIKeyboardTypeNumberPad;
    txt_recondtioning.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_recondtioning.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_recondtioning.delegate = self;
    txt_recondtioning.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
   
    [scrollView addSubview:txt_recondtioning];
    yOffset += 30.0f;

    //Profit Objective
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Profit Objective";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_profitobective = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_profitobective.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_profitobective.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_profitobective.placeholder = @"Profit Objective";
    txt_profitobective.returnKeyType = UIReturnKeyDone;
    txt_profitobective.keyboardType=UIKeyboardTypeNumberPad;
    txt_profitobective.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_profitobective.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_profitobective.delegate = self;
    txt_profitobective.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_profitobective];
    yOffset += 30.0f;
    
    //Appraised Value
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Appraised Value";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_appraisedvalue = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_appraisedvalue.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_appraisedvalue.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_appraisedvalue.placeholder = @"Appraised Value";
    txt_appraisedvalue.returnKeyType = UIReturnKeyDone;
    txt_appraisedvalue.keyboardType=UIKeyboardTypeNumberPad;
    txt_appraisedvalue.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_appraisedvalue.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_appraisedvalue.delegate = self;
    txt_appraisedvalue.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
   
    [scrollView addSubview:txt_appraisedvalue];
    yOffset += 30.0f;
    
    //Notes
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Notes";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_notes = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_notes.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_notes.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_notes.placeholder = @"Notes";
    txt_notes.returnKeyType = UIReturnKeyDone;
    txt_notes.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_notes.clearButtonMode = UITextFieldViewModeWhileEditing;
      txt_notes.delegate = self;
    txt_notes.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_notes];
    yOffset += 30.0f;
    
    //Sales Person
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Sales Person";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_datasalesperson = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_datasalesperson.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_datasalesperson.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_datasalesperson.placeholder = @"Sales Person";
    txt_datasalesperson.returnKeyType = UIReturnKeyDone;
    txt_datasalesperson.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_datasalesperson.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_datasalesperson.delegate = self;
    txt_datasalesperson.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_datasalesperson];

    txt_expectedsaleprice.text = [frm stringFromNumber:[NSNumber numberWithInt:[str_expectedsaleprice intValue]]];
    txt_recondtioning.text = [frm stringFromNumber:[NSNumber numberWithInt:[str_recondtioning intValue]]];
    txt_profitobective.text = [frm stringFromNumber:[NSNumber numberWithInt:[str_profitobective intValue]]];
    txt_appraisedvalue.text = [frm stringFromNumber:[NSNumber numberWithInt:[str_appraisedvalue intValue]]];
    txt_notes.text = [str_notes isEqualToString:@"n/a"] && isAppraisal ? @"":str_notes;
    txt_datasalesperson.text = [str_datasalesperson isEqualToString:@"n/a"] && isAppraisal ? @"":str_datasalesperson;
    
    self.view = view;

    if(isAppraisal)
    {
        UIBarButtonItem *saveBtn = [[UIBarButtonItem alloc] initWithTitle:@"Save" style:UIBarButtonItemStyleDone target:self action:@selector(saveAppraisal)];
        saveBtn.style = UIBarButtonItemStyleBordered;
        
        self.navigationItem.rightBarButtonItem = saveBtn;
    }

}
// To load the Scroll View
- (void)viewWillAppear:(BOOL)animated {
   	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter] addObserver: self 
											 selector: @selector(keyboardWasShown:)
												 name: UIKeyboardDidShowNotification 
											   object: nil];
	
    [[NSNotificationCenter defaultCenter] addObserver: self
											 selector: @selector(keyboardWasHidden:)
												 name: UIKeyboardDidHideNotification 
											   object: nil];
	
   	scrollView.frame = CGRectMake(0, 0, 320, 460);
	scrollView.contentSize = CGSizeMake(320, 500);
}
-(void) viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]
	 removeObserver:self];
}

-(void) keyboardWasShown: (NSNotification *)notif {
    return;
}

-(void) keyboardWasHidden: (NSNotification *)notif {
    return;
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
 BOOL result = NO; //default to reject
  if (textField.keyboardType == UIKeyboardTypeNumberPad ) {
    if(textField == txt_expectedsaleprice || textField == txt_recondtioning || textField == txt_profitobective | textField == txt_appraisedvalue)
    {
        if([string length] == 0){ //backspace
            result = YES;
        }
        else{
            if([[string componentsSeparatedByCharactersInSet:nonNumberSet] componentsJoinedByString: @""].length == string.length){
                result = YES;
            }
        }
        
        if(result){
            //grab a mutable copy of what's currently in the UITextField
            NSMutableString* mstring = [[textField text] mutableCopy];
            if([mstring length] == 0){
                //special case...nothing in the field yet, so set a currency symbol first
                [mstring appendString:[[NSLocale currentLocale] objectForKey:NSLocaleCurrencySymbol]];
                //now append the replacement string
                [mstring appendString:string];
            }
            else{
                //adding a char or deleting?
                if([string length] > 0){
                    [mstring insertString:string atIndex:range.location];
                }
                else {
                    //delete case - the length of replacement string is zero for a delete
                    [mstring deleteCharactersInRange:range];
                    if([mstring length] == 1)
                    {
                        //now append the replacement string
                        [mstring appendString:@"0"];
                    }
                }
            }
            //to get the grouping separators properly placed
            //first convert the string into a number. The function
            //will ignore any grouping symbols already present -- NOT in iOS4!
            //fix added below - remove locale specific currency separators first
            NSString* localeSeparator = [[NSLocale currentLocale]objectForKey:NSLocaleGroupingSeparator];
            NSNumber* number = [frm numberFromString:[mstring stringByReplacingOccurrencesOfString:localeSeparator withString:@""]];
            //now format the number back to the proper currency string
            //and get the grouping separators added in and put it in the UITextField
            if([[number stringValue] length] <= PRICE_MAX_LENGTH)
            [textField setText:[frm stringFromNumber:number]];
        }
        //always return no since we are manually changing the text field
        result= NO;
    }
    else
    {
        result=NO;
        if([string length] == 0){ //backspace
            result = YES;
        }
        else{
            if([[string componentsSeparatedByCharactersInSet:nonNumberSet] componentsJoinedByString: @""].length == string.length){
                    result = YES;
            }
        }
    }
  }
  else
  {
      result=NO;
      if([string length] == 0){ //backspace
          result = YES;
      }
      else{
          if([[string componentsSeparatedByCharactersInSet:nonCharacterSet] componentsJoinedByString: @""].length == string.length){
              if(textField == txt_datasalesperson)
              {
                  NSString* newText = [txt_datasalesperson.text stringByReplacingCharactersInRange:range withString:string];
                  if (newText.length<=NAME_MAX_LENGTH )
                      result = YES;
              }
              else
               result = YES;
          }
      }
      
      
  }
   //always return no since we are manually changing the text field
    return result;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    // add observer for the respective notifications (depending on the os version)
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(keyboardDidShow:) 
                                                     name:UIKeyboardDidShowNotification 
                                                   object:nil];		
    } else {
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(keyboardWillShow:) 
                                                     name:UIKeyboardWillShowNotification 
                                                   object:nil];
    }

}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark UITextField delegate methods

- (BOOL)textFieldShouldClear:(UITextField *)textField {
	return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if(isAppraisal)
    {
       return YES;
    }
    return NO;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if(isAppraisal)
    {
    if ((latsetTextField != nil) && (textField.keyboardType == UIKeyboardTypeNumberPad)) {
        // Add the Done button to keyboard
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
            if(doneButton)
            {
                [doneButton removeFromSuperview];
                doneButton = nil;
            }
            [self addButtonToKeyboard];
        }
    }
    else {
        [doneButton removeFromSuperview];
        doneButton = nil;
    }
    latsetTextField = textField;
    
    CGRect textFieldRect = [scrollView convertRect:textField.bounds fromView:textField];
    CGRect viewRect = [scrollView convertRect:scrollView.bounds fromView:scrollView];
	
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
	midline - viewRect.origin.y
	- MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
	(MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
	* viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
	
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
	
    UIInterfaceOrientation orientation =
	[[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationPortrait ||
        orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    }
    else
    {
        animatedDistance = floor(LANDSCAPE_KEYBOARD_HEIGHT * heightFraction);
    }
	
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [scrollView setFrame:viewFrame];
    
    [UIView commitAnimations];
    }
}

-(void) textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y += animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [scrollView setFrame:viewFrame];
    
    [UIView commitAnimations];
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [latsetTextField resignFirstResponder];
    latsetTextField=nil;
	return YES;
}

- (void)addButtonToKeyboard {
	// create custom button
	doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
	doneButton.frame = CGRectMake(0, 163, 106, 53);
	doneButton.adjustsImageWhenHighlighted = NO;
	if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.0) {
		[doneButton setImage:[UIImage imageNamed:@"DoneUp3.png"] forState:UIControlStateNormal];
		[doneButton setImage:[UIImage imageNamed:@"DoneDown3.png"] forState:UIControlStateHighlighted];
	} else {        
		[doneButton setImage:[UIImage imageNamed:@"DoneUp.png"] forState:UIControlStateNormal];
		[doneButton setImage:[UIImage imageNamed:@"DoneDown.png"] forState:UIControlStateHighlighted];
	}
	[doneButton addTarget:self action:@selector(doneButton:) forControlEvents:UIControlEventTouchUpInside];
	
    // locate keyboard view
	UIWindow* tempWindow = [[[UIApplication sharedApplication] windows] objectAtIndex:1];
	UIView* keyboard;
	for(int i=0; i<[tempWindow.subviews count]; i++) {
		keyboard = [tempWindow.subviews objectAtIndex:i];
		// keyboard found, add the button
		if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
			if([[keyboard description] hasPrefix:@"<UIPeripheralHost"] == YES)
				[keyboard addSubview:doneButton];
		} else {
			if([[keyboard description] hasPrefix:@"<UIKeyboard"] == YES)
				[keyboard addSubview:doneButton];
		}
	}
}
- (void)keyboardWillShow:(NSNotification *)note {
	// if clause is just an additional precaution, you could also dismiss it
    if (((UITextField *)(latsetTextField)).keyboardType == UIKeyboardTypeNumberPad) {
        if ([[[UIDevice currentDevice] systemVersion] floatValue] < 3.2) {
            if(doneButton)
            {
                [doneButton removeFromSuperview];
                doneButton = nil;
            }
            [self addButtonToKeyboard];
        }
    }
}
- (void)keyboardDidShow:(NSNotification *)note {
    if(doneButton)
    {
        [doneButton removeFromSuperview];
        doneButton = nil;
    }
	// if clause is just an additional precaution, you could also dismiss it
	if (((UITextField *)(latsetTextField)).keyboardType == UIKeyboardTypeNumberPad) {
        // Add the Done button in keyboard
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
            [self addButtonToKeyboard];
        }
    }
}
- (void)doneButton:(id)sender {
    if(doneButton)
    {
        [doneButton removeFromSuperview];
        doneButton = nil;
    }
    [latsetTextField resignFirstResponder];
    latsetTextField=nil;
}
- (void)pickerDone:(id)sender{
	[latsetTextField resignFirstResponder];
    latsetTextField = nil;
}
-(void) handleResponseForQuery:(NSMutableDictionary *)response
{
    appraisalDetailsController->asv->str_appraisalid = [response objectForKey:@"responseString"];
    [self alertUser:@"" title:[NSString stringWithFormat: @"Appraisal updated successfully."]];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
-(void) saveAppraisal
{
    [latsetTextField resignFirstResponder];
    str_expectedsaleprice =[[frm numberFromString:txt_expectedsaleprice.text] stringValue ];
     str_recondtioning =[[frm numberFromString:txt_recondtioning.text] stringValue ];
    str_profitobective =[[frm numberFromString:txt_profitobective.text] stringValue ];
    str_appraisedvalue =[[frm numberFromString:txt_appraisedvalue.text] stringValue ];
    str_notes = txt_notes.text  ;
    str_datasalesperson = txt_datasalesperson.text  ;
    if (loadingView == nil) {
        loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
    }
    reqType=10;
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                                [NSNumber numberWithInt:reqType],@"reqtype",
                                appraisalDetailsController->asv->str_appraisalid,@"appraisalid",
                                @"Active",@"status",
                                appraisalDetailsController->asv->str_customer,@"customer",
                                appraisalDetailsController->asv->str_customerAddress,@"customeraddress",
                                appraisalDetailsController->asv->str_city,@"city",
                                appraisalDetailsController->asv->str_state,@"state",
                                appraisalDetailsController->asv->str_zip,@"zip",
                                appraisalDetailsController->asv->str_phone,@"phone",
                                appraisalDetailsController->asv->str_mobile,@"mobile",
                                appraisalDetailsController->asv->str_email,@"email",
                                appraisalDetailsController->asv->str_vin,@"vin",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_year intValue]],@"year",
                                appraisalDetailsController->asv->str_make,@"make",
                                appraisalDetailsController->asv->str_model,@"model",
                                appraisalDetailsController->asv->str_trim,@"trim",
                                appraisalDetailsController->asv->str_style,@"style",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_mileage intValue]] ,@"mileage",
                                appraisalDetailsController->asv->str_titianiumKey,@"titaniumid",
                                appraisalDetailsController->asv->str_exteriorcolor,@"exteriorcolor",
                                appraisalDetailsController->asv->str_interiorcolor,@"interiorcolor",
                                [NSNumber numberWithInt:[str_appraisedvalue intValue]] ,@"appraisedvalue",
                                [NSNumber numberWithInt:[str_expectedsaleprice intValue]],@"expectedsaleprice",
                                str_notes,@"notes",
                                str_profitobective,@"profitobjective",
                                str_recondtioning,@"reconditioning",
                                str_datasalesperson,@"salesperson",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_daysupply intValue]] ,@"dayssupply",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_marketaveragemileage intValue]] ,@"marketaveragemileage",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_marketaverageprice intValue]] ,@"marketaverageprice",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_marketsize intValue]] ,@"marketsize",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_pricerank intValue]],@"pricerank",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_recommendedprice intValue]] ,@"recommendedprice",
                                self,@"delegate",
                                nil];
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
}

- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:message
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}
#pragma mark alertview delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(reqType == 10 && ![alertView.title isEqualToString:@"Error"]) 
    {
        if (loadingView != nil) {
            [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
            loadingView = nil;
        }
        reqType=0;
        self.appraisalDetailsController.refreshDataOn=YES;
        [self.navigationController popToViewController:appraisalDetailsController animated:YES];
    }
    else {
    if (loadingView != nil) {
        [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
        loadingView = nil;
    }
    } 
}
@end
