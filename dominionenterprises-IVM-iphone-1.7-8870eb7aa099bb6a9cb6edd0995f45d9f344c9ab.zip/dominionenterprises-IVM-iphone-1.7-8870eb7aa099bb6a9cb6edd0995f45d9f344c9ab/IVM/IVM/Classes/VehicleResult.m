//
//  VehicleResult.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/18/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "VehicleResult.h"

@implementation VehicleResult

@synthesize	vehicle_key;
//@synthesize	latitude;
//@synthesize	longitude;
//@synthesize	name;
//@synthesize	address;
//@synthesize	address2;
//@synthesize	city;
//@synthesize	state;
//@synthesize	postal_code;
@synthesize	vin;
@synthesize	stockNumber;
@synthesize	make;
@synthesize	model;
@synthesize	year;
@synthesize	price;
@synthesize	mileage;
@synthesize	externalColor;
@synthesize	internalColor;
@synthesize	bodyType;
@synthesize	trimLevel;
@synthesize	transmission;
@synthesize	image;
//@synthesize certifiedLogoUrl;
//@synthesize	distance;


@end
