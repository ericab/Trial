//
//  NetDataOperation.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/26/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//

#import "NetDataOperation.h"


@implementation NetDataOperation

@synthesize url = _url, target, action, data = _data;

- (id) init{
	return [self initWithUrl:nil];
}

- (id) initWithUrl:(NSURL*)url
{
	self = [super init];
	if (self != nil) {
		_url = url;
	}
	return self;
}

-(void)main{
	if([self isCancelled]) return;
	if(nil == self.url) return;
	@autoreleasepool {
		_data = [[NSData alloc] initWithContentsOfURL:_url];
		if(![self isCancelled]){
			if([target respondsToSelector:action])
				[target performSelectorOnMainThread:action withObject:self waitUntilDone:NO];
		}
	}
}


@end
