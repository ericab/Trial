//
//  VehicleHistoryController.h
//  IVM
//
//  Created by evokemacmini on 6/18/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CarfaxReportController.h"
#import "SearchResultsView.h"
@interface VehicleHistoryController : UIViewController
{
     CarfaxReportController *crc;
     SearchResultsView		*searchView;
}
@end
