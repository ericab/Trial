//
//  AppraisalDetailsController.m
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//

#import "SearchResultsController.h"
#import "appDelegate.h"
#import <QuartzCore/CoreAnimation.h>
#import "AppraisalDetailsController.h"
#import "SearchResultsView.h"
#import "AddAppraisalViewController.h"

#define kAdvancedSearchSearcher @"searcher"

@implementation AppraisalDetailsController
@synthesize appraisalDetails;
@synthesize appraisalSearchResultsController;
@synthesize reqType;
@synthesize refreshDataOn;
@synthesize isAppraisal;
@synthesize isAddAppraisal;

- (id) init
{
	self = [super init];
	if (self != nil) {
		self.title = @"Details";
		[appDelegate track:@"Details"];
	}
	return self;
}
- (id)initWithRestore:(NSDictionary*)data{
	self = [self init];
	if (self != nil)
	{
		searchObj = [data objectForKey:kAdvancedSearchSearcher];
		[self.view class];//Ensure that the view gets loaded
	}
	return self;
}
- (NSDictionary*)getRestoreData{
	NSMutableDictionary* dict = [NSMutableDictionary dictionaryWithCapacity:1];
	if(searchObj == nil)
	{
		//Attempt to get it
		searchObj = ((AppraisalDetailsView*)self.view).searchObject;
	}
	if(searchObj != nil)
	{
		searchObj.firstListing = 1;
		[dict setValue:searchObj forKey:kAdvancedSearchSearcher];
	}
	return dict;
}
-(void) handleResponseForQuery:(NSMutableDictionary *)response
{
    if([[response objectForKey:@"response"] objectForKey:@"dataproviders"])
    {
    reqType=0;
    arrayOfappraisalDetailDataProvider = [[response objectForKey:@"response"] objectForKey:@"dataproviders"];
        asv.dataProviderTitleArray=arrayOfappraisalDetailDataProvider;
        if([asv.dataProviderTitleArray count]>0)
        {
            reqType=4;
            NSMutableDictionary *dic;
            if(self.appraisalSearchResultsController.isAddAppraisal && vehicleMappingAppraisalKey)
                dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", [NSString stringWithFormat:@"%d",vehicleMappingAppraisalKey],@"appraisalid",[[asv.dataProviderTitleArray objectAtIndex:countProvider] objectForKey:@"providerType"] ,@"providerType", self,@"delegate", nil];
            else
            {
            dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", asv->str_appraisalid,@"appraisalid",[[asv.dataProviderTitleArray objectAtIndex:countProvider] objectForKey:@"providerType"] ,@"providerType", self,@"delegate", nil];
                countProvider=1;
            }
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            [ws initialize:dic];
            [ws callWSWithQuery:dic];  
        }
        else {
        reqType=0;
        self.appraisalSearchResultsController.isAddAppraisal=FALSE;
        [self stopLoadingView];
          [asv createCellUI];
            refreshDataOn=FALSE;
             }
    }
    else if ([[response objectForKey:@"response"] objectForKey:@"appraisals"])
    {
        reqType=0;
        arrayOfAppraisalDetails = [[response objectForKey:@"response"] objectForKey:@"appraisals"];
    }
    else if([[response objectForKey:@"response"] objectForKey:@"dataproviderdetailnada"])
    {
        NSString *szTemp1,*szTemp2;
        NSMutableArray *arrayOfdataProvidersDetails = [[response objectForKey:@"response"] objectForKey:@"dataproviderdetailnada"];
        if([arrayOfdataProvidersDetails count]>0)
        {
           NSMutableDictionary *dataProviderDetailsTemp = [arrayOfdataProvidersDetails objectAtIndex:0];
            szTemp1 =   [ NSString stringWithString: [dataProviderDetailsTemp objectForKey:@"vehiclevaluationcondition"]];
        if ([szTemp1 length]>0) {
            if([szTemp1 isEqualToString:@"ExtraClean"])
                szTemp1=@"Extra Clean";
            [asv.dataProviderConditionArray addObject:szTemp1];
        }
            szTemp2 =   [ NSString stringWithString: [dataProviderDetailsTemp objectForKey:@"providercode"]];
        }
        if(countProvider < [asv.dataProviderTitleArray count] )
        {
            NSMutableDictionary *dic;
            if(self.appraisalSearchResultsController.isAddAppraisal && vehicleMappingAppraisalKey )
            {
                if(reqType==22 || reqType==2)
                {
                    reqType=4;
                    dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", [NSString stringWithFormat:@"%d",vehicleMappingAppraisalKey],@"appraisalid", [[asv.dataProviderTitleArray objectAtIndex:countProvider] objectForKey:@"providerType"] ,@"providerType",self,@"delegate", nil];
                }
                else
                {
                    arrayOfdataProvidersDetailsOptions = [[response objectForKey:@"response"] objectForKey:@"dataproviderdetailnada1"];
                    NSMutableArray *array = [[NSMutableArray alloc]init];              
                    if([arrayOfdataProvidersDetailsOptions count] >0)
                    {
                        for(int i=0;i<[arrayOfdataProvidersDetailsOptions count];i++)
                        {
                            dataProviderDetailsOptions = [arrayOfdataProvidersDetailsOptions objectAtIndex:i];
                            
                            if([[dataProviderDetailsOptions objectForKey:@"isincluded"] boolValue])
                            {
                                [array addObject:[dataProviderDetailsOptions objectForKey:@"optionname"]]; 
                            }
                        }
                    }
                reqType=22;
                dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype",  [[asv.dataProviderTitleArray objectAtIndex:countProvider] objectForKey:@"providerType"],@"providerType",  asv->str_appraisalid,@"appraisalid",szTemp2,@"providerCode",szTemp1,@"vehicleValuationCondition",[NSArray arrayWithObjects:array, nil],@"selectedOptionNames" ,self,@"delegate", nil];
                    countProvider=countProvider+1;
                }
            }
            else    
            {
                reqType=4;
            dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", asv->str_appraisalid,@"appraisalid", [[asv.dataProviderTitleArray objectAtIndex:countProvider] objectForKey:@"providerType"] ,@"providerType",self,@"delegate", nil];
                countProvider=countProvider+1;
            }
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            [ws initialize:dic];
            [ws callWSWithQuery:dic];  
        }
        else {
            reqType=0;
            self.appraisalSearchResultsController.isAddAppraisal=FALSE;
            [self stopLoadingView];
                [asv createCellUI];
            refreshDataOn=FALSE;
        }
    }
    else
    {
        reqType=0;
        asv->str_vehicle_key= [response objectForKey:@"responseString"];
            [self alertUser:@"" title:[NSString stringWithFormat: @"Vehicle added to inventory successfully."]]; 
    }
    if ([arrayOfappraisalDetailDataProvider count]>0) {
     appraisalDetail = [arrayOfappraisalDetailDataProvider objectAtIndex:0];
    }
    if ([arrayOfAppraisalDetails count]>0) {
        appraisalDetails = [arrayOfAppraisalDetails objectAtIndex:0];
        arrayOfAppraisalDetails=nil;
        /* Customer Data*/
        NSString *szTemp = [appraisalDetails objectForKey:@"customername"];
        if ([szTemp length]>0) {
            asv->str_customer = szTemp;
        }
        else {
            asv->str_customer = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"address"];
        if ([szTemp length]>0) {
            asv->str_customerAddress = szTemp;
        }
        else {
            asv->str_customerAddress = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"city"];
        if ([szTemp length]>0) {
            asv->str_city = szTemp;
        }
        else {
            asv->str_city = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"state"];
        if ([szTemp length]>0) {
            asv->str_state = szTemp;
        }
        else {
            asv->str_state = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"zip"];
        if ([szTemp length]>0) {
            asv->str_zip = szTemp;
        }
        else {
            asv->str_zip = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"phone"];
        if ([szTemp length]>0) {
            asv->str_phone = szTemp;
        }
        else {
            asv->str_phone = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"mobile"];
        if ([szTemp length]>0) {
            asv->str_mobile = szTemp;
        }
        else {
            asv->str_mobile = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"email"];
        if ([szTemp length]>0) {
            asv->str_email = szTemp;
        }
        else {
            asv->str_email = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"trim"];
        if ([szTemp length]>0) {
            asv->str_trim = szTemp;
        }
        else {
            asv->str_trim = @"n/a";
        }
        
        /*Vehicle data */
        szTemp = [appraisalDetails objectForKey:@"vin"];
        if ([szTemp length]>0) {
            asv->str_vin = szTemp;
        }
        else {
            asv->str_vin = @"n/a";
        }
        /*Type as in Web portal*/
        szTemp = [appraisalDetails objectForKey:@"year"];
        if ([szTemp length]>0) {
            asv->str_year = szTemp;
        }
        else {
            asv->str_year = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"make"];
        if ([szTemp length]>0) {
            asv->str_make = szTemp;
        }
        else {
            asv->str_make = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"model"];
        if ([szTemp length]>0) {
            asv->str_model = szTemp;
        }
        else {
            asv->str_model = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"style"];
        if ([szTemp length]>0) {
            asv->str_style = szTemp;
        }
        else {
            asv->str_style = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"titianiumid"];
        if ([szTemp length]>0) {
            asv->str_titianiumKey = szTemp;
        }
        else {
            asv->str_titianiumKey = @"n/a";
        }
        
        szTemp = [appraisalDetails objectForKey:@"mileage"];
        if ([szTemp length]>0) {
            asv->str_mileage = szTemp;
        }
        else {
            asv->str_mileage = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"colorexterior"];
        if ([szTemp length]>0) {
            asv->str_exteriorcolor = szTemp;
        }
        else {
            asv->str_exteriorcolor = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"colorinterior"];
        if ([szTemp length]>0) {
            asv->str_interiorcolor = szTemp;
        }
        else {
            asv->str_interiorcolor = @"n/a";
        }
        
        /* Appraisal data*/
        szTemp = [appraisalDetails objectForKey:@"expectedsaleprice"]; 
        if ([szTemp length]>0) {
            asv->str_expectedsaleprice= szTemp;
        }
        else {
            asv->str_expectedsaleprice = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"profitobjective"]; 
        if ([szTemp length]>0) {
            asv->str_profitobective = szTemp;
        }
        else {
            asv->str_profitobective = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"reconditioning"];
        if ([szTemp length]>0) {
            
            asv->str_recondtioning =szTemp; 
        }
        else {
            asv->str_recondtioning = @"n/a";
        }
        szTemp =  [appraisalDetails objectForKey:@"appraisedvalue"];
        if ([szTemp length]>0) {
            asv->str_appraisedvalue = szTemp;
        }
        else {
            asv->str_appraisedvalue = @"n/a";
        }
        
        szTemp = [appraisalDetails objectForKey:@"profitobjective"]; 
        if ([szTemp length]>0) {
            asv->str_profitobective = szTemp;
        }
        else {
            asv->str_profitobective = @"n/a";
        }
        
        szTemp = [appraisalDetails objectForKey:@"notes"]; 
        if ([szTemp length]>0) {
            asv->str_notes = szTemp;
        }
        else {
            asv->str_notes = @"n/a";
        }
        
        szTemp = [appraisalDetails objectForKey:@"salesperson"];
        if ([szTemp length]>0) {
            asv->str_datasalesperson =szTemp; 
        }
        else {
            asv->str_datasalesperson = @"n/a";
        }
        
        /* Data Providers/ Market Control Analysis*/
        szTemp = [appraisalDetails objectForKey:@"marketsize"]; 
        if ([szTemp length]>0) {
            asv->str_marketsize = szTemp;
        }
        else {
            asv->str_marketsize = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"marketaverageprice"]; 
        if ([szTemp length]>0) {
            asv->str_marketaverageprice = szTemp;
            //[asv->txt_marketaverageprice setText: szTemp];
        }
        else {
            asv->str_marketaverageprice = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"marketaveragemilesage"]; 
        if ([szTemp length]>0) {
            asv->str_marketaveragemileage = szTemp;
        }
        else {
            asv->str_marketaveragemileage = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"recommendedprice"]; 
        if ([szTemp length]>0) {
            asv->str_recommendedprice = szTemp;
        }
        else {
            asv->str_recommendedprice = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"dayssupply"]; 
        if ([szTemp length]>0) {
            if([szTemp intValue] < 0)
                asv->str_daysupply  = @"n/a";
            else
                asv->str_daysupply = szTemp;
        }
        else {
            asv->str_daysupply = @"n/a";
        }
        szTemp = [appraisalDetails objectForKey:@"pricerank"]; 
        if ([szTemp length]>0) {
            asv->str_pricerank = szTemp;
        }
        else {
            asv->str_pricerank = @"n/a";
        }
        
        szTemp = [appraisalDetails objectForKey:@"appraisalid"]; 
        if ([szTemp length]>0) {
            asv->str_appraisalid = szTemp;
        }
        else {
            asv->str_appraisalid = @"n/a";
        }
        reqType=2;
        NSMutableDictionary *dic;
       if(self.appraisalSearchResultsController.isAddAppraisal && [asv->str_titianiumKey intValue])
       {
           vehicleMappingAppraisalKey=[[appDelegate currentInstance]selectVehicleMapping:[asv->str_titianiumKey intValue]];
           if(vehicleMappingAppraisalKey)
               dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype",[NSString stringWithFormat:@"%d",vehicleMappingAppraisalKey],@"appraisalid",self,@"delegate", nil];
           else
           {
               self.appraisalSearchResultsController.isAddAppraisal=FALSE;
              dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype",asv->str_appraisalid,@"appraisalid",self,@"delegate", nil]; 
           }
       }
       else
       {
           self.appraisalSearchResultsController.isAddAppraisal=FALSE;
       dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype",asv->str_appraisalid,@"appraisalid",self,@"delegate", nil];
       }
        IVMMobileServices *ws2 = [[IVMMobileServices alloc] init];
        [ws2 initialize:dic];
        [ws2 callWSWithQuery:dic];
    }
    }
-(void) stopLoadingView
{
    if (loadingView != nil) {
        [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
        loadingView = nil;
    }

}
-(void) loadingView
{
    //Turn on loading view
	if (loadingView == nil) {
		loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0] loadingText:@"Loading..."];
	}
}

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
    countProvider=0;
    asv = [[AppraisalDetailsView alloc]init];
   /* Customer Data*/
    asv.appraisalDetailsController=self;
    asv.dataProviderConditionArray=[[NSMutableArray alloc]init];
    asv = [asv initWithFrame:CGRectZero searchObject:searchObj filterMode:NO];
    asv.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;	asv.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
	asv.target = self;
	self.view = asv;
    
    UIBarButtonItem *reappraisalBtn = [[UIBarButtonItem alloc] initWithTitle:@"Reappraise" style:UIBarButtonItemStylePlain target:self action:@selector(reappraisalAction)];
    reappraisalBtn.style = UIBarButtonItemStyleBordered;
    
    self.navigationItem.rightBarButtonItem = reappraisalBtn;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Appraisal" style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];
    [self loadingView];

}
- (void)advSearchError:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}
-(void)reappraisalAction
{
    AddAppraisalViewController *reappraisalCntrlr = [[AddAppraisalViewController alloc]initWithNibName:nil bundle:nil];
    reappraisalCntrlr.title = @"Reappraise";
    reappraisalCntrlr.apprasialStatus=2;
    reappraisalCntrlr.reqType=12;
    [reappraisalCntrlr reappraisalData:appraisalDetails];
    reappraisalCntrlr.appraisalSearchResultsController=appraisalSearchResultsController;
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:12],@"reqtype", @"Titanium",@"providerType", reappraisalCntrlr,@"delegate", nil];
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
    [self.navigationController pushViewController:reappraisalCntrlr animated:YES];
}
-(void) backAction
{
    [self.navigationController popToViewController:appraisalSearchResultsController animated:YES];
}
-(void) addToInventory
{
    if (loadingView == nil) {
        loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]] ;
    }
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:23],@"reqtype",asv->str_appraisalid,@"appraisalid",self,@"delegate", nil];
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
}
- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:message
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}
#pragma mark alertview delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(reqType==8)
    {
        if (loadingView != nil) {
            [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
            loadingView = nil;
        }

        [[self navigationController] popViewControllerAnimated:YES];
    }
    else {
    [self stopLoadingView];
    //Turn off loading view ...
    if (loadingView != nil) {
        [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
        loadingView = nil;
    }
    }
}

- (void)search:(id)sender{
	searchObj = ((AppraisalDetailsView*)self.view).searchObject;
	if (searchObj.dealerLot == 0) {
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Invalid DealerLot"
															message:@"Please Pick a Dealer Lot."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}
	[[appDelegate currentInstance] saveSearch:searchObj];
	SearchResultsController *src = [SearchResultsController new];
	[self.navigationController pushViewController:src animated:YES];
	[src startSearch:searchObj];
}
- (void)dealloc {
	searchObj = nil;
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

-(void) viewWillAppear:(BOOL)animated
{
    if(self.refreshDataOn)
        [self refreshData];
    [super viewWillAppear:YES];
}

-(void) refreshData
{
    self.appraisalSearchResultsController.isAddAppraisal=NO;
    [self loadingView];
    self.reqType=8;
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:self.reqType],@"reqtype", [appraisalDetails objectForKey:@"appraisalid"],@"appraisalid",self,@"delegate", nil];
    IVMMobileServices *ws1 = [[IVMMobileServices alloc] init];
        [ws1 initialize:dic];
        [ws1 callWSWithQuery:dic];
    [asv.dataProviderLabelArray removeAllObjects];
    [asv.dataProviderTitleArray removeAllObjects];
    [asv.dataProviderValueArray removeAllObjects];
    [asv->appraisalMenu removeAllObjects];
    [asv.vechicleLabelArray removeAllObjects];
    [asv.vechicleTitleArray removeAllObjects];
    [asv.dataProviderConditionArray removeAllObjects];
    countProvider=0;
    [asv->appraisalTableView removeFromSuperview];
}
@end
