//
//  CarfaxReportController.h
//  IVM
//
//  Created by Sehaswaran Mayilerum on 6/18/12.

// Vehicle History  Web View Controller

#import <UIKit/UIKit.h>
#import "LoadingView.h"
#import "SearchResultsView.h"
@interface CarfaxReportController : UIViewController
{
     SearchResultsView		*searchView;
    @public NSString			*str_appraisalid;
    NSMutableArray *dealerInfo;
    
}
@property (strong, nonatomic) IBOutlet UIWebView *carfaxReportWebView;
@property (strong, nonatomic) IBOutlet NSString  *webUrl;
@property(nonatomic,assign) int reqType;
@property (strong, nonatomic) LoadingView   *loadingView;
@end

