    //
//  AppraisalSearchResultsController.m
//
//  Created by Raja Sekhar Nerella on 3/20/12.
//

#import "appDelegate.h"
#import "AdvancedSearchView.h"
#import "DetailsController.h"
#import "SearchResultCell.h"
#import "NetImageView.h"
#import <QuartzCore/CoreAnimation.h>
#import <CoreLocation/CoreLocation.h>
#import "AppraisalSearchResultsController.h"
#import "AppraisalSearchResultsView.h"
#import "AddToInventoryController.h"
#import "SettingsController.h"
#import "AppraisalDetailsController.h"
#import "AppraisalDetailsView.h"
#import "SearchResultsView.h"
#import "AddAppraisalViewController.h"
#import "SearchAppraisalsViewController.h"

#define kSearchResultsSearcher @"searcher"

@interface AppraisalSearchResultsController()
- (void) clearLastSearch;
- (void) alertUser:(NSString*)message title:(NSString*)title;

- (void) changeUISegmentFont:(UIView*) aView;
@end

static NSString *searchCellIdentifier = @"SearchCell";

@implementation AppraisalSearchResultsController
@synthesize bSearchIsOn,appraisalsList,arrayAppraisals;

@synthesize loadedAll;
@synthesize loadingMore;
@synthesize mySearchBar;
@synthesize refreshDataOn;
@synthesize reqType;
@synthesize isAddAppraisal;

- (id)initWithRestore:(NSDictionary*)data{
	self = [self init];
	if (self != nil)
	{
		searcher = [data objectForKey:kSearchResultsSearcher];
		[self.view class];//Ensure that the view gets loaded
		[self startSearch:searcher];
	}
	return self;
}
- (NSDictionary*)getRestoreData{
	NSMutableDictionary* dict = [NSMutableDictionary dictionaryWithCapacity:1];
	if(searchResults != nil)
	{
		searcher.firstListing = 1;
		[dict setValue:searcher forKey:kSearchResultsSearcher];
	}
	return dict;
}
- (id) init
{
	self = [super init];
	if (self != nil) {
		netImageCache = [NSMutableDictionary dictionary];
		mobileServices = [[IVMMobileServices alloc] init];
		mobileServices.delegate = self;
		_userToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];
		self.title = @"Appraisal";
		[appDelegate track:@"Appraisal"];
	}
	return self;
}
- (void)setView:(UIView *)view
{
    if (!(_viewLoaded = nil != view))
    {
		// Clean up code here
		searchView = nil;
    }
    [super setView:view];
}
-(void) handleResponseForQuery:(NSMutableDictionary *)response
{
    if([response objectForKey:@"responseString"])
    {
        [[appDelegate currentInstance] clearVehicleMapping];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:kVehicleMappedDate];
        [[NSUserDefaults standardUserDefaults] synchronize];
        //[self refreshData];
        NSMutableDictionary *dic;
        [copyListOfItems removeAllObjects];
        [arrayAppraisals removeAllObjects];
        
        reqType=26;
        dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", self,@"delegate", nil];
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        [ws initialize:dic];
        [ws callWSWithQuery:dic];

    }
    else
    {
    if(searching && !(reqType==1))
    {
         copyListOfItems = [[response objectForKey:@"response"] objectForKey:@"appraisals"];
    }
    else {
    arrayAppraisals = [[response objectForKey:@"response"] objectForKey:@"appraisals"];
    }
     if(reqType==26)
     {
         if([arrayAppraisals count])
             [[appDelegate currentInstance] saveVehicleMapping:arrayAppraisals];
         NSMutableDictionary *dic;
         if(searching)
         {
         NSString *searchText = mySearchBar.text;
         if(searchText.length > 0)
         {
             reqType=19;
             dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype",searchText,@"filter", self,@"delegate", nil];
         }
         else
         {
                 reqType=1;
                 dic= [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", self,@"delegate", nil];
         }
         }
         else
         {
         reqType=1;
         dic= [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", self,@"delegate", nil];
         }
         IVMMobileServices *ws = [[IVMMobileServices alloc] init];
         [ws initialize:dic];
         [ws callWSWithQuery:dic];
     }
    else if(isDeleted && reqType==19)
    {
        reqType=1;
        NSMutableDictionary *dic= [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", self,@"delegate", nil];
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
        isDeleted=FALSE;
        
    }
    else
    {
    [appraisalsList reloadData];
    if (loadingView != nil) {
        [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
        loadingView = nil;
    }
    }
    }
}
// Implement loadView to create a view hierarchy programmatically.
- (void)loadView {
    isAddAppraisal=NO;
    nonCharacterSet = [[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789 .,-"] invertedSet];
    
	UIView *vw = [[UIView alloc] initWithFrame:CGRectZero];
	vw.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
    self.appraisalsList = [[UITableView alloc]initWithFrame:CGRectMake(0, 40, 320, 460) style:UITableViewStyleGrouped];
    appraisalsList.backgroundColor = [UIColor clearColor];
    appraisalsList.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
    appraisalsList.delegate = self;
    appraisalsList.dataSource = self;
    searching = NO;
    letUserSelectRow = YES;
    self.view = appraisalsList;
}
// Implement viewDidLoad to do additional setup after loading the view.
- (void)viewDidLoad {
    [super viewDidLoad];
    //Initialize the array.
	listOfItems = [[NSMutableArray alloc] init];
    //Initialize the copy array.
	copyListOfItems = [[NSMutableArray alloc] init];
    [loadMore setImage:[UIImage imageNamed:@"uparrow.png"] forState:UIControlStateNormal];
    [loadMore setTitle:@"Pull Up for More ..." forState:UIControlStateNormal];
	[loadMore setImageEdgeInsets:UIEdgeInsetsMake(0.0, -30.0, 0.0, 0.0)];
    loadMore.userInteractionEnabled = NO;

    self.mySearchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0.0, 0.0, self.view.bounds.size.width, 44.0)];
    mySearchBar.placeholder = @"Search Customer or Vehicle";
    mySearchBar.AutocapitalizationType = UITextAutocapitalizationTypeNone;
    mySearchBar.delegate = self;
    mySearchBar.showsCancelButton = NO;
    mySearchBar.tintColor = [UIColor blackColor];
    [mySearchBar sizeToFit];
    
    //Add the search bar
	self.appraisalsList.tableHeaderView = mySearchBar;
	mySearchBar.autocorrectionType = UITextAutocorrectionTypeNo;

    //Turn on loading view
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(plusbutton:)];
    //Turn on loading view
	if (loadingView == nil) {
		loadingView =  [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0] loadingText:@"Loading..."];
	}
    if(_attemptedLoad) {
		[self startSearch:searcher];
    }
}
- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
	_viewAppeared = YES;
}
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
	_viewAppeared = NO;
}
-(void) viewWillAppear:(BOOL)animated
{
    self.isAddAppraisal=FALSE;
    if(self.refreshDataOn)
        [self refreshData];
    [super viewWillAppear:YES];
}
- (void)startSearch:(VehicleSearchObject*)search{
	//Set searcher
	searcher = search;
	searcher.firstListing = 1;
	mobileServices.baseResults = nil;
    self.loadedAll = NO;
	_attemptedLoad = !_viewLoaded;  //Changed Apr-12-2011
	if(_attemptedLoad) return;
	//Clear display for new search
	[self clearLastSearch];
	//Turn on loading view
	if (loadingView == nil) {
		loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0] loadingText:@"Loading..."];
	}
	searchView.filterButton.hidden = YES;
	rightBarButton.enabled = NO;
	[mobileServices searchVehiclesByToken:search withToken:_userToken];
}

- (void)plusbutton:(id)sender{
    isAddAppraisal=YES;
    AddAppraisalViewController *addAppraisal = nil;
    addAppraisal = [[AddAppraisalViewController alloc]initWithNibName:nil bundle:nil];
    addAppraisal.title = @"Appraisal";
    addAppraisal.apprasialStatus=1;
    addAppraisal.reqType=12;
    addAppraisal.appraisalSearchResultsController=self;
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:12],@"reqtype", @"Titanium",@"providerType", addAppraisal,@"delegate", nil];
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
    [self.navigationController pushViewController:addAppraisal animated:YES];
}
- (void)filterbutton:(id)sender{
}
- (void)sortbutton:(id)sender{
}
- (void) clearLastSearch{
	[mobileServices cancel];
	[netImageCache removeAllObjects];
	searchResults = nil;
	[searchView.searchTable reloadData];
}
- (void) resortSearchResults{
	NSString * DISTANCE     = @"distance";
	NSString * PRICE		= @"price";
	NSString * YEAR			= @"year";
	NSString * MILEAGE      = @"mileage";
	NSSortDescriptor * distanceDescriptor = [[NSSortDescriptor alloc] initWithKey:DISTANCE ascending:YES];
	NSSortDescriptor * priceDescriptor = [[NSSortDescriptor alloc] initWithKey:PRICE ascending:NO];
	NSSortDescriptor * yearDescriptor = [[NSSortDescriptor alloc] initWithKey:YEAR ascending:NO];
	NSSortDescriptor * mileageDescriptor = [[NSSortDescriptor alloc] initWithKey:MILEAGE ascending:YES];
	NSArray * descriptors= [NSArray arrayWithObjects:distanceDescriptor, nil];
	if (seg_sort.selectedSegmentIndex == 0) {
		descriptors = [NSArray arrayWithObjects:distanceDescriptor, nil];
	} else if (seg_sort.selectedSegmentIndex == 1) {
		descriptors = [NSArray arrayWithObjects:priceDescriptor, nil];
	} else if (seg_sort.selectedSegmentIndex == 2) {
		descriptors = [NSArray arrayWithObjects:yearDescriptor, nil];
	} else if (seg_sort.selectedSegmentIndex == 3) {
		descriptors = [NSArray arrayWithObjects:mileageDescriptor, nil];
	}
	NSArray * sortedArray = [(searchResults.listings) sortedArrayUsingDescriptors:descriptors];
	[searchResults.listings setArray:sortedArray];
}
- (void) VehicleSearchComplete:(VehicleSearchResults*)results withStatus:dResult{
	searchResults = results;
    loadMore.imageView.transform = CGAffineTransformIdentity;
    loadMore.titleLabel.text = @"Pull Up for More ...";
    if (self.loadingMore) {
        self.loadingMore = NO;
    }
    if([dResult isEqualToString:@"Success"]) {
        if (searchResults.totalCount%kMaxPageResults != 0) {
            self.loadedAll = YES;
        }
    } else if([dResult isEqualToString:@"RecordNotFound"]) {
        self.loadedAll = YES;
    } else if(dResult == nil) {
        self.loadedAll = YES;
    }
	//Turn off loading view
	if (loadingView != nil) {
		[loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
		loadingView = nil;
	}
	rightBarButton.enabled = YES;
	[searchView.searchTable reloadData];
	searchView.filterButton.hidden = NO;
	if(![dResult isEqualToString:@"Success"])
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"The Web Services Failed"
															message:dResult 
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}
	//Need to add specific error code handling in the future
	if(self.navigationController.topViewController == self)
	{
		if(!results)
		{
			[self alertUser:@"No Vehicles" title:@"No vehicles were found try modifying your search."];
			return;
		}
	}
}
- (void)getListings:(CLLocationCoordinate2D)coordinates{
	searchView.activityLabel.text = @"Searching Vehicles...";
	mobileServices.baseResults = nil;
	[mobileServices searchVehiclesByToken:searcher withToken:_userToken];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
	[netImageCache removeAllObjects];
}
-(IBAction)mapClicked:(id)sender
{
}
- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:message
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}
- (void) changeUISegmentFont:(UIView*) aView {
	if ([aView isKindOfClass:[UILabel class]]) {
		UILabel* label = (UILabel*)aView;
		label.textAlignment = UITextAlignmentCenter;
		label.font = [UIFont boldSystemFontOfSize:kDefaultFontSize];
	}
	for(UIView *sub in [aView subviews])
		[self changeUISegmentFont:sub];
}
- (void)segmentTouchhed:(id)sender{
	[self changeUISegmentFont:seg_sort];
	searcher.sortBy = [seg_sort titleForSegmentAtIndex:seg_sort.selectedSegmentIndex];
	//Resorting the searchResults listing by the segment selected
	[self resortSearchResults];
	[searchView.searchTable reloadData];
}
#pragma mark alertview delegate
- (void)alertView:(UIAlertView *)inAlertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    isDeleted=FALSE;
    if(reqType == 26)
    {
        reqType=0;
        if (loadingView != nil) {
            [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
            loadingView = nil;
        }
        [[self navigationController] popViewControllerAnimated:YES];
    }
    else
    {
	if(searching)
	{
     if (loadingView != nil) {
     [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
     loadingView = nil;
     }
	}
	else
	{
        if (loadingView != nil) {
            [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
            loadingView = nil;
        }
        if([inAlertView.message isEqualToString:@"DealerLotKey was not found."])
        {
        }
        else
		[[self navigationController] popViewControllerAnimated:YES];
	}
    }
}
#pragma mark UITableView delegates
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    AppraisalDetailsController *detailsController = [[AppraisalDetailsController alloc]init];
    detailsController.appraisalSearchResultsController=self;
    detailsController.reqType=8;
    NSMutableDictionary *dic;
    if (searching) {
           dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:8],@"reqtype", [NSString stringWithString:[[copyListOfItems objectAtIndex:indexPath.row] objectForKey:@"appraisalid"]],@"appraisalid",detailsController,@"delegate", nil];
    }
    else
    {
        dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:8],@"reqtype", [NSString stringWithString:[[arrayAppraisals objectAtIndex:indexPath.row] objectForKey:@"appraisalid"]],@"appraisalid",detailsController,@"delegate", nil];
    }
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
	[[self navigationController] pushViewController:detailsController animated:YES];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return indexPath.row >= [searchResults.listings count] ? 60.0f : 100.0f;
}
#pragma mark UITableView datasource methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	if(searching)
    {
        if([copyListOfItems count])
		 return @"Search Results";
        return @"No Result found";   
    }else {
        return nil;
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (searching)
		return [copyListOfItems count];
	else {

         return [ arrayAppraisals count];
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
  /*AppraisalList  Begin*/
    static NSString *CellIdentifier = @"CellIndentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] ;
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.textLabel.font = [UIFont systemFontOfSize:14];
    }
    NSNumberFormatter *frm = [[NSNumberFormatter alloc] init];
    [frm setNumberStyle:NSNumberFormatterCurrencyStyle];
    [frm setMaximumFractionDigits:0];
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [frm setLocale:usLocale];
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    [numberFormatter setLocale:usLocale];
    if(searching) 
    {
        cell.textLabel.text = [NSString stringWithFormat:@"%@ %@ %@ %@", [[copyListOfItems objectAtIndex:indexPath.row ]objectForKey:@"year"],[[copyListOfItems objectAtIndex:indexPath.row ]objectForKey:@"make"],[[copyListOfItems objectAtIndex:indexPath.row ]objectForKey:@"model"],[[copyListOfItems objectAtIndex:indexPath.row ]objectForKey:@"style"]] ;
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ | %@ mi  | ( %@ )", [frm stringFromNumber:[NSNumber numberWithInt:[[[copyListOfItems objectAtIndex:indexPath.row ]objectForKey:@"appraisedvalue"] intValue ]]],[numberFormatter stringFromNumber:[NSNumber numberWithInt:[[[copyListOfItems objectAtIndex:indexPath.row ]objectForKey:@"mileage"] intValue]]],[[copyListOfItems objectAtIndex:indexPath.row ]objectForKey:@"customername"]] ;
    }
	else 
    {
        cell.textLabel.text = [NSString stringWithFormat:@"%@ %@ %@ %@", [[arrayAppraisals objectAtIndex:indexPath.row ]objectForKey:@"year"],[[arrayAppraisals objectAtIndex:indexPath.row ]objectForKey:@"make"],[[arrayAppraisals objectAtIndex:indexPath.row ]objectForKey:@"model"],[[arrayAppraisals objectAtIndex:indexPath.row ]objectForKey:@"style"]] ;
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ | %@ mi  | ( %@ )", [frm stringFromNumber:[NSNumber numberWithInt:[[[arrayAppraisals objectAtIndex:indexPath.row ]objectForKey:@"appraisedvalue"] intValue ]]],[numberFormatter stringFromNumber:[NSNumber numberWithInt:[[[arrayAppraisals objectAtIndex:indexPath.row ]objectForKey:@"mileage"] intValue]]],[[arrayAppraisals objectAtIndex:indexPath.row ]objectForKey:@"customername"]] ;
    }
    return cell;
}
- (NSIndexPath *)tableView :(UITableView *)theTableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if(letUserSelectRow)
		return indexPath;
	else
		return nil;
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return YES if you want the specified item to be editable.
    return YES;
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    isDeleted=TRUE;
    //Turn on loading view
	if (loadingView == nil) {
        loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
    }
    reqType=27;
    NSMutableDictionary *dic ;
    if (searching) {
        dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", [NSString stringWithString:[[copyListOfItems objectAtIndex:indexPath.row] objectForKey:@"appraisalid"]],@"appraisalid",self,@"delegate", nil];
    }
    else
    {
        dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", [NSString stringWithString:[[arrayAppraisals objectAtIndex:indexPath.row] objectForKey:@"appraisalid"]],@"appraisalid",self,@"delegate", nil];
    }
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
}
- (void)scrollViewDidScroll:(UIScrollView *)aScrollView {
    CGPoint offset = aScrollView.contentOffset;
    CGRect bounds = aScrollView.bounds;
    CGSize size = aScrollView.contentSize;
    UIEdgeInsets inset = aScrollView.contentInset;
    float y = offset.y + bounds.size.height - inset.bottom;
    float h = size.height;
    float reload_distance = loadMore.frame.size.height;
    if(!self.loadedAll && !self.loadingMore && (y > h + reload_distance)) {
        [UIView beginAnimations:@"rotate" context:nil];
        [UIView setAnimationDuration:.5f];
        loadMore.imageView.transform = CGAffineTransformMakeRotation(M_PI);
        [UIView commitAnimations];
        loadMore.titleLabel.text = @"Release to Load ...";
        self.loadingMore = YES;
        // Loading More ...
        [self performSelector:@selector(loadingMorePages) withObject:NULL afterDelay:0.0];
    } else {
        if (!self.loadedAll) {
            CGRect rect = loadMore.frame;
            rect.origin.y = 370.0 - (y - h);
            loadMore.frame = rect;
        }
    }
}

- (NSString*)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath {
    return @"Archive";
}
- (void)loadingMorePages
{
}
#pragma mark -
#pragma mark Search Bar 

-(BOOL) searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    BOOL result = NO; //default to reject
    NSLog(@"%@",text);
    if([text length] == 0){ //backspace
        result = YES;
    }
    else{
        if ([text isEqualToString:@"\n"])
            result = YES; // accept validation button
         else if([[text componentsSeparatedByCharactersInSet:nonCharacterSet] componentsJoinedByString: @""].length == text.length){
             result = YES;
        }
    }
    return result;
}
- (void) searchBarTextDidBeginEditing:(UISearchBar *)theSearchBar {
	//This method is called again when the user clicks back from teh detail view.
	//So the overlay is displayed on the results, which is something we do not want to happen.
	if(searchBarActive)
		return;
	//Add the overlay view.
	if(ovController == nil)
		ovController = [[SearchAppraisalsViewController alloc] initWithNibName:@"OverlayView" bundle:[NSBundle mainBundle]];
	
	CGFloat yaxis = self.navigationController.navigationBar.frame.size.height;
	CGFloat width = self.view.frame.size.width;
	CGFloat height = self.view.frame.size.height;
	//Parameters x = origion on x-axis, y = origon on y-axis.
	CGRect frame = CGRectMake(0, yaxis, width, height);
	ovController.view.frame = frame;	
	ovController.view.backgroundColor = [UIColor grayColor];
	ovController.view.alpha = 0.5;
	ovController->rvController = self;
	[self.appraisalsList insertSubview:ovController.view aboveSubview:self.parentViewController.view];
	searching = YES;
	letUserSelectRow = NO;
    searchBarActive=YES;
	self.appraisalsList.scrollEnabled = NO;
    mySearchBar.showsCancelButton=YES;
}
-(void) searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    searchBarActive=NO;
}
- (void)searchBar:(UISearchBar *)theSearchBar textDidChange:(NSString *)searchText {
}
- (void) searchBarSearchButtonClicked:(UISearchBar *)theSearchBar {
	//Remove all objects first.
	[copyListOfItems removeAllObjects];
		[ovController.view removeFromSuperview];
		searching = YES;
		letUserSelectRow = YES;
		self.appraisalsList.scrollEnabled = YES;
		[self searchTableView];
}
- (void) searchTableView {
	
	NSString *searchText = mySearchBar.text;
    mySearchBar.showsCancelButton=NO;
	[mySearchBar resignFirstResponder];
	self.appraisalsList.scrollEnabled = YES;
	[ovController.view removeFromSuperview];
	ovController = nil;
    //Turn on loading view
	if (loadingView == nil) {
		loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
	}
    NSMutableDictionary *dic;
    if(searchText.length > 0)
    {
        reqType=19;
    dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype",searchText,@"filter", self,@"delegate", nil];
    }
    else {
        reqType=26;
        dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", self,@"delegate", nil];
    }
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
}
-(void) searchBarCancelButtonClicked:(UISearchBar *)cancelsearchBar
{
    mySearchBar.text = @"";
    mySearchBar.showsCancelButton=NO;
	[mySearchBar resignFirstResponder];
	letUserSelectRow = YES;
	searching = NO;
	self.appraisalsList.scrollEnabled = YES;
	[ovController.view removeFromSuperview];
	ovController = nil;
	[self.appraisalsList reloadData];
}
- (void)dealloc {
	mobileServices.delegate = nil;
	//cancel operations
	[mobileServices cancel];
	//release everything
	searchView = nil;
	mobileServices = nil;
	netImageCache = nil;
	searchResults = nil;
	rightBarButton = nil;
	[self.navigationItem setRightBarButtonItem:nil];
	searcher = nil;
    loadMore = nil;
}
-(void) refreshData
{
    refreshDataOn=FALSE;
    //Turn on loading view
	if (loadingView == nil) {
		loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0] loadingText:@"Loading..."];
	}
    NSMutableDictionary *dic;
        [copyListOfItems removeAllObjects];
        [arrayAppraisals removeAllObjects];
        reqType=26;
        dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", self,@"delegate", nil];
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
    [self.appraisalsList reloadData];
}
@end
