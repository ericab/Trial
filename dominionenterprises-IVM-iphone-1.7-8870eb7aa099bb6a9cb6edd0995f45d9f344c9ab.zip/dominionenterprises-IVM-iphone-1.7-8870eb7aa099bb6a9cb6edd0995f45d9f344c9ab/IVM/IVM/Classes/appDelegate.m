//
//  appDelegate.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/11/08.
//  Copyright GetAuto.com 2008. All rights reserved.
//
#import "appDelegate.h"
#import "IVM.h"
#import "RecentSearchController.h"
#import "SavedListingsController.h"
#import "CameraViewController.h"
#import "RestoreProtocols.h"
#import "Reachability.h"
#import "OMAppMeasurement.h"
#import "HMACSHA256.h"
#import "DataCommonDigestAddition.h"
#import "LoadingView.h"
#import "Photo.h"

@interface appDelegate()
- (void)createEditableCopyOfDatabaseIfNeeded;
- (void)initializeDatabase;
@end

static OMAppMeasurement* s;
enum{
	TAG_HOME = 1,
	TAG_RECENTSEARCH = 2,
	TAG_RECENTADDED = 3,
	TAG_CAMERA = 4
};

@implementation appDelegate

@synthesize window, tabController, _userToken, _checkString;
@synthesize loginViewController;
@synthesize dealerVehicleHistory;
@synthesize vehicleHistoryStatus;
+ (void) initialize {
	if ([self class] == [appDelegate class]) {
		// Once-only initializion
		s = [[OMAppMeasurement alloc] init];
		// Specify the Report Suite ID(s) to track here
		s.account = @"dedsivmapp";
		// You may add or alter any code config here
		s.pageName = @"";
		s.pageURL = @"";
		s.currencyCode = @"USD";
		// Turn on and configure debugging here
		s.debugTracking = NO;
		/* WARNING: Changing any of the below variables will cause drastic changes
		 to how your visitor data is collected.  Changes should only be made
		 when instructed to do so by your account manager. */
		s.dc = @"112";

	}
	// Initialization for this class and any subclasses
}
+ (appDelegate*) currentInstance
{
	return (appDelegate*)[UIApplication sharedApplication].delegate;
}
+ (void)track:(NSString*)pagename
{
//#ifndef TARGET_IPHONE_SIMULATOR	
	s.pageName = pagename;
	[s track];
//#endif	
}
- (UIImage*) viewBackground {
	if(_viewBackground == nil){
		_viewBackground = [UIImage imageNamed:@"background.png"];
	}
	return _viewBackground;
}
-(void) switchBackHome
{
	[tabController setSelectedViewController:[tabController.viewControllers objectAtIndex:0]];
}
-(void) setUserIdPwd:(NSString*)userId andData:(NSString*)userPwd
{
	_userId = userId;
	_userPwd = userPwd;
	if (![[[NSUserDefaults standardUserDefaults] stringForKey:kUserName] isEqualToString:userId]) {
		[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserName];
		[[NSUserDefaults standardUserDefaults] setObject:_userId forKey:kUserName];
		[[NSUserDefaults standardUserDefaults] synchronize];
		//Clear the history database of previous USER
		[self clearRecent];
		[self clearBookmark];
	} 
	[NSThread detachNewThreadSelector:@selector(doAuthorization) toTarget:self withObject:nil];
}
-(void) setLoginStatus:(BOOL)bStatus
{
    loginStatus = bStatus;
}
-(void) setAuthenticateStatus:(BOOL)bStatus
{
    authenticatingStatus = bStatus;
}
-(void) dismissLoginView
{
	//Save the logined in User Name
	[[NSUserDefaults standardUserDefaults] setObject:_userId forKey:kUserName];
	[[NSUserDefaults standardUserDefaults] synchronize];
	//Load the DealerLots
	[self ValidateTokenAndDealerLots];
    tabController.selectedIndex=0;
	//Dismiss the LoginView
	[[tabController.viewControllers objectAtIndex:tabController.selectedIndex] dismissModalViewControllerAnimated:YES];
}
-(void) createAppViews
{
	tabController = [[UITabBarController alloc] init];
	//First Controller
	svc = [HomeViewController new];
	UINavigationController* snc = [[UINavigationController alloc] initWithRootViewController:svc];
	RecentSearchController *rcc = [RecentSearchController new];
	UINavigationController *rnc = [[UINavigationController alloc] initWithRootViewController:rcc];
	SavedListingsController *slc = [SavedListingsController new];
	UINavigationController *slnc = [[UINavigationController alloc] initWithRootViewController:slc];
	CameraViewController* cvc = [[CameraViewController alloc] initWithType:YES];
	UINavigationController* cnc = [[UINavigationController alloc] initWithRootViewController:cvc];
	snc.navigationBar.barStyle = UIBarStyleBlackOpaque;
	snc.navigationBar.tintColor = [UIColor colorWithRed:RedMake(kNavTintColor) green:GreenMake(kNavTintColor) blue:BlueMake(kNavTintColor) alpha:1.0];
	rnc.navigationBar.barStyle = UIBarStyleBlackOpaque;
	rnc.navigationBar.tintColor = [UIColor colorWithRed:RedMake(kNavTintColor) green:GreenMake(kNavTintColor) blue:BlueMake(kNavTintColor) alpha:1.0];
	slnc.navigationBar.barStyle = UIBarStyleBlackOpaque;
	slnc.navigationBar.tintColor = [UIColor colorWithRed:RedMake(kNavTintColor) green:GreenMake(kNavTintColor) blue:BlueMake(kNavTintColor) alpha:1.0];
	cnc.navigationBar.barStyle = UIBarStyleBlackOpaque;
	cnc.navigationBar.tintColor = [UIColor colorWithRed:RedMake(kNavTintColor) green:GreenMake(kNavTintColor) blue:BlueMake(kNavTintColor) alpha:1.0];
	UITabBarItem *tmp_tbi = [[UITabBarItem alloc] initWithTitle:@"Home" image:[UIImage imageNamed:@"home_icon.png"] tag:TAG_HOME];
	snc.tabBarItem = tmp_tbi;
	tmp_tbi = [[UITabBarItem alloc] initWithTitle:@"Recents" image:[UIImage imageNamed:@"recents.png"] tag:TAG_RECENTSEARCH];
	rnc.tabBarItem = tmp_tbi;
	tmp_tbi = [[UITabBarItem alloc] initWithTitle:@"Last Added" image:[UIImage imageNamed:@"last_added.png"] tag:TAG_RECENTADDED];
	slnc.tabBarItem = tmp_tbi;
	tmp_tbi = [[UITabBarItem alloc] initWithTitle:@"Camera" image:[UIImage imageNamed:@"camera.png"] tag:TAG_CAMERA];
	cnc.tabBarItem = tmp_tbi;
	tabController.viewControllers = [NSArray arrayWithObjects:snc, rnc, slnc, cnc, nil];
	tabController.delegate = self;
	
	NSDate *start = (NSDate*)[[NSUserDefaults standardUserDefaults] objectForKey:kLastLaunch];
	//Update last launch
	[[NSUserDefaults standardUserDefaults] setObject:[NSDate date] forKey:kLastLaunch];
	NSDate *end = (NSDate*)[[NSUserDefaults standardUserDefaults] objectForKey:kLastExit];
	
	//Make sure there was a successful exit of the application before restoring state
	if(start != nil && end != nil && [end timeIntervalSinceDate:start] > 0)
	{
		NSData *tmp_state = [[NSUserDefaults standardUserDefaults] dataForKey:kRestoreLocationKey];
		
		[[NSUserDefaults standardUserDefaults]removeObjectForKey:kRestoreLocationKey];
		[[NSUserDefaults standardUserDefaults]synchronize];
		if(tmp_state != nil)
		{
			NSDictionary* savedState = [NSKeyedUnarchiver unarchiveObjectWithData:tmp_state];
			if(savedState != nil && [[savedState allKeys] count] > 0)
			{
				NSNumber *view_index = (NSNumber*)[[savedState allKeys] objectAtIndex:0];
				tabController.selectedIndex = [view_index intValue];
				NSArray *state_data = [savedState objectForKey:[[savedState allKeys] objectAtIndex:0]];		
				
				id<AppRestore> selected = [[(UINavigationController*)tabController.selectedViewController viewControllers] objectAtIndex:0];
				[selected restore:state_data];
			}
		}
	}
	[window addSubview:tabController.view];
	[window makeKeyAndVisible];
}
- (void) ValidateTokenAndDealerLots {
	//Get the DealerLots list associated with the Token
	int dlstatus;
    vehicleHistoryStatus=NO;
    [self DealerLots:&dlstatus passToken:_userToken];
}
-(void) doAuthorization
{
	loginStatus = FALSE;
	@autoreleasepool {
	//Check if there is User Token
		int authStatus = 0;
		authenticatingStatus = YES;
		[self LoginAuthentication:&authStatus];
		while (authenticatingStatus) {
			[NSThread sleepForTimeInterval:1];
		};  
		// Do your download/parsing
		if (loginStatus) {
			[self performSelectorOnMainThread:@selector(dismissLoginView) withObject:self waitUntilDone:NO];
		}
	}
}
- (void)applicationDidFinishLaunching:(UIApplication *)application {
    
   // NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
	_service = [IVMMobileServices new];
	_service.delegate = self;
 
    //Check if the network connection is avaiable
    [self checkNetworkConnection];

	window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
 
	[self createEditableCopyOfDatabaseIfNeeded];
	[self initializeDatabase];

	int authStatus = 0;
	//Check the KeepLoggedIN setting
	BOOL	keepLogin = [[NSUserDefaults standardUserDefaults] boolForKey:kKeepLoggedIn];
	if (keepLogin) {
		//Check if there is User Token
		authenticatingStatus = YES;
		[self UserAuthentication:&authStatus];
		while (authenticatingStatus) {
			[NSThread sleepForTimeInterval:1];
		}
		if( loginStatus ) {
			[self ValidateTokenAndDealerLots];
		}
	}
	//Create the App Views
	[self createAppViews];

	if( !loginStatus ) {
         [[appDelegate currentInstance] clearVehicleMapping];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:kVehicleMappedDate];
		[[NSUserDefaults standardUserDefaults] synchronize];
        loginViewController = [LoginViewController new];
		loginViewController.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
		
		UINavigationController*	currentNav;
		if (tabController.selectedViewController) {
			currentNav = [[(UINavigationController*)tabController.selectedViewController viewControllers] objectAtIndex:0];
		} else {
			currentNav = (UINavigationController*)[tabController.viewControllers objectAtIndex:0];
		}
		[currentNav presentModalViewController:loginViewController animated:NO];
	}	
	
	if (authStatus == -1) {
		[self alertNoNetwork];
	}
	//Fade-in the login-in page of application
	splashView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
	splashView.image = [UIImage imageNamed:@"Default.png"];
	[window addSubview:splashView];
	[window bringSubviewToFront:splashView];
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:2.0];
	[UIView setAnimationTransition:UIViewAnimationTransitionNone forView:window cache:YES];
	[UIView setAnimationDelegate:self]; 
	[UIView setAnimationDidStopSelector:@selector(startupAnimationDone:finished:context:)];
	splashView.alpha = 0.0;
	splashView.frame = CGRectMake(-60, -85, 440, 635);
	[UIView commitAnimations];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
	id<AppRestore> selected = [[(UINavigationController*)[tabController selectedViewController] viewControllers] objectAtIndex:0];
	NSDictionary *state = [NSDictionary dictionaryWithObject:[selected getRestoreData] forKey:[NSNumber numberWithInt:tabController.selectedIndex]];
	// save the drill-down hierarchy of selections to preferences
	NSData* state_data = [NSKeyedArchiver archivedDataWithRootObject:state];
	[[NSUserDefaults standardUserDefaults] setObject:state_data forKey:kRestoreLocationKey];
	// Close the database.
    if (sqlite3_close(database) != SQLITE_OK) {
        NSAssert1(0, @"Error: failed to close database with message '%s'.", sqlite3_errmsg(database));
    }
	[[NSUserDefaults standardUserDefaults] setObject:[NSDate date] forKey:kLastExit];
}

- (void)startupAnimationDone:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context {
	[splashView removeFromSuperview];
}

- (void)initializeDatabase{
	// The database is stored in the application bundle. 
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:@"IVM.sqlite"];
	if (sqlite3_open([path UTF8String], &database) != SQLITE_OK)
	{
        // Even though the open failed, call close to properly clean up resources.
        sqlite3_close(database);
        NSAssert1(0, @"Failed to open database with message '%s'.", sqlite3_errmsg(database));
        // Additional error handling, as appropriate...		
	}
}
// Creates a writable copy of the bundled default database in the application Documents directory.
- (void)createEditableCopyOfDatabaseIfNeeded {
    // First, test for existence.
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *writableDBPath = [documentsDirectory stringByAppendingPathComponent:@"IVM.sqlite"];
    
    success = [fileManager fileExistsAtPath:writableDBPath];
    if (success) return;
    // The writable database does not exist, so copy the default to the appropriate location.
    NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"IVM.sqlite"];
    success = [fileManager copyItemAtPath:defaultDBPath toPath:writableDBPath error:&error];
    if (!success) {
        NSAssert1(0, @"Failed to create writable database file with message '%@'.", [error localizedDescription]);
    }
}

#pragma mark Bookmarks
- (NSArray*) getBookmarks{
	if(!database) return nil;
	 NSMutableArray *listings = [NSMutableArray array];
	 sqlite3_stmt *select_statement = nil;
	 static char *sql = "SELECT VehicleKey, VIN, StockNumber, Make, Model, Year, Price, Mileage, ExternalColor, InternalColor, BodyType, TrimLevel, Transmission, Image FROM SavedListings ORDER BY CreateDate DESC";
	 if (sqlite3_prepare_v2(database, sql, -1, &select_statement, NULL) != SQLITE_OK) {
		 NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	 }
	  
	 while (sqlite3_step(select_statement) == SQLITE_ROW) {
		 VehicleResult *result = [VehicleResult new];
		 
		 result.vehicle_key = sqlite3_column_int(select_statement, 0);
		 char *tmp = (char*)sqlite3_column_text(select_statement, 1);
		 result.vin = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
		 tmp = (char*)sqlite3_column_text(select_statement, 2);
		 result.stockNumber = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
		 tmp = (char*)sqlite3_column_text(select_statement, 3);
		 result.make = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
		 tmp = (char*)sqlite3_column_text(select_statement, 4);
		 result.model = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
		 result.year = sqlite3_column_int(select_statement, 5);
		 result.price = sqlite3_column_int(select_statement, 6);
		 result.mileage = sqlite3_column_int(select_statement, 7);
		 tmp = (char*)sqlite3_column_text(select_statement, 8);
		 result.externalColor = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
		 tmp = (char*)sqlite3_column_text(select_statement, 9);
		 result.internalColor = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
		 tmp = (char*)sqlite3_column_text(select_statement, 10);
		 result.bodyType = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
		 tmp = (char*)sqlite3_column_text(select_statement, 11);
		 result.trimLevel = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
		 tmp = (char*)sqlite3_column_text(select_statement, 12);
		 result.transmission = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
		 tmp = (char*)sqlite3_column_text(select_statement, 13);
		 result.image = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
		 
		 [listings addObject:result];
	 }
	sqlite3_finalize(select_statement);
	return listings;
}

- (void) saveBookmark:(VehicleResult*) listing{
	if(!database) return;
    // Open the database. The database was prepared outside the application.
	sqlite3_stmt *insert_statement = nil;
	static char *sql = "INSERT INTO SavedListings (VehicleKey, VIN, StockNumber, Make, Model, Year, Price, Mileage, ExternalColor, InternalColor, BodyType, TrimLevel, Transmission, Image) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	if (sqlite3_prepare_v2(database, sql, -1, &insert_statement, NULL) != SQLITE_OK) {
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	}
	
	sqlite3_bind_int(insert_statement, 1, listing.vehicle_key);
	if(listing.vin == nil)
		sqlite3_bind_null(insert_statement, 2);
	else
		sqlite3_bind_text(insert_statement, 2, [listing.vin UTF8String], -1, SQLITE_TRANSIENT);
	if(listing.stockNumber == nil)
		sqlite3_bind_null(insert_statement, 3);
	else
		sqlite3_bind_text(insert_statement, 3, [listing.stockNumber UTF8String], -1, SQLITE_TRANSIENT);
	if(listing.make == nil)
		sqlite3_bind_null(insert_statement, 4);
	else
		sqlite3_bind_text(insert_statement, 4, [listing.make UTF8String], -1, SQLITE_TRANSIENT);
	if(listing.model == nil)
		sqlite3_bind_null(insert_statement, 5);
	else
		sqlite3_bind_text(insert_statement, 5, [listing.model UTF8String], -1, SQLITE_TRANSIENT);
	sqlite3_bind_int(insert_statement, 6, listing.year);
	sqlite3_bind_int(insert_statement, 7, listing.price);
	sqlite3_bind_int(insert_statement, 8, listing.mileage);
	if(listing.externalColor == nil)
		sqlite3_bind_null(insert_statement, 9);
	else
		sqlite3_bind_text(insert_statement, 9, [listing.externalColor UTF8String], -1, SQLITE_TRANSIENT);
	if(listing.internalColor == nil)
		sqlite3_bind_null(insert_statement, 10);
	else
		sqlite3_bind_text(insert_statement, 10, [listing.internalColor UTF8String], -1, SQLITE_TRANSIENT);
	if(listing.bodyType == nil)
		sqlite3_bind_null(insert_statement, 11);
	else
		sqlite3_bind_text(insert_statement, 11, [listing.bodyType UTF8String], -1, SQLITE_TRANSIENT);
	if(listing.trimLevel == nil)
		sqlite3_bind_null(insert_statement, 12);
	else
		sqlite3_bind_text(insert_statement, 12, [listing.trimLevel UTF8String], -1, SQLITE_TRANSIENT);
	if(listing.transmission == nil)
		sqlite3_bind_null(insert_statement, 13);
	else
		sqlite3_bind_text(insert_statement, 13, [listing.transmission UTF8String], -1, SQLITE_TRANSIENT);
	if(listing.image == nil)
		sqlite3_bind_null(insert_statement, 14);
	else
		sqlite3_bind_text(insert_statement, 14, [listing.image UTF8String], -1, SQLITE_TRANSIENT);
	
	int success = sqlite3_step(insert_statement);
	sqlite3_finalize(insert_statement);	
	if (success == SQLITE_ERROR) {
		NSAssert1(0, @"Error: failed to insert into the database with message '%s'.", sqlite3_errmsg(database));
	}
}

- (void) updateBookmark:(Photo*)phData {
	if(!database) return;

	sqlite3_stmt *update_statement = nil;
	static char *sql = "UPDATE SavedListings SET Image = ? WHERE VehicleKey = ?";
	if (sqlite3_prepare_v2(database, sql, -1, &update_statement, NULL) != SQLITE_OK) {
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	}
	
	sqlite3_bind_text(update_statement, 1, [phData.t100Image UTF8String], -1, SQLITE_TRANSIENT);
	sqlite3_bind_int(update_statement, 2, phData.vehicleKey);
	
	int success = sqlite3_step(update_statement);
	sqlite3_finalize(update_statement);	
	if (success == SQLITE_ERROR) {
		NSAssert1(0, @"Error: failed to insert into the database with message '%s'.", sqlite3_errmsg(database));
	}
}

- (BOOL) hasBookmark:(int)vehicleKey {
	if(!database) return NO;
	BOOL hasMark = NO;
	sqlite3_stmt *select_statement = nil;
	static char *sql = "SELECT VehicleKey FROM SavedListings WHERE VehicleKey = ?";
	if (sqlite3_prepare_v2(database, sql, -1, &select_statement, NULL) != SQLITE_OK) {
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	}
	
	sqlite3_bind_int(select_statement, 1, vehicleKey);
	
	hasMark = sqlite3_step(select_statement) == SQLITE_ROW;

	sqlite3_finalize(select_statement);
	
	return hasMark;
}

- (void) deleteBookmark:(int)vehicleKey{
	if(!database) return;
	sqlite3_stmt *delete_statement = nil;
	static char *sql = "DELETE FROM SavedListings WHERE VehicleKey = ?";
	if (sqlite3_prepare_v2(database, sql, -1, &delete_statement, NULL) != SQLITE_OK) {
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	}
	
	sqlite3_bind_int(delete_statement, 1, vehicleKey);
	sqlite3_step(delete_statement);
	sqlite3_finalize(delete_statement);
}

- (void) clearBookmark {
	if(!database) return;
	sqlite3_stmt *delete_all_statement = nil;
	static char *sql = "DELETE FROM SavedListings";
	if (sqlite3_prepare_v2(database, sql, -1, &delete_all_statement, NULL) != SQLITE_OK) {
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	}
	
	sqlite3_step(delete_all_statement);
	sqlite3_finalize(delete_all_statement);
}

#pragma mark Recent Searches
- (void) saveSearch:(VehicleSearchObject*)search{
	if(!database) return;
    // Open the database. The database was prepared outside the application.
	sqlite3_stmt *insert_statement = nil;
	static char *sql = "INSERT INTO RecentSearches (DealerLot, FirstListing, ListingsPerPage, Make, Model, Year, MinPrice, MaxPrice, MinMileage, MaxMileage, Sort) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	if (sqlite3_prepare_v2(database, sql, -1, &insert_statement, NULL) != SQLITE_OK) {
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	}
	sqlite3_bind_int(insert_statement, 1, search.dealerLot);
	sqlite3_bind_int(insert_statement, 2, search.firstListing);
	sqlite3_bind_int(insert_statement, 3, search.listingsPerPage);
	if(search.make == nil)
		search.make = @"";
	sqlite3_bind_text(insert_statement, 4, [search.make UTF8String], -1, SQLITE_TRANSIENT);
	if(search.model == nil)
		search.model = @"";
	sqlite3_bind_text(insert_statement, 5, [search.model UTF8String], -1, SQLITE_TRANSIENT);
	sqlite3_bind_int(insert_statement, 6, search.year);
	sqlite3_bind_int(insert_statement, 7, search.minPrice);
	sqlite3_bind_int(insert_statement, 8, search.maxPrice);
	sqlite3_bind_int(insert_statement, 9, search.minMileage);
	sqlite3_bind_int(insert_statement, 10, search.maxMileage);
	if(search.sortBy)
		sqlite3_bind_text(insert_statement, 11, [search.sortBy UTF8String], -1, SQLITE_TRANSIENT);
	else
		sqlite3_bind_null(insert_statement, 11);
	
	int success = sqlite3_step(insert_statement);
	sqlite3_finalize(insert_statement);	
	if (success == SQLITE_ERROR) {
		NSAssert1(0, @"Error: failed to insert into the database with message '%s'.", sqlite3_errmsg(database));
	}
}

- (NSArray*) getSearches{
	if(!database) return nil;
	NSMutableArray *searches = [NSMutableArray array];
	sqlite3_stmt *select_statement = nil;
	static char *sql = "SELECT RSID, DealerLot, FirstListing, ListingsPerPage, Make, Model, Year, MinPrice, MaxPrice, MinMileage, MaxMileage, Sort  FROM RecentSearches ORDER BY CreateDate DESC";
	if (sqlite3_prepare_v2(database, sql, -1, &select_statement, NULL) != SQLITE_OK) {
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	}
	
	while (sqlite3_step(select_statement) == SQLITE_ROW) {
		char* tmp = nil;
		VehicleSearchObject *search = [VehicleSearchObject new];
		search.pk = sqlite3_column_int(select_statement, 0);
		search.dealerLot = sqlite3_column_int(select_statement, 1);
		search.firstListing = sqlite3_column_int(select_statement, 2);
		search.listingsPerPage = sqlite3_column_int(select_statement, 3);
		tmp = (char*)sqlite3_column_text(select_statement, 4);
		search.make = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
		tmp = (char*)sqlite3_column_text(select_statement, 5);
		search.model = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
			
		search.year = sqlite3_column_int(select_statement, 6);
		search.minPrice = sqlite3_column_int(select_statement, 7);
		search.maxPrice = sqlite3_column_int(select_statement, 8);
		search.minMileage = sqlite3_column_int(select_statement, 9);
		search.maxMileage = sqlite3_column_int(select_statement, 10);
		tmp = (char*)sqlite3_column_text(select_statement, 11);
		search.sortBy = tmp == NULL ? nil : [NSString stringWithUTF8String:tmp];
		
		[searches addObject:search];
	}
	sqlite3_finalize(select_statement);
	
	if([searches count] > 10)
	{
		//Remove any more than 10
		VehicleSearchObject *oldSearch = [searches objectAtIndex:10];
		char *delete = "DELETE FROM RecentSearches WHERE RSID <= ?";
		sqlite3_stmt *delete_statement = nil;
		if (sqlite3_prepare_v2(database, delete, -1, &delete_statement, NULL) != SQLITE_OK) {
			NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
		}
		sqlite3_bind_int(delete_statement, 1, oldSearch.pk);	
		sqlite3_step(delete_statement);	
		sqlite3_finalize(delete_statement);
		[searches removeObjectsInRange:(NSRange){ 10, [searches count] - 10}];
	}
 return searches;
}

- (void) deleteSearch:(int)pkID{
	if(!database) return;
	sqlite3_stmt *delete_statement = nil;
	static char *sql = "DELETE FROM RecentSearches WHERE RSID = ?";
	if (sqlite3_prepare_v2(database, sql, -1, &delete_statement, NULL) != SQLITE_OK) {
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	}
	
	sqlite3_bind_int(delete_statement, 1, pkID);	
	sqlite3_step(delete_statement);	
	sqlite3_finalize(delete_statement);
}

- (void) clearRecent{
	if(!database) return;
	sqlite3_stmt *delete_statement = nil;
	static char *sql = "DELETE FROM RecentSearches";
	if (sqlite3_prepare_v2(database, sql, -1, &delete_statement, NULL) != SQLITE_OK) {
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	}
	sqlite3_step(delete_statement);	
	sqlite3_finalize(delete_statement);
}
- (void) saveVehicleMapping:(NSMutableArray *)appraisals{
	if(!database) return;
    // Open the database. The database was prepared outside the application.
	sqlite3_stmt *insert_statement = nil;
	static char *sql = "INSERT INTO VehicleMapping (providerCode, appraisalKey) VALUES(?, ?)";
    for(int appraisalIndex=0;appraisalIndex<[appraisals count];appraisalIndex++)
    {
        if (sqlite3_prepare_v2(database, sql, -1, &insert_statement, NULL) != SQLITE_OK) {
            NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
        }
        sqlite3_bind_int(insert_statement, 1, [[[appraisals objectAtIndex:appraisalIndex] objectForKey:@"titianiumid"] intValue]);
	       sqlite3_bind_int(insert_statement, 2, [[[appraisals objectAtIndex:appraisalIndex] objectForKey:@"appraisalid"] intValue]);
	
           int success = sqlite3_step(insert_statement);
           sqlite3_finalize(insert_statement);
	       if (success == SQLITE_ERROR) {
		     NSAssert1(0, @"Error: failed to insert into the database with message '%s'.", sqlite3_errmsg(database));
	       }
    }
}

- (NSInteger) selectVehicleMapping:(NSInteger ) providerCode{
	if(!database) return 0;
    // Open the database. The database was prepared outside the application.
	sqlite3_stmt *select_statement = nil;
	NSString *sqlStatement = [NSString stringWithFormat: 
                              @"select appraisalKey from VehicleMapping where providerCode= \"%d\" ORDER BY appraisalKey DESC LIMIT 1", 
                              providerCode];

    if (sqlite3_prepare_v2(database, [sqlStatement UTF8String] , -1, &select_statement , NULL) != SQLITE_OK) {
            NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
        }
    NSInteger appraisalKey=0;     
       while(sqlite3_step(select_statement) == SQLITE_ROW) {
        appraisalKey = sqlite3_column_int(select_statement,0);
       }
        sqlite3_finalize(select_statement);
    return appraisalKey;
   
}
- (void) clearVehicleMapping{
	if(!database) return;
	sqlite3_stmt *delete_statement = nil;
	static char *sql = "DELETE FROM VehicleMapping";
	if (sqlite3_prepare_v2(database, sql, -1, &delete_statement, NULL) != SQLITE_OK) {
		NSAssert1(0, @"Error: failed to prepare statement with message '%s'.", sqlite3_errmsg(database));
	}
	sqlite3_step(delete_statement);	
	sqlite3_finalize(delete_statement);
}
- (void)DealerLots:(int*)status passToken:(NSString*)inToken
{
	Reachability *curReach = [Reachability reachabilityForInternetConnection];
	NetworkStatus netStatus = [curReach currentReachabilityStatus];
	
	if(netStatus == NotReachable)
	{
		[self alertNoNetwork];
		*status = -1;
		return;
	}

	*status = 1;
		
	[_service cancel];
    
	[_service getDealersByToken:inToken];
}
- (void) cancelDealerLots{
	[_service cancel];
}

- (void) GetDealersByTokenComplete:(NSMutableArray*)dealers dResult:(NSString*)dResult {
	if (![dResult isEqualToString:@"Success" ])
	{
		//Delete the Invalid Authentication Token
		[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserToken];
		[[NSUserDefaults standardUserDefaults] synchronize];

		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Get DealerLots Error"
											message:dResult 
											delegate:self 
											cancelButtonTitle:@"Ok"
											otherButtonTitles:nil];
		[alertView show];
	}
	
	if(dealers != nil && [dealers count] > 0)
	{
		dealerList = [[NSMutableArray alloc] initWithArray:dealers];
        int	defaultDealerLot = [[NSUserDefaults standardUserDefaults] integerForKey:kDefaultDealerLot];
       
        if(([self checkIndexOfDealerArray:defaultDealerLot]) && defaultDealerLot > 0  ) {
            //Dealer  *tDealer = [dealers objectAtIndex:0];
            svc.reqType=28;
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:svc.reqType],@"reqtype",svc,@"delegate", nil];
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            [ws initialize:dic];
            [ws callWSWithQuery:dic];
        }
        else
        {
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultDealerLot];
            [[NSUserDefaults standardUserDefaults] removeObjectForKey:kVehicleMappedDate];
            [[NSUserDefaults standardUserDefaults] synchronize];
            vehicleHistoryStatus=YES;
            [svc stopLoadingView];
            [svc refreshData];
        }
        
	} else {
		dealerList = nil;
        [svc stopLoadingView];
    }
    
}

-(void)GetDealersVehicleHistoryByTokenComplete:(DealerVehicleHistory *)dealerVehicleHistoryNew
{
    vehicleHistoryStatus=YES;
    self.dealerVehicleHistory=dealerVehicleHistoryNew;
    [svc stopLoadingView];
    
    
    

}
- (NSMutableArray*) getDealerList{
	return dealerList;
}
- (void) _showAlert:(NSString*)inMessage
{
	UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:@"Authentication Error" message:inMessage delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
	[alertView show];
}

- (void) ValidateTokenComplete:(int)resultCode {
	if (resultCode == 200) {
		[self setAuthenticateStatus:FALSE];
		[self setLoginStatus:TRUE];
	} else {
		[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserToken];
		[[NSUserDefaults standardUserDefaults] synchronize];
		NSString	*messageString;
		
		switch (resultCode) {
			case 401:
				messageString = @"Unauthorized Error!";
				break;
			case 403:
				messageString = @"Forbidden Error!";
				break;
			case 500:
				messageString = @"Internal Error!";
				break;
			default:
				messageString = @"Unknown Error!";
				break;
		}
		
        [self performSelectorOnMainThread:@selector(_showAlert:) withObject:messageString waitUntilDone:NO];

		[self setAuthenticateStatus:FALSE];
		[self setLoginStatus:FALSE];
	}
}

- (void) GenerateTokenComplete:(NSString*)inToken andResult:(int)resultCode {
	_userToken = inToken;
    //_userToken = @"28532da4-25aa-4942-8bd7-072d3c13383c";
	if (resultCode == 201) {
		[[NSUserDefaults standardUserDefaults] setObject:_userToken forKey:kUserToken];
		[[NSUserDefaults standardUserDefaults] synchronize];
		[self setAuthenticateStatus:FALSE];
		[self setLoginStatus:TRUE];
	} else {
		[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserToken];
		[[NSUserDefaults standardUserDefaults] synchronize];

		NSString	*messageString;
		
		switch (resultCode) {
			case 401:
				messageString = @"Unauthorized Error!";
				break;
			case 403:
				messageString = @"Forbidden Error!";
				break;
			case 500:
				messageString = @"Internal Error!";
				break;
			default:
				messageString = @"Unknown Error!";
				break;
		}

        [self performSelectorOnMainThread:@selector(_showAlert:) withObject:messageString waitUntilDone:NO];

		[self setAuthenticateStatus:FALSE];
		[self setLoginStatus:FALSE];
	}
}

- (void)UserAuthentication:(int*)status
{
	Reachability *curReach = [Reachability reachabilityForInternetConnection];
	NetworkStatus netStatus = [curReach currentReachabilityStatus];
	
	if(netStatus == NotReachable)
	{
//		[self alertNoNetwork];
		*status = -1;
		[self setAuthenticateStatus:FALSE];
		[self setLoginStatus:FALSE];
		return;
	}

	_userToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];

	if(_userToken != nil)
	{
		NSString *hashingString = [NSString stringWithFormat:@"%@%@%@", _userToken, preHashString, hashKeyString];
		
		NSData* tData = [hashingString dataUsingEncoding:NSUTF8StringEncoding];
		NSData *hashedData = [tData dataWithSha256];
		
		_checkString = [HMACSHA256 base64forData:hashedData];
		
		[self setAuthenticateStatus:TRUE];
		
		[_service cancel];
		[_service validateToken:_userToken andCheck:_checkString];
	}
	else {
		[self setAuthenticateStatus:FALSE];
		[self setLoginStatus:FALSE];
	}

	return;		
}

- (void)LoginAuthentication:(int*)status
{
	Reachability *curReach = [Reachability reachabilityForInternetConnection];
	NetworkStatus netStatus = [curReach currentReachabilityStatus];
	
	if(netStatus == NotReachable)
	{
//		[self alertNoNetwork];
		*status = -1;
		return;
	}
	
	NSString *hashingString = [NSString stringWithFormat:@"%@%@%@%@", preHashString, _userId, _userPwd, hashKeyString];

	NSData* tData = [hashingString dataUsingEncoding:NSUTF8StringEncoding];
	
	NSData *hashedData = [tData dataWithSha256];
	_checkString = [HMACSHA256 base64forData:hashedData];
	
	*status = 1;

	[_service cancel];
	[_service generateToken:_userId withPwd:_userPwd andCheck:_checkString];

	return;		
}

- (void) alertNoNetwork{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Check Network Connection"
														message:@"No network connection available" 
													   delegate:self 
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}

- (void)alertView:(UIAlertView *)inAlertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
   [svc stopLoadingView];    
    //Display LoginView
    loginViewController = [LoginViewController new];
    loginViewController.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    [(UINavigationController*)[tabController.viewControllers objectAtIndex:0] presentModalViewController:loginViewController animated:YES];
}
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController{
	UINavigationController *tmpNav = nil;

	tmpNav = (UINavigationController*)[tabBarController.viewControllers objectAtIndex:tabBarController.selectedIndex];

	switch (viewController.tabBarItem.tag) {
		case TAG_RECENTADDED:
			[(SavedListingsController*)[[tmpNav viewControllers] objectAtIndex:0] load];
			break;
		case TAG_RECENTSEARCH:
			[(RecentSearchController*)[[tmpNav viewControllers] objectAtIndex:0] load];
			break;
		case TAG_CAMERA:
			[(CameraViewController*)[[tmpNav viewControllers] objectAtIndex:0] cameraButtonTouchAction];
			break;
		default:
			[tmpNav popToRootViewControllerAnimated:YES];		//Animated Deallocates Details View
			break;
	}
}


- (BOOL)checkNetworkConnection
{
	int retryCount = 0;
    while (retryCount < 3) {
        Reachability *curReach = [Reachability reachabilityForInternetConnection];
        NetworkStatus netStatus = [curReach currentReachabilityStatus];
        
        if(netStatus == NotReachable)
        {
            [NSThread sleepForTimeInterval:WaitNetworkTimerDuration];
            retryCount++;
        } else {
            break;
        }
    }
    
    if (retryCount >= 3) {
        [self alertNoNetwork];
        return FALSE;
    }
    
    return TRUE;
}
/*void uncaughtExceptionHandler(NSException *exception) {
    NSLog(@"CRASH: %@", exception);
    NSLog(@"Stack Trace: %@", [exception callStackSymbols]);
    // Internal error reporting
}*/
- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title														message:message												   delegate:self											  cancelButtonTitle:@"Ok"										  otherButtonTitles:nil];
	[alertView show];
}
-(int)checkIndexOfDealerArray:(int) oldLotKey{
    int returnIndexofMatched=0;
    for (int dealerArrayIndex=0; dealerArrayIndex<[dealerList count]   ; dealerArrayIndex++){
        if(((Dealer*)[dealerList objectAtIndex:dealerArrayIndex ]).lotKey == oldLotKey){
            // Do not add
            returnIndexofMatched=dealerArrayIndex+1;
            break;
        }
    }
    
    return returnIndexofMatched;
}
@end
