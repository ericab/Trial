//
//  LoginViewController.h
//  GetAuto.com
//
//  Created by Shaofeng Tu on 6/10/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"
#import "IVMMobileServices.h"

@interface LoginViewController : UIViewController<UITextFieldDelegate, IVMMobileServicesDelegate, AppRestore> {
	UITextField			*txt_userID;
	UITextField			*txt_password;
	UIButton			*btn_login;
	NSString			*_userID;
	NSString			*_userPwd;
	NSString			*_hashedString;
	NSString			*_generatedToken;
	IVMMobileServices	*_mobileServices;
	NSCharacterSet      *nonUserIDCharactersSet;
	UIButton			*btn_checkbox;
	BOOL				checkboxSelected;
}
@end
