//
//  SearchResultsController.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/25/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//

#import "SearchResultsController.h"
#import "SearchResultsView.h"
#import "appDelegate.h"
#import "AdvancedSearchView.h"
#import "DetailsController.h"
#import "SearchResultCell.h"
#import "NetImageView.h"
#import "SearchResultsView.h"
#import <QuartzCore/CoreAnimation.h>
#import <CoreLocation/CoreLocation.h>
//#import "RMViewController.h"

#define kSearchResultsSearcher @"searcher"

@interface SearchResultsController()
- (void) clearLastSearch;
- (void)alertUser:(NSString*)message title:(NSString*)title;

- (void) changeUISegmentFont:(UIView*) aView;
@end

static NSString *searchCellIdentifier = @"SearchCell";

@implementation SearchResultsController

@synthesize loadedAll;
@synthesize loadingMore;

- (id)initWithRestore:(NSDictionary*)data{
	self = [self init];
	if (self != nil)
	{
		searcher = [data objectForKey:kSearchResultsSearcher];
		[self.view class];//Ensure that the view gets loaded
//		if(searcher.latitude == 0.0f)
//			searcher.latitude = -1.0f;
//		if(searcher.longitude == 0.0f)
//			searcher.longitude = -1.0f;
		[self startSearch:searcher];
	}
	return self;
}
- (NSDictionary*)getRestoreData{
	NSMutableDictionary* dict = [NSMutableDictionary dictionaryWithCapacity:1];
	if(searchResults != nil)
	{
		searcher.firstListing = 1;
		[dict setValue:searcher forKey:kSearchResultsSearcher];
	}
	return dict;
}

- (id) init
{
	self = [super init];
	if (self != nil) {
		netImageCache = [NSMutableDictionary dictionary];
		mobileServices = [[IVMMobileServices alloc] init];
		mobileServices.delegate = self;
		
//		[LocationController sharedInstance].locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
//		[LocationController sharedInstance].locationManager.distanceFilter = kCLDistanceFilterNone;
		
		_userToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];
		
//		rightBarButton = [[UIBarButtonItem alloc] initWithTitle:@"Map" style:UIBarButtonItemStyleBordered target:self action:@selector(mapClicked:)];
//		[self.navigationItem setRightBarButtonItem:rightBarButton];
		self.title = @"Search Results";
		[appDelegate track:@"Search Results"];
	}
	return self;
}

- (void)setView:(UIView *)view
{
    if (!(_viewLoaded = nil != view))
    {
		// Clean up code here
		searchView = nil;
		//searcher.firstListing = 1;
    }
	
    [super setView:view];
}

// Implement loadView to create a view hierarchy programmatically.
- (void)loadView {
	UIView *vw = [[UIView alloc] initWithFrame:CGRectZero];
	vw.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
//	vw.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
	self.view = vw;

//	UIColor *textColor = [UIColor lightGrayColor];
//	UIFont *lblFont = [UIFont fontWithName:kDefaultFont size:kDefaultFontSize + 3.0];
	 
	float yOffset = 0.0f;
	 
/*	//Sort
	UILabel *tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 120.0f, 20.0)];
	tmpLabel.font = lblFont;
	tmpLabel.textColor = textColor;
	tmpLabel.backgroundColor = [UIColor clearColor];
	tmpLabel.text = @"Sort Results By";
	[self.view addSubview:tmpLabel];
	[tmpLabel release];
	 
	yOffset += 20.0f;
	 
	NSArray *sorts = [NSArray arrayWithObjects:@"Distance", @"Price", @"Year", @"Mileage", nil];
	seg_sort = [[UISegmentedControl alloc] initWithItems:sorts];
	seg_sort.frame = CGRectMake(10.0f, yOffset, 300.0f, 30.0f);
	seg_sort.segmentedControlStyle = UISegmentedControlStyleBordered;
	[seg_sort addTarget:self action:@selector(segmentTouchhed:) forControlEvents:UIControlEventValueChanged];
	if(searcher.sortBy)
		 seg_sort.selectedSegmentIndex = [sorts indexOfObject:searcher.sortBy];
	[self.view addSubview:seg_sort];
	[self changeUISegmentFont:seg_sort];
	 
	yOffset += 30.0f;
*/
	searchView = [[SearchResultsView alloc] initWithFrame:CGRectMake(0.0f, yOffset + 2.0f, 0.0f, 0.0f)];
	searchView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	searchView.searchTable.delegate = self;
	searchView.searchTable.dataSource = self;
	[self.view addSubview:searchView];


    loadMore = [UIButton buttonWithType:UIButtonTypeCustom];
    loadMore.frame = CGRectMake(0.0f, 460.0f, 320.0f, 40.0);
    [loadMore setTitleColor:[UIColor blueColor] forState: UIControlStateNormal];
    loadMore.titleLabel.font = [UIFont italicSystemFontOfSize:kDefaultFontSize];
	loadMore.titleLabel.adjustsFontSizeToFitWidth = YES;
	[self.view addSubview:loadMore];
}

// Implement viewDidLoad to do additional setup after loading the view.
- (void)viewDidLoad {
    [super viewDidLoad];
	
    [loadMore setImage:[UIImage imageNamed:@"uparrow.png"] forState:UIControlStateNormal];
    [loadMore setTitle:@"Pull Up for More ..." forState:UIControlStateNormal];
	[loadMore setImageEdgeInsets:UIEdgeInsetsMake(0.0, -30.0, 0.0, 0.0)];
    loadMore.userInteractionEnabled = NO;

	if(_attemptedLoad) {
		[self startSearch:searcher];
    }
}

- (void)viewDidAppear:(BOOL)animated {
	[super viewDidAppear:animated];
	_viewAppeared = YES;
}

- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
	_viewAppeared = NO;
}

- (void)startSearch:(VehicleSearchObject*)search{
	//Set searcher
	searcher = search;
	searcher.firstListing = 1;
	mobileServices.baseResults = nil;
    self.loadedAll = NO;
		
	_attemptedLoad = !_viewLoaded;  //Changed Apr-12-2011
	if(_attemptedLoad) return;
	
	//Clear display for new search
	[self clearLastSearch];
	
	//Turn on loading view
	if (loadingView == nil) {
		loadingView = [LoadingView loadingViewInView:self.view loadingText:@"Loading..."];
	}
    
//	[searchView.activityIndicator startAnimating];
//	searchView.activityLabel.hidden = NO;
	searchView.filterButton.hidden = YES;
	rightBarButton.enabled = NO;

	[mobileServices searchVehiclesByToken:search withToken:_userToken];
}
	
- (void) clearLastSearch{
	[mobileServices cancel];
	[netImageCache removeAllObjects];
	searchResults = nil;
	[searchView.searchTable reloadData];
}

- (void) resortSearchResults{
	NSString * DISTANCE     = @"distance";
	NSString * PRICE		= @"price";
	NSString * YEAR			= @"year";
	NSString * MILEAGE      = @"mileage";
//	NSArray * descriptors;
	
	NSSortDescriptor * distanceDescriptor = [[NSSortDescriptor alloc] initWithKey:DISTANCE ascending:YES];
	NSSortDescriptor * priceDescriptor = [[NSSortDescriptor alloc] initWithKey:PRICE ascending:NO];
	NSSortDescriptor * yearDescriptor = [[NSSortDescriptor alloc] initWithKey:YEAR ascending:NO];
	NSSortDescriptor * mileageDescriptor = [[NSSortDescriptor alloc] initWithKey:MILEAGE ascending:YES];

	NSArray * descriptors= [NSArray arrayWithObjects:distanceDescriptor, nil];
	
	if (seg_sort.selectedSegmentIndex == 0) {
		descriptors = [NSArray arrayWithObjects:distanceDescriptor, nil];
	} else if (seg_sort.selectedSegmentIndex == 1) {
		descriptors = [NSArray arrayWithObjects:priceDescriptor, nil];
	} else if (seg_sort.selectedSegmentIndex == 2) {
		descriptors = [NSArray arrayWithObjects:yearDescriptor, nil];
	} else if (seg_sort.selectedSegmentIndex == 3) {
		descriptors = [NSArray arrayWithObjects:mileageDescriptor, nil];
	}
	
	NSArray * sortedArray = [(searchResults.listings) sortedArrayUsingDescriptors:descriptors];

	[searchResults.listings setArray:sortedArray];
}

- (void) VehicleSearchComplete:(VehicleSearchResults*)results withStatus:dResult{
	searchResults = results;
	
    loadMore.imageView.transform = CGAffineTransformIdentity;
    loadMore.titleLabel.text = @"Pull Up for More ...";
    
    if (self.loadingMore) {
        self.loadingMore = NO;
    }
    
    if([dResult isEqualToString:@"Success"]) {
        if (searchResults.totalCount%kMaxPageResults != 0) {
            self.loadedAll = YES;
        }
    } else if([dResult isEqualToString:@"RecordNotFound"]) {
        self.loadedAll = YES;
    } else if(dResult == nil) {
        self.loadedAll = YES;
    }
    
	//Turn off loading view
	if (loadingView != nil) {
		[loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
		loadingView = nil;
	}
    
//	[searchView.activityIndicator stopAnimating];
//	searchView.activityLabel.hidden = YES;
	rightBarButton.enabled = YES;
	[searchView.searchTable reloadData];
	searchView.filterButton.hidden = NO;
	
	if(![dResult isEqualToString:@"Success"])
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"The Web Services Failed"
															message:dResult 
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		
		return;
	}
	
	
	//Need to add specific error code handling in the future
	if(self.navigationController.topViewController == self)
	{
		if(!results)
		{
			[self alertUser:@"No Vehicles" title:@"No vehicles were found try modifying your search."];
			return;
		}
/*		else if(!results.isBasedOnCriteria && searcher.firstListing < 2)
		{
			UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil
																message:@"We currently do not have any vehicles matching your criteria but here are other featured vehicles in your area"
															   delegate:nil
													  cancelButtonTitle:@"Ok"
													  otherButtonTitles:nil];
			[alertView show];
			[alertView release];
		}
*/	}
}

- (void)getListings:(CLLocationCoordinate2D)coordinates{
	searchView.activityLabel.text = @"Searching Vehicles...";
//	searcher.latitude = coordinates.latitude;
//	searcher.longitude = coordinates.longitude;
	
	mobileServices.baseResults = nil;
	[mobileServices searchVehiclesByToken:searcher withToken:_userToken];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
	[netImageCache removeAllObjects];
}

-(IBAction)mapClicked:(id)sender
{
//	RMViewController *rmvc = [[[RMViewController alloc] initWithListings:searchResults imageCache:netImageCache detailsMode:NO] autorelease];
//	[self.navigationController pushViewController:rmvc animated:YES];
}

- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:message
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}

- (void) changeUISegmentFont:(UIView*) aView {
	if ([aView isKindOfClass:[UILabel class]]) {
		UILabel* label = (UILabel*)aView;
		label.textAlignment = UITextAlignmentCenter;
		label.font = [UIFont boldSystemFontOfSize:kDefaultFontSize];
	}
	for(UIView *sub in [aView subviews])
		[self changeUISegmentFont:sub];
}

- (void)segmentTouchhed:(id)sender{
	[self changeUISegmentFont:seg_sort];

	searcher.sortBy = [seg_sort titleForSegmentAtIndex:seg_sort.selectedSegmentIndex];

	//Resorting the searchResults listing by the segment selected
	[self resortSearchResults];
	
	[searchView.searchTable reloadData];
}

- (void)alertView:(UIAlertView *)inAlertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	/*if(_hasFiltered)
	{
		[self flipAction:self];
	}
	else*/
	//{
		[[self navigationController] popViewControllerAnimated:YES];
	//}
}

/*- (IBAction)doneAction:(id)sender
{
	//save preferences and re-search
	[self flipAction:sender];
}
*/
/*- (IBAction)flipAction:(id)sender
{
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:1.0];
	[UIView setAnimationTransition:([searchView superview] == self.view ? UIViewAnimationTransitionFlipFromLeft : UIViewAnimationTransitionFlipFromRight)
						   forView:self.view 
							 cache:YES];
	if ([rightBarButton.title isEqualToString:@"Cancel"])
	{
		if(sender != rightBarButton)
		{
			_hasFiltered = YES;
			searcher = [[(AdvancedSearchView*)[[self.view subviews] objectAtIndex:0] searchObject] retain];
			[self startSearch:searcher andGetLocation:NO];
		}
		[[[self.view subviews] objectAtIndex:0] removeFromSuperview];
		[self.view addSubview:searchView];
		self.navigationItem.hidesBackButton = NO;
		[rightBarButton setTitle:@"Map"];
		[rightBarButton setAction:@selector(mapClicked:)];
	}
	else
	{
#warning Pass searcher as copy
		AdvancedSearchView *asc = [[AdvancedSearchView alloc] initWithFrame:searchView.frame searchObject:searcher filterMode:YES];
		asc.layer.contents = (id)[appDelegate viewBackground].CGImage;
		[asc.search addTarget:self action:@selector(flipAction:) forControlEvents:UIControlEventTouchUpInside];
		[searchView removeFromSuperview];
		[self.view addSubview:asc];
		self.navigationItem.hidesBackButton = YES;
		[rightBarButton setTitle:@"Cancel"];
		[rightBarButton setAction:@selector(flipAction:)];
		[rightBarButton setEnabled:YES];
		
		[asc release];
	}
	
	[UIView commitAnimations];
}*/


#pragma mark CLLocationManagerDelegate delegates
/*
 *  locationManager:updatedLocation:
 *  
 *  Discussion:
 *    Invoked when a new location is available. oldLocation may be nil if there is no previous location
 *    available.
 */
/*- (void)locationUpdated:(CLLocationManager *)manager withLocation:(CLLocation *)location
{
	if([location.timestamp timeIntervalSinceNow] < -60) return;
	[LocationController sharedInstance].delegate = nil;
	[[[LocationController sharedInstance] locationManager] stopUpdatingLocation];
	[self getListings:location.coordinate];
}
*/
/*
 *  locationManager:failedWithError:
 *  
 *  Discussion:
 *    Invoked when an error has occurred.
 */
/*- (void)locationFailed:(CLLocationManager *)manager withError:(NSError *)error
{
//	[self alertUser:@"There was an error locating you try another search" title:@"Location Error"];
	if ([error domain] == kCLErrorDomain) {
		
		// We handle CoreLocation-related errors here
		switch ([error code]) {
				// "Don't Allow" on two successive app launches is the same as saying "never allow". The user
				// can reset this for all apps by going to Settings > General > Reset > Reset Location Warnings.
			case kCLErrorDenied:
				[self alertUser:@"\nZip Code or Current Location Needed!" title:@"Location Error"];
				break;
			case kCLErrorLocationUnknown:
				[self alertUser:@"\nUnknown Location Error." title:@"Location Error"];
				break;
				
			default:
				[self alertUser:@"\nDefault Location Failed Error." title:@"Location Error"];
				break;
		}
	} else {
		// We handle all non-CoreLocation errors here
	}
}
*/

#pragma mark UITableView delegates
/*
- (UITableViewCellAccessoryType)tableView:(UITableView *)tableView accessoryTypeForRowWithIndexPath:(NSIndexPath *)indexPath{
	return UITableViewCellAccessoryDisclosureIndicator;
}
*/
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
/*	if(indexPath.row >= [searchResults.listings count])
	{
		//Paging selected
		searcher.firstListing += searcher.listingsPerPage;
	 	mobileServices.baseResults = searchResults;
		[searchView.activityIndicator startAnimating];
		((UILabel*)[[[tableView cellForRowAtIndexPath:indexPath].contentView subviews] objectAtIndex:0]).text = @"Downloading...";
		[[tableView cellForRowAtIndexPath:indexPath] setUserInteractionEnabled:NO];
		[mobileServices searchVehiclesByToken:searcher withToken:_userToken];
		return;
	}
*/	
	VehicleResult *selected = (VehicleResult*)[searchResults.listings objectAtIndex:indexPath.row];
	UIImage *tmp = selected.image != nil ? [NetImageView imageForURL:[NSURL URLWithString:selected.image] withSize:CGSizeMake(100.0f, 75.0f) inCache:netImageCache] : nil;
//	DetailsController *detailsController = [[DetailsController alloc] initWithListing:selected andImage:tmp andPhotos:NO];
	DetailsController *detailsController = [[DetailsController alloc] initWithListing:selected andImage:tmp andPhotos:YES];
	[[self navigationController] pushViewController:detailsController animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return indexPath.row >= [searchResults.listings count] ? 60.0f : 100.0f;
}

#pragma mark UITableView datasource methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	int rows = [searchResults.listings count];
	if(searchResults.totalCount > rows) rows++;
	return rows;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.row >= [searchResults.listings count])
	{
		UITableViewCell *pagingcell = [tableView dequeueReusableCellWithIdentifier:@"paging"];
		NSString *text = [NSString stringWithFormat:@"Displaying %d of %d\nTouch for next %d", [searchResults.listings count], searchResults.totalCount, MIN(25,searchResults.totalCount - [searchResults.listings count])];
		if(!pagingcell)
		{
			pagingcell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"paging"];
			pagingcell.contentView.backgroundColor = [UIColor clearColor];
			pagingcell.backgroundColor = [UIColor blueColor];
			
			UILabel *plabel = [[UILabel alloc] initWithFrame:CGRectMake(5.0f, 5.0f, pagingcell.frame.size.width, 50.0f)];
			plabel.backgroundColor = [UIColor clearColor];
			plabel.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
			plabel.textAlignment = UITextAlignmentCenter;
			plabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
			plabel.numberOfLines = 2;
			plabel.text = text;
			[pagingcell.contentView addSubview:plabel];
		}
		else if(![searchView.activityIndicator isAnimating])
		{
			pagingcell.userInteractionEnabled = YES;
			((UILabel*)[[pagingcell.contentView subviews] objectAtIndex:0]).text = text;
		}
		
		return pagingcell;
	}
	
	SearchResultCell *cell = (SearchResultCell *)[tableView dequeueReusableCellWithIdentifier:searchCellIdentifier];
	if(cell == nil)
		cell = [[SearchResultCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:searchCellIdentifier];

	VehicleResult *listing = [searchResults.listings objectAtIndex:indexPath.row];

//	cell.netImage.cache = netImageCache;
//	[cell.netImage setImageURL:listing.image == nil ? nil : [NSURL URLWithString:listing.image]];

    cell.netImage.layer.borderWidth = 1;
    cell.netImage.layer.borderColor = [UIColor lightGrayColor].CGColor;		
    cell.netImage.layer.shadowOffset = CGSizeMake(4.0, 4.0);
    cell.netImage.layer.shadowOpacity = 0.6;
    cell.netImage.layer.shadowColor = [UIColor grayColor].CGColor;
    
    cell.netImage.cache = nil;
	[cell.netImage setImageURL:listing.image == nil ? nil : [NSURL URLWithString:listing.image] cache:nil];

    //	NSLog(@"cell.image = %@",listing.image );

//	cell.bodytype.text = listing.bodyType;
	cell.bodytype.text = [NSString stringWithFormat:@"Stock #:%@", listing.stockNumber];
	
//	cell.distance.hidden = listing.distance < 0;
//	cell.distance.text = [NSString stringWithFormat:@"%2.2f mi", listing.distance];

	if(listing.trimLevel == nil){
		cell.vehicle.text = [NSString stringWithFormat:@"%d %@ %@", listing.year, listing.make, listing.model];
	} else {
		cell.vehicle.text = [NSString stringWithFormat:@"%d %@ %@ %@", listing.year, listing.make, listing.model, listing.trimLevel];
	}
	
	cell.certifiedLogo.cache = netImageCache;
//	if(listing.certifiedLogoUrl)
//		[cell.certifiedLogo setImageURL:[NSURL URLWithString:listing.certifiedLogoUrl]];
//	else
//		cell.certifiedLogo.image = nil;
		
	{
		NSNumberFormatter *frm = [[NSNumberFormatter alloc] init];
		[frm setNumberStyle:NSNumberFormatterCurrencyStyle];
		[frm setCurrencySymbol:@""];
		[frm setMaximumFractionDigits:0];
        
        NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
        [frm setLocale:usLocale];
        
		cell.mileage.text = [NSString stringWithFormat:@"%@ mi", [frm stringFromNumber:[NSNumber numberWithInt:listing.mileage]]];
	}
	
//	cell.colors.text = [NSString stringWithFormat:@"%@, %@",  listing.externalColor ? listing.externalColor : @"", listing.internalColor ? listing.internalColor : @""];
	cell.colors.text = [NSString stringWithFormat:@"%@",  listing.externalColor ? listing.externalColor : @""];

	//cell.mlsNumber.hidden = listing.trimLevel == nil;
//	cell.mlsNumber.text = listing.transmission;

	if(listing.price > 0)
	{
		NSNumberFormatter *frm = [[NSNumberFormatter alloc] init];
		[frm setNumberStyle:NSNumberFormatterCurrencyStyle];
		[frm setMaximumFractionDigits:0];
        
        NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
        [frm setLocale:usLocale];
        
		cell.price.text = [frm stringFromNumber:[NSNumber numberWithInt:listing.price]];
	}
	else
		cell.price.text = @"Call For Price";
	
	
	cell.backgroundColor = [UIColor colorWithRed:RedMake(kResultBackground) green:GreenMake(kResultBackground) blue:BlueMake(kResultBackground) alpha:1.0];
	cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	return cell;
}

- (void)scrollViewDidScroll:(UIScrollView *)aScrollView {
    CGPoint offset = aScrollView.contentOffset;
    CGRect bounds = aScrollView.bounds;
    CGSize size = aScrollView.contentSize;
    UIEdgeInsets inset = aScrollView.contentInset;
    float y = offset.y + bounds.size.height - inset.bottom;
    float h = size.height;
    
//    float reload_distance = 10;
    float reload_distance = loadMore.frame.size.height;
    if(!self.loadedAll && !self.loadingMore && (y > h + reload_distance)) {
        [UIView beginAnimations:@"rotate" context:nil];
        [UIView setAnimationDuration:.5f];
        loadMore.imageView.transform = CGAffineTransformMakeRotation(M_PI);
        [UIView commitAnimations];
        
        loadMore.titleLabel.text = @"Release to Load ...";
        self.loadingMore = YES;
        
        // Loading More ...
        [self performSelector:@selector(loadingMorePages) withObject:NULL afterDelay:0.0];
    } else {
        if (!self.loadedAll) {
            CGRect rect = loadMore.frame;
            rect.origin.y = 370.0 - (y - h);
            
            loadMore.frame = rect;
        }
    }

}

- (void)loadingMorePages
{
    //Loading More Pages of the Searching Results
    searcher.firstListing += searcher.listingsPerPage;
    mobileServices.baseResults = searchResults;
    
	//Turn on loading view
	if (loadingView == nil) {
		loadingView = [LoadingView loadingViewInView:self.view loadingText:@"Loading More..."];
	}
    
    //Paging selected
    searcher.firstListing += searcher.listingsPerPage;
    mobileServices.baseResults = searchResults;
    [searchView.activityIndicator startAnimating];

    [mobileServices searchVehiclesByToken:searcher withToken:_userToken];
}


- (void)dealloc {
	//Clear delegates
/*	if([LocationController sharedInstance].delegate == self)
	{
		[[LocationController sharedInstance].locationManager stopUpdatingLocation];
		[LocationController sharedInstance].delegate = nil;
	}
*/
	mobileServices.delegate = nil;
	//cancel operations
	[mobileServices cancel];
	//release everything
	searchView = nil;
	mobileServices = nil;
	netImageCache = nil;
	searchResults = nil;
	rightBarButton = nil;
	[self.navigationItem setRightBarButtonItem:nil];
	searcher = nil;
    loadMore = nil;
	
}

@end
