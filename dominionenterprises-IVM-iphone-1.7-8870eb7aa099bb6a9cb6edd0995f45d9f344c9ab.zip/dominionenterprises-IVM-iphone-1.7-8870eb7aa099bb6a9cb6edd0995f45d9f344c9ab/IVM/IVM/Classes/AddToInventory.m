//
//  AddToInventory.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 3/13/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "AddToInventory.h"
#import "appDelegate.h"
#import "MakesAndModels.h"
#import <QuartzCore/QuartzCore.h>


static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;
static const CGFloat LANDSCAPE_KEYBOARD_HEIGHT = 162;


@implementation AddToInventory

@synthesize txt_vinCode, txt_price, txt_mileage, btn_VinCodeScan, btn_linkPictures, btn_addVehicle,  vehicleLabel;
@synthesize backgroundView01, backgroundView02;
@synthesize price, mileage, viewScanning,  priceLabel, mileageLabel;
@dynamic vinCode;

//- (NSString*) sort
//{
//	return [seg_sort titleForSegmentAtIndex:[seg_sort selectedSegmentIndex]];
//}
//- (void) setZip:(NSString*)inVinCode
- (void) setVinCode:(NSString*)inVinCode
{
	@synchronized(txt_vinCode)
	{
		txt_vinCode.text = inVinCode;
	}
}

- (NSString*) vinCode{
	@synchronized(txt_vinCode)
	{
		return txt_vinCode.text;
	}
	return nil; //Supress warning.. never gets hit
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self != nil) {
        // Initialization code
		float yOffset = 20.0f;
		viewScanning = TRUE;
		
		currencyFormatter = [[NSNumberFormatter alloc] init];
		[currencyFormatter setFormatterBehavior:NSNumberFormatterBehavior10_4];
		[currencyFormatter setGeneratesDecimalNumbers:YES];
		[currencyFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
		[currencyFormatter setCurrencySymbol:@""];
//		[currencyFormatter setAllowsFloats:YES];
		[currencyFormatter setMaximumFractionDigits:0];
		[currencyFormatter setLocale:[NSLocale currentLocale]];
		
        NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
        [currencyFormatter setLocale:usLocale];
        
        
		//set up the reject character set
		NSMutableCharacterSet *numberSet = [[NSCharacterSet decimalDigitCharacterSet] mutableCopy];
		[numberSet formUnionWithCharacterSet:[NSCharacterSet whitespaceCharacterSet]];
		nonNumberSet = [numberSet invertedSet];

		NSMutableCharacterSet *upcaseCharactersSet = [[NSCharacterSet uppercaseLetterCharacterSet] mutableCopy];
		[upcaseCharactersSet formUnionWithCharacterSet:[NSCharacterSet decimalDigitCharacterSet]];
		nonVINCodeCharactersSet = [upcaseCharactersSet invertedSet];

        backgroundView01 = [[UIView alloc] initWithFrame:CGRectMake(10.0f, yOffset - 5.0, 300.0f, 155.0f)];
        backgroundView01.backgroundColor = [UIColor whiteColor];
		backgroundView01.layer.cornerRadius = 8.0;
		[self addSubview:backgroundView01];

        backgroundView02 = [[UIView alloc] initWithFrame:CGRectMake(10.0f, 200.0, 300.0f, 155.0f)];
        backgroundView02.backgroundColor = [UIColor whiteColor];
		backgroundView02.layer.cornerRadius = 8.0;
		[self addSubview:backgroundView02];
        
        vinView = [[UIImageView alloc] initWithFrame:CGRectMake(20.0f, yOffset + 10.0, 280.0f, 60.0)];
        vinView.image = [UIImage imageNamed:@"vin.jpg"];
        [self addSubview:vinView];

		btn_VinCodeScan = [UIButton buttonWithType:UIButtonTypeCustom];
		btn_VinCodeScan.frame = CGRectMake(20.0f, yOffset + 90.0, 280.0f, 45.0);
		[btn_VinCodeScan setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
		[btn_VinCodeScan setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btn_VinCodeScan.titleLabel.font = [UIFont boldSystemFontOfSize: 20];
		[btn_VinCodeScan setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		[btn_VinCodeScan setTitle:@"Scan the VIN BarCode" forState:UIControlStateNormal];
		[self addSubview:btn_VinCodeScan];
		
		// OR Label
		orLabel = [[UILabel alloc] initWithFrame:CGRectMake(140.0f, 170.0, 40.0f, 30.0f)];
		orLabel.backgroundColor = [UIColor clearColor];
		orLabel.textColor = [UIColor blackColor];
		orLabel.font = [UIFont boldSystemFontOfSize:kDefaultFontSize + 6.0];
		orLabel.text = @"OR";
		[self addSubview:orLabel];

		vehicleLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, yOffset, 220.0f, 50.0f)];
//		vehicleLabel.textColor = [UIColor colorWithRed:RedMake(kSCAddressRGB) green:GreenMake(kSCAddressRGB) blue:BlueMake(kSCAddressRGB) alpha:1.0];
		vehicleLabel.textColor = [UIColor blackColor];
		vehicleLabel.backgroundColor = [UIColor clearColor];
		vehicleLabel.lineBreakMode = UILineBreakModeWordWrap;
		vehicleLabel.numberOfLines = 0;
		vehicleLabel.hidden = viewScanning;
		[self addSubview:vehicleLabel];

		yOffset += 60.0f;

		//VIN Code Label
		vinLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 220.0, 180.0f, 15.0f)];
		vinLabel.backgroundColor = [UIColor clearColor];
		vinLabel.textColor = [UIColor blackColor];
		vinLabel.font = [UIFont systemFontOfSize:kDefaultFontSize + 2.0];
		vinLabel.text = @"Manual VIN Entry";
		[self addSubview:vinLabel];
		
		yOffset += 30.0f;
		
//		txt_vinCode = [[UITextField alloc] initWithFrame:CGRectMake(20.0f, yOffset, 280.0f, 30.0f)];
		txt_vinCode = [[UITextField alloc] initWithFrame:CGRectMake(20.0f, 240.0, 280.0f, 30.0f)];
		txt_vinCode.borderStyle = UITextBorderStyleRoundedRect;
		txt_vinCode.returnKeyType = UIReturnKeyDone;
		txt_vinCode.clearButtonMode = UITextFieldViewModeWhileEditing;
		txt_vinCode.font = [UIFont systemFontOfSize:kDefaultFontSize + 2.0];
        txt_vinCode.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
//		txt_vinCode.placeholder = @"Scan BarCode/Input Manaully";
		txt_vinCode.placeholder = @"VIN Number";
		txt_vinCode.autocorrectionType = UITextAutocorrectionTypeNo;
		txt_vinCode.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
		txt_vinCode.delegate = self;
		txt_vinCode.enabled= viewScanning;
		[self addSubview:txt_vinCode];
		
		//yOffset += 50.0f;

		priceLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, yOffset, 100.0f, 30.0)];
		priceLabel.textColor = [UIColor blackColor];
		priceLabel.backgroundColor = [UIColor clearColor];
		priceLabel.text = @"Price $";
		[self addSubview:priceLabel];
		
		txt_price = [[UITextField alloc] initWithFrame:CGRectMake(120.0f, yOffset, 180.0f, 30.0f)];
		txt_price.borderStyle = UITextBorderStyleRoundedRect;
		txt_price.returnKeyType = UIReturnKeyDone;
		txt_price.clearButtonMode = UITextFieldViewModeWhileEditing;
		txt_price.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
		txt_price.placeholder = @"Price $";
		[txt_price addTarget:self action:@selector(getValue:) forControlEvents:UIControlEventEditingDidEnd];
		txt_price.autocorrectionType = UITextAutocorrectionTypeNo;
		txt_price.delegate = self;
		txt_price.enabled= !viewScanning;
		[self addSubview:txt_price];
		
		yOffset += 40.0f;
		
		mileageLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, yOffset, 100.0f, 30.0)];
		mileageLabel.textColor = [UIColor blackColor];
		mileageLabel.backgroundColor = [UIColor clearColor];
		mileageLabel.text = @"Mileage";
		[self addSubview:mileageLabel];
		
		
		txt_mileage = [[UITextField alloc] initWithFrame:CGRectMake(120.0f, yOffset, 180.0f, 30.0f)];
		txt_mileage.borderStyle = UITextBorderStyleRoundedRect;
		txt_mileage.returnKeyType = UIReturnKeyDone;
		txt_mileage.clearButtonMode = UITextFieldViewModeWhileEditing;
		txt_mileage.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
		txt_mileage.placeholder = @"Mileage";
		[txt_mileage addTarget:self action:@selector(getValue:) forControlEvents:UIControlEventEditingDidEnd];
		txt_mileage.autocorrectionType = UITextAutocorrectionTypeNo;
		txt_mileage.delegate = self;
		txt_mileage.enabled= !viewScanning;
		[self addSubview:txt_mileage];

		yOffset += 90.0f;
		
		yOffset += 55.0f;
		
		btn_addVehicle = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		if (viewScanning) {
			[btn_addVehicle setTitle:@"VIN Decoder" forState:UIControlStateNormal];
		} else {
			[btn_addVehicle setTitle:@"Add To Inventory" forState:UIControlStateNormal];
		}
		[btn_addVehicle setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
		[btn_addVehicle setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btn_addVehicle.titleLabel.font = [UIFont boldSystemFontOfSize: 20];
		[btn_addVehicle setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		btn_addVehicle.frame = CGRectMake(20.0f, yOffset, 280.0f, 45.0f);	
		[self addSubview:btn_addVehicle];
		
	}

    return self;
}

/*
- (void)alertView:(UIAlertView *)inAlertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	[target performSelector:errorCallback withObject:self];
}
*/

- (void) refreshViews
{
	viewScanning = !viewScanning;
	
	btn_VinCodeScan.hidden = !viewScanning;
	orLabel.hidden = !viewScanning;
	vinLabel.hidden = !viewScanning;
	vinView.hidden = !viewScanning;
	backgroundView01.hidden = !viewScanning;
	backgroundView02.hidden = !viewScanning;
	vinView.hidden = !viewScanning;
	vehicleLabel.hidden = viewScanning;
	txt_vinCode.enabled= viewScanning;
	txt_price.enabled= !viewScanning;
	txt_mileage.enabled= !viewScanning;
	priceLabel.hidden = viewScanning;
	mileageLabel.hidden = viewScanning;
	txt_price.hidden = viewScanning;
	txt_mileage.hidden = viewScanning;

	if (viewScanning) {
		[btn_addVehicle setTitle:@"VIN Decoder" forState:UIControlStateNormal];
	} else {
		[btn_addVehicle setTitle:@"Add To Inventory" forState:UIControlStateNormal];
	}
}

#pragma mark UITextField delegate methods
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    CGRect textFieldRect = [self.window convertRect:textField.bounds fromView:textField];
    CGRect viewRect = [self.window convertRect:self.bounds fromView:self];
	
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
	midline - viewRect.origin.y
	- MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
	(MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
	* viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
	
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
	
    UIInterfaceOrientation orientation =
	[[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationPortrait ||
        orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    }
    else
    {
        animatedDistance = floor(LANDSCAPE_KEYBOARD_HEIGHT * heightFraction);
    }
	
    CGRect viewFrame = self.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self setFrame:viewFrame];
    
    [UIView commitAnimations];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = self.frame;
    viewFrame.origin.y += animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [self setFrame:viewFrame];
    
    [UIView commitAnimations];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	return YES;
}

- (void)getValue:(id)sender {
	if( ((UITextField *)sender) == txt_price ){
		price = [[currencyFormatter numberFromString:((UITextField *)sender).text] floatValue];
	}else if (((UITextField *)sender) == txt_mileage) {
		mileage = [[currencyFormatter numberFromString:((UITextField *)sender).text] floatValue];
	}
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
	BOOL result = NO; //default to reject
	
	//Handle the VIN Code text field without using formater
	if (textField == txt_vinCode) {
		if([string length] == 0){ //backspace
			return YES;
		}else{
			if([string stringByTrimmingCharactersInSet:nonVINCodeCharactersSet].length > 0){
				return YES;
			}
		}
	} else if (textField == txt_price || textField == txt_mileage) {
	
		if([string length] == 0){ //backspace
			result = YES;
		}else{
			if([string stringByTrimmingCharactersInSet:nonNumberSet].length > 0){
				result = YES;
			}
		}
	
		//here we deal with the UITextField on our own
		if(result){
			//grab a mutable copy of what's currently in the UITextField
			NSMutableString* mstring = [[textField text] mutableCopy];
			if([mstring length] == 0){
				//now append the replacement string
				[mstring appendString:string];
			}else{
				//adding a char or deleting?
				if([string length] > 0){
					[mstring insertString:string atIndex:range.location];
				}else {
					//delete case - the length of replacement string is zero for a delete
					[mstring deleteCharactersInRange:range];
				}
			}
		
			//to get the grouping separators properly placed
			//first convert the string into a number. The function
			//will ignore any grouping symbols already present -- NOT in iOS4!
			//fix added below - remove locale specific currency separators first
			NSString* localeSeparator = [[NSLocale currentLocale] 
										 objectForKey:NSLocaleGroupingSeparator];
			NSNumber* number = [currencyFormatter numberFromString:[mstring
																	stringByReplacingOccurrencesOfString:localeSeparator 
																	withString:@""]];
			
			//now format the number back to the proper currency string
			//and get the grouping separators added in and put it in the UITextField
			[textField setText:[currencyFormatter stringFromNumber:number]];
		}
	}
	
	//always return no since we are manually changing the text field
	return NO;
}
- (void)shiftUpButton {
//	CGRect viewFrame = btn_addVehicle.frame;
//	viewFrame.origin.y -= 20.0f;
	
//	[UIView beginAnimations:nil context:NULL];
//	[UIView setAnimationBeginsFromCurrentState:YES];
//	[UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
	
	priceLabel.hidden = YES;
	mileageLabel.hidden = YES;
	txt_price.hidden = YES;
	txt_mileage.hidden = YES;
	
//	[btn_addVehicle setFrame:viewFrame];
	
//	[UIView commitAnimations];
}

- (void)shiftDownButton {
//	CGRect viewFrame = btn_addVehicle.frame;
//	viewFrame.origin.y += 20.0f;
	
//	[UIView beginAnimations:nil context:NULL];
//	[UIView setAnimationBeginsFromCurrentState:YES];
//	[UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
	
//	[btn_addVehicle setFrame:viewFrame];
	
//	[UIView commitAnimations];

	priceLabel.hidden = NO;
	mileageLabel.hidden = NO;
	txt_price.hidden = NO;
	txt_mileage.hidden = NO;
    backgroundView01.hidden = YES;
    backgroundView02.hidden = YES;
    orLabel.hidden = YES;
    vinLabel.hidden = YES;
    
}


@end
