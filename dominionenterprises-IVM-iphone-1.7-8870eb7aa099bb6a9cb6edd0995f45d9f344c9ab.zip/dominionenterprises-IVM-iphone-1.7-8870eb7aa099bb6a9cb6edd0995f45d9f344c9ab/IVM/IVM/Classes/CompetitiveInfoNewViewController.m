//
//  CompetitiveInfoNewViewController.m
//  IVM
//
//  Created by Sehaswaran Mayilerum on 6/21/12.

//
#import "CompetitiveInfoNewViewController.h"
#import "CompetitiveInfoDetailNewViewController.h"
#import "UIKitCategories.h"
@interface CompetitiveInfoNewViewController ()
@end

@implementation CompetitiveInfoNewViewController
@synthesize reqType;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)initalize
{
    frm = [[NSNumberFormatter alloc] init];
    [frm setNumberStyle:NSNumberFormatterCurrencyStyle];
    [frm setMaximumFractionDigits:0];
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [frm setLocale:usLocale];
    numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    [numberFormatter setLocale:usLocale];
    arrayOfCompetitiveInfo=[[NSMutableArray alloc]init];
    self.tableView.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initalize];
    if (loadingView == nil) {
        loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
	}
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
-(void) handleResponseForQuery:(NSMutableDictionary *)response
{
    reqType=0;
    arrayOfCompetitiveInfo = [[response objectForKey:@"response"] objectForKey:@"competitiveinfo"];
    if([arrayOfCompetitiveInfo count])
        [self.tableView reloadData];
    //Turn off loading view
	if (loadingView != nil) {
		[loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
		loadingView = nil;
	}
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [arrayOfCompetitiveInfo count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=nil;
    static NSString *CellIdentifier = @"Cell";
    cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    // Configure the cell...
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] ;
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        cell.textLabel.font = [UIFont systemFontOfSize:14];
    }
    id competitiveInfo=[ arrayOfCompetitiveInfo objectAtIndex:indexPath.row];
    cell.textLabel.text=[NSString stringWithFormat:@"%@ %@ %@ %@",[competitiveInfo objectForKey:@"year"],[competitiveInfo objectForKey:@"make"],[competitiveInfo objectForKey:@"model"],[competitiveInfo objectForKey:@"trim"]];
    cell.detailTextLabel.text=[NSString stringWithFormat:@"%@ | %@ mi",[frm stringFromNumber:[NSNumber numberWithInt:[[competitiveInfo objectForKey:@"price"] intValue]]],[numberFormatter stringFromNumber:[NSNumber numberWithInt:[[competitiveInfo objectForKey:@"mileage"] intValue]]]];
    return cell;
}
#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
     CompetitiveInfoDetailNewViewController *competitiveInfoDetailNewViewController = [[CompetitiveInfoDetailNewViewController alloc] initWithStyle:UITableViewStyleGrouped];
     // Pass the selected object to the new view controller.
    competitiveInfoDetailNewViewController.competitiveInfoDetail=[arrayOfCompetitiveInfo objectAtIndex:indexPath.row];
    competitiveInfoDetailNewViewController.title=@"Details";
     [self.navigationController pushViewController:competitiveInfoDetailNewViewController animated:YES];
}
-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60.0f;
}
- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:message
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}
#pragma mark alertview delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(reqType==9)
    {
        //Turn off loading view ...
        if (loadingView != nil) {
            [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
            loadingView = nil;
        }
        [[self navigationController] popViewControllerAnimated:YES];
    }
    else {
        //Turn off loading view ...
        if (loadingView != nil) {
            [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
            loadingView = nil;
        }
    }
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
@end
