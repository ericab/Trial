//
//  SearchResultsView.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 1/22/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "SearchResultsController.h"
#import "VehicleSearchObject.h"
#import "SearchResultsView.h"


@implementation SearchResultsView

@synthesize filterButton, activityLabel, activityIndicator, searchTable, mainView;

- (id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self != nil) {
		// Initialization code
		searchTable = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
		searchTable.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		searchTable.backgroundColor = [UIColor clearColor];
		[self addSubview:searchTable];
		
		//filterButton = [[UIButton buttonWithType:UIButtonTypeInfoDark] retain];
		//filterButton.frame = CGRectMake(frame.size.width - 50.0f, frame.size.height - 40.0f, 50.0f, 40.0f);
		//filterButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleTopMargin;
		//[self addSubview:filterButton];
		
		activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
		/*activityIndicator.frame = CGRectMake(frame.size.width / 2.0f - activityIndicator.frame.size.width / 2.0f, 
											 frame.size.height / 2.0f - activityIndicator.frame.size.height / 2.0f + 1.0f,
											 activityIndicator.frame.size.width, activityIndicator.frame.size.height);*/
        activityIndicator.frame = CGRectMake(30, 
											 85,
											 activityIndicator.frame.size.width, activityIndicator.frame.size.height);
		activityIndicator.autoresizingMask = UIViewAutoresizingFlexibleTopMargin  | UIViewAutoresizingFlexibleBottomMargin | 
			UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
		
		activityLabel = [[UILabel alloc] initWithFrame:CGRectMake(frame.size.width / 2.0f,
																  frame.size.height / 2.0f - 11.0f, self.frame.size.width, 20.0f)];
		activityLabel.shadowOffset = CGSizeMake(2.0f, 3.0f);
		activityLabel.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | 
			UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleWidth;
		activityLabel.textColor = [UIColor whiteColor];
		activityLabel.backgroundColor = [UIColor clearColor];
		activityLabel.textAlignment = UITextAlignmentCenter;

		[self addSubview:activityIndicator];
		[self addSubview:activityLabel];
    }
    return self;
}

- (void) setFrame:(CGRect)frame{
	[super setFrame:frame];
}



@end
