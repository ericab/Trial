//
//  HomeViewController.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 1/28/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"

@class VehicleSearchObject;

@interface HomeViewController : UIViewController<UITextFieldDelegate, UIAlertViewDelegate, AppRestore> {
	BOOL	checkboxSelected;
}

-(void) performSearch:(VehicleSearchObject*)vso;

@end
