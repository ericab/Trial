//
//  MarketControlAnalysisController.m
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//
#import "SearchResultsController.h"
#import "appDelegate.h"
#import <QuartzCore/CoreAnimation.h>
#import "MarketControlAnalysisController.h"
#import "MarketControlAnalysisView.h"

#define kAdvancedSearchSearcher @"searcher"

@implementation MarketControlAnalysisController

@synthesize marketPriceLabelArray,marketPriceTitleArray;
- (id) init
{
	self = [super init];
	if (self != nil) {
		self.title = @"Market Pricing";
		[appDelegate track:@"Market Pricing"];
	}
	return self;
}
- (id)initWithRestore:(NSDictionary*)data{
	self = [self init];
	if (self != nil)
	{
		searchObj = [data objectForKey:kAdvancedSearchSearcher];
		[self.view class];//Ensure that the view gets loaded
	}
	return self;
}
- (NSDictionary*)getRestoreData{
	NSMutableDictionary* dict = [NSMutableDictionary dictionaryWithCapacity:1];
	if(searchObj == nil)
	{
		//Attempt to get it
		searchObj = ((MarketControlAnalysisView*)self.view).searchObject;
	}
	if(searchObj != nil)
	{
		searchObj.firstListing = 1;
		[dict setValue:searchObj forKey:kAdvancedSearchSearcher];
	}
	return dict;
}
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    NSNumberFormatter *frm = [[NSNumberFormatter alloc] init];
    [frm setNumberStyle:NSNumberFormatterCurrencyStyle];
    [frm setMaximumFractionDigits:0];
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [frm setLocale:usLocale];
    
    UIView *view = [[UIView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    [view setAutoresizingMask:UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth];
    [view setBackgroundColor:[UIColor whiteColor]];
    UIImageView *backgroundImage=  [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];;
    [view addSubview:backgroundImage];
    [view sendSubviewToBack:backgroundImage];
    
    self.view = view;
    marketPriceTitleArray = [NSMutableArray arrayWithObjects:str_marketsize,str_marketaverageprice,str_marketaveragemileage,str_recommendedprice,str_pricerank,str_dayssupply,nil ];
    marketPriceLabelArray = [NSMutableArray arrayWithObjects:@"Market Size",@"Market Average Price",@"Market Average Mileage",@""@"Recommended Price",@"Price Rank",@"Days Supply",nil];
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    [numberFormatter setLocale:usLocale];
    
    UIView *viewTop = [[UIView alloc] initWithFrame:CGRectMake(10, 10, 300, 280)];
    [viewTop setAutoresizingMask:UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth];
    [viewTop setBackgroundColor:[UIColor colorWithRed:RedMake(kNavTintColor) green:GreenMake(kNavTintColor) blue:BlueMake(kNavTintColor) alpha:1.0]];
    viewTop.userInteractionEnabled=NO;
    [viewTop.layer setCornerRadius:8.0f];
    [viewTop.layer setMasksToBounds:YES];
    [view addSubview:viewTop];
    
    for(int i=0;i<6;i++)
    {
        UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(15,(i*30),170,30)];
        label.font=[UIFont boldSystemFontOfSize:14];
        label.backgroundColor=[UIColor clearColor];
        label.textAlignment=UITextAlignmentLeft;
        label.text=[NSString stringWithFormat:@"%@",[marketPriceLabelArray objectAtIndex:i]];
        label.textColor=[UIColor whiteColor];
        label.numberOfLines=0;
        [viewTop addSubview:label];
        
        UILabel *labelOne=[[UILabel alloc]initWithFrame:CGRectMake(185,(i*30),110,30)];
        labelOne.font=[UIFont boldSystemFontOfSize:12];
        labelOne.backgroundColor=[UIColor clearColor];
        labelOne.textAlignment=UITextAlignmentLeft;
        if(!(i==1) && !(i==2) && !(i==3))
            labelOne.text=[NSString stringWithFormat:@" :   %@",[marketPriceTitleArray objectAtIndex:i]];
        else 
        {
            if(i==1 || i==3)
                labelOne.text=[NSString stringWithFormat:@" :   %@",[frm stringFromNumber:[NSNumber numberWithInt:[[marketPriceTitleArray objectAtIndex:i] intValue]]]]; 
            if(i==2)
                labelOne.text=[NSString stringWithFormat:@" :   %@ mi",[numberFormatter stringFromNumber:[NSNumber numberWithInt:[[marketPriceTitleArray objectAtIndex:i] intValue]]]];
        }
        labelOne.textColor=[UIColor whiteColor];
        labelOne.numberOfLines=0;
        [viewTop addSubview:labelOne];
    }
}
- (void)advSearchError:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}
// To load the Scroll View
- (void)viewWillAppear:(BOOL)animated {
   	[super viewWillAppear:animated];
	[[NSNotificationCenter defaultCenter] addObserver: self 
											 selector: @selector(keyboardWasShown:)
												 name: UIKeyboardDidShowNotification 
											   object: nil];
    [[NSNotificationCenter defaultCenter] addObserver: self
											 selector: @selector(keyboardWasHidden:)
												 name: UIKeyboardDidHideNotification 
											   object: nil];
   	scrollView.frame = CGRectMake(0, 0, 320, 460);
	scrollView.contentSize = CGSizeMake(320, 500);
}
-(void) viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]
	 removeObserver:self];
}
-(void) keyboardWasShown: (NSNotification *)notif {
    return;
}

-(void) keyboardWasHidden: (NSNotification *)notif {
    return;
}
- (void)search:(id)sender{
	searchObj = ((MarketControlAnalysisView*)self.view).searchObject;
	if (searchObj.dealerLot == 0) {
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Invalid DealerLot"
															message:@"Please Pick a Dealer Lot."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}
	[[appDelegate currentInstance] saveSearch:searchObj];
	SearchResultsController *src = [SearchResultsController new];
	[self.navigationController pushViewController:src animated:YES];
	[src startSearch:searchObj];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
       [textField resignFirstResponder];
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
- (void)dealloc {
	searchObj = nil;
}
@end
