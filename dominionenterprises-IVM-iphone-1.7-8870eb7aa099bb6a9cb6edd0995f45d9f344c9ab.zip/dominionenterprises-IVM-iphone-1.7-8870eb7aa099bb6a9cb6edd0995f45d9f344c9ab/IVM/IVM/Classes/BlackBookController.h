//
//  BlackBookController.h
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//  Data Providers Detail Controller

#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"
#import "SearchResultsView.h"
#import "LoadingView.h"
#import "AppraisalDetailsController.h"
#import "ALPickerView.h"
@class VehicleSearchObject;

@interface BlackBookController : UIViewController<UITextFieldDelegate, UIPickerViewDelegate,UIPickerViewDataSource, ItemRestore,ALPickerViewDelegate,UITextViewDelegate> {
	VehicleSearchObject *searchObj;
    NSDictionary *dataProviderDetails;
    NSDictionary *dataProviderDetailsOptions;
    NSMutableArray *arrayOfdataProvidersDetails;
    NSMutableArray *arrayOfdataProvidersDetailsOptions;
    
    UIScrollView		*scrollView;
    
    UITextField			*txt_model;
	UITextField			*txt_trim;
	UITextField			*txt_Year;
	UITextField			*txt_make;
	UITextField			*txt_style;
    UITextField			*txt_blackbookoptions;
    UITextView			*txt_blackbookmoreoptions;
    UITextField			*txt_mileage;
    
    NSMutableArray *arrayOfdataProviderStyles;
    NSMutableArray *arrayOfdataProviderModels;
    NSMutableArray *arrayOfdataProviderTrims;
    
    NSMutableArray *arrayOfdataProviderYears;
    NSMutableArray *arrayOfdataProviderMakes;
    NSMutableArray *arrayOfdataProviderClean;
    NSMutableArray *arrayOfdataProviderExtra;
    NSMutableArray *arrayOfdataProviderCodes;
    NSString *providerCode;
    NSString *vehicleappraisalkey;
    UIPickerView		*pickerYear;
    UIToolbar *_pickerDone;
    UIToolbar			*_pickerYearDone;
    UIToolbar *conditionPicker;
    id latsetTextField;
    NSMutableArray		*oneDataSource;
    UIButton *doneButton;
    LoadingView	*loadingView;
    
    NSMutableArray *entries;
	NSMutableDictionary *selectionStates;
    ALPickerView *alpickerView;
    CGFloat				animatedDistance;
    int selectedRow;
    BOOL isRefreshBookValuesDataOnDetails;
    BOOL refreshDataOn;
    
}
@property(nonatomic,strong) NSString *providerType;
@property(nonatomic,assign) int reqType;
@property(nonatomic,assign) BOOL isMapped;
@property(nonatomic,strong) NSString *str_appraisalid;
@property(nonatomic,strong)  AppraisalDetailsController *appraisalDetailsController;
@property(nonatomic,assign) BOOL isAppraisal;
@property(nonatomic,strong)ALPickerView *alpickerView;
- (void)advSearchError:(id)sender;

@end
