/*
 *  RestoreProtocols.h
 *  GetAuto.com
 *
 *  Created by Joseph Humphrey on 2/13/09.
 *  Copyright 2009 GetAuto.com. All rights reserved.
 *
 */

//Designed for root view controllers
@protocol AppRestore<NSObject>

- (NSArray*)getRestoreData;
- (void)restore:(NSArray*)data;

@end

//Designed for child items
@protocol ItemRestore<NSObject>

- (id)initWithRestore:(NSDictionary*)data;
- (NSDictionary*)getRestoreData;

@end
