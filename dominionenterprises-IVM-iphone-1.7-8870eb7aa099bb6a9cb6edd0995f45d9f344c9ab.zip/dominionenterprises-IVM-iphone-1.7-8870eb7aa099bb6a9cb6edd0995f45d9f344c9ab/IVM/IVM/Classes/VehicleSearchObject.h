//
//  VehicleSearchObject.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/18/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VehicleSearchObject : NSObject<NSCoding> {
	int			pk;
	int			dealerLot;
//	float		latitude;
//	float		longitude;
//	NSString	*zip;
//	int			radius;
	int			firstListing;
	int			listingsPerPage;
	NSString	*make;
	NSString	*model;
	int			year;
	int			minPrice;
	int			maxPrice;
	int			minMileage;
	int			maxMileage;
	NSString	*sortBy;
}

@property(assign)	int			pk;
//@property(assign)	int			type;
//@property(assign)	float		latitude;
//@property(assign)	float		longitude;
//@property(copy)		NSString	*zip;
//@property(assign)	int			radius;
@property(assign)	int			dealerLot;
@property(assign)	int			firstListing;
@property(assign)	int			listingsPerPage;
@property(copy)		NSString	*make;
@property(copy)		NSString	*model;
@property(assign)	int			year;
@property(assign)	int			minPrice;
@property(assign)	int			maxPrice;
@property(assign)	int			minMileage;
@property(assign)	int			maxMileage;
@property(copy)		NSString	*sortBy;

@end
