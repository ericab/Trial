//
//  MakesAndModels.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 3/5/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MakesAndModels : NSObject<NSCoding> {
	NSDate	*time_created;
	NSArray	*makes;
	NSArray	*models;
}

@property(readonly, strong)		NSArray	*makes;
//Array of arrays of strings for the models
//Every model array should have All Models at index 0
@property(readonly, strong)		NSArray *models;
@property(readonly, strong)		NSDate	*time_created;

- (id) initWithMakes:(NSArray*)inMakes andModels:(NSArray*)inModels;
//Returns sorted array of makes starting with the fragment
- (NSArray*) makesStartingWith:(NSString*)fragment;
//Returns sorted array of models starting with the fragment
- (NSArray*) modelsAtIndex:(int)index StartingWith:(NSString*)fragment;
- (int) indexOfMake:(NSString*)make;
- (int) indexOfModel:(NSString*)model atIndex:(int)index;

@end
