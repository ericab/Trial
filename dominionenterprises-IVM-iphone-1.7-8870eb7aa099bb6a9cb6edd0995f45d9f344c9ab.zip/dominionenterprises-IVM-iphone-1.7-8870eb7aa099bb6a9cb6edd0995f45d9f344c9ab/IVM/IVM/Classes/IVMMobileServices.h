//
//  IVMMobileServices.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/18/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class VehicleSearchResults;
@class VehicleDetails;
@class VehicleSearchObject;
@class MakesAndModels;
@class SearchValuesResults;
@class DecodeData;
@class Photo;
@class DetailActions;
@class DealerVehicleHistory;
//Rest Services Begin
@protocol XMLResponseDelegate <NSObject>
@optional
-(void) handleResponseForQuery:(NSMutableDictionary *)response;
-(void) alertUser:(NSString*)message title:(NSString*)title;
@end

//Rest Services End
@protocol IVMMobileServicesDelegate<NSObject>
@optional
- (void) DealersComplete:(NSArray*)dealers;
- (void) VehicleSearchComplete:(VehicleSearchResults*)results withStatus:dResult;
- (void) VehicleDetailsComplete:(VehicleDetails*)vehicle withStatus:(NSString*)inResult;
- (void) MakesAndModelsComplete:(MakesAndModels*)makesModels;
- (void) GetDealersByTokenComplete:(NSMutableArray*)dealers dResult:(NSString*)dResult;
- (void) SearchValuesComplete:(SearchValuesResults*)svResults withStatus:dResult;
- (void) GetDecodeDataComplete:(DecodeData*)decodeData dResult:(NSString*)dResult;
- (void) GenerateTokenComplete:(NSString*)inToken andResult:(int)resultCode;
- (void) ValidateTokenComplete:(int)resultCode;
- (void) AddVehiclePhotoComplete:(Photo*)photoData inResult:(NSString*)inResult;
- (void) ActionWebServicesComplete:(NSString*)actResult;
-(void)GetDealersVehicleHistoryByTokenComplete:(DealerVehicleHistory *)dealerVehicleHistoryNew;

@end

@interface IVMMobileServices : NSObject <NSXMLParserDelegate, NSURLConnectionDelegate>{
	NSURLConnection						*conn;
	NSMutableData						*mData;
	VehicleSearchResults				*baseResults;
    //XMLResponseDelegate for Rest Services
	id<IVMMobileServicesDelegate,XMLResponseDelegate>		__unsafe_unretained delegate;
	SEL									complete;

	int									_actCode;
    
    /* Rest Services Begin*/
    BOOL shouldLog;
    NSMutableDictionary *requestRest;
    
    NSMutableData *receivedData;
    NSURLConnection *con;
    NSString *matchingElement;
    NSMutableString *soapResults; NSXMLParser *xmlParser;
    BOOL elementFound;
    int statusCode;
    NSString *responseString;
    NSMutableArray *dealerList;
    /*Rest Services End*/
    NSDate *lastVehicleMappedDate;
    NSDateFormatter *vehicleMappingformatter;
    DealerVehicleHistory *dealerVehicleHistoryNew;
}

@property(unsafe_unretained)	id<IVMMobileServicesDelegate>	delegate;
@property(strong)	VehicleSearchResults				*baseResults;

- (void) searchVehiclesByToken:(VehicleSearchObject*)search withToken:(NSString*)inToken;
- (void) getVehicleDetailsByToken:(int)key withToken:(NSString*)inToken;
- (void) requestDealerByLocation:(CLLocationCoordinate2D)LatLon radius:(double)radius andManufacturers:(NSString*)manufacturers andSort:(NSString*)sort;
- (void) requestDealerByZipCode:(NSString*)zipCode radius:(double)radius andManufacturers:(NSString*)manufacturers andSort:(NSString*)sort;
- (void) makesAndModels;
- (void) getDealersByToken:(NSString*)inToken;
- (void) getSearchValuesByToken:(int)dealerLotKey withToken:(NSString*)inToken;
- (void) validateToken:(NSString*)tokenString andCheck:(NSString*)checkString;
- (void) generateToken:(NSString*)userId withPwd:(NSString*)userPwd andCheck:(NSString*)checkString;
- (void) getDecodeDataByToken:(NSString*)vinCode withToken:(NSString*)inToken;
- (void) addVehicleByToken:(VehicleDetails*)vehicleData withToken:(NSString*)inToken;
- (void) addVehiclePhotoByToken:(int)vehicleKey withToken:(NSString*)inToken inImage:(NSString*)photoData;
- (void) actionWebServices:(DetailActions*)actionData;
- (void) updatePriceByToken:(int)vehicleKey withToken:(NSString*)inToken withValue:(int)priceValue;
- (void) updateStatusByToken:(int)vehicleKey withToken:(NSString*)inToken;

- (void) cancel;
//Rest Services
-(void) initialize:(NSMutableDictionary*)sent;
-(void) callWSWithQuery:(NSMutableDictionary *)req;
-(NSMutableDictionary *) parseRecievedData;
-(NSMutableDictionary *) parseRecievedJSONData;
//Rest Services

@end