//
//  AppraisalSearchResultsController.h
//
//  Created by Raja Sekhar Nerella on 3/20/12.
//

#import <UIKit/UIKit.h>
#import "LoadingView.h"
#import "IVM.h"
#import "RestoreProtocols.h"
#import "SearchResultsView.h"
#import "LoadingView.h"

@class MapViewController;
@class AdvancedSearchController;
@class AppraisalSearchResultsView;
@class SearchAppraisalsViewController;

@interface AppraisalSearchResultsController : UIViewController<UINavigationBarDelegate, UITableViewDelegate,
			UIAlertViewDelegate, UITableViewDataSource, UISearchBarDelegate, IVMMobileServicesDelegate, ItemRestore,XMLResponseDelegate> {
	AppraisalSearchResultsView			*searchView;
	IVMMobileServices					*mobileServices;
	VehicleSearchResults				*searchResults;
	VehicleSearchObject					*searcher;
                
	//Used to cache NetImageViews so they can complete the image download
	NSMutableDictionary					*netImageCache;
	UIBarButtonItem						*rightBarButton;
	BOOL								_viewLoaded;
	BOOL								_attemptedLoad;
	BOOL								_hasFiltered;
	BOOL								_viewAppeared;
	BOOL								_pushSingleListing;
                    
    LoadingView                         *loadingView;
    UIButton                            *loadMore;
	NSString                            *_userToken;
	UISegmentedControl                  *seg_sort;
    NSMutableArray                      *arrayAppraisals;            
    UISearchBar                         *mySearchBar;
    BOOL                                bSearchIsOn;
                
                UIActivityIndicatorView	*activityIndicator;
                UILabel					*activityLabel;
                UITableView				*appraisalsList;
                UIButton				*filterButton;
                UIView					*mainView;
                BOOL searching;
                BOOL letUserSelectRow;
                BOOL searchBarActive;
                NSMutableArray *listOfItems;
                NSMutableArray *copyListOfItems;
                SearchAppraisalsViewController *ovController;
                BOOL isAddAppraisal;
                NSCharacterSet      *nonCharacterSet;
                BOOL isDeleted;
}

@property (assign) BOOL loadingMore;
@property (assign) BOOL loadedAll;
@property (nonatomic, retain) UISearchBar *mySearchBar; 
@property (assign) BOOL bSearchIsOn;
@property (nonatomic,retain) UITableView  *appraisalsList;  
@property (nonatomic,retain) NSMutableArray   *arrayAppraisals; 
@property(nonatomic,assign) BOOL refreshDataOn;
@property(nonatomic,assign) int reqType; 
@property(nonatomic,assign) BOOL isAddAppraisal;

- (void)startSearch:(VehicleSearchObject*)search;
-(IBAction)mapClicked:(id)sender;
-(void) refreshData;
@end