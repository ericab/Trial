//
//  appDelegate.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/11/08.
//  Copyright GetAuto.com 2008. All rights reserved.
//
#import <UIKit/UIKit.h>
// This includes the header for the SQLite library.
#import <sqlite3.h>
#import "IVMMobileServices.h"
#import "LoginViewController.h"
#import "HomeViewController.h"

@class VehicleResult, VehicleSearchObject, Photo,DealerVehicleHistory;

@interface appDelegate : NSObject <UIApplicationDelegate, UITabBarControllerDelegate, IVMMobileServicesDelegate, UIAlertViewDelegate> {
    UIWindow					*window;
	UITabBarController			*tabController;
	sqlite3						*database;
	IVMMobileServices			*_service;
	id							target;
	SEL							sel_callback;
	LoginViewController			*loginViewController;
	BOOL						loginStatus;
	BOOL						authenticatingStatus;
    BOOL vehicleHistoryStatus;

	NSString					*_userId;
	NSString					*_userPwd;
	NSString					*_userToken;
	NSString					*_checkString;
	NSMutableArray				*dealerList;
	UIImageView                 *splashView;
	UIImage						*_viewBackground;
    HomeViewController* svc;
}

@property (nonatomic, strong) UIWindow				*window;
@property (nonatomic, strong) UITabBarController	*tabController;
@property (nonatomic, strong) LoginViewController	*loginViewController;
@property(copy)			NSString	*_userToken;
@property(copy)			NSString	*_checkString;
@property(nonatomic,strong) DealerVehicleHistory *dealerVehicleHistory;
@property(nonatomic,assign) BOOL vehicleHistoryStatus;;

- (UIImage*) viewBackground;
- (void) setLoginStatus:(BOOL)bStatus;
- (void) setUserIdPwd:(NSString*)userId andData:(NSString*)userPwd;
- (BOOL) hasBookmark:(int)vehicleKey;
- (void) saveBookmark:(VehicleResult*)listing;
- (void) updateBookmark:(Photo*)phData;
- (NSArray*) getBookmarks;
- (void) deleteBookmark:(int)vehicleKey;
- (void) clearBookmark;
- (void) saveSearch:(VehicleSearchObject*)search;
- (NSArray*) getSearches;
- (void) deleteSearch:(int)pkID;
- (void) clearRecent;
- (void) saveVehicleMapping:(NSMutableArray *)appraisals;
- (NSInteger) selectVehicleMapping:(NSInteger ) providerCode;
- (void) clearVehicleMapping;

- (void) alertNoNetwork;				//Pops up an alert window to check network connection and then goes to he home screen
- (void) ValidateTokenAndDealerLots;
- (void) DealerLots:(int*)status passToken:(NSString*)inToken;
- (void) GetDealersByTokenComplete:(NSMutableArray*)dealers dResult:(NSString*)dResult;
- (void) cancelDealerLots;
- (NSMutableArray*) getDealerList;
- (void)UserAuthentication:(int*)status;
- (void)LoginAuthentication:(int*)status;
+ (appDelegate*) currentInstance;
+ (void) track:(NSString*)pageName;
-(void) switchBackHome;
- (void)startupAnimationDone:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;
- (BOOL)checkNetworkConnection;
- (void) GetDealersVehicleHistoryByTokenComplete:(DealerVehicleHistory*)dealerVehicleHistoryNew;
@end
