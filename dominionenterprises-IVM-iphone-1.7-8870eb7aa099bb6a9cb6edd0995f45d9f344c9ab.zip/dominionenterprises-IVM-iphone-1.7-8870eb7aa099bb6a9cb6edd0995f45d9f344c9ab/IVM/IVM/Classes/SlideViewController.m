//
//  SlideViewController.m
//  Dealerships
//
//  Created by GetAuto on 9/23/11.

//

#import "SlideViewController.h"
#import "appDelegate.h"
#import "NetImageView.h"

@implementation SlideViewController

@synthesize photoScrollView;
@synthesize slidePageControl;
@synthesize pageControlIsChangingPage;
@synthesize listing;
@synthesize loadingView;
@synthesize orgFrame;
@synthesize orgPageFrame;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil data:(VehicleDetails *)vehicleDetails
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    
    //Omniture Track Call
    [appDelegate track:@"Slideshow"];
    
    self.listing = vehicleDetails;

    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Close" style:UIBarButtonItemStyleBordered target:self action:@selector(backToPreviousView:)];
    
    self.navigationItem.title = @"Photos";
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    if ([listing.regularPhotos count] > 0) {
        //Turn on loading view
        if (loadingView == nil) {
            loadingView = [LoadingView loadingViewInView:self.photoScrollView];
        }
    }

    self.orgFrame = self.photoScrollView.frame;
    self.orgPageFrame = self.slidePageControl.frame;
    
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didRotate:) name:UIDeviceOrientationDidChangeNotification object:nil];
    
}

-(void) viewWillDisappear:(BOOL)animated 
{
    [[UIDevice currentDevice] endGeneratingDeviceOrientationNotifications];
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if ([listing.regularPhotos count] > 0) {
        [self buildScrollImages];
        self.slidePageControl.numberOfPages = [listing.regularPhotos count];
        
    	//Turn off loading view
        if (loadingView != nil) {
            [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
            loadingView = nil;
        }
    } else {
        self.slidePageControl.numberOfPages = 0;
    }
}

- (void)viewDidUnload
{
    //Remove all subviews if there are
    for (UIView *view in [photoScrollView subviews]) {
        [view removeFromSuperview];
    }
    
    [self setPhotoScrollView:nil];
    [self setSlidePageControl:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
//    self.listing = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didRotate:(NSNotification *)notification {
    pageControlIsChangingPage = YES;
    
    if ([UIDevice currentDevice].orientation == UIDeviceOrientationLandscapeLeft) {
        photoScrollView.transform = CGAffineTransformMakeRotation(M_PI/2);
        CGRect frame = [photoScrollView frame];
        [photoScrollView setFrame:frame];
        
        photoScrollView.frame = CGRectMake(10.0, 50.0, 300.0, 400.0);
        
        [photoScrollView setContentSize:CGSizeMake(400.0 * [listing.regularPhotos count], 300.0)];
        
        CGFloat cx = 0;
        for (UIView *vImage in [photoScrollView subviews]) {
            if ([vImage isKindOfClass:[UIImageView class]]) {
                CGRect rect = vImage.frame;
                rect.size.height = 300.0;
                rect.size.width = 400.0;
                rect.origin.x = cx;
                rect.origin.y = 0.0;
                
                vImage.frame = rect;
                
                cx += rect.size.width;
            }        
        }

        [self.photoScrollView setContentOffset:CGPointMake(400.0 * self.slidePageControl.currentPage, 0) animated:YES];
        
        self.slidePageControl.transform = CGAffineTransformMakeRotation(M_PI/2);
        frame = [self.slidePageControl frame];
        float temp_f = frame.size.height;
        frame.size.height = frame.size.width;
        frame.size.width = temp_f;
        frame.origin.x = -130.0;
        [self.slidePageControl setFrame:frame];
    } else if ([UIDevice currentDevice].orientation == UIDeviceOrientationLandscapeRight) {
        photoScrollView.transform = CGAffineTransformMakeRotation(-M_PI/2);
        CGRect frame = [photoScrollView frame];
        [photoScrollView setFrame:frame];
        
        photoScrollView.frame = CGRectMake(10.0, 50.0, 300.0, 400.0);
        
        [photoScrollView setContentSize:CGSizeMake(400.0 * [listing.regularPhotos count], 300.0)];
        
        CGFloat cx = 0;
        for (UIView *vImage in [photoScrollView subviews]) {
            if ([vImage isKindOfClass:[UIImageView class]]) {
                CGRect rect = vImage.frame;
                rect.size.height = 300.0;
                rect.size.width = 400.0;
                rect.origin.x = cx;
                rect.origin.y = 0.0;
                
                vImage.frame = rect;
                
                cx += rect.size.width;
            }        
        }
        
        [self.photoScrollView setContentOffset:CGPointMake(400.0 * self.slidePageControl.currentPage, 0) animated:YES];
        
        self.slidePageControl.transform = CGAffineTransformMakeRotation(-M_PI/2);
        frame = [self.slidePageControl frame];
        float temp_f = frame.size.height;
        frame.size.height = frame.size.width;
        frame.size.width = temp_f;
        frame.origin.x = 130.0;
        [self.slidePageControl setFrame:frame];
    } else {
        slidePageControl.transform = CGAffineTransformMakeRotation(0);
        [slidePageControl setFrame:self.orgPageFrame];
        
        photoScrollView.transform = CGAffineTransformMakeRotation(0);
        [photoScrollView setFrame:self.orgFrame];
        [photoScrollView setContentSize:CGSizeMake(320.0 * [listing.regularPhotos count], 240.0)];
        
        CGFloat cx = 0;
        for (UIView *vImage in [photoScrollView subviews]) {
            if ([vImage isKindOfClass:[UIImageView class]]) {
                CGRect rect = vImage.frame;
                rect.size.height = 240.0;
                rect.size.width = 320.0;
                rect.origin.x = cx;
                rect.origin.y = 0.0;
                
                vImage.frame = rect;
                
                cx += rect.size.width;
            }        
        }
        
        [self.photoScrollView setContentOffset:CGPointMake(320.0 * self.slidePageControl.currentPage, 0) animated:YES];
    }
    
    pageControlIsChangingPage = NO;
}

- (void) buildScrollImages
{
    //Remove all subviews if there are
    for (UIView *view in [photoScrollView subviews]) {
        [view removeFromSuperview];
    }
    
	[photoScrollView setCanCancelContentTouches:NO];
    
	CGFloat cx = 0;
	for (NSUInteger nimages = 0; nimages < [listing.regularPhotos count]; nimages++) {
        if (nimages > 1) {
            NetImageView *imageView = [[NetImageView alloc] initWithFrame:CGRectMake(0, 0, 320.0, 240.0) andUrl:nil andCache:nil];
            
            imageView.opaque = YES;
            imageView.userInteractionEnabled = NO;
            imageView.backgroundColor = [UIColor blackColor];
            imageView.contentMode = UIViewContentModeScaleAspectFit;
            imageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
            
            imageView.cache = nil;
            [imageView setImageURL:[NSURL URLWithString:[listing.regularPhotos objectAtIndex:nimages]] cache:nil];

            CGRect rect = imageView.frame;
            rect.origin.x = ((photoScrollView.frame.size.width - imageView.frame.size.width) / 2) + cx;
            rect.origin.y = ((photoScrollView.frame.size.height - imageView.frame.size.height) / 2);
            
            imageView.frame = rect;
            
            [photoScrollView addSubview:imageView];
            imageView = nil;
        } else {
            UIImageView *imageView = [[UIImageView alloc] init];
            imageView.frame = CGRectMake(0, 0, 320.0, 240.0);
            
            NSData  *imgData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[listing.regularPhotos objectAtIndex:nimages]]];
            if (imgData != nil) {
                imageView.image = [UIImage imageWithData:imgData];
            } else {
                imageView.image = [UIImage imageNamed:@"hd_nophoto.png"];
            }
            
            CGRect rect = imageView.frame;
            rect.origin.x = ((photoScrollView.frame.size.width - imageView.frame.size.width) / 2) + cx;
            rect.origin.y = ((photoScrollView.frame.size.height - imageView.frame.size.height) / 2);
            
            imageView.frame = rect;
            
            [photoScrollView addSubview:imageView];
            imageView = nil;
        }
        
		cx += photoScrollView.frame.size.width;
	}
	
	[photoScrollView setContentSize:CGSizeMake(cx, [photoScrollView bounds].size.height)];
}


#pragma mark -
#pragma mark UIScrollViewDelegate stuff
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (pageControlIsChangingPage) {
        return;
    }
    
	/*
	 *	We switch page at 50% across
	 */
    CGFloat pageWidth = 0.0;
    if (UIDeviceOrientationIsLandscape([UIDevice currentDevice].orientation)) {
        pageWidth = scrollView.frame.size.height;
    } else {
        pageWidth = scrollView.frame.size.width;
    }
    
    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    self.slidePageControl.currentPage = page;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)_scrollView 
{
    pageControlIsChangingPage = NO;
}

#pragma mark -
#pragma mark PageControl stuff
- (IBAction)changePage:(id)sender 
{
	/*
	 *	Change the scroll view
	 */
    CGRect frame = photoScrollView.frame;
    frame.origin.x = frame.size.width * slidePageControl.currentPage;
    frame.origin.y = 0;
	
    [photoScrollView scrollRectToVisible:frame animated:YES];
    
	/*
	 *	When the animated scrolling finishings, scrollViewDidEndDecelerating will turn this off
	 */
    pageControlIsChangingPage = YES;
}

- (void)backToPreviousView:(id)sender
{
	[[self parentViewController] dismissModalViewControllerAnimated:YES];
}

@end
