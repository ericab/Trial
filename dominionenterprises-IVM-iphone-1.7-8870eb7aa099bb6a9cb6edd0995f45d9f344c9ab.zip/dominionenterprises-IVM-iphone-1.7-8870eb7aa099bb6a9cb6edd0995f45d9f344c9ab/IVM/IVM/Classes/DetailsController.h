//
//  DetailsController.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 12/1/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"
#import "IVMMobileServices.h"
#import "ModifyViewController.h"

@class VehicleDetails;
@class VehicleResult;
@class DetailsCell;
//@class SlideShowViewController;

@interface DetailsController : UIViewController <UITableViewDelegate, UITableViewDataSource, UIActionSheetDelegate, 
												UIAlertViewDelegate, IVMMobileServicesDelegate, ModifyViewControllerDelegate, ItemRestore>
{
@private
	UITableView					*tableView;
	DetailsCell					*_detailsCell;
	UITableViewCell				*_vOptionsCell;
	NSMutableArray				*_slideImages;
	NSMutableArray				*_options;
	VehicleDetails				*_listing;
	VehicleResult				*_preListing;
	UIImage						*_preImage;
	IVMMobileServices			*_mobileServices;
	float						_vOptionsHeight;
	BOOL						viewLoaded;
	BOOL						attemptedLoad;
	BOOL						hasData;
	BOOL						hasPhotos;
	UIActivityIndicatorView		*activity;
	NSString					*_userToken;

	BOOL						refreshView;

	UIActionSheet				*actionSheet;
	ModifyViewController		*modController;
}

@property(nonatomic, strong)	UIActionSheet		*actionSheet;
@property (strong, nonatomic) UIViewController      *zoominoutModalViewController;
@property (assign) CGRect   imageFrame;

- (id)initWithListing:(VehicleResult*)listing andImage:(UIImage*)image andPhotos:(bool)hasPhoto;
- (id)initWithDetailsListing:(VehicleDetails*)listing andImage:(UIImage*)image andPhotos:(bool)hasPhoto;
- (void)styleAction:(id)sender;
- (void)startSlideShow:(id)sender;
//- (void)showDirections:(id)sender;
- (void)saveBookmark:(id)sender;

- (void)showModal:(UIView*) modalView;

- (void) presentZoomInOutModalViewController:(UIViewController *)aViewController frame:(CGRect)newRect animated:(BOOL)isAnimated withAlpha:(CGFloat)anAlpha;
- (void) dismissZoomInOutModalViewController:(CGRect)newRect animated:(BOOL)animated;

@end
