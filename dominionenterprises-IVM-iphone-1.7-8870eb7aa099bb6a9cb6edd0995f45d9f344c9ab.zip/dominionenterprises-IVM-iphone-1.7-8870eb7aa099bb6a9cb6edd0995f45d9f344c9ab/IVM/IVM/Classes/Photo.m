//
//  Photo.m
//  GetAuto.com
//
//  Created by Shaofeng Tu on 7/16/09.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import "Photo.h"


@implementation Photo

@synthesize		lotKey;
@synthesize		vehicleKey;
@synthesize		c640Image;
@synthesize		m200Image;
@synthesize		s1024Image;
@synthesize		t100Image;


@end
