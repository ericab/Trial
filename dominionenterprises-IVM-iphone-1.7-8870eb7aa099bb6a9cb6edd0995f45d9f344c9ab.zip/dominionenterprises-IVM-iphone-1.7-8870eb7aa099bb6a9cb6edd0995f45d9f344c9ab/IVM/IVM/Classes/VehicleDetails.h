//
//  VehicleDetails.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/18/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <Foundation/Foundation.h>

/*
<DealerName>Priority Toyota</DealerName>
<DealerLotKey>2916</DealerLotKey>
<Address>1800 Greenbrier Parkway</Address>
<Address2 />
<City>Chesapeake</City>
<State>VA</State>
<Postal_Code>23320</Postal_Code>
<VIN>1HGCM66457A092985</VIN>
<Vehicle_Key>15360968</Vehicle_Key>
<StockNumber>986129</StockNumber>
<Year>2007</Year>
<Mileage>33245</Mileage>
<Price>18988</Price>
<Make>Honda</Make>
<Model>Accord SE</Model>
<Body>4 Dr Sedan</Body>
<Transmission>Automatic</Transmission>
<Engine>6 Cyl.</Engine>
<Options>
<Option>Power Steering</Option>
<Option>Power Brakes</Option>
</Options>
<TrimLevel>SE</TrimLevel>*/
@interface VehicleDetails : NSObject {
	NSString	*dealerName;
	int			dealerLotKey;
	NSString	*address;
	NSString	*address2;
	NSString	*city;
	NSString	*state;
	NSString	*postal_code;
	NSString	*vin;
	int			vehicle_key;
	NSString	*stockNumber;
	NSString	*titaniumID;
	int			year;
	int			mileage;
	int			price;
	NSString	*make;
	NSString	*model;
	NSString	*body;
	NSString	*transmission;
	NSString	*engine;
	NSArray		*options;
	NSString	*trimLevel;
	NSString	*externalColor;
	NSString	*internalColor;
	NSArray		*regularPhotos;
	NSArray		*thumbPhotos;
	NSString	*dealerEmail;
	NSString	*dealerPhone;
	NSString	*dealerWebUrl;
	NSString	*certifiedLogoUrl;
	NSString	*autoVinUrl;
	NSDate		*time_created;
	NSString	*type;
	NSString	*status;
	NSDate		*time_updated;
	bool		isNew;
}

@property(copy)		NSString	*dealerName;
@property(assign)	int			dealerLotKey;
@property(copy)		NSString	*address;
@property(copy)		NSString	*address2;
@property(copy)		NSString	*city;
@property(copy)		NSString	*state;
@property(copy)		NSString	*postal_code;
@property(copy)		NSString	*vin;
@property(assign)	int			vehicle_key;
@property(copy)		NSString	*stockNumber;
@property(copy)		NSString	*titaniumID;
@property(assign)	int			year;
@property(assign)	int			mileage;
@property(assign)	int			price;
@property(copy)		NSString	*make;
@property(copy)		NSString	*model;
@property(copy)		NSString	*body;
@property(copy)		NSString	*transmission;
@property(copy)		NSString	*engine;
@property(strong)	NSArray		*options;
@property(copy)		NSString	*trimLevel;
@property(copy)		NSString	*externalColor;
@property(copy)		NSString	*internalColor;
@property(strong)	NSArray		*regularPhotos;
@property(strong)	NSArray		*thumbPhotos;
@property(copy)		NSString	*dealerEmail;
@property(copy)		NSString	*dealerPhone;
@property(copy)		NSString	*dealerWebUrl;
@property(copy)		NSString	*certifiedLogoUrl;
@property(copy)		NSString	*autoVinUrl;
@property(strong)		NSDate	*time_created;
@property(copy)		NSString	*type;
@property(copy)		NSString	*status;
@property(strong)		NSDate	*time_updated;
@property(assign)	bool		isNew;

@end
