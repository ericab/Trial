//
//  SavedListingsController.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 1/23/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "SavedListingsController.h"
#import "IVM.h"
#import "SearchResultCell.h"
#import "NetImageView.h"
#import "DetailsController.h"
#import "SearchResultCell.h"
#import "appDelegate.h"
#import <QuartzCore/CoreAnimation.h>
#import <objc/runtime.h>


@implementation SavedListingsController

@synthesize listingTable;

- (id) init
{
	self = [super init];
	if (self != nil) {
		self.title = @"Last Added";
		imgCache = [NSMutableDictionary dictionary];
		self.navigationItem.leftBarButtonItem = [self editButtonItem];
		[appDelegate track:@"Last Added"];
	}
	return self;
}

// Invoked when the user touches Edit.
- (void)setEditing:(BOOL)editing animated:(BOOL)animated {
	// Updates the appearance of the Edit|Done button as necessary.
	[super setEditing:editing animated:animated];
	[listingTable setEditing:editing animated:YES];
	// Disable the add button while editing.
	if (editing) {
		self.navigationItem.rightBarButtonItem.enabled = NO;
	} else {
		self.navigationItem.rightBarButtonItem.enabled = YES;
	}
}

- (void)tableView:(UITableView *)tv commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    // If row is deleted, remove it from the list.
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [[appDelegate currentInstance] deleteBookmark:((VehicleResult*)[listings objectAtIndex:indexPath.row]).vehicle_key];
		[(NSMutableArray*)listings removeObjectAtIndex:indexPath.row];
        // Animate the deletion from the table.
        [listingTable deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] 
		 withRowAnimation:UITableViewRowAnimationFade];
    }
}

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	UIView *vw = [[UIView alloc] initWithFrame:CGRectZero];
	vw.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
//	vw.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
	self.view = vw;
	
	listingTable = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
	listingTable.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	listingTable.backgroundColor = [UIColor clearColor];
//	listingTable.layer.contents = (id)[appDelegate viewBackground].CGImage;
//	listingTable.backgroundColor = [UIColor colorWithPatternImage:[appDelegate viewBackground]];
//	self.view = listingTable;
	
	listingTable.dataSource = self;
	listingTable.delegate = self;

	[self.view addSubview:listingTable];
}


/*/ Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

- (void)load{
	[self setEditing:NO];
	listings = [[appDelegate currentInstance] getBookmarks];
	[listingTable reloadData];
}

- (void)clear{
	listings = nil;
	[listingTable reloadData];
	[imgCache removeAllObjects];
}

- (void)setView:(UIView*)view{
	if(!view)
	{
		listingTable = nil;
	}
	[super setView:view];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [listings count];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	VehicleResult *selected = (VehicleResult*)[listings objectAtIndex:indexPath.row];
//	selected.distance = -1.0;	//Supresses distance label
	//UIImage *tmp = selected.photo != nil ? [NetImageView imageForURL:[NSURL URLWithString:selected.photo] withSize:CGSizeMake(100.0f, 75.0f) inCache:imgCache] : nil;
	DetailsController *detailsController = [[DetailsController alloc] initWithListing:selected andImage:nil andPhotos:YES];
	[[self navigationController] pushViewController:detailsController animated:YES];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	VehicleResult *listing = [listings objectAtIndex:indexPath.row];
	SearchResultCell *cell = (SearchResultCell *)[tableView dequeueReusableCellWithIdentifier:@"cell"];
	if(cell == nil)
		cell = [[SearchResultCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
	
	cell.netImage.cache = imgCache;
	[cell.netImage setImageURL:listing.image == nil ? nil : [NSURL URLWithString:listing.image]];
	
//	cell.bodytype.text = listing.bodyType;
	cell.bodytype.text = [NSString stringWithFormat:@"%@", listing.vin];
	
//	cell.distance.hidden = listing.distance < 0;
//	cell.distance.text = [NSString stringWithFormat:@"%2.2f mi", listing.distance];
//	if(listing.certifiedLogoUrl)
//		[cell.certifiedLogo setImageURL:[NSURL URLWithString:listing.certifiedLogoUrl]];
//	else
//		cell.certifiedLogo.image = nil;
	
	cell.vehicle.text = [NSString stringWithFormat:@"%d %@ %@", listing.year, listing.make, listing.model];
	
	{
		NSNumberFormatter *frm = [[NSNumberFormatter alloc] init];
		[frm setNumberStyle:NSNumberFormatterCurrencyStyle];
		[frm setCurrencySymbol:@""];
		[frm setMaximumFractionDigits:0];
        
        NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
        [frm setLocale:usLocale];
        
     
        
		cell.mileage.text = [NSString stringWithFormat:@"%@ mi", [frm stringFromNumber:[NSNumber numberWithInt:listing.mileage]]];
	}
	
	if (listing.externalColor != nil || listing.internalColor != nil) {
		cell.colors.text = [NSString stringWithFormat:@"%@, %@",  listing.externalColor, listing.internalColor];
	} else {
		cell.colors.text = [NSString stringWithFormat:@"%@",  @"Colors: N/A"];
	}

//	cell.colors.text = [NSString stringWithFormat:@"%@, %@",  listing.externalColor, listing.internalColor];
	
	//cell.mlsNumber.hidden = listing.trimLevel == nil;
//	cell.mlsNumber.text = listing.transmission;
	cell.mlsNumber.text = [NSString stringWithFormat:@"Vehicle Key: %d", listing.vehicle_key];
	
	if(listing.price > 0)
	{
		NSNumberFormatter *frm = [[NSNumberFormatter alloc] init];
		[frm setNumberStyle:NSNumberFormatterCurrencyStyle];
		[frm setMaximumFractionDigits:0];
        NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
        [frm setLocale:usLocale];
		cell.price.text = [frm stringFromNumber:[NSNumber numberWithInt:listing.price]];
	}
	else
		cell.price.text = @"Call For Price";
	
	return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 100.0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data

	if (imgCache.count != 0) {
		[imgCache removeAllObjects];
	}
}

- (NSArray*)getRestoreData{
	NSMutableArray *children = [NSMutableArray array];
	for(int i = [self.navigationController.viewControllers indexOfObject:self] + 1; i < [self.navigationController.viewControllers count]; i++)
	{
		UIViewController *vc = [self.navigationController.viewControllers objectAtIndex:i];
		if([vc conformsToProtocol:@protocol(ItemRestore)])
			[children addObject:[NSDictionary dictionaryWithObject:[vc performSelector:@selector(getRestoreData)] forKey:NSStringFromClass([vc class])]];
	}

	return children;
}

- (void)restore:(NSArray*)data{
	for(NSDictionary* child_data in data)
	{
		if([[child_data allKeys] count] < 1) continue;
		NSString *clss = [[child_data allKeys] objectAtIndex:0];
		Class controller = [[NSBundle mainBundle] classNamed:clss];
		if(class_conformsToProtocol(controller, @protocol(ItemRestore)))
		{
			id<ItemRestore> tmp = [[controller alloc] initWithRestore:[child_data objectForKey:clss]];
			if([tmp isKindOfClass:[UIViewController class]])
				[self.navigationController pushViewController:(UIViewController*)tmp animated:NO];
		}		
	}

	//Reload the Bookmarks data
	[self load];
}

- (void)dealloc {
	NSLog(@"Debug in dealloc ... 000");
	
	listings = nil;
	imgCache = nil;

}

@end
