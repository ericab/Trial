//
//  AppraisalDetailsView.m
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//
#import "IVM.h"
#import "appDelegate.h"
#import "SearchResultsController.h"
#import "IVMMobileServices.h"
#import "SearchValues.h"
#import "SearchValuesResults.h"
#import "SearchResultsView.h"
#import "AppraisalDetailsView.h"
#import "MarketControlAnalysisController.h"
#import "UIKitCategories.h"
#import "BlackBookController.h"
#import "AppraisalCustomerDetailsController.h"
#import "AppraisalVehicleDetailsController.h"
#import "AppraisalAppraisalDetailsController.h"
#import "AppraisalDataProvidersDetailsController.h"
#import "CompetitiveInfoNewViewController.h"
#import "CarfaxReportController.h"
#import "AppraisalDetailsController.h"
@interface AppraisalDetailsView()

- (void)registerForKeyboardNotifications;
- (void)unregisterForKeyboardNotifications;
@end

enum{
	MODE_MAKEMODEL = 1,
	MODE_PRICE = 2,
	MODE_YEAR = 3,
	MODE_MILES = 4,
	MODE_DEALERLOT = 5
};
enum{
    VEHICLE_HISTORY,
	APPRAISAL_CUSTOMER ,
	APPRAISAL_VEHICLE,
	APPRAISAL_APRAISAL,
    APPRAISAL_MARKET_CONTROL_ANALYTICS,
	APPRAISAL_DATAPROVIDER,
    APPRAISAL_COMPETITIVEINFO,
    ADD_TO_INVENTORY
};


@implementation AppraisalDetailsView

@synthesize searchObject, target;
@synthesize dealerList,vechicleTitleArray,vechicleLabelArray;
@synthesize dataProviderLabelArray,dataProviderTitleArray;
@synthesize dataProviderValueArray;
@synthesize appraisalDetailsController;
@synthesize dataProviderConditionArray;

-(id) init
{
    self=[super init];
    str_customer = @"n/a";    
    str_customerAddress = @"n/a";
    str_city = @"n/a";
    str_state = @"n/a";
    str_zip = @"n/a";
    str_phone = @"n/a";
    str_mobile = @"n/a";
    str_email = @"n/a";
    str_trim = @"n/a";
    str_vin = @"n/a";
    str_year = @"n/a";
    str_make = @"n/a";
    str_model = @"n/a";
    str_style = @"n/a";
    str_mileage = @"n/a";
    str_exteriorcolor = @"n/a";
    str_interiorcolor = @"n/a";
    str_expectedsaleprice = @"n/a";
    str_profitobective = @"n/a";
    str_recondtioning = @"n/a";
    str_appraisedvalue = @"n/a";
    str_profitobective = @"n/a";
    str_notes = @"n/a";
    str_datasalesperson = @"n/a";
    str_marketsize = @"n/a";
    str_marketaverageprice = @"n/a";
    str_marketaveragemileage = @"n/a";
    str_recommendedprice = @"n/a";
   str_daysupply = @"n/a";
    str_pricerank = @"n/a";
    str_appraisalid = @"n/a";
    str_vehicle_key=@"n/a";
    return self;
}
- (id)initWithFrame:(CGRect)frame {
    return [self initWithFrame:frame searchObject:nil filterMode:NO];
}
- (id)initWithFrame:(CGRect)frame searchObject:(VehicleSearchObject*)searchObj filterMode:(BOOL)filter {
	self = [super initWithFrame:frame];
	if(self != nil)
	{
    }
	return self;
}
- (void)alertView:(UIAlertView *)inAlertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [target advSearchError:nil];
}
#pragma mark UITextField delegate methods
- (BOOL)textFieldShouldClear:(UITextField *)textField {
	return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    if (textField == txt_dataproviders) {
        [txt_dataproviders resignFirstResponder];
        [self showPicker:textField];
        txt_dataproviders.text = [oneDataSource objectAtIndex:0];
        return NO;
    }
		return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    latsetTextField = textField;
}
- (void)showPicker:(id)sender{
	if(sender == txt_dataproviders)
	{
		[pickerOne reloadComponent:0];
		int row1 = 0;
		[pickerOne selectRow:row1 inComponent:0 animated:NO];
		_pickerDone.hidden = NO;
		pickerOne.hidden = NO;
		[self bringSubviewToFront:pickerOne];
		[self bringSubviewToFront:_pickerDone];
		
		[UIView beginAnimations:@"FadeIn" context:nil];
		[UIView setAnimationDuration:0.7];
		_pickerDone.alpha = 1.0;
		pickerOne.alpha = 1.0;
		[UIView commitAnimations];
	}
}
- (void)pickerCancel:(id)sender{
	[UIView beginAnimations:@"FadeOut" context:nil];
	[UIView setAnimationDuration:0.7];
	_pickerDone.alpha = 0.0;
	pickerOne.alpha = 0.0;
	[UIView commitAnimations];
}
- (void)pickerDone:(id)sender{
	[UIView beginAnimations:@"FadeOut" context:nil];
	[UIView setAnimationDuration:0.7];
	_pickerDone.alpha = 0.0;
	pickerOne.alpha = 0.0;
	[UIView commitAnimations];
    if ([txt_dataproviders.text isEqualToString:@"BlackBook"]) {
        BlackBookController *blackBookController = [[BlackBookController alloc]init];
        UIViewController *myController = [self firstAvailableUIViewController];
        [myController.navigationController pushViewController:blackBookController animated:YES];
    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (void)unregisterForKeyboardNotifications
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}
#pragma mark UIPickerView delegate methods
// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
	if([pickerView isEqual: pickerOne]) {
		return 1;
	} else if([pickerView isEqual: pickerTwo]) {
		return 2;
	}
	return 0;
}
// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
	if([pickerView isEqual: pickerOne]) {
        return [oneDataSource count];
	} else if([pickerView isEqual: pickerTwo]) {
		return [(NSArray*)[twoDataSource objectAtIndex:component] count];
	}
	return 0;
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
	if([pickerView isEqual: pickerOne]) {
		return [oneDataSource objectAtIndex:row];
	} else if([pickerView isEqual: pickerTwo]) {
		return [(NSArray*)[twoDataSource objectAtIndex:component] objectAtIndex:row];
	}
	return 0;
}
- (void)pickerView:(UIPickerView *)thePickerView 
      didSelectRow:(NSInteger)row 
       inComponent:(NSInteger)component {
    txt_dataproviders.text = [oneDataSource objectAtIndex:row];
}
- (void) MakesAndModelsComplete:(MakesAndModels*)makesModels{
	if(makesModels == nil)
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Unable to update Makes"
															message:@"Please ensure you have a network connection and try again."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}
	mAndm = makesModels;
}
- (void) SearchValuesComplete:(SearchValuesResults*)svResults withStatus:dResult{
	if(![dResult isEqualToString:@"Success"])
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"The Web Services Failed"
															message:dResult 
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}
	if(svResults == nil)
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Unable to get Makes/Models"
															message:@"Please ensure you have a network connection and try again."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}
	searchValuesResults = svResults;
	[searchView.activityIndicator stopAnimating];
	searchView.activityLabel.hidden = YES;
	[searchView removeFromSuperview];
}
- (void)dealloc {
	[self unregisterForKeyboardNotifications];
}
#pragma mark tableview Datasource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(dataProviderLabelArray.count)
        return 3;
	return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section==1 && dataProviderLabelArray.count)
        return dataProviderLabelArray.count+1;
    if(section==0)
        return dataProviderTitleArray.count ? vechicleLabelArray.count : vechicleLabelArray.count+1;
    return appraisalMenu.count;//[ arrayAppraisals count];
}
-(void)createCellUI{
    [self initalize];
    appraisalTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 372) style:UITableViewStyleGrouped];
    appraisalTableView.dataSource = self;
    appraisalTableView.delegate   = self;
    appraisalTableView.backgroundColor = [UIColor clearColor];
         [self  addSubview:appraisalTableView];
}
-(void)initalize
{
   frm = [[NSNumberFormatter alloc] init];
    [frm setNumberStyle:NSNumberFormatterCurrencyStyle];
    [frm setMaximumFractionDigits:0];
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [frm setLocale:usLocale];
    numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    [numberFormatter setLocale:usLocale];
    
    if ([dataProviderTitleArray count]>0) {
        dataProviderLabelArray=[[NSMutableArray alloc]init];
        dataProviderValueArray=[[NSMutableArray alloc]init];
        for(int i=0;i<[dataProviderTitleArray count];i++)
        {
            NSDictionary *appraisalDetail = [dataProviderTitleArray objectAtIndex:i];
            [dataProviderValueArray addObject:[appraisalDetail objectForKey:@"basePrice"]];
            NSString *providerType=[appraisalDetail objectForKey:@"providerType"];
            if([providerType isEqualToString:@"BlackBook"])
                providerType=@"Black Book";
            else  if([providerType isEqualToString:@"KelleyBlueBook"])
                providerType=@"KBB";
            else  if([providerType isEqualToString:@"Nada"])
                providerType=@"NADA";
            [dataProviderLabelArray addObject:providerType ];
        }
    }
    if([appDelegate currentInstance].dealerVehicleHistory.hasCarfax)
        appraisalMenu = [NSMutableArray arrayWithObjects:@"Carfax",@"Customer",@"Vehicle",@"Appraisal",@"Market Pricing",@"Data Providers",@"Competitive Information",@"Add to Inventory",nil];
    else
    appraisalMenu = [NSMutableArray arrayWithObjects:@"Vehicle History",@"Customer",@"Vehicle",@"Appraisal",@"Market Pricing",@"Data Providers",@"Competitive Information",@"Add to Inventory",nil];
    vechicleTitleArray = [NSMutableArray arrayWithObjects:str_recommendedprice,[NSString stringWithFormat:@"%@ %@ %@ %@",str_year,str_make,str_model,str_style],str_mileage,str_exteriorcolor,str_interiorcolor,str_customer, nil];
    vechicleLabelArray = [NSMutableArray arrayWithObjects:@"Recommended Price",@"Vehicle",@""@"Mileage",@"Exterior Color",@"Interior Color", @"Name",nil];
}
-(void)createCustomCellUI:(UITableViewCell*)cell indexpath:(NSIndexPath*)indexPath{
   if(indexPath.section==0){    
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(15,5,130,20)];
    label.font=[UIFont boldSystemFontOfSize:12];
    label.backgroundColor=[UIColor clearColor];
    label.textAlignment=UITextAlignmentLeft;
    label.tag=1;
    label.textColor=[UIColor whiteColor];
    label.numberOfLines=0;
     [cell.contentView addSubview:label];
    UILabel *labelOne=[UILabel alloc];
        labelOne=[labelOne initWithFrame:CGRectMake(145,5,150,20)];
        labelOne.font=[UIFont boldSystemFontOfSize:12];
        labelOne.textAlignment=UITextAlignmentLeft;
        labelOne.textColor=[UIColor whiteColor];
    labelOne.backgroundColor=[UIColor clearColor];
    labelOne.numberOfLines=0;
    labelOne.tag=2;
    [cell.contentView addSubview:labelOne];
       if(indexPath.row==1)
       {
           UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300,1)];
           [lineView setBackgroundColor:[UIColor redColor]]; //Change as per your req.
           lineView.userInteractionEnabled = NO;
           [cell.contentView addSubview:lineView];
       }
   }
   else  {
       //UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(50,5,95,20)];
       UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(15,5,130,20)];
       label.font=[UIFont boldSystemFontOfSize:12];
       label.backgroundColor=[UIColor clearColor];
       label.textAlignment=UITextAlignmentLeft;
       label.tag=1;
       label.textColor=[UIColor whiteColor];
       label.numberOfLines=0;
       UILabel *labelOne=[UILabel alloc];
         if(indexPath.row==0)
        {
            [cell.contentView addSubview:label];
        labelOne=[labelOne initWithFrame:CGRectMake(0,5,300,20)];
        labelOne.font=[UIFont boldSystemFontOfSize:14];
        labelOne.textAlignment=UITextAlignmentCenter;
            labelOne.text=@"Book Values";
        labelOne.textColor=[UIColor lightGrayColor];
        }
        else    
        {
        /*UIImageView *imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake(15,5,25,20);
        imageView.tag=4;
        [cell.contentView addSubview:imageView];*/
        [cell.contentView addSubview:label];
        labelOne=[labelOne initWithFrame:CGRectMake(145,5,150,20)];
        labelOne.font=[UIFont boldSystemFontOfSize:12];
        labelOne.textAlignment=UITextAlignmentLeft;
        labelOne.textColor=[UIColor whiteColor];
        }
       labelOne.backgroundColor=[UIColor clearColor];
       labelOne.tag=2;
       labelOne.numberOfLines=0;
       [cell.contentView addSubview:labelOne];
       if(indexPath.row==1)
       {
           UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300,1)];
           [lineView setBackgroundColor:[UIColor redColor]]; //Change as per your req.
           lineView.userInteractionEnabled = NO;
           [cell.contentView addSubview:lineView];
       }
     }
    cell.textLabel.backgroundColor=[UIColor clearColor];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;   
}
-(void)updateDataCustomCellUI:(UITableViewCell*)cell indexpath:(NSIndexPath*)indexPath{
   /* if(indexPath.section == 1)
    {
         UIImageView *imageView=(UIImageView*)[cell.contentView viewWithTag:4];
        NSString *dataProvider = [dataProviderLabelArray objectAtIndex:indexPath.row-1];
        if([dataProvider isEqualToString:@"Black Book"])
        {
           imageView.image=[UIImage imageNamed:@"blackbook.jpg"];
        }
        else if([dataProvider isEqualToString:@"KBB"])
        {
           imageView.image=[UIImage imageNamed:@"KBBLogo.jpg"];                                        
                                                   
        }
        else if([dataProvider isEqualToString:@"Galves"])
        {
           imageView.image=[UIImage imageNamed:@"GalvesLogo.jpg"];                                        
                                                   
        }
        else if([dataProvider isEqualToString:@"Edmunds"])
        {
           imageView.image=[UIImage imageNamed:@"edmunds.jpg"];                                     
        }
        else
        {
            imageView.image=[UIImage imageNamed:@"nada.jpg"];                                       
        }
    }*/
    UILabel *label=(UILabel*)[cell.contentView viewWithTag:1];
   if(indexPath.section==0)
   {
        label.text=[NSString stringWithFormat:@"%@",[vechicleLabelArray objectAtIndex:indexPath.row]];
   }
    if(indexPath.section == 1)
    {
        label.text=[NSString stringWithFormat:@"%@",[dataProviderLabelArray objectAtIndex:indexPath.row-1]];
    }
    UILabel *labelOne=(UILabel*)[cell.contentView viewWithTag:2];
    if(indexPath.section == 1)
    {
        if([[dataProviderLabelArray objectAtIndex:indexPath.row-1] isEqualToString:@"Galves"])
            labelOne.text=[NSString stringWithFormat:@": %@",[frm stringFromNumber:[NSNumber numberWithInt:[[dataProviderValueArray objectAtIndex:indexPath.row-1] intValue]]]];
        else
        labelOne.text=[NSString stringWithFormat:@": %@  (%@)",[frm stringFromNumber:[NSNumber numberWithInt:[[dataProviderValueArray objectAtIndex:indexPath.row-1] intValue]]],[dataProviderConditionArray objectAtIndex:indexPath.row-1]];
    }
    else if((indexPath.row!=2) && (indexPath.row!=0))
    {
        labelOne.text=[NSString stringWithFormat:@": %@",[vechicleTitleArray objectAtIndex:indexPath.row]];
        [labelOne sizeToFit];
    }
    else 
    {
        if(indexPath.row==0)
            labelOne.text=[NSString stringWithFormat:@": %@",[frm stringFromNumber:[NSNumber numberWithInt:[[vechicleTitleArray objectAtIndex:indexPath.row] intValue]]]]; 
        if(indexPath.row==2)
            labelOne.text=[NSString stringWithFormat:@": %@ mi",[numberFormatter stringFromNumber:[NSNumber numberWithInt:[[vechicleTitleArray objectAtIndex:indexPath.row] intValue]]]];
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=nil;
    if(indexPath.section== 1 && dataProviderTitleArray.count)
    {
        static NSString *CellIdentifier0 = @"CellIndentifier0";
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier0];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier0] ;
            [cell setBackgroundColor:[UIColor colorWithRed:RedMake(kNavTintColor) green:GreenMake(kNavTintColor) blue:BlueMake(kNavTintColor) alpha:1.0]];
            cell.userInteractionEnabled=NO;
            cell.textLabel.font=[UIFont boldSystemFontOfSize:12];
            cell.textLabel.textColor=[UIColor whiteColor];
            [self createCustomCellUI:cell indexpath:indexPath];
        }
        if(indexPath.row!=0)
            [self updateDataCustomCellUI:cell indexpath:indexPath];
    }
    else if(indexPath.section==0)
    {
        static NSString *CellIdentifier = @"CellIndentifier1";
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] ;
            [cell setBackgroundColor:[UIColor colorWithRed:RedMake(kNavTintColor) green:GreenMake(kNavTintColor) blue:BlueMake(kNavTintColor) alpha:1.0]];
            cell.userInteractionEnabled=NO;
            cell.textLabel.font=[UIFont boldSystemFontOfSize:12];
            cell.textLabel.textColor=[UIColor whiteColor];
            
            [self createCustomCellUI:cell indexpath:indexPath];
        }
        if(!(dataProviderTitleArray.count) && indexPath.row==6)
        {
            cell.textLabel.text = @"No data provider is mapped yet."; 
        }
        else if(indexPath.row!=6)
            [self updateDataCustomCellUI:cell indexpath:indexPath];
        tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    }
    else {
        static NSString *CellIdentifier = @"CellIndentifier2";
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
             cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
    cell.textLabel.text = [NSString stringWithFormat:@"%@",[appraisalMenu  objectAtIndex:indexPath.row]];
    tableView.separatorStyle=UITableViewCellSeparatorStyleSingleLine;     
    }
     return cell;  
}
-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section==2)
        return 44.0f;
    else if(indexPath.section==1 && !dataProviderLabelArray.count)
        return 44.0f;
    else if(indexPath.section == 0 && indexPath.row < 6 )
    {
         CGSize constraint = CGSizeMake(150.0f - (6.0f * 2), 20000.0f);
        CGSize size = [[vechicleTitleArray objectAtIndex:indexPath.row ] sizeWithFont:[UIFont systemFontOfSize:12] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
        CGFloat height = MAX(size.height, 20.0f);
        return  height + (12.0f);
    }
    return 32.0f;
}
#pragma mark tableview Delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIViewController *myController;
    switch (indexPath.row) {
        case VEHICLE_HISTORY:
        {
            if(!([appDelegate currentInstance].dealerVehicleHistory.hasCarfax) && !([appDelegate currentInstance].dealerVehicleHistory.hasAutoCheck))
            {
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Status"
                                                                    message:@"Vehicle History is not enabled."
                                                                   delegate:nil
                                                          cancelButtonTitle:@"Ok"
                                                          otherButtonTitles:nil];
                
                [alertView show];
            }
            else
            {
            if ([str_vin isEqualToString:@"n/a"] || [str_vin isEqualToString:@""] )
            {
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Status"                                                                    message:[NSString stringWithFormat:@"%@ requires vaild VIN.",[appraisalMenu objectAtIndex:indexPath.row]]                                                                   delegate:nil                                                         cancelButtonTitle:@"Ok"                                                          otherButtonTitles:nil];
                [alertView show];
                return;
            }
            else {
                UIViewController *myController;
                myController = [self firstAvailableUIViewController];
                CarfaxReportController *carfaxRptController =[[CarfaxReportController alloc] initWithNibName:@"CarfaxReportController_iPhone" bundle:nil];
                carfaxRptController->str_appraisalid=str_appraisalid;
                carfaxRptController.title=[appraisalMenu objectAtIndex:indexPath.row];
                if([appDelegate currentInstance].dealerVehicleHistory.hasCarfax)
                {
                  carfaxRptController.reqType=17;
                    [myController.navigationController pushViewController:carfaxRptController animated:YES];
                    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:carfaxRptController.reqType],@"reqtype", str_appraisalid,@"appraisalid", carfaxRptController,@"delegate", nil];
                    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
                    [ws initialize:dic];
                    [ws callWSWithQuery:dic];
                }
                else if([appDelegate currentInstance].dealerVehicleHistory.hasAutoCheck)
                {
                    carfaxRptController.reqType=18;
                    [myController.navigationController pushViewController:carfaxRptController animated:YES];
                    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:carfaxRptController.reqType],@"reqtype", str_appraisalid,@"appraisalid", carfaxRptController,@"delegate", nil];
                    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
                    [ws initialize:dic];
                    [ws callWSWithQuery:dic];

                }
            }
            }
        }
            break;
        case APPRAISAL_CUSTOMER:
        {
            AppraisalCustomerDetailsController *custViewController = [[AppraisalCustomerDetailsController alloc]initWithNibName:nil bundle:Nil];
            myController = [self firstAvailableUIViewController];
            custViewController->str_customer = str_customer;
            custViewController->str_customerAddress = str_customerAddress;
            custViewController->str_city = str_city;
            custViewController->str_state = str_state;
            custViewController->str_zip = str_zip;
            custViewController->str_phone = str_phone;
            custViewController->str_mobile = str_mobile;
            custViewController->str_email = str_email;
            custViewController.isAppraisal=self.appraisalDetailsController.isAppraisal;
            custViewController.appraisalDetailsController=self.appraisalDetailsController;
            [myController.navigationController pushViewController:custViewController animated:YES];
            custViewController.navigationItem.title = @"Customer";
        }
            break;
        case APPRAISAL_VEHICLE:
        {
            AppraisalVehicleDetailsController *vehicleViewController = [[AppraisalVehicleDetailsController alloc]initWithNibName:nil bundle:Nil];
            vehicleViewController.navigationItem.title = @"Vehicle";
            vehicleViewController->str_vin = str_vin ;
            vehicleViewController->str_year = str_year;
             vehicleViewController->str_make = str_make;
             vehicleViewController->str_model = str_model;
            vehicleViewController->str_trim = str_trim;
             vehicleViewController->str_style = str_style;
            vehicleViewController->str_mileage = str_mileage;
            vehicleViewController->str_exteriorcolor = str_exteriorcolor;
            vehicleViewController->str_interiorcolor = str_interiorcolor;
            myController = [self firstAvailableUIViewController];
            [myController.navigationController pushViewController:vehicleViewController animated:YES];
        }  
            break;
        case APPRAISAL_APRAISAL:
        {
            AppraisalAppraisalDetailsController *appraisalViewController = [[AppraisalAppraisalDetailsController alloc]initWithNibName:nil bundle:Nil];
            appraisalViewController.navigationItem.title = @"Appraisal";
            if([str_expectedsaleprice intValue])
            appraisalViewController->str_expectedsaleprice = str_expectedsaleprice;
            else
                appraisalViewController->str_expectedsaleprice=str_marketaverageprice;
            appraisalViewController->str_profitobective = str_profitobective;
            appraisalViewController->str_datasalesperson= str_datasalesperson;
             appraisalViewController->str_appraisedvalue= str_appraisedvalue;
             appraisalViewController->str_notes= str_notes;
             appraisalViewController->str_recondtioning= str_recondtioning;
            appraisalViewController.isAppraisal=self.appraisalDetailsController.isAppraisal;
            appraisalViewController.appraisalDetailsController=self.appraisalDetailsController;
            myController = [self firstAvailableUIViewController];
            [myController.navigationController pushViewController:appraisalViewController animated:YES];
        }  
            break;
        case APPRAISAL_MARKET_CONTROL_ANALYTICS:
        {
            MarketControlAnalysisController *mcaViewController = [[MarketControlAnalysisController alloc]initWithNibName:nil bundle:Nil];
            mcaViewController.navigationItem.title = @"Market Pricing";
            mcaViewController->str_marketsize = str_marketsize;;
            mcaViewController->str_marketaverageprice = str_marketaverageprice;
            mcaViewController->str_marketaveragemileage = str_marketaveragemileage;
            mcaViewController->str_recommendedprice = str_recommendedprice;
            mcaViewController->str_dayssupply = str_daysupply;
            mcaViewController->str_pricerank = str_pricerank;
            mcaViewController->str_appraisalid = str_appraisalid;
            myController = [self firstAvailableUIViewController];
            [myController.navigationController pushViewController:mcaViewController animated:YES];
        }
            break;
        case APPRAISAL_DATAPROVIDER:
        {
            AppraisalDataProvidersDetailsController *dataproviderViewController = [[AppraisalDataProvidersDetailsController alloc]initWithNibName:nil bundle:Nil];
            /* Data Providers/ Market Control Analysis*/
            dataproviderViewController.reqType=11;
            dataproviderViewController.isAppraisal=self.appraisalDetailsController.isAddAppraisal;
            dataproviderViewController->str_marketsize = str_marketsize;;
            dataproviderViewController->str_marketaverageprice = str_marketaverageprice;
            dataproviderViewController->str_marketaveragemileage = str_marketaveragemileage;
            dataproviderViewController->str_recommendedprice = str_recommendedprice;
            dataproviderViewController->str_dayssupply = str_daysupply;
            dataproviderViewController->str_pricerank = str_pricerank;
            dataproviderViewController->str_appraisalid = str_appraisalid;
            dataproviderViewController.appraisalDetailsController=appraisalDetailsController;
            {
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:11],@"reqtype", str_appraisalid,@"appraisalid", dataproviderViewController,@"delegate", nil];
                IVMMobileServices *ws = [[IVMMobileServices alloc] init];
                [ws initialize:dic];
                [ws callWSWithQuery:dic];
                myController = [self firstAvailableUIViewController];
                [myController.navigationController pushViewController:dataproviderViewController animated:YES];
                dataproviderViewController.navigationItem.title = @"Data Providers";
            }
        }  
        break;
            case APPRAISAL_COMPETITIVEINFO:
            {
                CompetitiveInfoNewViewController *competitiveViewController = [[CompetitiveInfoNewViewController alloc]initWithStyle:UITableViewStyleGrouped];
                competitiveViewController.reqType=9;
               NSString *str_marketradius = @"100";
               NSString *str_filtertype = @"None";
               NSString *str_filtervalue = @"";
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:9],@"reqtype",str_appraisalid,@"appraisalid",str_marketradius,@"marketradius", str_filtertype,@"filtertype",str_filtervalue,@"filtervalue",competitiveViewController,@"delegate", nil];
                IVMMobileServices *ws = [[IVMMobileServices alloc] init];
                [ws initialize:dic];
                [ws callWSWithQuery:dic];
                myController = [self firstAvailableUIViewController];
                [myController.navigationController pushViewController:competitiveViewController animated:YES];
                competitiveViewController.navigationItem.title = @"Competitive Information";
            }
            break;
        case ADD_TO_INVENTORY:
        {
            if ([str_vin isEqualToString:@"n/a"] || [str_vin isEqualToString:@""] ) 
            {
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Status"                                                                    message:@"Add to Inventory requires vaild VIN."                                                                   delegate:nil                                                          cancelButtonTitle:@"Ok"                                                          otherButtonTitles:nil];
                [alertView show];
                return;
            }
            else 
            [self.appraisalDetailsController addToInventory];
        }
            break;
        default:
            break;
    }
}
-(void) aMethod
{
    [modalView removeFromSuperview];
}
@end
