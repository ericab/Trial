//
//  AdvancedSearchController.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 1/14/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"

@class VehicleSearchObject;

@interface AdvancedSearchController : UIViewController<UITextFieldDelegate, UIPickerViewDelegate, ItemRestore> {
	VehicleSearchObject *searchObj;
}

- (void)advSearchError:(id)sender;

@end
