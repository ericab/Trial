//
//  SearchResultsController.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/25/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoadingView.h"
#import "IVM.h"
#import "RestoreProtocols.h"

@class MapViewController;
@class AdvancedSearchController;
@class SearchResultsView;

@interface SearchResultsController : UIViewController<UINavigationBarDelegate, UITableViewDelegate,
			UIAlertViewDelegate, UITableViewDataSource, IVMMobileServicesDelegate, ItemRestore> {
//			UIAlertViewDelegate, UITableViewDataSource, LocationControllerDelegate, IVMMobileServicesDelegate, ItemRestore> {
	SearchResultsView					*searchView;
	//MapViewController					*mapController;
	IVMMobileServices					*mobileServices;
	VehicleSearchResults				*searchResults;
	VehicleSearchObject					*searcher;
                
	//Used to cache NetImageViews so they can complete the image download
	NSMutableDictionary					*netImageCache;
	UIBarButtonItem						*rightBarButton;
	BOOL								_viewLoaded;
	BOOL								_attemptedLoad;
	BOOL								_hasFiltered;
	BOOL								_viewAppeared;
	BOOL								_pushSingleListing;

    LoadingView					*loadingView;
    UIButton                    *loadMore;

	NSString		*_userToken;
	UISegmentedControl		*seg_sort;
}

@property (assign) BOOL loadingMore;
@property (assign) BOOL loadedAll;

- (void)startSearch:(VehicleSearchObject*)search;

-(IBAction)mapClicked:(id)sender;
//-(IBAction)flipAction:(id)sender;

@end