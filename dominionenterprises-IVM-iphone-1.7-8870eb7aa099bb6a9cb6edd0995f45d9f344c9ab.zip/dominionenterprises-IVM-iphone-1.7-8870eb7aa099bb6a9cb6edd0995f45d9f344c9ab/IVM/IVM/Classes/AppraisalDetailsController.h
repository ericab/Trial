//
//  AppraisalDetailsController.h
//
// .
//  

#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"
#import "AppraisalDetailsView.h"
#import "AppraisalSearchResultsController.h"
#import "LoadingView.h"
@class VehicleSearchObject;

@interface AppraisalDetailsController : UIViewController<UITextFieldDelegate, UIPickerViewDelegate, ItemRestore> {
	VehicleSearchObject *searchObj;
    NSDictionary    *dataProviderDetails;
    NSMutableArray  *arrayOfdataProviders;
    @public AppraisalDetailsView *asv;
    NSMutableArray *arrayOfAppraisalDetails;
    NSDictionary    *appraisalDetails;
    NSMutableArray *arrayOfappraisalDetailDataProvider;
    NSDictionary    *appraisalDetail;
    LoadingView				*loadingView;
    int countProvider;
    NSInteger vehicleMappingAppraisalKey;
     NSMutableArray *arrayOfdataProvidersDetailsOptions;
    NSDictionary *dataProviderDetailsOptions;
}

@property (nonatomic,retain)  NSDictionary    *appraisalDetails;
@property(nonatomic,retain) AppraisalSearchResultsController *appraisalSearchResultsController;
@property(nonatomic,assign) int reqType;
@property(nonatomic,assign) BOOL refreshDataOn;
@property(nonatomic,assign)BOOL isAppraisal;
@property(nonatomic,assign) BOOL isAddAppraisal;
- (void)advSearchError:(id)sender;
-(void) addToInventory;
-(void) refreshData;
@end
