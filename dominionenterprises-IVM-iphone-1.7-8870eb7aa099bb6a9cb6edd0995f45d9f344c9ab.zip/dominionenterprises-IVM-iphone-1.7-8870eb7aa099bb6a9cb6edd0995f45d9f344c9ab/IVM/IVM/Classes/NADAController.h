//
//  NADAController.h
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//

#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"
#import "SearchResultsView.h"

@class VehicleSearchObject;

@interface NADAController : UIViewController<UITextFieldDelegate, UIPickerViewDelegate,UIPickerViewDataSource, ItemRestore> {
	VehicleSearchObject *searchObj;
    NSDictionary *dataProviderDetails;
    NSDictionary *dataProviderDetailsOptions;
    NSMutableArray *arrayOfdataProvidersDetails;
    NSMutableArray *arrayOfdataProvidersDetailsOptions;

     UIScrollView		*scrollView;
    
    
    UITextField			*txt_model;
	UITextField			*txt_trim;
	UITextField			*txt_Year;
	UITextField			*txt_make;
	UITextField			*txt_style;
    UITextField			*txt_nadaoptions;
     UITextField			*txt_nadamoreoptions;
    UITextField			*txt_mileage;
    SearchResultsView                 *progressView;
    
    NSMutableArray *arrayOfdataProviderStyles;
    NSMutableArray *arrayOfdataProviderModels;
    NSMutableArray *arrayOfdataProviderTrims;
    
    NSMutableArray *arrayOfdataProviderYears;
    NSMutableArray *arrayOfdataProviderMakes;
    NSMutableArray *arrayOfdataProviderClean;
    NSMutableArray *arrayOfdataProviderExtra;
    NSString *providerType;
    UIPickerView		*pickerYear;
    UIToolbar			*_pickerYearDone;
    id latsetTextField;
    NSMutableArray		*oneDataSource;

}

- (void)advSearchError:(id)sender;

@end
