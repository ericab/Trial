//
//  AppraisalSearchResultsController.m
//
//  Created by Raja Sekhar Nerella on 3/20/12.
//

#import <UIKit/UIKit.h>

@interface AppraisalSearchResultsView : UIView {
	UIActivityIndicatorView	*activityIndicator;
	UILabel					*activityLabel;
	UITableView				*searchTable;
	UIButton				*filterButton;
	UIView					*mainView;
}

@property(nonatomic, strong)	UIActivityIndicatorView	*activityIndicator;
@property(nonatomic, strong)	UILabel					*activityLabel;
@property(nonatomic, strong)	UITableView				*searchTable;
@property(nonatomic, strong)	UIButton				*filterButton;
@property(nonatomic, strong)	UIView					*mainView;

@end
