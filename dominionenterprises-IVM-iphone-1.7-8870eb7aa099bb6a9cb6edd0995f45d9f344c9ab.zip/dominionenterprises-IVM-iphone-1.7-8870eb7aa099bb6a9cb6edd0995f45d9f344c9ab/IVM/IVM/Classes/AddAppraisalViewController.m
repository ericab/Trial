//
//  AddAppraisalViewController.m
//  IVM
//
//  Created by Raja Sekhar Nerella on 29/05/12.

//

#import "AddAppraisalViewController.h"
#import "AppraisalDetailsController.h"
@interface AddAppraisalViewController ()
- (void)registerForKeyboardNotifications;
- (void)unregisterForKeyboardNotifications;
@end

@implementation AddAppraisalViewController
@synthesize btn_VinCodeScan;
@synthesize apprasialStatus;
@synthesize appraisalSearchResultsController;
@synthesize reqType;

static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;
static const CGFloat LANDSCAPE_KEYBOARD_HEIGHT = 162;

static const CGFloat VIN_MAX_LENGTH = 17;
static const CGFloat PRICE_MAX_LENGTH = 10;
static const CGFloat MILEAGE_MAX_LENGTH = 6;
static const CGFloat ZIP_MAX_LENGTH = 6;
static const CGFloat NAME_MAX_LENGTH = 100;

static const CGFloat EMAIL_MAX_LENGTH = 200;
static const CGFloat MOBILE_MAX_LENGTH = 14;
static const CGFloat PHONE_MAX_LENGTH = 14;
static const CGFloat CITY_MAX_LENGTH = 50;
static const CGFloat ADDRESS_MAX_LENGTH = 250;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        mobileServices = [[IVMMobileServices alloc] init];
		mobileServices.delegate = self;
        
		_userToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];
        
       
    }
    return self;
}
- (void)buildStatesList
{
    // static arrays of states , exterior colors and interior colors as web services are not available
    stateNames = [NSMutableArray arrayWithObjects:@"Alabama",  
                       @"Alaska",  
                       @"Arizona",  
                       @"Arkansas",  
                       @"California",  
                       @"Colorado",  
                       @"Connecticut",  
                       @"Delaware",  
                       @"District Of Columbia",  
                       @"Florida",  
                       @"Georgia",  
                       @"Hawaii",  
                       @"Idaho",  
                       @"Illinois",  
                       @"Indiana",  
                       @"Iowa",  
                       @"Kansas",  
                       @"Kentucky",  
                       @"Louisiana",  
                       @"Maine",  
                       @"Maryland",  
                       @"Massachusetts",  
                       @"Michigan",  
                       @"Minnesota",  
                       @"Mississippi",  
                       @"Missouri",  
                       @"Montana",
                       @"Nebraska",
                       @"Nevada",
                       @"New Hampshire",
                       @"New Jersey",
                       @"New Mexico",
                       @"New York",
                       @"North Carolina",
                       @"North Dakota",
                       @"Ohio",  
                       @"Oklahoma",  
                       @"Oregon",  
                       @"Pennsylvania",  
                       @"Rhode Island",  
                       @"South Carolina",  
                       @"South Dakota",
                       @"Tennessee",  
                       @"Texas",  
                       @"Utah",  
                       @"Vermont",  
                       @"Virginia",  
                       @"Washington",  
                       @"West Virginia",  
                       @"Wisconsin",  
                       @"Wyoming", nil];
    
    stateCodes = [NSMutableArray arrayWithObjects:@"AL",  
                       @"AK",  
                       @"AZ",  
                       @"AR",  
                       @"CA",  
                       @"CO",  
                       @"CT",  
                       @"DE",  
                       @"DC",  
                       @"FL",  
                       @"GA",  
                       @"HI",  
                       @"ID",  
                       @"IL",  
                       @"IN",  
                       @"IA",  
                       @"KS",  
                       @"KY",  
                       @"LA",  
                       @"MEe",  
                       @"MD",  
                       @"MA",  
                       @"MI",  
                       @"MN",  
                       @"MS",  
                       @"MO",  
                       @"MT",
                       @"NE",
                       @"NV",
                       @"NH",
                       @"NJ",
                       @"NM",
                       @"NY",
                       @"NC",
                       @"ND",
                       @"OH",  
                       @"OK",  
                       @"OR",  
                       @"PA",  
                       @"RI",  
                       @"SC",  
                       @"SD",
                       @"TN",  
                       @"TX",  
                       @"UT",  
                       @"VT",  
                       @"VA",  
                       @"WA",  
                       @"WV",  
                       @"WI",  
                       @"WY", nil];
    
    exteriorColors = [NSMutableArray arrayWithObjects:@"Beige",  
                  @"Black",  
                  @"Blue",  
                  @"Brown",  
                  @"Dk. Blue",  
                  @"Dk. Brown",  
                  @"Dk. Gray",  
                  @"Dk. Green",  
                  @"Dk. Red",  
                  @"Gold",  
                  @"Gray",  
                  @"Green",  
                  @"Lt. Blue",  
                  @"Lt. Brown",  
                  @"Lt. Gray",  
                  @"Lt. Green",
                  @"Maroon",  
                  @"Off White",  
                  @"Orange",  
                  @"Pink",  
                  @"Purple",  
                  @"Red",  
                  @"Silver",  
                  @"Tan",  
                  @"White",  
                  @"Yellow",  
                  nil];
    
    statuses = [NSMutableArray arrayWithObjects:@"Active",  
                      @"Deleted",  
                      nil];
    
    currencyFormatter = [[NSNumberFormatter alloc] init];
    
    [currencyFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
    
    [currencyFormatter setMaximumFractionDigits:0];
    
    
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [currencyFormatter setLocale:usLocale];
    
    //set up the reject character set
    NSMutableCharacterSet *numberSet = [[NSCharacterSet decimalDigitCharacterSet] mutableCopy];
    [numberSet formUnionWithCharacterSet:[NSCharacterSet whitespaceCharacterSet]];
    nonNumberSet = [numberSet invertedSet];
    
    nonCharacterSet = [[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789 .,-"] invertedSet];
    
    
    NSMutableCharacterSet *upcaseCharactersSet = [[NSCharacterSet uppercaseLetterCharacterSet] mutableCopy];
    [upcaseCharactersSet formUnionWithCharacterSet:[NSCharacterSet decimalDigitCharacterSet]];
    nonVINCodeCharactersSet = [upcaseCharactersSet invertedSet];
    
    numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    
    
    [numberFormatter setLocale:usLocale];
}

-(void) loadView
{
     statuses = [NSMutableArray array];
    years = [NSMutableArray array];
    makes = [NSMutableArray array];
    models = [NSMutableArray array];
    styles = [NSMutableArray array];
    trims = [NSMutableArray array];
    exteriorColors = [NSMutableArray array];
    interiorColors = [NSMutableArray array];
    stateNames = [NSMutableArray array];
    stateCodes = [NSMutableArray array];
    providerSummary = [NSMutableArray array];
    titaniumIds = [NSMutableArray array];
    
    reqType=0;
   
    phoneNumberFormatter = [[PhoneNumberFormatter alloc] init];
    
    [self buildStatesList];
    
    UIView *view = [[UIView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    [view setAutoresizingMask:UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth];
    [view setBackgroundColor:[UIColor whiteColor]];
    UIImageView *backgroundImage=  [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];;
    [view addSubview:backgroundImage];
    [view sendSubviewToBack:backgroundImage];
    
       
    scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [view addSubview:scrollView];
    
    yOffset = 10.0f;
    
    
    backgroundView01 = [[UIView alloc] initWithFrame:CGRectMake(10.0f, yOffset - 5.0, 300.0f, 155.0f)];
    backgroundView01.backgroundColor = [UIColor whiteColor];
    backgroundView01.layer.cornerRadius = 8.0;
    [scrollView addSubview:backgroundView01];
  
    yOffset += 10.0f;
    
    vinView = [[UIImageView alloc] initWithFrame:CGRectMake(20.0f, yOffset, 280.0f, 60.0)];
    vinView.image = [UIImage imageNamed:@"vin.jpg"];
    [scrollView addSubview:vinView];
    
    yOffset += 80.0f;
    
    btn_VinCodeScan = [UIButton buttonWithType:UIButtonTypeCustom];
    btn_VinCodeScan.frame = CGRectMake(20.0f, yOffset, 280.0f, 45.0);
    [btn_VinCodeScan setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
    [btn_VinCodeScan setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn_VinCodeScan.titleLabel.font = [UIFont boldSystemFontOfSize: 20];
    [btn_VinCodeScan setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
    [btn_VinCodeScan setTitle:@"Scan the VIN BarCode" forState:UIControlStateNormal];
    [scrollView addSubview:btn_VinCodeScan];
    
    yOffset += 70.0f;
    
    // OR Label
    orLabel = [[UILabel alloc] initWithFrame:CGRectMake(140.0f, yOffset, 40.0f, 30.0f)];
    orLabel.backgroundColor = [UIColor clearColor];
    orLabel.textColor = [UIColor blackColor];
    orLabel.font = [UIFont boldSystemFontOfSize:kDefaultFontSize + 6.0];
    orLabel.text = @"OR";
    [scrollView addSubview:orLabel];

    yOffset += 30.0f;
    
    
    backgroundView02 = [[UIView alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 155.0f)];
    backgroundView02.backgroundColor = [UIColor whiteColor];
    backgroundView02.layer.cornerRadius = 8.0;
    [scrollView addSubview:backgroundView02];
    
    yOffset += 20.0f;
    
    //VIN Code Label
    vinLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, yOffset, 180.0f, 15.0f)];
    vinLabel.backgroundColor = [UIColor clearColor];
    vinLabel.textColor = [UIColor blackColor];
    vinLabel.font = [UIFont systemFontOfSize:kDefaultFontSize + 2.0];
    vinLabel.text = @"Manual VIN Entry";
    [scrollView addSubview:vinLabel];
    
    yOffset += 20.0f;
    
    txt_vin = [[UITextField alloc] initWithFrame:CGRectMake(20.0f, yOffset, 280.0f, 30.0f)];
    txt_vin.borderStyle = UITextBorderStyleRoundedRect;
    txt_vin.returnKeyType = UIReturnKeyDone;
    txt_vin.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_vin.font = [UIFont systemFontOfSize:kDefaultFontSize + 2.0];
    txt_vin.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_vin.placeholder = @"VIN Number";
    txt_vin.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_vin.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
    txt_vin.delegate = self;
    
    [scrollView addSubview:txt_vin];
    
    yOffset += 55.0f;
    
    btn_vinDecode = [UIButton buttonWithType:UIButtonTypeCustom];
    btn_vinDecode.frame = CGRectMake(20.0f, yOffset, 280.0f, 45.0);
    [btn_vinDecode setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
    [btn_vinDecode setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn_vinDecode.titleLabel.font = [UIFont boldSystemFontOfSize: 20];
    [btn_vinDecode setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
    [btn_vinDecode setTitle:@"Decode" forState:UIControlStateNormal];
    [btn_vinDecode addTarget:self action:@selector(decodeVinCode) forControlEvents:UIControlEventTouchUpInside];
    [btn_VinCodeScan addTarget:self action:@selector(scanButtonTapped) forControlEvents:UIControlEventTouchUpInside];
    [scrollView addSubview:btn_vinDecode];
   
    
    yOffset += 80.0f;
    
    
    
    UIColor *textColor = [UIColor blackColor];
    UIFont *lblFont = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0];
    
    //Year
    UILabel *tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Year";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_year = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_year.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_year.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_year.placeholder = @"Year";
    txt_year.returnKeyType = UIReturnKeyDone;
    txt_year.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_year.delegate = self;
    txt_year.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    
    [scrollView addSubview:txt_year];
    yOffset += 30.0f;
    
    //Make
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Make";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_make = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_make.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_make.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_make.placeholder = @"Make";
    txt_make.returnKeyType = UIReturnKeyDone;
    txt_make.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_make.delegate = self;
    txt_make.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    
    [scrollView addSubview:txt_make];
    yOffset += 30.0f;
    
    //Model
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Model";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_model = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_model.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_model.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_model.placeholder = @"Model";
    txt_model.returnKeyType = UIReturnKeyDone;
    txt_model.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_model.delegate = self;
    txt_model.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    
    [scrollView addSubview:txt_model];
    yOffset += 30.0f;
    
    //Trim
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Trim";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_trim = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_trim.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_trim.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_trim.placeholder = @"Trim";
    txt_trim.returnKeyType = UIReturnKeyDone;
    txt_trim.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_trim.delegate = self;
    txt_trim.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    
    [scrollView addSubview:txt_trim];

    yOffset += 30.0f;
    
    //Style
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Style";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_style = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_style.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_style.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_style.placeholder = @"Style";
    txt_style.returnKeyType = UIReturnKeyDone;
    txt_style.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_style.delegate = self;
    txt_style.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    
    [scrollView addSubview:txt_style];
    yOffset += 30.0f;
        
       
    //Mileage
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Mileage";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_mileage = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_mileage.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_mileage.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_mileage.placeholder = @"Mileage";
    txt_mileage.returnKeyType = UIReturnKeyDone;
    txt_mileage.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_mileage.delegate = self;
    txt_mileage.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [txt_mileage setKeyboardType:UIKeyboardTypeNumberPad];
    [scrollView addSubview:txt_mileage];
    yOffset += 30.0f;
    
    //Exterior Color
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Exterior Color";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_exteriorcolor = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_exteriorcolor.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_exteriorcolor.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_exteriorcolor.placeholder = @"Exterior Color";
    txt_exteriorcolor.returnKeyType = UIReturnKeyDone;
    txt_exteriorcolor.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_exteriorcolor.delegate = self;
    txt_exteriorcolor.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
     [scrollView addSubview:txt_exteriorcolor];
    yOffset += 30.0f;
    
    
    //interior Color
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Interior Color";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_interiorcolor = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_interiorcolor.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_interiorcolor.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_interiorcolor.placeholder = @"Interior Color";
    txt_interiorcolor.returnKeyType = UIReturnKeyDone;
    txt_interiorcolor.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_interiorcolor.delegate = self;
    txt_interiorcolor.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [scrollView addSubview:txt_interiorcolor];
    
    yOffset += 30.0f;
    
    if(self.apprasialStatus==2)
    {
    //Customer
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 150.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Customer Name";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_customer = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_customer.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_customer.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_customer.placeholder = @"Customer Name";
    txt_customer.returnKeyType = UIReturnKeyDone;
    txt_customer.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_customer.delegate = self;
    txt_customer.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    
    [scrollView addSubview:txt_customer];
    
    yOffset += 30.0f;
    
    //Address
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 150.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Customer Address";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_customerAddress = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_customerAddress.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_customerAddress.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_customerAddress.placeholder = @"Customer Address";
    txt_customerAddress.returnKeyType = UIReturnKeyDone;
    txt_customerAddress.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_customerAddress.delegate = self;
    txt_customerAddress.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_customerAddress];
    
    yOffset += 30.0f;

    //City
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Customer City";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_city = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_city.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_city.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_city.placeholder = @"Customer City";
    txt_city.returnKeyType = UIReturnKeyDone;
    txt_city.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_city.delegate = self;
    txt_city.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_city];
    
    yOffset += 30.0f;
    
    //State
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Customer State";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_state = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_state.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_state.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_state.placeholder = @"Customer State";
    txt_state.returnKeyType = UIReturnKeyDone;
    txt_state.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_state.delegate = self;
    txt_state.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_state];
    
    yOffset += 30.0f;
    
    //Zip
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 200.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Customer Zip";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;

    txt_zip = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_zip.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_zip.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_zip.placeholder = @"Customer Zip";
    txt_zip.returnKeyType = UIReturnKeyDone;
    txt_zip.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_zip.delegate = self;
    txt_zip.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [txt_zip setKeyboardType:UIKeyboardTypeNumberPad];
    [scrollView addSubview:txt_zip];
    
    yOffset += 30.0f;
    
    //Phone
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Customer Phone";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;

    txt_phone = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_phone.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_phone.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_phone.placeholder = @"Customer Phone";
    txt_phone.returnKeyType = UIReturnKeyDone;
    txt_phone.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_phone.delegate = self;
    txt_phone.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [txt_phone setKeyboardType:UIKeyboardTypeNumberPad];
    [scrollView addSubview:txt_phone];
    
    yOffset += 30.0f;
    //Mobile
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Customer Mobile";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;

    txt_mobile = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_mobile.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_mobile.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_mobile.placeholder = @"Customer Mobile";
    txt_mobile.returnKeyType = UIReturnKeyDone;
    txt_mobile.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_mobile.delegate = self;
    txt_mobile.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [txt_mobile setKeyboardType:UIKeyboardTypeNumberPad];
    [scrollView addSubview:txt_mobile];
    
    yOffset += 30.0f;
    
    //Email
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Customer  Email";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;

    txt_email = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_email.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_email.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_email.placeholder = @"Email";
    txt_email.returnKeyType = UIReturnKeyDone;
    txt_email.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_email.delegate = self;
    txt_email.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [txt_email setKeyboardType:UIKeyboardTypeEmailAddress];
    [scrollView addSubview:txt_email];
    
     yOffset += 30.0f;
 
    //Expected Sale Price
     tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 150.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Expected Sale Price";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_expectedsaleprice = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_expectedsaleprice.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_expectedsaleprice.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_expectedsaleprice.placeholder = @"Expected Sale Price";
    txt_expectedsaleprice.returnKeyType = UIReturnKeyDone;
    txt_expectedsaleprice.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_expectedsaleprice.delegate = self;
    txt_expectedsaleprice.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [txt_expectedsaleprice setKeyboardType:UIKeyboardTypeNumberPad];
    [scrollView addSubview:txt_expectedsaleprice];
    yOffset += 30.0f;

        //Recondtioning
        tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
        tmpLabel.font = lblFont;
        tmpLabel.textColor = textColor;
        tmpLabel.backgroundColor = [UIColor clearColor];
        tmpLabel.text = @"Reconditioning";
        [scrollView addSubview:tmpLabel];
        
        yOffset += 20.0f;
        txt_recondtioning = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
        txt_recondtioning.borderStyle = UITextBorderStyleRoundedRect;
        
        txt_recondtioning.font = [UIFont systemFontOfSize:kDefaultFontSize];
        txt_recondtioning.placeholder = @"Reconditioning";
        txt_recondtioning.returnKeyType = UIReturnKeyDone;
        txt_recondtioning.autocorrectionType = UITextAutocorrectionTypeNo;
        txt_recondtioning.delegate = self;
        txt_recondtioning.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        [txt_recondtioning setKeyboardType:UIKeyboardTypeNumberPad];
        [scrollView addSubview:txt_recondtioning];
        yOffset += 30.0f;

     //Profit Objective
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Profit Objective";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_profitobective = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_profitobective.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_profitobective.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_profitobective.placeholder = @"Profit Objective";
    txt_profitobective.returnKeyType = UIReturnKeyDone;
    txt_profitobective.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_profitobective.delegate = self;
    txt_profitobective.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        [txt_profitobective setKeyboardType:UIKeyboardTypeNumberPad];
    [scrollView addSubview:txt_profitobective];
    yOffset += 30.0f;
    
    //Appraised Value
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Appraised Value";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_appraisedvalue = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_appraisedvalue.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_appraisedvalue.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_appraisedvalue.placeholder = @"Appraised Value";
    txt_appraisedvalue.returnKeyType = UIReturnKeyDone;
    txt_appraisedvalue.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_appraisedvalue.delegate = self;
    txt_appraisedvalue.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        [txt_appraisedvalue     setKeyboardType:UIKeyboardTypeNumberPad];
    [scrollView addSubview:txt_appraisedvalue];
    yOffset += 30.0f;
    
    //Notes
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Notes";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_notes = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_notes.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_notes.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_notes.placeholder = @"Notes";
    txt_notes.returnKeyType = UIReturnKeyDone;
    txt_notes.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_notes.delegate = self;
    txt_notes.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [scrollView addSubview:txt_notes];
      yOffset += 30.0f;
        
        //Sales Person
        tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
        tmpLabel.font = lblFont;
        tmpLabel.textColor = textColor;
        tmpLabel.backgroundColor = [UIColor clearColor];
        tmpLabel.text = @"Sales Person";
        [scrollView addSubview:tmpLabel];
        
        yOffset += 20.0f;
        txt_datasalesperson = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
        txt_datasalesperson.borderStyle = UITextBorderStyleRoundedRect;
        
        txt_datasalesperson.font = [UIFont systemFontOfSize:kDefaultFontSize];
        txt_datasalesperson.placeholder = @"Sales Person";
        txt_datasalesperson.returnKeyType = UIReturnKeyDone;
        txt_datasalesperson.autocorrectionType = UITextAutocorrectionTypeNo;
        txt_datasalesperson.delegate = self;
        txt_datasalesperson.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        [scrollView addSubview:txt_datasalesperson];
        yOffset += 30.0f;

    }

      if (!bReappraisalSelected) {
 
    txt_appraisalid.text = @"0";//AppraisalId": 0,
    txt_status.text = @"";//"Status": "None",
    txt_customer.text = @"";//"CustomerName": "Test Save",
    txt_customerAddress.text = @"";//"CustomerAddress": "1234 Somewhere",
    txt_city.text = @"";//"CustomerCity": "Someplace",
    txt_state.text = @"";//"CustomerState": "OH",
    txt_zip.text = @"";//"CustomerPostalCode": "45036",
    
    txt_phone.text = @"";// "CustomerPhone": "111-222-3333",
    txt_mobile.text = @"";//CustomerMobile": "444-555-6666",
    txt_email.text =  @"";//"CustomerEmail": "me@mydomain.com",
    txt_vin.text = @""; //"Vin": "",
    txt_year.text = @"";//"Year": 2000,
    txt_make.text = @"";//"Make": "Honda",
    txt_model.text = @"";//: "Accord",
    txt_trim.text = @"";//"Trim": "EX V6",
    txt_style.text = @"";//"Style": "4 Dr EX V6 Sedan",
    txt_mileage.text = @"";//"Mileage": 25000,

    txt_exteriorcolor.text = @"";//"ColorExterior": "Blue",
    txt_interiorcolor.text = @"";//"ColorInterior": "Grey",
    txt_appraisedvalue.text = @"";//"AppraisedValue": 12000,
    txt_expectedsaleprice.text = @"";//"ExpectedSalePrice": 13500,
    txt_notes.text = @"";//"Notes": "My note on this appraisal.",
    txt_profitobective.text = @"";//"ProfitObjective": 1000,
    txt_recondtioning.text = @"";//"Reconditioning": 500,
    txt_datasalesperson.text = @"";//"SalesPerson": "Some Salesperson",
    txt_dayssupply.text= @""; //"DaysSupply": 5,
    txt_marketaveragemileage.text = @"";//"MarketAverageMilesage": 18500,
    txt_marketaverageprice.text= @"";// "MarketAveragePrice": 11500,
    txt_marketsize.text = @"";//"MarketSize": 6,
    txt_pricerank.text = @"";// "PriceRank": 2,
    txt_recommendedprice.text = @"";//"RecommendedPrice": 2250,
    txt_dealerlotkey.text = @"";//"DealerLotKey": 162551
        
        
    }
    else 
    {
        txt_make.text= str_make;
        txt_model.text= str_model ;// @"Accord";
        txt_year.text = str_year ;//@"2000";
        txt_vin.text =str_vin ;//@"345343434343";
        txt_style.text=str_style;//@"style";
        txt_dealerlotkey.text=str_dealerlotkey;
        txt_mileage.text=[NSString stringWithFormat:@"%@ mi", [numberFormatter stringFromNumber:[NSNumber numberWithInt:[str_mileage intValue]]]];
        txt_exteriorcolor.text=str_exteriorcolor;
        txt_interiorcolor.text=str_interiorcolor;
        txt_customer.text=str_customer;
        txt_customerAddress.text=str_customerAddress;
        txt_city.text=str_city;
        txt_state.text=str_state;
        txt_zip.text=str_zip;
        txt_phone.text=[phoneNumberFormatter format:str_phone withLocale:@"us"];
        txt_mobile.text=[phoneNumberFormatter format:str_mobile withLocale:@"us"];
        txt_email.text=str_email;
        txt_expectedsaleprice.text=[currencyFormatter stringFromNumber:[NSNumber numberWithInt:[str_expectedsaleprice intValue]]];
        txt_profitobective.text=[currencyFormatter stringFromNumber:[NSNumber numberWithInt:[str_profitobective intValue]]];
        txt_datasalesperson.text=str_datasalesperson;
        txt_appraisedvalue.text=[currencyFormatter stringFromNumber:[NSNumber numberWithInt:[str_appraisedvalue intValue]]];
        txt_notes.text=str_notes;
        txt_recondtioning.text=[currencyFormatter stringFromNumber:[NSNumber numberWithInt:[str_recondtioning intValue]]];
        txt_status.text=str_status;
        txt_trim.text = str_trim;
        txt_exteriorcolor.text=str_exteriorcolor;
        txt_interiorcolor.text=str_interiorcolor;
        txt_notes.text=str_notes;
        txt_datasalesperson.text=str_datasalesperson;

    }

    //Picker View Creation		
    _pickerOneDone = [UIToolbar new];
    [_pickerOneDone sizeToFit];
    
    _pickerOneDone.frame = CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 215.0f - 42.0f, [UIScreen mainScreen].applicationFrame.size.width, _pickerOneDone.frame.size.height);
    _pickerOneDone.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
    _pickerOneDone.barStyle = UIBarStyleBlack;
    _pickerOneDone.contentMode = UIViewContentModeRight;
    UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(pickerDone:)];
    UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [_pickerOneDone setItems:[NSArray arrayWithObjects:spacer, done, nil] animated:NO];

    //DealerLot/Year Picker
    
    pickerOne = [[UIPickerView alloc] initWithFrame:CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 215.0f, [UIScreen mainScreen].applicationFrame.size.width, 0.0f)];
    pickerOne.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    pickerOne.showsSelectionIndicator = YES;
    pickerOne.delegate = self;
    pickerOne.dataSource = self;

    txt_state.inputView = pickerOne;
    txt_state.inputAccessoryView = _pickerOneDone;
    txt_year.inputView = pickerOne;
    txt_year.inputAccessoryView = _pickerOneDone;
    txt_make.inputView = pickerOne;
    txt_make.inputAccessoryView = _pickerOneDone;
    txt_model.inputView = pickerOne;
    txt_model.inputAccessoryView = _pickerOneDone;
    txt_style.inputView = pickerOne;
    txt_style.inputAccessoryView = _pickerOneDone;
    txt_trim.inputView = pickerOne;
    txt_trim.inputAccessoryView = _pickerOneDone;
    txt_exteriorcolor.inputView = pickerOne;
    txt_exteriorcolor.inputAccessoryView = _pickerOneDone;
    txt_interiorcolor.inputView = pickerOne;
    txt_interiorcolor.inputAccessoryView = _pickerOneDone;
    
    if(apprasialStatus == 2)
    {
    btn_calculate = [UIButton buttonWithType:UIButtonTypeCustom];
    btn_calculate.frame = CGRectMake(20.0f, yOffset, 125.0f, 45.0);
    [btn_calculate setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
    [btn_calculate setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn_calculate.titleLabel.font = [UIFont boldSystemFontOfSize: 20];
   [btn_calculate setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
    
    [btn_calculate addTarget:self action:@selector(calculateAppraisal) forControlEvents:UIControlEventTouchUpInside];

    [btn_calculate setTitle:@"Create" forState:UIControlStateNormal];

    [scrollView addSubview:btn_calculate];
        
        btn_update = [UIButton buttonWithType:UIButtonTypeCustom];
        btn_update.frame = CGRectMake(170.0f, yOffset, 125.0f, 45.0);
        [btn_update setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
        [btn_update setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        btn_update.titleLabel.font = [UIFont boldSystemFontOfSize: 20];
        [btn_update setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
        
        [btn_update addTarget:self action:@selector(saveAppraisal) forControlEvents:UIControlEventTouchUpInside];
        
        [btn_update setTitle:@"Update" forState:UIControlStateNormal];
        
        [scrollView addSubview:btn_update];
    }
    else
    {
        btn_calculate = [UIButton buttonWithType:UIButtonTypeCustom];
        btn_calculate.frame = CGRectMake(20.0f, yOffset, 280.0f, 45.0);
        [btn_calculate setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
        [btn_calculate setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        btn_calculate.titleLabel.font = [UIFont boldSystemFontOfSize: 20];
        [btn_calculate setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
        
        [btn_calculate addTarget:self action:@selector(calculateAppraisal) forControlEvents:UIControlEventTouchUpInside];
        
        [btn_calculate setTitle:@"Create Appraisal" forState:UIControlStateNormal];
        
        [scrollView addSubview:btn_calculate];
    }
    if(![self checkMandatory])
    {
        [btn_calculate setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
         
        btn_calculate.userInteractionEnabled=NO;
    }
    self.view = view;
    

    [self loadingView];
    
}
-(BOOL) checkMandatory
{
    BOOL check=NO;
    if([str_titaniumid length]>0)
    {
    if([txt_year.text length]>0)
    {
        if([txt_make.text length] > 0)
        {
            if([txt_model.text length] > 0)
            {
                if([txt_trim.text length] > 0)
                {
                    if([txt_style.text length] > 0)
                    {
                        if([txt_mileage.text length] > 0 && [[numberFormatter numberFromString:[txt_mileage.text stringByTrimmingCharactersInSet:nonNumberSet]] intValue ])
                        {
                            check=YES;
                        }
                    }
                }
            }
        }
    }
    }
    return check;
}
// To load the Scroll View
- (void)viewWillAppear:(BOOL)animated {
   	[super viewWillAppear:animated];
    calculateApprasial = NO;
    saveApprasial = NO;
	if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(keyboardDidShow:) 
                                                     name:UIKeyboardDidShowNotification 
                                                   object:nil];		
    } else {
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(keyboardWillShow:) 
                                                     name:UIKeyboardWillShowNotification 
                                                   object:nil];
    }
   	scrollView.frame = CGRectMake(0, 0, 320, 460);
	scrollView.contentSize = CGSizeMake(320, yOffset+150.0);
	
}


-(void) viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]
	 removeObserver:self];
}

-(void) keyboardWasShown: (NSNotification *)notif {

    return;
}

-(void) keyboardWasHidden: (NSNotification *)notif {

    return;
}

#define VinCodeLength	17

- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:message
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}


-(IBAction)calculateAppraisal
{
    calculateApprasial = YES;
    saveApprasial= NO;
    self.appraisalSearchResultsController.isAddAppraisal=YES;
    

    if(latsetTextField)
    {
        [latsetTextField resignFirstResponder];
        latsetTextField=nil;
        selectedRow=0;
    }

     str_make = txt_make.text;//@"Honda";
     str_model =txt_model.text;// @"Accord";
     str_year = txt_year.text;//@"2000";
     str_vin = txt_vin.text;//@"345343434343";
     str_style = txt_style.text;//@"style";
    str_dealerlotkey = txt_dealerlotkey.text;
    str_mileage =[[numberFormatter numberFromString:[txt_mileage.text stringByTrimmingCharactersInSet:nonNumberSet]] stringValue ];
    str_exteriorcolor = txt_exteriorcolor.text;
    str_interiorcolor =txt_interiorcolor.text;
     str_customer = txt_customer.text;
   str_customerAddress = txt_customerAddress.text;
    str_city= txt_city.text;
    str_state = txt_state.text;
     str_zip = txt_zip.text;
    str_phone=[phoneNumberFormatter strip:txt_phone.text];
    str_mobile = [phoneNumberFormatter strip:txt_mobile.text];
    str_email = txt_email.text;
    str_expectedsaleprice =[[currencyFormatter numberFromString:txt_expectedsaleprice.text] stringValue ];
    str_profitobective =[[currencyFormatter numberFromString:txt_profitobective.text] stringValue ];
    str_datasalesperson = txt_datasalesperson.text;
    str_appraisedvalue =[[currencyFormatter numberFromString:txt_appraisedvalue.text] stringValue ];
   str_notes = txt_notes.text;
     str_recondtioning =[[currencyFormatter numberFromString:txt_recondtioning.text] stringValue ];
    str_status = txt_status.text;
    str_trim = txt_trim.text;
    str_exteriorcolor = txt_exteriorcolor.text;
    str_interiorcolor = txt_interiorcolor.text;
     str_notes = txt_notes.text;
     str_datasalesperson = txt_datasalesperson.text;

    BOOL emailVaild=YES;
    
    if(![str_email isEqualToString:@""] && apprasialStatus == 2)
    {
        emailVaild=[self validateEmailWithString:str_email];
    }
    if(!emailVaild)
    {
        [self alertUser:@"Email-id is Invaild." title:[NSString stringWithFormat: @"Invaild"]];
    }
    else
    {
    if(![str_vin isEqualToString:@""])
    {
        
        if (loadingView == nil) {
            loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
        }
        reqType=21;
    //Call the Apprasial Mobile Services
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:21],@"reqtype", @"Titanium",@"providerType",str_vin,@"vin", self,@"delegate", nil];
    
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
    }
    else
    {
    calculateApprasial =NO;
    NSMutableDictionary *dic;
    reqType=10;
    if(apprasialStatus==1)
    {
        dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                                    [NSNumber numberWithInt:reqType],@"reqtype",
                                    [NSNumber numberWithInt:0],@"appraisalid",
                                    @"Active" ,@"status",
                                    str_vin,@"vin",
                                    [NSNumber numberWithInt:[str_year intValue]],@"year",
                                    str_make,@"make",
                                    str_model,@"model",
                                    str_trim,@"trim",
                                    str_style,@"style",
                                    [NSNumber numberWithInt:[str_mileage intValue]] ,@"mileage",
                                    str_titaniumid,@"titaniumid",
                                    str_exteriorcolor,@"exteriorcolor",
                                    str_interiorcolor,@"interiorcolor",
                                    @"add",@"action",
                                    self,@"delegate",
                                    nil];
        
    }
    else {
            dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                                [NSNumber numberWithInt:reqType],@"reqtype",
                                [NSNumber numberWithInt:0],@"appraisalid",
                                @"Active",@"status",
                                 str_customer,@"customer",
                                 str_customerAddress,@"customeraddress",
                                str_city,@"city",
                                str_state,@"state",
                                str_zip,@"zip",
                                str_phone,@"phone",
                                 str_mobile,@"mobile",
                                 str_email,@"email",
                                str_vin,@"vin",
                                [NSNumber numberWithInt:[str_year intValue]],@"year",
                                str_make,@"make",
                                str_model,@"model",
                                 str_trim,@"trim",
                                str_style,@"style",
                                [NSNumber numberWithInt:[str_mileage intValue]] ,@"mileage",
                                str_titaniumid,@"titaniumid",
                                str_exteriorcolor,@"exteriorcolor",
                                str_interiorcolor,@"interiorcolor",
                                [NSNumber numberWithInt:[str_appraisedvalue intValue]] ,@"appraisedvalue",
                                [NSNumber numberWithInt:[str_expectedsaleprice intValue]],@"expectedsaleprice",
                                str_notes,@"notes",
                                str_profitobective,@"profitobjective",
                                str_recondtioning,@"reconditioning",
                                str_datasalesperson,@"salesperson",
                               [NSNumber numberWithInt:[str_dayssupply intValue]] ,@"dayssupply",
                                [NSNumber numberWithInt:[str_marketaveragemileage intValue]] ,@"marketaveragemileage",
                              [NSNumber numberWithInt:[str_marketaverageprice intValue]] ,@"marketaverageprice",
                               [NSNumber numberWithInt:[str_marketsize intValue]] ,@"marketsize",
                                [NSNumber numberWithInt:[str_pricerank intValue]],@"pricerank",
                                [NSNumber numberWithInt:[str_recommendedprice intValue]] ,@"recommendedprice",
                                @"update",@"action",
                                self,@"delegate",
                                nil];
    }

    if (loadingView == nil) {
        loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
    }
    
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];   
    
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
    
    }
    }
}

/* Save the appraisal*/
-(void) saveAppraisal
{
    saveApprasial = YES;
    calculateApprasial = NO;
    
    if(self.appraisalSearchResultsController.isAddAppraisal)
        self.appraisalSearchResultsController.isAddAppraisal=NO;
    
    if(latsetTextField)
    {
        [latsetTextField resignFirstResponder];
        latsetTextField=nil;
        selectedRow=0;
    }
    str_make = txt_make.text;//@"Honda";
    str_model =txt_model.text;// @"Accord";
    str_year = txt_year.text;//@"2000";
    str_vin = txt_vin.text;//@"345343434343";
    str_style = txt_style.text;//@"style";
    str_dealerlotkey = txt_dealerlotkey.text;
    
    str_mileage =[[numberFormatter numberFromString:[txt_mileage.text stringByTrimmingCharactersInSet:nonNumberSet]] stringValue ];
    str_exteriorcolor = txt_exteriorcolor.text;
    str_interiorcolor =txt_interiorcolor.text;
    str_customer = txt_customer.text;
    str_customerAddress = txt_customerAddress.text;
    str_city= txt_city.text;
    str_state = txt_state.text;
    str_zip = txt_zip.text;
    str_phone=[phoneNumberFormatter strip:txt_phone.text];
    str_mobile = [phoneNumberFormatter strip:txt_mobile.text];
    str_email = txt_email.text;
    str_expectedsaleprice =[[currencyFormatter numberFromString:txt_expectedsaleprice.text] stringValue ];
    str_profitobective =[[currencyFormatter numberFromString:txt_profitobective.text] stringValue ];
    str_datasalesperson = txt_datasalesperson.text;
    str_appraisedvalue =[[currencyFormatter numberFromString:txt_appraisedvalue.text] stringValue ];
    str_notes = txt_notes.text;
    str_recondtioning =[[currencyFormatter numberFromString:txt_recondtioning.text] stringValue ];
    str_status = txt_status.text;
    str_trim = txt_trim.text;
    str_exteriorcolor = txt_exteriorcolor.text;
    str_interiorcolor = txt_interiorcolor.text;
    str_notes = txt_notes.text;
    str_datasalesperson = txt_datasalesperson.text;

    BOOL emailVaild=YES;
    
    if(![str_email isEqualToString:@""])
    {
        emailVaild=[self validateEmailWithString:str_email];
    }
    if(!emailVaild)
    {
        [self alertUser:@"Email-id is Invaild." title:[NSString stringWithFormat: @"Invaild"]];
    }
    else
    {
    if(![str_vin isEqualToString:@""])
    {
        
        if (loadingView == nil) {
            loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
        }
        reqType=21;
        //Call the Apprasial Mobile Services
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", @"Titanium",@"providerType",str_vin,@"vin", self,@"delegate", nil];
        
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
    }
    else
    {
    saveApprasial =NO;
    reqType=10;
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                                [NSNumber numberWithInt:reqType],@"reqtype",
                                str_appraisalid,@"appraisalid",
                                @"Active",@"status",
                                str_customer,@"customer",
                                str_customerAddress,@"customeraddress",
                                str_city,@"city",
                                str_state,@"state",
                                str_zip,@"zip",
                                str_phone,@"phone",
                                str_mobile,@"mobile",
                                str_email,@"email",
                                str_vin,@"vin",
                                [NSNumber numberWithInt:[str_year intValue]],@"year",
                                str_make,@"make",
                                str_model,@"model",
                                str_trim,@"trim",
                                str_style,@"style",
                                [NSNumber numberWithInt:[str_mileage intValue]] ,@"mileage",
                                str_titaniumid,@"titaniumid",
                                str_exteriorcolor,@"exteriorcolor",
                                str_interiorcolor,@"interiorcolor",
                                [NSNumber numberWithInt:[str_appraisedvalue intValue]] ,@"appraisedvalue",
                                [NSNumber numberWithInt:[str_expectedsaleprice intValue]],@"expectedsaleprice",
                                str_notes,@"notes",
                                str_profitobective,@"profitobjective",
                                str_recondtioning,@"reconditioning",
                                str_datasalesperson,@"salesperson",
                                [NSNumber numberWithInt:[str_dayssupply intValue]] ,@"dayssupply",
                                [NSNumber numberWithInt:[str_marketaveragemileage intValue]] ,@"marketaveragemileage",
                                [NSNumber numberWithInt:[str_marketaverageprice intValue]] ,@"marketaverageprice",
                                [NSNumber numberWithInt:[str_marketsize intValue]] ,@"marketsize",
                                [NSNumber numberWithInt:[str_pricerank intValue]],@"pricerank",
                                [NSNumber numberWithInt:[str_recommendedprice intValue]] ,@"recommendedprice",
                                @"update",@"action",
                                self,@"delegate",
                                nil];
    
    if (loadingView == nil) {
        loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
    }
    
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
    }
    }
}
-(void) reappraisalData:(NSDictionary *)appraisalDetails
{

    bReappraisalSelected = TRUE;
    
    /* Customer Data*/
    
    NSString *szTemp = [appraisalDetails objectForKey:@"customername"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_customer = szTemp;

    }
    else {
        str_customer = @"";
    }
    szTemp = [appraisalDetails objectForKey:@"address"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_customerAddress = szTemp;
    }
    else {
        str_customerAddress = @"";
    }
    szTemp = [appraisalDetails objectForKey:@"city"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_city = szTemp;
    }
    else {
        str_city = @"";
    }
    szTemp = [appraisalDetails objectForKey:@"state"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_state = szTemp;
    }
    else {
        str_state = @"";
    }
    szTemp = [appraisalDetails objectForKey:@"zip"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_zip = szTemp;
    }
    else {
        str_zip = @"";
    }
    
    szTemp = [appraisalDetails objectForKey:@"phone"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_phone = szTemp;
    }
    else {
        str_phone = @"";
    }
    szTemp = [appraisalDetails objectForKey:@"mobile"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_mobile = szTemp;
    }
    else {
        str_mobile = @"";
    }
    szTemp = [appraisalDetails objectForKey:@"email"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_email = szTemp;
    }
    else {
        str_email = @"";
    }
    szTemp = [appraisalDetails objectForKey:@"trim"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_trim = szTemp;
    }
    else {
        str_trim = @"";
    }
    
    str_trim_old = [NSString stringWithFormat:@"%@",str_trim];
    
    /*Vehicle data */
    szTemp = [appraisalDetails objectForKey:@"vin"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_vin = szTemp;
    }
    else {
        str_vin = @"";
    }
    /*Type as in Web portal*/
    szTemp = [appraisalDetails objectForKey:@"year"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_year = szTemp;
    }
    else {
        str_year = @"";
    }
    str_year_old = [NSString stringWithFormat:@"%@",str_year];
    
    szTemp = [appraisalDetails objectForKey:@"make" ];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_make = szTemp;
    }
    else {
        str_make = @"";
    }
    
    str_make_old = [NSString stringWithFormat:@"%@",str_make];
    
    szTemp = [appraisalDetails objectForKey:@"model"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"])  {
        str_model = szTemp;
    }
    else {
        str_model = @"";
    }
    
    str_model_old = [NSString stringWithFormat:@"%@",str_model];
    
    szTemp = [appraisalDetails objectForKey:@"style"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_style = szTemp;
    }
    else {
        str_style = @"";
    }
    
    
    str_style_old = [NSString stringWithFormat:@"%@",str_style];
    
    szTemp = [appraisalDetails objectForKey:@"mileage"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_mileage = szTemp;
    }
    else {
        str_mileage = @"";
    }
    
    str_mileage_old = [NSString stringWithFormat:@"%@",str_mileage];
    
    szTemp = [appraisalDetails objectForKey:@"colorexterior"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_exteriorcolor = szTemp;
    }
    else {
        str_exteriorcolor = @"";
    }
    szTemp = [appraisalDetails objectForKey:@"colorinterior"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_interiorcolor = szTemp;
    }
    else {
        str_interiorcolor = @"";
    }
    
    /* Appraisal data*/
    szTemp = [appraisalDetails objectForKey:@"expectedsaleprice"]; 
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_expectedsaleprice= szTemp;
    }
    else {
        str_expectedsaleprice = @"0";
    }
    szTemp = [appraisalDetails objectForKey:@"profitobjective"]; 
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_profitobective = szTemp;
    }
    else {
        str_profitobective = @"0";
    }
    szTemp = [appraisalDetails objectForKey:@"reconditioning"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        
        str_recondtioning =szTemp; 
    }
    else {
        str_recondtioning = @"0";
    }
    szTemp =  [appraisalDetails objectForKey:@"appraisedvalue"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_appraisedvalue = szTemp;
    }
    else {
        str_appraisedvalue = @"0";
    }
    
    szTemp = [appraisalDetails objectForKey:@"profitobjective"]; 
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_profitobective = szTemp;
    }
    else {
        str_profitobective = @"0";
    }
    
    szTemp = [appraisalDetails objectForKey:@"notes"]; 
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_notes = szTemp;
    }
    else {
        str_notes = @"";
    }
    
    szTemp = [appraisalDetails objectForKey:@"salesperson"];
    if ([szTemp length]>0 && ![szTemp isEqualToString:@"n/a"]) {
        str_datasalesperson =szTemp; 
    }
    else {
        str_datasalesperson = @"";
    }
    
    /* Data Providers/ Market Control Analysis*/
    szTemp = [appraisalDetails objectForKey:@"marketsize"]; 
    if ([szTemp length]>0) {
        str_marketsize = szTemp;
    }
    else {
        str_marketsize = @"0";
    }
    
    szTemp = [appraisalDetails objectForKey:@"marketaverageprice"]; 
    if ([szTemp length]>0) {
        str_marketaverageprice = szTemp;
    }
    else {
        str_marketaverageprice = @"0";
    }
    szTemp = [appraisalDetails objectForKey:@"marketaveragemilesage"]; 
    if ([szTemp length]>0) {
        str_marketaveragemileage = szTemp;
    }
    else {
           str_marketaveragemileage = @"0";
    }
    szTemp = [appraisalDetails objectForKey:@"recommendedprice"]; 
    if ([szTemp length]>0) {
        str_recommendedprice = szTemp;
    }
    else {
       str_recommendedprice = @"0";
    }
    szTemp = [appraisalDetails objectForKey:@"dayssupply"]; 
    if ([szTemp length]>0) {
        str_dayssupply = szTemp;
    }
    else {
        str_dayssupply = @"0";
    }
    szTemp = [appraisalDetails objectForKey:@"pricerank"]; 
    if ([szTemp length]>0) {
        str_pricerank = szTemp;
    }
    else {
        str_pricerank = @"0";
    }
    
    szTemp = [appraisalDetails objectForKey:@"appraisalid"]; 
    if ([szTemp length]>0) {
        str_appraisalid = szTemp;
    }
    else {
        str_appraisalid = @"0";
    }

    
    szTemp = [appraisalDetails objectForKey:@"status"];
    if ([szTemp length]>0) {
        str_status = szTemp;
    }
    else {
        str_status = @"";
    }
    szTemp = [appraisalDetails objectForKey:@"titianiumid"];
    if ([szTemp length]>0) {
        str_titaniumid = szTemp;
    }
    else {
        str_titaniumid = @"";
    }

     txt_make.text= str_make;
   txt_model.text= str_model ;// @"Accord";
     txt_year.text = str_year ;//@"2000";
   txt_vin.text =str_vin ;//@"345343434343";
     txt_style.text=str_style;//@"style";
     txt_dealerlotkey.text=str_dealerlotkey;
    
    txt_mileage.text=str_mileage;
    txt_exteriorcolor.text=str_exteriorcolor;
    txt_interiorcolor.text=str_interiorcolor;
     txt_customer.text=str_customer;
    txt_customerAddress.text=str_customerAddress;
    txt_city.text=str_city;
    txt_state.text=str_state;
     txt_zip.text=str_zip;
    txt_interiorcolor.text=str_phone;
    txt_mobile.text=[phoneNumberFormatter format:str_mobile withLocale:@"us"];;
    txt_email.text=str_email;
    txt_phone.text=[phoneNumberFormatter format:str_phone withLocale:@"us"];
    txt_expectedsaleprice.text=str_expectedsaleprice;
    txt_profitobective.text=str_profitobective;
     txt_datasalesperson.text=str_datasalesperson;
    txt_appraisedvalue.text=str_appraisedvalue;
     txt_notes.text=str_notes;
    txt_recondtioning.text =str_recondtioning;
     txt_status.text=str_status;
     txt_trim.text = str_trim;
    txt_exteriorcolor.text=str_exteriorcolor;
    txt_interiorcolor.text=str_interiorcolor;
     txt_notes.text=str_notes;
    txt_datasalesperson.text=str_datasalesperson;
    
}

-(void) handleResponseForQuery:(NSMutableDictionary *)response
{
    
    if([[response objectForKey:@"response"] objectForKey:@"years"])
    {
        reqType=0;
        years = [[response objectForKey:@"response"] objectForKey:@"years"];
        if (loadingView != nil)
        {
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:13],@"reqtype", @"Titanium",@"providerType",txt_year.text,@"year", self,@"delegate", nil];
        
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
        }
        else
            [self stopLoadingView];
        
    }
    else if([[response objectForKey:@"response"] objectForKey:@"makes"])
    {
        reqType=0;
        makes = [[response objectForKey:@"response"] objectForKey:@"makes"];
        if (loadingView != nil && ![txt_make.text isEqualToString:@""] )
        {
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:14],@"reqtype", @"Titanium",@"providerType",txt_year.text,@"year",txt_make.text,@"make", self,@"delegate", nil];
        
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
      }
        else
        {
            [self stopLoadingView];
        }
    }
    else if([[response objectForKey:@"response"] objectForKey:@"models"])
    {
        reqType=0;
        models = [[response objectForKey:@"response"] objectForKey:@"models"];
        if (loadingView != nil && ![txt_model.text isEqualToString:@""] )
        {
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:15],@"reqtype", @"Titanium",@"providerType",txt_year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", self,@"delegate", nil];
            
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            
            [ws initialize:dic];
            [ws callWSWithQuery:dic];
        }
        else
        {
            [self stopLoadingView];
        }
    }
    else if([[response objectForKey:@"response"] objectForKey:@"trims"])
    {
        reqType=0;
        trims = [[response objectForKey:@"response"] objectForKey:@"trims"];
        if (loadingView != nil && ![txt_trim.text isEqualToString:@""] )
        {
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:16],@"reqtype", @"Titanium",@"providerType",txt_year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", txt_trim.text,@"trim",self,@"delegate", nil];
        
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
       }
        else
        {
            [self stopLoadingView];
        }

    }
    else if([[response objectForKey:@"response"] objectForKey:@"styles"])
    {
        reqType=0;
        styles = [[response objectForKey:@"response"] objectForKey:@"styles"];
        if (loadingView != nil && ![txt_style.text isEqualToString:@""])
        {
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:24],@"reqtype", @"Titanium",@"providerType",txt_year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", txt_trim.text,@"trim",txt_style.text,@"style",self,@"delegate", nil];
            
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            
            [ws initialize:dic];
            [ws callWSWithQuery:dic];
        }
        else
        {
            [self stopLoadingView];
        }
    }
    else if([[response objectForKey:@"response"] objectForKey:@"providerCodes"])
    {
        titaniumIds = [[response objectForKey:@"response"] objectForKey:@"providerCodes"];
        if([titaniumIds count]>0)
        {
            str_titaniumid=[titaniumIds objectAtIndex:0];
            if([self checkMandatory])
            {
                [btn_calculate setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                [btn_calculate setUserInteractionEnabled:YES];
            }
            else 
            {
                [btn_calculate setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
                [btn_calculate setUserInteractionEnabled:NO];
            }
        }
        [self stopLoadingView];
    }

    else if([[response objectForKey:@"response"] objectForKey:@"dataproviders"])
    {
       reqType=0;
        providerSummary = [[response objectForKey:@"response"] objectForKey:@"dataproviders"];
        if([providerSummary count]>0)
        {
            providerSummaryDetails=[providerSummary objectAtIndex:0];
            if(calculateApprasial || saveApprasial)
            {
                if((![txt_year.text isEqualToString:[providerSummaryDetails objectForKey:@"year"]] && ![[providerSummaryDetails objectForKey:@"year"] isEqualToString:@""])  || (![txt_make.text isEqualToString:[providerSummaryDetails objectForKey:@"make"]] && ![[providerSummaryDetails objectForKey:@"make"] isEqualToString:@""]) || (![txt_model.text isEqualToString:[providerSummaryDetails objectForKey:@"model"]] && ![[providerSummaryDetails objectForKey:@"model"] isEqualToString:@""]) || (![txt_trim.text isEqualToString:[providerSummaryDetails objectForKey:@"trim"]] && ![[providerSummaryDetails objectForKey:@"trim"] isEqualToString:@""]) || (![txt_style.text isEqualToString:[providerSummaryDetails objectForKey:@"style"]] && ![[providerSummaryDetails objectForKey:@"style"] isEqualToString:@""]) )
                {
                    
                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Confirm"                                                   message:@"VIN and Type are not matching. Do you want to continue?"                                                                  delegate:self                                                          cancelButtonTitle:@"No"                                                          otherButtonTitles:@"Yes",nil];
                    [alertView show];
                }
                else
                {
                    NSMutableDictionary *dic;
                    reqType=10;
                    if(apprasialStatus==1)
                    {
                        dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                               [NSNumber numberWithInt:reqType],@"reqtype",
                               [NSNumber numberWithInt:0],@"appraisalid",
                               @"Active" ,@"status",
                               str_vin,@"vin",
                               [NSNumber numberWithInt:[str_year intValue]],@"year",
                               str_make,@"make",
                               str_model,@"model",
                               str_trim,@"trim",
                               str_style,@"style",
                               [NSNumber numberWithInt:[str_mileage intValue]] ,@"mileage",
                               str_titaniumid,@"titaniumid",
                               str_exteriorcolor,@"exteriorcolor",
                               str_interiorcolor,@"interiorcolor",
                               @"add",@"action",
                               self,@"delegate",
                               nil];
                        
                    }
                    else {
                        if(calculateApprasial)
                        {
                        dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                               [NSNumber numberWithInt:reqType],@"reqtype",
                               [NSNumber numberWithInt:0],@"appraisalid",
                               @"Active",@"status",
                               str_customer,@"customer",
                               str_customerAddress,@"customeraddress",
                               str_city,@"city",
                               str_state,@"state",
                               str_zip,@"zip",
                               str_phone,@"phone",
                               str_mobile,@"mobile",
                               str_email,@"email",
                               str_vin,@"vin",
                               [NSNumber numberWithInt:[str_year intValue]],@"year",
                               str_make,@"make",
                               str_model,@"model",
                               str_trim,@"trim",
                               str_style,@"style",
                               [NSNumber numberWithInt:[str_mileage intValue]] ,@"mileage",
                               str_titaniumid,@"titaniumid",
                               str_exteriorcolor,@"exteriorcolor",
                               str_interiorcolor,@"interiorcolor",
                               [NSNumber numberWithInt:[str_appraisedvalue intValue]] ,@"appraisedvalue",
                               [NSNumber numberWithInt:[str_expectedsaleprice intValue]],@"expectedsaleprice",
                               str_notes,@"notes",
                               str_profitobective,@"profitobjective",
                               str_recondtioning,@"reconditioning",
                               str_datasalesperson,@"salesperson",
                               [NSNumber numberWithInt:[str_dayssupply intValue]] ,@"dayssupply",
                               [NSNumber numberWithInt:[str_marketaveragemileage intValue]] ,@"marketaveragemileage",
                               [NSNumber numberWithInt:[str_marketaverageprice intValue]] ,@"marketaverageprice",
                               [NSNumber numberWithInt:[str_marketsize intValue]] ,@"marketsize",
                               [NSNumber numberWithInt:[str_pricerank intValue]],@"pricerank",
                               [NSNumber numberWithInt:[str_recommendedprice intValue]] ,@"recommendedprice",
                               @"update",@"action",
                               self,@"delegate",
                               nil];
                        }
                        if(saveApprasial)
                        {
                            dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                                   [NSNumber numberWithInt:reqType],@"reqtype",
                                   str_appraisalid,@"appraisalid",
                                   @"Active",@"status",
                                   str_customer,@"customer",
                                   str_customerAddress,@"customeraddress",
                                   str_city,@"city",
                                   str_state,@"state",
                                   str_zip,@"zip",
                                   str_phone,@"phone",
                                   str_mobile,@"mobile",
                                   str_email,@"email",
                                   str_vin,@"vin",
                                   [NSNumber numberWithInt:[str_year intValue]],@"year",
                                   str_make,@"make",
                                   str_model,@"model",
                                   str_trim,@"trim",
                                   str_style,@"style",
                                   [NSNumber numberWithInt:[str_mileage intValue]] ,@"mileage",
                                   str_titaniumid,@"titaniumid",
                                   str_exteriorcolor,@"exteriorcolor",
                                   str_interiorcolor,@"interiorcolor",
                                   [NSNumber numberWithInt:[str_appraisedvalue intValue]] ,@"appraisedvalue",
                                   [NSNumber numberWithInt:[str_expectedsaleprice intValue]],@"expectedsaleprice",
                                   str_notes,@"notes",
                                   str_profitobective,@"profitobjective",
                                   str_recondtioning,@"reconditioning",
                                   str_datasalesperson,@"salesperson",
                                   [NSNumber numberWithInt:[str_dayssupply intValue]] ,@"dayssupply",
                                   [NSNumber numberWithInt:[str_marketaveragemileage intValue]] ,@"marketaveragemileage",
                                   [NSNumber numberWithInt:[str_marketaverageprice intValue]] ,@"marketaverageprice",
                                   [NSNumber numberWithInt:[str_marketsize intValue]] ,@"marketsize",
                                   [NSNumber numberWithInt:[str_pricerank intValue]],@"pricerank",
                                   [NSNumber numberWithInt:[str_recommendedprice intValue]] ,@"recommendedprice",
                                   @"update",@"action",
                                   self,@"delegate",
                                   nil];
                        }
                    }
                    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
                    
                    [ws initialize:dic];
                    [ws callWSWithQuery:dic];
                    
                }
                
            }
            else
            {
                txt_year.text = [providerSummaryDetails objectForKey:@"year"];
                txt_make.text =   [providerSummaryDetails objectForKey:@"make"];
                txt_model.text =   [providerSummaryDetails objectForKey:@"model"];
                txt_style.text =  [providerSummaryDetails objectForKey:@"style"];
                txt_trim.text =  [providerSummaryDetails objectForKey:@"trim"];
            }
        }
        if(!calculateApprasial && !saveApprasial)
        {
            reqType=13;
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", @"Titanium",@"providerType",txt_year.text,@"year", self,@"delegate", nil];
        
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
        }
    }
    else
    {
    str_appraisalid = [response objectForKey:@"responseString"];
        self.appraisalSearchResultsController.refreshDataOn=YES;
    if(apprasialStatus==1 || self.appraisalSearchResultsController.isAddAppraisal)
    {
    [self alertUser:@"" title:[NSString stringWithFormat: @"Appraisal added successfully."]];
    }
    else
       [self alertUser:@"" title:[NSString stringWithFormat: @"Appraisal updated successfully."]]; 
        
    }
}
#pragma mark alertview delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if([alertView.title isEqualToString:@"Invaild"])
    {
        [alertView dismissWithClickedButtonIndex:buttonIndex animated:YES];
    }
    else
    {
    if([alertView.title isEqualToString:@"Confirm"])
    {
        if(buttonIndex==1)
        {
            NSMutableDictionary *dic;
            reqType=10;
            if(apprasialStatus==1)
            {
                dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                       [NSNumber numberWithInt:reqType],@"reqtype",
                       [NSNumber numberWithInt:0],@"appraisalid",
                       @"Active" ,@"status",
                       str_vin,@"vin",
                       [NSNumber numberWithInt:[str_year intValue]],@"year",
                       str_make,@"make",
                       str_model,@"model",
                       str_trim,@"trim",
                       str_style,@"style",
                       [NSNumber numberWithInt:[str_mileage intValue]] ,@"mileage",
                       str_titaniumid,@"titaniumid",
                       str_exteriorcolor,@"exteriorcolor",
                       str_interiorcolor,@"interiorcolor",
                       @"add",@"action",
                       self,@"delegate",
                       nil];
                
            }
            else {
                if(calculateApprasial)
                {
                dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                       [NSNumber numberWithInt:reqType],@"reqtype",
                       [NSNumber numberWithInt:0],@"appraisalid",
                       @"Active",@"status",
                       str_customer,@"customer",
                       str_customerAddress,@"customeraddress",
                       str_city,@"city",
                       str_state,@"state",
                       str_zip,@"zip",
                       str_phone,@"phone",
                       str_mobile,@"mobile",
                       str_email,@"email",
                       str_vin,@"vin",
                       [NSNumber numberWithInt:[str_year intValue]],@"year",
                       str_make,@"make",
                       str_model,@"model",
                       str_trim,@"trim",
                       str_style,@"style",
                       [NSNumber numberWithInt:[str_mileage intValue]] ,@"mileage",
                       str_titaniumid,@"titaniumid",
                       str_exteriorcolor,@"exteriorcolor",
                       str_interiorcolor,@"interiorcolor",
                       [NSNumber numberWithInt:[str_appraisedvalue intValue]] ,@"appraisedvalue",
                       [NSNumber numberWithInt:[str_expectedsaleprice intValue]],@"expectedsaleprice",
                       str_notes,@"notes",
                       str_profitobective,@"profitobjective",
                       str_recondtioning,@"reconditioning",
                       str_datasalesperson,@"salesperson",
                       [NSNumber numberWithInt:[str_dayssupply intValue]] ,@"dayssupply",
                       [NSNumber numberWithInt:[str_marketaveragemileage intValue]] ,@"marketaveragemileage",
                       [NSNumber numberWithInt:[str_marketaverageprice intValue]] ,@"marketaverageprice",
                       [NSNumber numberWithInt:[str_marketsize intValue]] ,@"marketsize",
                       [NSNumber numberWithInt:[str_pricerank intValue]],@"pricerank",
                       [NSNumber numberWithInt:[str_recommendedprice intValue]] ,@"recommendedprice",
                       @"update",@"action",
                       self,@"delegate",
                       nil];
                }
                if(saveApprasial)
                {
                    dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                           [NSNumber numberWithInt:reqType],@"reqtype",
                           str_appraisalid,@"appraisalid",
                           @"Active",@"status",
                           str_customer,@"customer",
                           str_customerAddress,@"customeraddress",
                           str_city,@"city",
                           str_state,@"state",
                           str_zip,@"zip",
                           str_phone,@"phone",
                           str_mobile,@"mobile",
                           str_email,@"email",
                           str_vin,@"vin",
                           [NSNumber numberWithInt:[str_year intValue]],@"year",
                           str_make,@"make",
                           str_model,@"model",
                           str_trim,@"trim",
                           str_style,@"style",
                           [NSNumber numberWithInt:[str_mileage intValue]] ,@"mileage",
                           str_titaniumid,@"titaniumid",
                           str_exteriorcolor,@"exteriorcolor",
                           str_interiorcolor,@"interiorcolor",
                           [NSNumber numberWithInt:[str_appraisedvalue intValue]] ,@"appraisedvalue",
                           [NSNumber numberWithInt:[str_expectedsaleprice intValue]],@"expectedsaleprice",
                           str_notes,@"notes",
                           str_profitobective,@"profitobjective",
                           str_recondtioning,@"reconditioning",
                           str_datasalesperson,@"salesperson",
                           [NSNumber numberWithInt:[str_dayssupply intValue]] ,@"dayssupply",
                           [NSNumber numberWithInt:[str_marketaveragemileage intValue]] ,@"marketaveragemileage",
                           [NSNumber numberWithInt:[str_marketaverageprice intValue]] ,@"marketaverageprice",
                           [NSNumber numberWithInt:[str_marketsize intValue]] ,@"marketsize",
                           [NSNumber numberWithInt:[str_pricerank intValue]],@"pricerank",
                           [NSNumber numberWithInt:[str_recommendedprice intValue]] ,@"recommendedprice",
                           @"update",@"action",
                           self,@"delegate",
                           nil];
                }
            }
            IVMMobileServices *ws = [[IVMMobileServices alloc] init];
            [ws initialize:dic];
            [ws callWSWithQuery:dic];
 
        }
        else
        {
            [self stopLoadingView];
            [alertView dismissWithClickedButtonIndex:buttonIndex animated:YES];
        }
        
    }
    else if(reqType == 10 && ![alertView.title isEqualToString:@"Error"])
    {
        [self stopLoadingView];
    AppraisalDetailsController *detailsController = [[AppraisalDetailsController alloc]init];
    detailsController.appraisalSearchResultsController=self.appraisalSearchResultsController;
            detailsController.isAppraisal=self.appraisalSearchResultsController.refreshDataOn;
        detailsController.isAddAppraisal=self.appraisalSearchResultsController.isAddAppraisal;
    if(self.appraisalSearchResultsController.isAddAppraisal || (apprasialStatus == 2 && (![str_mileage isEqualToString:str_mileage_old] || ![str_year isEqualToString:str_year_old] || ![str_make isEqualToString:str_make_old] || ![str_model isEqualToString:str_model_old] || ![str_trim isEqualToString:str_trim_old] || ![str_style isEqualToString:str_style_old])))
    {
        detailsController.reqType=25;
        NSString *str_marketradius = @"100";
        NSString *str_filtertype = @"None";
        NSString *str_filtervalue = @"";
        
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:detailsController.reqType],@"reqtype",str_appraisalid,@"appraisalid",str_marketradius,@"marketradius", str_filtertype,@"filtertype",str_filtervalue,@"filtervalue",detailsController,@"delegate", nil];
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
        
    }
    else
    {
        detailsController.reqType=8;
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:detailsController.reqType],@"reqtype", str_appraisalid,@"appraisalid",detailsController,@"delegate", nil];
        IVMMobileServices *ws1 = [[IVMMobileServices alloc] init];
        [ws1 initialize:dic];
        [ws1 callWSWithQuery:dic];
        
    }
    [[self navigationController] pushViewController:detailsController animated:YES];
    }
    else if(reqType==12)
    {
        [self stopLoadingView];
        [[self navigationController] popViewControllerAnimated:YES];
    }
    else {
        if(reqType==10)
            reqType=0;
        [self stopLoadingView];
    }
    }

}
-(void) loadingView
{
    if (loadingView == nil) {
        loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
    }
}
-(void) stopLoadingView
{
    if (loadingView != nil)
    {
        
        [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
        loadingView = nil;
    }
}

- (IBAction) decodeVinCode
{
    calculateApprasial = NO;
    saveApprasial =NO;
	str_vin = txt_vin.text;

	//Int Checking the VIN Code validation
    if([str_vin length] == 0)
    {
		[self alertUser:@"Please Enter VIN Code!" title:@"Enter VIN Code"];
		return; /*rsnerella*/        
    }
    else if([str_vin length] != VinCodeLength)
	{
		[self alertUser:@"The VIN Code Is Invalid!" title:@"Invalid VIN Code"];
		return; /*rsnerella*/
	}
    if(latsetTextField!=nil)
    {
        [latsetTextField resignFirstResponder];
        latsetTextField=nil;
        selectedRow=0;
    }
	//Call the Apprasial Mobile Services
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:21],@"reqtype", @"Titanium",@"providerType",str_vin,@"vin", self,@"delegate", nil];
    
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
	     //Turn on loading view ...
     if (loadingView == nil) {
     loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0] loadingText:@"Loading ..."];
     }
      vinCode = txt_vin.text;
      str_titaniumid=@"";
    
 #if 0        
 #endif	
}
#pragma mark UITextField delegate methods

- (BOOL)textFieldShouldClear:(UITextField *)textField {
	return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    if (textField == txt_status || textField == txt_year || textField == txt_make || textField == txt_model || textField == txt_trim || textField == txt_style || textField == txt_state || textField == txt_exteriorcolor || textField == txt_interiorcolor) {
        [self showPicker:textField];
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
     
        if ((latsetTextField != nil) && (textField.keyboardType == UIKeyboardTypeNumberPad)) {
        // Add the Done button to keyboard
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
            if(doneButton)
            {
                [doneButton removeFromSuperview];
                doneButton = nil;
            }
            [self addButtonToKeyboard];
        }
    }
    else {
        [doneButton removeFromSuperview];
        
        doneButton = nil;
    }
    latsetTextField = textField;
    
    CGRect textFieldRect = [scrollView convertRect:textField.bounds fromView:textField];
    CGRect viewRect = [scrollView convertRect:scrollView.bounds fromView:scrollView];
	
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
	midline - viewRect.origin.y
	- MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
	(MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
	* viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
	
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
	
    UIInterfaceOrientation orientation =
	[[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationPortrait ||
        orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    }
    else
    {
        animatedDistance = floor(LANDSCAPE_KEYBOARD_HEIGHT * heightFraction);
    }
	
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y -= animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [scrollView setFrame:viewFrame];
    
    [UIView commitAnimations];
   
}

-(void) textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y += animatedDistance;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    
    [scrollView setFrame:viewFrame];
    
    [UIView commitAnimations];
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [latsetTextField resignFirstResponder];
    latsetTextField=nil;
    selectedRow=0;
	return YES;
}

- (void)addButtonToKeyboard {
	// create custom button
	doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
	doneButton.frame = CGRectMake(0, 163, 106, 53);
	doneButton.adjustsImageWhenHighlighted = NO;
	if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.0) {
		[doneButton setImage:[UIImage imageNamed:@"DoneUp3.png"] forState:UIControlStateNormal];
		[doneButton setImage:[UIImage imageNamed:@"DoneDown3.png"] forState:UIControlStateHighlighted];
	} else {        
		[doneButton setImage:[UIImage imageNamed:@"DoneUp.png"] forState:UIControlStateNormal];
		[doneButton setImage:[UIImage imageNamed:@"DoneDown.png"] forState:UIControlStateHighlighted];
	}
	[doneButton addTarget:self action:@selector(doneButton:) forControlEvents:UIControlEventTouchUpInside];
	
    // locate keyboard view
	UIWindow* tempWindow = [[[UIApplication sharedApplication] windows] objectAtIndex:1];
	UIView* keyboard;
	for(int i=0; i<[tempWindow.subviews count]; i++) {
		keyboard = [tempWindow.subviews objectAtIndex:i];
		// keyboard found, add the button
		if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
			if([[keyboard description] hasPrefix:@"<UIPeripheralHost"] == YES)
				[keyboard addSubview:doneButton];
		} else {
			if([[keyboard description] hasPrefix:@"<UIKeyboard"] == YES)
				[keyboard addSubview:doneButton];
		}
	}
    
}
- (void)keyboardWillShow:(NSNotification *)note {
	// if clause is just an additional precaution, you could also dismiss it
    if (((UITextField *)(latsetTextField)).keyboardType == UIKeyboardTypeNumberPad) {
        if ([[[UIDevice currentDevice] systemVersion] floatValue] < 3.2) {
            if(doneButton)
            {
                [doneButton removeFromSuperview];
                doneButton = nil;
            }
            [self addButtonToKeyboard];
        }
    }
}

- (void)keyboardDidShow:(NSNotification *)note {
    
    if(doneButton)
    {
        [doneButton removeFromSuperview];
        doneButton = nil;
    }
	// if clause is just an additional precaution, you could also dismiss it
	if (((UITextField *)(latsetTextField)).keyboardType == UIKeyboardTypeNumberPad) {
        // Add the Done button in keyboard
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
            
            [self addButtonToKeyboard];
        }
    }
    
}
- (void)doneButton:(id)sender {
    if(doneButton)
    {
        [doneButton removeFromSuperview];
        doneButton = nil;
    }
    [latsetTextField resignFirstResponder];
    latsetTextField=nil;
    selectedRow=0;
}
- (void)pickerDone:(id)sender{
	    
    if((UITextField*)latsetTextField == txt_status)
    {
        if(selectedRow > 0)
            [latsetTextField  setText:[oneDataSource objectAtIndex:selectedRow]] ;
        else
            [latsetTextField setText:@""];
        
    }
    else
        if((UITextField*)latsetTextField == txt_year)
        {
            if(selectedRow > 0)
            {
                [latsetTextField  setText:[oneDataSource objectAtIndex:selectedRow]] ;
                [self loadingView];
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:13],@"reqtype", @"Titanium",@"providerType",txt_year.text,@"year", self,@"delegate", nil];
                
                IVMMobileServices *ws = [[IVMMobileServices alloc] init];
                [ws initialize:dic];
                [ws callWSWithQuery:dic];
            }
            else
                [latsetTextField setText:@""];
            txt_make.text=@"";
            txt_model.text=@"";
            txt_trim.text=@"";
            txt_style.text=@"";
            str_titaniumid=@"";
            [makes removeAllObjects];
            [models removeAllObjects];
            [trims removeAllObjects];
            [styles removeAllObjects];
        }
        else if((UITextField*)latsetTextField == txt_make)
        {
            if(selectedRow > 0)
            {
                [latsetTextField  setText:[oneDataSource objectAtIndex:selectedRow]] ;
                [self loadingView];
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:14],@"reqtype", @"Titanium",@"providerType",txt_year.text,@"year",txt_make.text,@"make", self,@"delegate", nil];
                
                IVMMobileServices *ws = [[IVMMobileServices alloc] init];
                
                [ws initialize:dic];
                [ws callWSWithQuery:dic];
            }
            else
                [latsetTextField setText:@""];
            txt_model.text=@"";
            txt_trim.text=@"";
            txt_style.text=@"";
            str_titaniumid=@"";
            [models removeAllObjects];
            [trims removeAllObjects];
            [styles removeAllObjects];
            
        }
        else if((UITextField*)latsetTextField == txt_model)
        {
            if(selectedRow > 0)
            {
                [latsetTextField  setText:[oneDataSource objectAtIndex:selectedRow]] ;
                [self loadingView];
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:15],@"reqtype", @"Titanium",@"providerType",txt_year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", self,@"delegate", nil];
                
                IVMMobileServices *ws = [[IVMMobileServices alloc] init];
                [ws initialize:dic];
                [ws callWSWithQuery:dic];
            }
            else
                [latsetTextField setText:@""];
            txt_trim.text=@"";
            txt_style.text=@"";
            str_titaniumid=@"";
            [trims removeAllObjects];
            [styles removeAllObjects];
        }
        else if((UITextField*)latsetTextField == txt_trim)
        {
            if(selectedRow > 0)
            {
                [latsetTextField  setText:[oneDataSource objectAtIndex:selectedRow]] ;
                [self loadingView];
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:16],@"reqtype", @"Titanium",@"providerType",txt_year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", txt_trim.text,@"trim",self,@"delegate", nil];
                
                IVMMobileServices *ws = [[IVMMobileServices alloc] init];
                [ws initialize:dic];
                [ws callWSWithQuery:dic];
            }
            else
                [latsetTextField setText:@""];
            txt_style.text=@"";
            str_titaniumid=@"";
            [styles removeAllObjects];
        }
        else if((UITextField*)latsetTextField == txt_style)
        {
            if(selectedRow > 0)
            {
                [latsetTextField  setText:[oneDataSource objectAtIndex:selectedRow]] ;
                [self loadingView];
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:24],@"reqtype", @"Titanium",@"providerType",txt_year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", txt_trim.text,@"trim",txt_style.text,@"style",self,@"delegate", nil];
                
                IVMMobileServices *ws = [[IVMMobileServices alloc] init];
                [ws initialize:dic];
                [ws callWSWithQuery:dic];
            }
            else
            {
                [latsetTextField setText:@""];
                str_titaniumid=@"";
            }
            
        }
        else if((UITextField*)latsetTextField == txt_state)
        {
            if(selectedRow > 0)
                [latsetTextField  setText:[stateCodes objectAtIndex:selectedRow-1]] ;
            else
                [latsetTextField setText:@""];
            //If the user selected the state as "District Of Columbia", the city should be "Washington".
            if ([txt_state.text isEqualToString:@"DC"]) {
                txt_city.text = @"Washington";
            }
        }
    
        else {
            if(selectedRow > 0)
                [latsetTextField  setText:[oneDataSource objectAtIndex:selectedRow]] ;
            else
                [latsetTextField setText:@""];
            
        }
    if([self checkMandatory])
    {
        [btn_calculate setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btn_calculate setUserInteractionEnabled:YES];
    }
    else 
    {
        [btn_calculate setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [btn_calculate setUserInteractionEnabled:NO];
    }
    [latsetTextField resignFirstResponder];
    latsetTextField = nil;
    selectedRow=0;
}
- (void)getValue:(id)sender {
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
	BOOL result = NO; //default to reject
    
    if (textField == txt_year || textField == txt_make || textField == txt_model || textField == txt_trim || textField == txt_style || textField == txt_state || textField == txt_exteriorcolor || textField == txt_interiorcolor) {
        NSString* newText = [textField.text stringByReplacingCharactersInRange:range withString:string];
        if(textField == txt_year)
        {
            if([years containsObject:newText])
            {
                result = YES;
            }
        }
        else if(textField == txt_make)
        {
            if([makes containsObject:newText])
            {
                result = YES;
            }
        }
        else if(textField == txt_model)
        {
            if([models containsObject:newText])
            {
                result = YES;
            }
        }
        else if(textField == txt_trim)
        {
            if([trims containsObject:newText])
            {
                result = YES;
            }
        }
        else if(textField == txt_style)
        {
            if([styles containsObject:newText])
            {
                result = YES;
            }
        }
        else if(textField == txt_state)
        {
            if([stateCodes containsObject:newText])
            {
                result = YES;
            }
        }
        else if(textField == txt_exteriorcolor || textField == txt_interiorcolor)
        {
            if([exteriorColors containsObject:newText])
            {
                result = YES;
            }
        }
            
    }
    else
    {
     //Handle the VIN Code text field without using formater
     if (textField == txt_vin) {
     if([string length] == 0){ //backspace
        return YES;
     }else{
              if([[string componentsSeparatedByCharactersInSet:nonVINCodeCharactersSet] componentsJoinedByString: @""].length == string.length){
                  NSString* newText = [txt_vin.text stringByReplacingCharactersInRange:range withString:string];
                  if (newText.length<=VIN_MAX_LENGTH )
                      return YES;
              }          
     }
     } 
    else if (textField.keyboardType == UIKeyboardTypeNumberPad ) {
        if(textField == txt_expectedsaleprice || textField == txt_recondtioning || textField == txt_profitobective | textField == txt_appraisedvalue)
        {
        if([string length] == 0){ //backspace
            result = YES;
        }
        else{
            if([[string componentsSeparatedByCharactersInSet:nonNumberSet] componentsJoinedByString: @""].length == string.length){
                result = YES;
            }
        }

        if(result){
            //grab a mutable copy of what's currently in the UITextField
            NSMutableString* mstring = [[textField text] mutableCopy];
            if([mstring length] == 0){
                //special case...nothing in the field yet, so set a currency symbol first
                [mstring appendString:[[NSLocale currentLocale] objectForKey:NSLocaleCurrencySymbol]];
                //now append the replacement string
                [mstring appendString:string];
                }
            else{
                //adding a char or deleting?
                if([string length] > 0){
                    [mstring insertString:string atIndex:range.location];
                    }
                else {
                    //delete case - the length of replacement string is zero for a delete
                    [mstring deleteCharactersInRange:range];
                    if([mstring length] == 1)
                    {
                        //now append the replacement string
                        [mstring appendString:@"0"];
                    }
                    }
                }
            
            //to get the grouping separators properly placed
            //first convert the string into a number. The function
            //will ignore any grouping symbols already present -- NOT in iOS4!
            //fix added below - remove locale specific currency separators first
            NSString* localeSeparator = [[NSLocale currentLocale]objectForKey:NSLocaleGroupingSeparator];
            NSNumber* number = [currencyFormatter numberFromString:[mstring stringByReplacingOccurrencesOfString:localeSeparator withString:@""]];
            //now format the number back to the proper currency string
            //and get the grouping separators added in and put it in the UITextField
            if([[number stringValue] length] <= PRICE_MAX_LENGTH)
              [textField setText:[currencyFormatter stringFromNumber:number]];
            }
        //always return no since we are manually changing the text field
        result= NO;
        }
        else if(textField == txt_zip)
        {
            if([string length] == 0){ //backspace
                result = YES;
            }
            else{
                if([[string componentsSeparatedByCharactersInSet:nonNumberSet] componentsJoinedByString: @""].length == string.length){
                    NSString* newText = [textField.text stringByReplacingCharactersInRange:range withString:string];
                    if(textField == txt_zip && newText.length<=ZIP_MAX_LENGTH)
                    {
                        result = YES;
                    }
                    else
                        result = NO;
                }
            }
            
        }
        else if(textField == txt_phone || textField == txt_mobile)
        {
            if([string length] == 0){ //backspace
                result = YES;
            }
            else{
                if([[string componentsSeparatedByCharactersInSet:nonNumberSet] componentsJoinedByString: @""].length == string.length){
                   
                    
                    NSString* newText = [textField.text stringByReplacingCharactersInRange:range withString:string];
                    if(textField == txt_phone && newText.length<=PHONE_MAX_LENGTH)
                    {
                        [textField setText:[phoneNumberFormatter format:newText withLocale:@"us"]];
                    }
                    else if(textField == txt_mobile && newText.length<=MOBILE_MAX_LENGTH)
                    {
                        [textField setText:[phoneNumberFormatter format:newText withLocale:@"us"]];
                    }
                }
            }
            
        } else  if(textField == txt_mileage)
        {
            if([string length] == 0){ //backspace
                result = YES;
            }
            else{
                if([[string componentsSeparatedByCharactersInSet:nonNumberSet] componentsJoinedByString: @""].length == string.length){
                    result = YES;
                }
            }
            
            if(result){
                //grab a mutable copy of what's currently in the UITextField
                NSMutableString* mstring = [[textField text] mutableCopy];
                //adding a char or deleting?
                if([string length] > 0){
                    if([mstring length] >0)
                    {
                        NSString* localeSeparator = [[NSLocale currentLocale]objectForKey:NSLocaleGroupingSeparator];
                        mstring=[[mstring stringByReplacingOccurrencesOfString:localeSeparator withString:@""] mutableCopy];  
                      mstring=[[mstring substringToIndex:mstring.length-3] mutableCopy];
                    [mstring insertString:string atIndex:mstring.length];
                    }
                    else
                        [mstring insertString:string atIndex:range.location];
                }
                else {
                    //delete case - the length of replacement string is zero for a delete
                    if([mstring length] >0)
                    {
                        NSString* localeSeparator = [[NSLocale currentLocale]objectForKey:NSLocaleGroupingSeparator];
                        mstring=[[mstring stringByReplacingOccurrencesOfString:localeSeparator withString:@""] mutableCopy];  
                        mstring=[[mstring substringToIndex:mstring.length-3] mutableCopy];
                        
                        [mstring deleteCharactersInRange:NSMakeRange(mstring.length-1,1)];
                    }
                    else
                     [mstring deleteCharactersInRange:range];
                }
                if(![mstring isEqualToString:@""])
                {
                if([mstring length] <= MILEAGE_MAX_LENGTH)
                  [textField setText:[NSString stringWithFormat:@"%@ mi",[numberFormatter stringFromNumber:[NSNumber numberWithInt:[mstring intValue]]]]];
                }
                else
                    [textField setText:@""]; 
            }
            result= NO;
        }
        else
        {
            result=YES;
        }
    }
    else
    {
         result=NO;
        if(textField == txt_email)
        {
            if([string length] == 0){ //backspace
                result = YES;
            }
            else{
                if ([[txt_email.text componentsSeparatedByString:@"@"] count] > 1) {
                    if([[string componentsSeparatedByCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:[ALPHA_NUMERIC stringByAppendingString:@".-"]] invertedSet]] componentsJoinedByString: @""].length == string.length){
                        result = YES;
                    }
                    
                } else {
                    if([[string componentsSeparatedByCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:[ALPHA_NUMERIC stringByAppendingString:@".!#$%&'*+-/=?^_`{|}~@"]] invertedSet]] componentsJoinedByString: @""].length ==string.length){
                        result = YES;
                    }
                }
                if(result)
                {
                    NSString* newText = [txt_email.text stringByReplacingCharactersInRange:range withString:string];
                    if (newText.length<=EMAIL_MAX_LENGTH )
                        result = YES;
                    else
                        result =NO;
                    
                }
            }
            
        }
        else{
        if([string length] == 0){ //backspace
            result = YES;
        }
        else{
            if([[string componentsSeparatedByCharactersInSet:nonCharacterSet] componentsJoinedByString: @""].length == string.length){
                if(textField == txt_datasalesperson) 
                {
                NSString* newText = [txt_datasalesperson.text stringByReplacingCharactersInRange:range withString:string];
                if (newText.length<=NAME_MAX_LENGTH )
                    result = YES;
                }
                else if(textField == txt_customer || textField == txt_customerAddress || textField == txt_city)
                {
                    NSString* newText = [textField.text stringByReplacingCharactersInRange:range withString:string];
                    if(textField == txt_customer && newText.length<=NAME_MAX_LENGTH)
                    {
                        result = YES;
                    }
                    else if(textField == txt_customerAddress && newText.length<=ADDRESS_MAX_LENGTH)
                    {
                        result = YES;
                    }
                    else if(textField == txt_city && newText.length<=CITY_MAX_LENGTH)
                    {
                        result = YES;
                    }
                    else
                        result = NO;
                }
                else
                    result = YES;
            }
        }
        }
    }
        
    if([self checkMandatory])
    {
        [btn_calculate setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btn_calculate setUserInteractionEnabled:YES];
    }
    else 
    {
        [btn_calculate setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [btn_calculate setUserInteractionEnabled:NO];
    }
    }
	//always return no since we are manually changing the text field
	return result;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    // add observer for the respective notifications (depending on the os version)
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(keyboardDidShow:) 
                                                     name:UIKeyboardDidShowNotification 
                                                   object:nil];		
    } else {
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(keyboardWillShow:) 
                                                     name:UIKeyboardWillShowNotification 
                                                   object:nil];
    }

}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    //[[NSNotificationCenter defaultCenter] removeObserver:self];
    [self unregisterForKeyboardNotifications];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
#pragma mark User Interation Methods
// ADD: bring up the reader when the scan button is tapped
- (IBAction) scanButtonTapped
{
    ZBarReaderViewController *reader = [ZBarReaderViewController new];
    //	[reader.readerView.captureReader.captureOutput setValue:nil forKey:@"videoSettings"];	//Added to solve the 3GS(IOS 4.21) frozen issue
    reader.readerDelegate = self;
	reader.tracksSymbols = YES;
    ZBarImageScanner *scanner = reader.scanner;
	scanner.enableCache = YES;
    //TODO: (optional) additional reader configuration here
	
    //Disable rarely used I2/5 to improve performance
    [scanner setSymbology: ZBAR_I25
				   config: ZBAR_CFG_ENABLE
					   to: 0];
    //	reader.readerView.zoom = 1.0;
	
    //Present and release the controller
    [self presentModalViewController: reader
							animated: YES];
}
// ADD: do something with decoded barcode data
- (void) imagePickerController: (UIImagePickerController*) reader
 didFinishPickingMediaWithInfo: (NSDictionary*) info
{
    //TODO: (optional) this is the image of the barcode...
    //UIImage *image =
    //  [info objetForKey: UIImagePickerControllerOriginalImage];
    //Get the results
    id <NSFastEnumeration> results = [info objectForKey: ZBarReaderControllerResults];
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        //Just grab the first barcode
        break;
    if(!symbol)
        //This should not occur, but doesn't hurt to check
        return;
    //Put the barcode data in the text view
    //See ZBarSymbol.h for other symbol properties
	if( symbol.type == ZBAR_CODE39 )
	{
		//Take the first letter 'I' off
		if ([symbol.data length] == 18 && [symbol.data characterAtIndex:0] == 'I') {
			txt_vin.text = [symbol.data substringFromIndex:1];
		} else {
			txt_vin.text = symbol.data;
		}
        //		addToInventoryView.txt_vinCode.text = symbol.data;
	}
	else {
        //		NSString *temp_str = [NSString stringWithFormat:@"\nInvalid BarCode Type!\n\nCode: @\nType: @", symbol.data, symbol.typeName];
        //		[self alertUser:temp_str title:@"Invalid VIN Code"];
	}
    //Dismiss the controller (NB: dismiss from the *picker*)
    [reader dismissModalViewControllerAnimated: YES];
}

#pragma mark UIPickerView delegate methods

// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    if([pickerView isEqual: pickerOne]) {  
        return 1;
    }
    return 0;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if([pickerView isEqual: pickerOne]) { 
        return oneDataSource.count ;
    }
    return 0;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if([pickerView isEqual: pickerOne]) {
        return [oneDataSource objectAtIndex:row] ;
    }
    return 0;
}
- (void)pickerView:(UIPickerView *)thePickerView 
      didSelectRow:(NSInteger)row 
       inComponent:(NSInteger)component {
    selectedRow=row;
}
- (void)showPicker:(id)sender{
    int row1 = 0;
    if(sender == txt_status)
	{
        oneDataSource =[NSMutableArray arrayWithArray:statuses] ;
        [oneDataSource insertObject:@"-status-" atIndex:0];
        if([txt_status.text length] > 0)
            row1=[statuses indexOfObject:txt_status.text]+1;
    }  
    else
	if(sender == txt_year)
	{
        oneDataSource =[NSMutableArray arrayWithArray:years] ;
        [oneDataSource insertObject:@"-year-" atIndex:0];
        if([txt_year.text length] > 0)
            row1=[years indexOfObject:txt_year.text]+1;
    }  
    else if(sender == txt_make)
    {
        oneDataSource =[NSMutableArray arrayWithArray:makes] ;
        [oneDataSource insertObject:@"-make-" atIndex:0];
        if([txt_make.text length] > 0)
            row1=[makes indexOfObject:txt_make.text]+1;
    }
    else if(sender == txt_model)
    {
       oneDataSource =[NSMutableArray arrayWithArray:models] ;
        [oneDataSource insertObject:@"-model-" atIndex:0];
        if([txt_model.text length] > 0)
            row1=[models indexOfObject:txt_model.text]+1;
    }
    else if(sender == txt_trim)
    {
       oneDataSource =[NSMutableArray arrayWithArray:trims] ;
        [oneDataSource insertObject:@"-trim-" atIndex:0];
        if([txt_trim.text length] > 0)
            row1=[trims indexOfObject:txt_trim.text]+1;
    }
    else if(sender == txt_style)
    {
        oneDataSource =[NSMutableArray arrayWithArray:styles] ;
        [oneDataSource insertObject:@"-style-" atIndex:0];
        if([txt_style.text length] > 0)
            row1=[styles indexOfObject:txt_style.text]+1;
    }
    else if(sender == txt_exteriorcolor)
    {
        oneDataSource =[NSMutableArray arrayWithArray:exteriorColors] ;
        [oneDataSource insertObject:@" " atIndex:0];
        if([txt_exteriorcolor.text length] > 0)
            row1=[exteriorColors indexOfObject:txt_exteriorcolor.text]+1;
    }
    else if(sender == txt_interiorcolor)
    {
        oneDataSource =[NSMutableArray arrayWithArray:exteriorColors] ;
        [oneDataSource insertObject:@" " atIndex:0];
        if([txt_interiorcolor.text length] > 0)
            row1=[exteriorColors indexOfObject:txt_interiorcolor.text]+1;
    }
    else if(sender == txt_state)
    {
        oneDataSource =[NSMutableArray arrayWithArray:stateNames] ;
        [oneDataSource insertObject:@" " atIndex:0];
        if([txt_state.text length] > 0)
            row1=[stateCodes indexOfObject:txt_state.text]+1;
    }
    [pickerOne reloadComponent:0];
    [pickerOne selectRow:row1 inComponent:0 animated:NO];
    [UIView beginAnimations:@"FadeIn" context:nil];
    [UIView setAnimationDuration:0.7];
    _pickerOneDone.alpha = 1.0;
    pickerOne.alpha = 1.0;
    [UIView commitAnimations];
	selectedRow = row1;
    
}
- (void)pickerCancel:(id)sender{
	[UIView beginAnimations:@"FadeOut" context:nil];
	[UIView setAnimationDuration:0.7];
	_pickerOneDone.alpha = 0.0;
	pickerOne.alpha = 0.0;
	[UIView commitAnimations];
    latsetTextField=nil;
    selectedRow=0;
}

- (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

- (void)registerForKeyboardNotifications
{
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(keyboardWasShown:)
												 name:UIKeyboardDidShowNotification object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(keyboardWasHidden:)
												 name:UIKeyboardDidHideNotification object:nil];
}

- (void)unregisterForKeyboardNotifications
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
@end
