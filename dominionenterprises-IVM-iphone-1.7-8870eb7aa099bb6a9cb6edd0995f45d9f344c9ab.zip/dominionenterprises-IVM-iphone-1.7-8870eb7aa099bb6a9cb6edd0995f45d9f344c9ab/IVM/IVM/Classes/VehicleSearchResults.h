//
//  VehicleSearchResults.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/18/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface VehicleSearchResults : NSObject {
	int				totalCount;
	NSMutableArray	*listings;
	bool			isBasedOnCriteria;
}

@property(assign)			int				totalCount;
//@property(retain, readonly)	NSMutableArray	*listings;
@property(strong)	NSMutableArray	*listings;
@property(assign)	bool		isBasedOnCriteria;

@end
