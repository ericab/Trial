//
//  CompetitiveInfoDetailNewViewController.h
//  IVM
//
//  Created by Sehaswaran Mayilerum on 6/21/12.

// Competitive Info Detail View Controller
#import <UIKit/UIKit.h>

@interface CompetitiveInfoDetailNewViewController : UITableViewController
{
    NSMutableArray *competitiveInfoDetailLabelArray;
    NSMutableArray *competitiveInfoDetailValueArray;
    NSNumberFormatter *frm;
    NSNumberFormatter *numberFormatter;
}
@property(nonatomic,strong) NSMutableDictionary *competitiveInfoDetail;
@end
