//
//  RecentSearchController.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/9/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"

@interface RecentSearchController : UIViewController<UITableViewDelegate, UITableViewDataSource, AppRestore> {
	UITableView	*table;
	NSArray	*searches;
}

-(void)load;

@end
