//
//  NetImage.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/26/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//

#import "NetImageView.h"


@implementation NetImageView

@synthesize imageURL, cache, noImage;
@synthesize imageData;


#pragma mark initialization
//default constructor for this class
- (id) initWithFrame:(CGRect)inFrame andUrl:(NSURL *)url andCache:(NSMutableDictionary*)inCache {
	self = [super initWithImage:nil];
	if(self) {
//		if(!missingPhoto)
//			missingPhoto = [UIImage imageNamed:@"no_photo.png"];
		
//		self._imageData = [NSMutableData data];
//		self.noImage = missingPhoto;
//		self.contentMode = UIViewContentModeScaleAspectFit;
//		self.frame = inFrame;
//		self.cache = inCache;
//		self.imageURL = url;
        _con = nil;
	}
    
    self.noImage = [UIImage imageNamed:@"no_photo.png"];;
    self.imageData = [NSMutableData data];
    self.imageURL = url;
    self.cache = inCache;
    self.contentMode = UIViewContentModeScaleAspectFit;
    self.frame = inFrame;

	return self;
}

#pragma mark Static Methods

+ (id) netImageWithStringUrl:(NSString *)url andCache:(NSMutableDictionary*)inCache
{
	NSURL  *rurl = nil;
	if(url != nil)
		rurl = [NSURL URLWithString:url];
	return [[self alloc] initWithFrame:CGRectMake(0,0,[UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width) andUrl:rurl andCache:inCache];
}

+ (UIImage*) imageForURL:(NSURL *)inURL withSize:(CGSize)inSize inCache:(NSDictionary*)inCache {
	return (UIImage*)[inCache objectForKey:[inURL absoluteString]];
}

#pragma mark Instance Methods

- (void) setImageURL:(NSURL*)url cache:(NSMutableDictionary*)inCache {
    if (!imageData) {
        self.imageData = [NSMutableData data];
        self.noImage = [UIImage imageNamed:@"no_photo.png"];;
        self.cache = inCache;
    }
    
    imageURL = url;
	
//	_realUrl = imageURL == nil ? nil : 
//	[NSURL URLWithString:[NSString stringWithFormat:resizeUrl, 
//						   (int)self.frame.size.width, (int)self.frame.size.height, [imageURL absoluteString]]];
//    _realUrl = imageURL;
    
	//Cancel operation if necessary
	[self clearDownload];
	
	//Set No Photo
	if(imageURL == nil) {
		self.image = self.noImage;
    } else {
		UIImage *cachedImg = [self getImageFromCache:imageURL];
        
		//Return if cached image
		if(cachedImg){
			self.image = cachedImg;
			return;
		}
		
		//Turn on loading view
		if (loadingView == nil) {
			loadingView = [LoadingView loadingImageInView:self];
		}
		
		_con = [NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:imageURL] delegate:self];
	}
}

- (void) setImage:(UIImage*)inImage {
	//Alwasy No Image
	if(inImage == nil) {
		//[self clearNDO];
		[self clearDownload];
		inImage = noImage;
	}
	
	[super setImage:inImage];
	
	//Cache Image
	if(imageURL != nil) {
		[cache setValue:inImage forKey:[imageURL absoluteString]];
    }
}

- (UIImage *) getImageFromCache:(NSURL*)url {
	return (UIImage*)[cache objectForKey:[url absoluteString]];
}

#pragma mark NSURLConnection delegate methods
- (void) connection:(NSURLConnection *)urlconn didReceiveResponse:(NSURLResponse *)response {
	[imageData setLength:0];
}

- (void) connection:(NSURLConnection *)urlconn didReceiveData:(NSData *)data {
    [imageData appendData:data];
}

- (void) connectionDidFinishLoading:(NSURLConnection *)urlconn {
	//Turn off loading view
	if (loadingView != nil) {
		[loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
		loadingView = nil;
	}
    
	if(!imageData) {
		self.image = noImage;
	} else {
		UIImage *myImage = [UIImage imageWithData:imageData];
		if(myImage){						
			self.image = myImage;
		} else {
			self.image = noImage;
#if CONFIG_Debug
			NSLog(@"Image Data Invalid For : %@", _realUrl);
#endif
		}
        
//        [imageData setLength:0];
    }
}

- (void) connection:(NSURLConnection*)urlconn didFailWithError:(NSError*)error {
	self.image = nil;
#if CONFIG_Debug
	NSLog(@"Image Error: %@", error);
#endif
}

- (void) clearDownload {
	[_con cancel];
	_con = nil;
	[imageData setLength:0];

	if (loadingView != nil) {
		[loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
		loadingView = nil;
	}
}

- (void) dealloc
{
	[self clearDownload];
	imageData = nil;
	noImage = nil;
	imageURL = nil;
}

@end