//
//  AddToInventoryController.m
//  GetAuto.com
//
//  Created by Shaofeng Tu on 6/1/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import "AddToInventoryController.h"
#import "AddToInventory.h"
//#import "DealerSearchResults.h"
#import <QuartzCore/CoreAnimation.h>
#import "appDelegate.h"
#import "DetailsController.h"
#import "IVM.h"


#define kDealerRadius	@"dr"
#define kDealerManuf	@"dm"
#define kDealerZip		@"dz"

#define VinCodeLength	17


@implementation AddToInventoryController

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

- (id) init
{
	self = [super init];
	if (self != nil) {
		self.title = @"Add Vehicle";
		mobileServices = [[IVMMobileServices alloc] init];
		mobileServices.delegate = self;

		_userToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];

		[appDelegate track:@"Add To Inventory"];
	}
	return self;
}

- (id)initWithRestore:(NSDictionary*)data{
	self = [self init];
	if (self != nil)
	{
		restore_data = data;
		[self.view class];//Ensure that the view gets loaded
	}
	return self;
}
- (NSDictionary*)getRestoreData{
	NSMutableDictionary *dict = [NSMutableDictionary dictionary];
	if(addToInventoryView)
	{
		//Don't want restore the old VIN Number
		//		[dict setValue:addToInventoryView.vinCode forKey:kDealerZip];
	}
	return dict;
}

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	addToInventoryView = [[AddToInventory alloc] initWithFrame:CGRectZero];
	addToInventoryView.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
//	addToInventoryView.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
	
	[addToInventoryView.btn_VinCodeScan addTarget:self action:@selector(scanButtonTapped) forControlEvents:UIControlEventTouchUpInside];
//	[addToInventoryView.btn_linkPictures addTarget:self action:@selector(editButtonTapped) forControlEvents:UIControlEventTouchUpInside];
	[addToInventoryView.btn_addVehicle addTarget:self action:@selector(addVehicleButtonTapped) forControlEvents:UIControlEventTouchUpInside];
	
	if(restore_data) {
		addToInventoryView.vinCode = [restore_data valueForKey:kDealerZip];
	}
    
	self.view = addToInventoryView;
	
	//Shift up the AddVehicleButton
	[addToInventoryView shiftUpButton];
}

- (void)addToInventoryViewError:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}
/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:message
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}

#pragma mark User Interation Methods

// ADD: bring up the reader when the scan button is tapped
- (IBAction) scanButtonTapped
{
    ZBarReaderViewController *reader = [ZBarReaderViewController new];
//	[reader.readerView.captureReader.captureOutput setValue:nil forKey:@"videoSettings"];	//Added to solve the 3GS(IOS 4.21) frozen issue
    reader.readerDelegate = self;
	reader.tracksSymbols = YES;

    ZBarImageScanner *scanner = reader.scanner;
	scanner.enableCache = YES;
	
    //TODO: (optional) additional reader configuration here
	
    //Disable rarely used I2/5 to improve performance
    [scanner setSymbology: ZBAR_I25
				   config: ZBAR_CFG_ENABLE
					   to: 0];

//	reader.readerView.zoom = 1.0;
	
    //Present and release the controller
    [self presentModalViewController: reader
							animated: YES];
}

// ADD: do something with decoded barcode data
- (void) imagePickerController: (UIImagePickerController*) reader
 didFinishPickingMediaWithInfo: (NSDictionary*) info
{
    //TODO: (optional) this is the image of the barcode...
    //UIImage *image =
    //  [info objetForKey: UIImagePickerControllerOriginalImage];
	
    //Get the results
    id <NSFastEnumeration> results = [info objectForKey: ZBarReaderControllerResults];
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        //Just grab the first barcode
        break;
    if(!symbol)
        //This should not occur, but doesn't hurt to check
        return;
	
    //Put the barcode data in the text view
    //See ZBarSymbol.h for other symbol properties
	if( symbol.type == ZBAR_CODE39 )
	{
		//Take the first letter 'I' off
		if ([symbol.data length] == 18 && [symbol.data characterAtIndex:0] == 'I') {
			addToInventoryView.txt_vinCode.text = [symbol.data substringFromIndex:1];
		} else {
			addToInventoryView.txt_vinCode.text = symbol.data;
		}

//		addToInventoryView.txt_vinCode.text = symbol.data;
	}
	else {
//		NSString *temp_str = [NSString stringWithFormat:@"\nInvalid BarCode Type!\n\nCode: @\nType: @", symbol.data, symbol.typeName];
//		[self alertUser:temp_str title:@"Invalid VIN Code"];
	}

	
    //Dismiss the controller (NB: dismiss from the *picker*)
    [reader dismissModalViewControllerAnimated: YES];
}
/*
- (void) readerView:(ZBarReaderView*)readerView didReadSymbols:(ZBarSymbolSet*)symbols fromImage:(UIImage*)image
{
    ZBarSymbol *symbol = nil;
    for(symbol in symbols)
        //Just grab the first barcode
        break;
    if(!symbol)
        //This should not occur, but doesn't hurt to check
        return;
	
    //Put the barcode data in the text view
    //See ZBarSymbol.h for other symbol properties
	if( symbol.type == ZBAR_CODE39 )
	{
		//Take the first letter 'I' off
		if ([symbol.data length] == 18 && [symbol.data characterAtIndex:0] == 'I') {
			addToInventoryView.txt_vinCode.text = [symbol.data substringFromIndex:1];
		} else {
			addToInventoryView.txt_vinCode.text = symbol.data;
		}
		
		//		addToInventoryView.txt_vinCode.text = symbol.data;
	}
	else {
		//		NSString *temp_str = [NSString stringWithFormat:@"\nInvalid BarCode Type!\n\nCode: @\nType: @", symbol.data, symbol.typeName];
		//		[self alertUser:temp_str title:@"Invalid VIN Code"];
	}
	
	
    //Dismiss the controller (NB: dismiss from the *picker*)
    [reader dismissModalViewControllerAnimated: YES];
}
*/

/*
// ADD: Enable the VIN Code textfield for input manually
- (IBAction) editButtonTapped
{
	addToInventoryView.txt_vinCode.enabled= TRUE;
}
*/

// ADD: Send out VIN Code, and get the vehicle data back
- (IBAction) addVehicleButtonTapped
{
	mobileServices.baseResults = nil;
	addToInventoryView.vinCode = addToInventoryView.txt_vinCode.text;
/*	
	//Take the first letter 'I' off
	if ([addToInventoryView.vinCode length] == 18 && [addToInventoryView.vinCode characterAtIndex:0] == 'I') {
		addToInventoryView.vinCode = [addToInventoryView.txt_vinCode.text substringFromIndex:1];
	}
*/	
	//Double Checking the VIN Code validation
    if([addToInventoryView.vinCode length] == 0)
    {
		[self alertUser:@"Please Enter VIN Code!" title:@"Enter VIN Code"];
		return; /*rsnerella*/        
    }
    else if([addToInventoryView.vinCode length] != VinCodeLength)
	{
		[self alertUser:@"The VIN Code Is Invalid!" title:@"Invalid VIN Code"];
		return; /*rsnerella*/
	}
    
	//Call the IVM Mobile Services
	if (addToInventoryView.viewScanning) {
		//Turn on loading view ...
		if (loadingView == nil) {
			loadingView = [LoadingView loadingViewInView:self.view loadingText:@"Waiting ..."];
            //loadingView = [LoadingView loadingViewInView:[[UIApplication sharedApplication] windows] objectAtIndex:0] loadingText:@"Waiting ..."];
		}
		
		[mobileServices getDecodeDataByToken:addToInventoryView.vinCode withToken:_userToken];
	} else {
		//Turn on loading view ...
		if (loadingView == nil) {
			loadingView = [LoadingView loadingViewInView:self.view loadingText:@"Waiting ..."];
            //loadingView = [LoadingView loadingViewInView:[[UIApplication sharedApplication] windows] objectAtIndex:0] loadingText:@"Waiting ..."];
		}
		
		VehicleDetails *vehDetails = [VehicleDetails new];
		
		vehDetails.year = decData.year;
		vehDetails.make = decData.make;
		vehDetails.model = decData.model;
		if ([decData.trims count] > 0) {
			vehDetails.trimLevel = [decData.trims objectAtIndex:0];
		}else {
			vehDetails.trimLevel = @"";
		}
//		vehDetails.trimLevel = [decData.trims objectAtIndex:0];
		vehDetails.vin = decData.vin;
		vehDetails.price = addToInventoryView.price;
		vehDetails.mileage = addToInventoryView.mileage;
		vehDetails.dealerLotKey = [[NSUserDefaults standardUserDefaults] integerForKey:kDefaultDealerLot];
		vehDetails.time_created = [NSDate  date];
		vehDetails.type = @"PassengerVehicle";
		vehDetails.status = @"Active";
		
		[mobileServices addVehicleByToken:vehDetails withToken:_userToken];
	}
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}

- (void) GetDecodeDataComplete:(DecodeData*)decodeData dResult:(NSString*)dResult {
	//Turn off loading view ...
	if (loadingView != nil) {
		[loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
//		[loadingView release];
		loadingView = nil;
	}

	if (![dResult isEqualToString:@"Success" ])
	{
		//Delete the Invalid Authentication Token
		[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserToken];
        
           UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Get Decode Data Error"
                                                               message:dResult 
                                                              delegate:self 
                                                     cancelButtonTitle:@"Ok"
                                                     otherButtonTitles:nil];
           [alertView show];
           /*return; rsnerella*/            
	}

	decData = decodeData;
	
	
	//Need to add specific error code handling in the future
	if(self.navigationController.topViewController == self)
	{
		if(!decodeData)
		{
			[self alertUser:@"No Decode Data" title:@"Can't Get VIN Decode Data."];
			return;
		}
	}

	//Shift down the AddVehicleButton
//	[addToInventoryView shiftDownButton];
	
	NSMutableString *trimString = [NSMutableString string];
	for (int i=0; i<[decData.trims count]; i++) {
		[trimString appendFormat:@"%@ ", [decData.trims objectAtIndex:i]];
	}
	
	if (trimString != nil) {
		addToInventoryView.vehicleLabel.text = [NSString stringWithFormat:@"%d %@ %@ %@\nVIN: %@", 
												decData.year, decData.make, decData.model, trimString, decData.vin];
	}else {
		addToInventoryView.vehicleLabel.text = [NSString stringWithFormat:@"%d %@ %@\nVIN: %@", 
												decData.year, decData.make, decData.model, decData.vin];
	}
	
	[addToInventoryView refreshViews];
}

#pragma mark MobileSearch
- (void) VehicleDetailsComplete:(VehicleDetails*)vehicleListing withStatus:(NSString*)inResult{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	
	
	//Turn off loading view ...
	if (loadingView != nil) {
		[loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
//		[loadingView release];
		loadingView = nil;
	}

	if(![inResult isEqualToString:@"Success"])
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Failed To Add Vehicle"
															message:inResult 
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		
		return;
	}
/*	
	//NSLog(@"vehicleListing.vehicle_key = %d", vehicleListing.vehicle_key);
	//NSLog(@"vehicleListing.vin = %@", vehicleListing.vin);
	//NSLog(@"vehicleListing.stockNumber = %@", vehicleListing.stockNumber);
	//NSLog(@"vehicleListing.make = %@", vehicleListing.make);
	//NSLog(@"vehicleListing.model = %@", vehicleListing.model);
	//NSLog(@"vehicleListing.year = %d", vehicleListing.year);
	//NSLog(@"vehicleListing.price = %d", vehicleListing.price);
	//NSLog(@"vehicleListing.mileage = %d", vehicleListing.mileage);
	//NSLog(@"vehicleListing.externalColor = %@", vehicleListing.externalColor);
	//NSLog(@"vehicleListing.internalColor = %@", vehicleListing.internalColor);
	//NSLog(@"vehicleListing.trimLevel = %@", vehicleListing.trimLevel);
*/	
	//Added the bookmark automatically
	VehicleResult *_preListing = [VehicleResult new];
//	_preListing.distance = -1.0;	//Supresses distance label
	_preListing.vehicle_key = vehicleListing.vehicle_key;
	_preListing.vin = vehicleListing.vin;
	_preListing.stockNumber = vehicleListing.stockNumber;
	_preListing.make = vehicleListing.make;
	_preListing.model = vehicleListing.model;
	_preListing.year = vehicleListing.year;
	_preListing.price = vehicleListing.price;
	_preListing.mileage = vehicleListing.mileage;
	_preListing.externalColor = vehicleListing.externalColor;
	_preListing.internalColor = vehicleListing.internalColor;
	_preListing.trimLevel = vehicleListing.trimLevel;
//	_preListing.image = (NSString *)[vehicleListing.thumbPhotos indexOfObject:0];		//No any photos there

	[[appDelegate currentInstance] saveBookmark:_preListing];
//	[_preListing release];
	

	DetailsController *detailsController = [[DetailsController alloc] initWithListing:_preListing andImage:nil andPhotos:YES];
	[[self navigationController] pushViewController:detailsController animated:YES];
}

- (void)dealloc {
	addToInventoryView = nil;

}

@end
