//
//  UIButton+Underline.m
//  GetAuto.com
//
//  Created by Rakesh on 9/3/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "UIButton+Underline.h"


@implementation UIButton(Underline)

- (void)underline
{
	UILabel * label;
	for(UIView* control in self.subviews)
	{
		if([control isKindOfClass:[UILabel class]])
		{
			label = (UILabel*)control;
			break;
		}
	}
	CGRect frame = label.frame;
	CGContextRef context = UIGraphicsGetCurrentContext();
	UIColor *color = [self titleColorForState:self.state];
	const CGFloat* components = CGColorGetComponents(color.CGColor);
	CGContextSetFillColor(context, components);
	CGContextAddRect(context, CGRectMake(frame.origin.x, 
										 frame.origin.y + frame.size.height, 
										 frame.size.width, 2.0));
	CGContextDrawPath(context, kCGPathFill);
	UIGraphicsPopContext();
}

@end
