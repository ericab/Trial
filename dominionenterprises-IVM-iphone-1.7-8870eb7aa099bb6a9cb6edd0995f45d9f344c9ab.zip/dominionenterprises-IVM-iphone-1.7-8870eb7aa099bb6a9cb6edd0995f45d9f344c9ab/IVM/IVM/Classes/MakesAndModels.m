//
//  MakesAndModels.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 3/5/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "MakesAndModels.h"


@implementation MakesAndModels

@synthesize makes, models, time_created;

- (id) init
{
	self = [super init];
	if (self != nil) {
		time_created = [NSDate date];
	}
	return self;
}

- (id) initWithMakes:(NSArray*)inMakes andModels:(NSArray*)inModels{
	if([inMakes count] != [inModels count]) return nil;
	self = [super init];
	if (self != nil) {		
		makes = inMakes;
		models = inModels;
		time_created = [NSDate date];
	}
	return self;
}

#pragma mark NSCoding Methods
- (id)initWithCoder:(NSCoder *)decoder{
	self = [super init];
	if(self != nil){
		makes = [decoder decodeObjectForKey:@"makes"];
		models = [decoder decodeObjectForKey:@"models"];
		time_created = [decoder decodeObjectForKey:@"time"];
	}
	return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder{
	[encoder encodeObject:makes forKey:@"makes"];
	[encoder encodeObject:models forKey:@"models"];
	[encoder encodeObject:time_created forKey:@"time"];
}

#pragma mark Search Methods
- (NSArray*) makesStartingWith:(NSString*)fragment{
	if(fragment == nil || [fragment isEqualToString:@""])
		return makes;
	NSMutableArray *newMakes = [NSMutableArray array];
	for(NSString *make in makes)
	{
		if([make compare:fragment options:NSCaseInsensitiveSearch range:(NSRange){ 0 , [fragment length] }] == NSOrderedSame)
			[newMakes addObject:make];
	}
	return newMakes;
}

- (NSArray*) modelsAtIndex:(int)index StartingWith:(NSString*)fragment{
	if(fragment == nil || [fragment isEqualToString:@""])
		return [models objectAtIndex:index];
	NSMutableArray *newModels = [NSMutableArray array];
	for(NSString *model in [models objectAtIndex:index])
	{
		if([model compare:fragment options:NSCaseInsensitiveSearch range:(NSRange){ 0 , [fragment length] }] == NSOrderedSame)
			[newModels addObject:model];
	}
	return newModels;
}

- (int) indexOfMake:(NSString*)make{
	for(int i = 0; i < [makes count]; i++)
	{
		if([make compare:[makes objectAtIndex:i] options:NSCaseInsensitiveSearch] == NSOrderedSame)
			return i;
	}
	return NSNotFound;
}

- (int) indexOfModel:(NSString*)model atIndex:(int)index{
	NSArray *makes_models = (NSArray*)[models objectAtIndex:index];
	for(int i = 0; i < [makes_models count]; i++)
	{
		if([model compare:[makes_models objectAtIndex:i] options:NSCaseInsensitiveSearch] == NSOrderedSame)
			return i;
	}
	return NSNotFound;
}

#pragma mark Clean Up

@end
