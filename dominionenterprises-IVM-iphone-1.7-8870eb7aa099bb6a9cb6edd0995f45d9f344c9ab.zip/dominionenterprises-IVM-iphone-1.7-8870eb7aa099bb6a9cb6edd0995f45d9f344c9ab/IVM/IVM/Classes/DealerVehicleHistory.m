//
//  DealerVehicleHistory.m
//  IVM
//
//  Created by Sehaswaran Mayilerum on 6/27/12.

//

#import "DealerVehicleHistory.h"

@implementation DealerVehicleHistory
@synthesize hasCarfax,hasAutoCheck;
@end
