//
//  SearchResultsView.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 1/22/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchResultsView : UIView {
	UIActivityIndicatorView	*activityIndicator;
	UILabel					*activityLabel;
	UITableView				*searchTable;
	UIButton				*filterButton;
	UIView					*mainView;
}

@property(nonatomic, strong)	UIActivityIndicatorView	*activityIndicator;
@property(nonatomic, strong)	UILabel					*activityLabel;
@property(nonatomic, strong)	UITableView				*searchTable;
@property(nonatomic, strong)	UIButton				*filterButton;
@property(nonatomic, strong)	UIView					*mainView;

@end
