//
//  LocationController.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/26/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//

#import "LocationController.h"

static LocationController *sharedCLDelegate = nil;

@implementation LocationController

@synthesize locationManager, delegate;

- (id) init {
	if(self = [super init])
	{
		CLLocationManager *loc = [[CLLocationManager alloc] init];
		loc.delegate = self;
		locationManager = loc;
	}
	return self;
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation{
	[self.delegate locationUpdated:self.locationManager withLocation:newLocation];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
	[self.delegate locationFailed:self.locationManager withError:error];
	
	[manager stopUpdatingLocation];
}

+ (LocationController *)sharedInstance{
	@synchronized(self) {
        if (sharedCLDelegate == nil) {
            sharedCLDelegate = [[self alloc] init]; // assignment not done here
        }
    }
    return sharedCLDelegate;
}

#pragma mark Singleton persistance methods
+ (id)allocWithZone:(NSZone *)zone {
    @synchronized(self) {
        if (sharedCLDelegate == nil) {
            sharedCLDelegate = [super allocWithZone:zone];
            return sharedCLDelegate;  // assignment and return on first allocation
        }
    }
    return nil; // on subsequent allocation attempts return nil
}
- (id)copyWithZone:(NSZone *)zone
{
    return self;
}

- (id)retain {
    return self;
}

- (unsigned)retainCount {
    return UINT_MAX;  // denotes an object that cannot be released
}

- (void)release {
    //do nothing
}

- (id)autorelease {
    return self;
}
@end
