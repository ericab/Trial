//
//  VehicleSearchResults.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/18/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "VehicleSearchResults.h"


@implementation VehicleSearchResults

@synthesize totalCount;
@synthesize listings;
@synthesize isBasedOnCriteria;

- (id) init
{
	self = [super init];
	if (self != nil) {
		listings = [NSMutableArray new];
	}
	return self;
}


@end
