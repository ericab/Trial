//
//  EdmundsController.m
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//

#import "SearchResultsController.h"
#import "appDelegate.h"
#import <QuartzCore/CoreAnimation.h>
#import "EdmundsController.h"
#import "EdmundsView.h"

#define kAdvancedSearchSearcher @"searcher"

@implementation EdmundsController

- (id) init
{
	self = [super init];
	if (self != nil) {
		self.title = @"Edmunds";
		[appDelegate track:@"Edmunds"];
	}
    
	return self;
}


- (id)initWithRestore:(NSDictionary*)data{
	self = [self init];
	if (self != nil)
	{
		searchObj = [data objectForKey:kAdvancedSearchSearcher];
		[self.view class];//Ensure that the view gets loaded
	}
    
	return self;
}

- (NSDictionary*)getRestoreData{
	NSMutableDictionary* dict = [NSMutableDictionary dictionaryWithCapacity:1];
	if(searchObj == nil)
	{
		//Attempt to get it
		searchObj = ((EdmundsView*)self.view).searchObject;
	}
    
	if(searchObj != nil)
	{
		searchObj.firstListing = 1;
		[dict setValue:searchObj forKey:kAdvancedSearchSearcher];
	}
    
	return dict;
}

//// Implement loadView to create a view hierarchy programmatically, without using a nib.
//- (void)loadView {
//	EdmundsView *asv = [[EdmundsView alloc] initWithFrame:CGRectZero searchObject:searchObj filterMode:NO];
//	asv.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
////	asv.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
//	asv.target = self;
////	asv.errorCallback = @selector(advSearchError:);
//	self.view = asv;
//}
//
//- (void)advSearchError:(id)sender{
//	[self.navigationController popViewControllerAnimated:YES];
//}
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
    //	BlackBookView *asv = [[BlackBookView alloc] initWithFrame:CGRectZero searchObject:searchObj filterMode:NO];
    //	asv.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
    ////	asv.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
    //	asv.target = self;
    ////	asv.errorCallback = @selector(advSearchError:);
    //	self.view = asv;
    arrayOfdataProviderYears=[NSMutableArray array];
    arrayOfdataProviderMakes=[NSMutableArray array];
    arrayOfdataProviderModels=[NSMutableArray array];
    arrayOfdataProviderTrims=[NSMutableArray array];
    arrayOfdataProviderStyles=[NSMutableArray array];
    arrayOfdataProviderClean=[NSMutableArray array];
    [self buildStatesList];
    
    
    UIView *view = [[UIView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    [view setAutoresizingMask:UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth];
    [view setBackgroundColor:[UIColor whiteColor]];
    UIImageView *backgroundImage=  [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];;
    [view addSubview:backgroundImage];
    [view sendSubviewToBack:backgroundImage];
    
    
    
    scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [view addSubview:scrollView];
    
    UIColor *textColor = [UIColor blackColor];
    UIFont *lblFont = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0];
    
    float yOffset = 10.0f;
    
    //Year
    UILabel *tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Year";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_Year = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_Year.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_Year.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_Year.placeholder = @"Year";
    txt_Year.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_Year.delegate = self;
    txt_Year.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_Year];
    
    yOffset += 30.0f;
    
    //Make
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 135.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Make";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_make = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_make.borderStyle = UITextBorderStyleRoundedRect;
    txt_make.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_make.placeholder = @"Make";
    txt_make.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_make.delegate = self;
    txt_make.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_make];
    
    yOffset += 30.0f;
    //Mileage
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 135.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Mileage";
    [scrollView addSubview:tmpLabel];
    
    
    yOffset += 20.0f;
    
    txt_mileage = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_mileage.borderStyle = UITextBorderStyleRoundedRect;
    txt_mileage.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_mileage.placeholder = @"Mileage";
    txt_mileage.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_mileage.delegate = self;
    txt_mileage.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_mileage];
    
    yOffset += 30.0f;
    
    
    //Model
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 155.0f, 20.0f)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Model";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    
    txt_model = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_model.borderStyle = UITextBorderStyleRoundedRect;
    txt_model.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_model.placeholder = @"Model";
    txt_model.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_model.delegate = self;
    txt_model.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_model];
    
    yOffset += 30.0f;
    
    //Trim
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 130.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Trim";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    
    txt_trim = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_trim.borderStyle = UITextBorderStyleRoundedRect;
    txt_trim.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_trim.placeholder = @"Trim";
    txt_trim.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_trim.delegate = self;
    txt_trim.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_trim];
    
    yOffset += 30.0f;
	
    //Style
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 90.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Style";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_style = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_style.borderStyle = UITextBorderStyleRoundedRect;
    txt_style.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_style.placeholder = @"Style";
    txt_style.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_style.delegate = self;
    txt_style.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_style];
    
    yOffset += 30.0f;
    
    //NADA Options
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 130.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Edmunds Condition";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_edmundsoptions = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_edmundsoptions.borderStyle = UITextBorderStyleRoundedRect;
    txt_edmundsoptions.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_edmundsoptions.placeholder = @"Clean/ Average/ Rough";
    txt_edmundsoptions.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_edmundsoptions.delegate = self;
    txt_edmundsoptions.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_edmundsoptions];
    
   /* yOffset += 30.0f;
    
    //NADA More Options
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 130.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Edmunds More Options";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_edmundsmoreoptions = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_edmundsmoreoptions.borderStyle = UITextBorderStyleRoundedRect;
    txt_edmundsmoreoptions.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_edmundsmoreoptions.placeholder = @"w/o AUTO TRANS/ SPORT/ TITANIUM SPORT/ NAVIGATION/ QUATTRO/ AUDI DRIVE SELECT/ S-LINE/ ADAPTIVE CRUISE CONTROL";
    txt_edmundsmoreoptions.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_edmundsmoreoptions.delegate = self;
    txt_edmundsmoreoptions.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_edmundsmoreoptions];
    
    // yOffset += 30.0f;
     */  
    
    
    //Picker View Creation		
    _pickerYearDone = [UIToolbar new];
    [_pickerYearDone sizeToFit];
    _pickerYearDone.frame = CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 215.0f - 42.0f, [UIScreen mainScreen].applicationFrame.size.width, _pickerYearDone.frame.size.height);
    //[[UIToolbar alloc] initWithFrame:CGRectMake(0.0f, frame.size.height - 215.0f - 40.0f, frame.size.width, 44.0f)];
    _pickerYearDone.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
    _pickerYearDone.barStyle = UIBarStyleBlackTranslucent;
    _pickerYearDone.contentMode = UIViewContentModeRight;
    UIBarButtonItem *cancel = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(pickerCancel:)];
    
    UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(pickerDone:)];
    UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [_pickerYearDone setItems:[NSArray arrayWithObjects:cancel,spacer, done, nil] animated:NO];
    
    //DealerLot/Year Picker
    pickerYear = [[UIPickerView alloc] initWithFrame:CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 215.0f, [UIScreen mainScreen].applicationFrame.size.width, 0.0f)];
    pickerYear.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    pickerYear.showsSelectionIndicator = YES;
    pickerYear.delegate = self;
    pickerYear.dataSource = self;   
    pickerYear.alpha = 0.0;
    pickerYear.hidden = YES;
    [view addSubview:pickerYear];
    
    _pickerYearDone.alpha = 0.0;
    _pickerYearDone.hidden = YES;
    // oneDataSource = [NSMutableArray arrayWithObjects:@"Market Control Analytics",@"Black Book",@"Kelly Blue Book",@"Edmunds",@"Galves",@"NADA", nil];
    
    [view addSubview:_pickerYearDone];
    
    txt_Year.inputView = pickerYear;
    txt_Year.inputAccessoryView = _pickerYearDone;
    txt_make.inputView = pickerYear;
    txt_make.inputAccessoryView = _pickerYearDone;
    txt_model.inputView = pickerYear;
    txt_model.inputAccessoryView = _pickerYearDone;
    txt_style.inputView = pickerYear;
    txt_style.inputAccessoryView = _pickerYearDone;
    txt_trim.inputView = pickerYear;
    txt_trim.inputAccessoryView = _pickerYearDone;
    txt_edmundsoptions.inputView = pickerYear;
    txt_edmundsoptions.inputAccessoryView = _pickerYearDone;
    
    self.view = view;
   [self loadingView];
    
}
-(void) loadingView
{
    progressView = [[SearchResultsView alloc] initWithFrame:CGRectMake(100.0f, 50.0f, 0.0f, 0.0f)];
    [ self.view addSubview:progressView];
    [progressView.activityIndicator startAnimating];
}
- (void)buildStatesList
{
    // static arrays of clean options
    arrayOfdataProviderClean = [NSMutableArray arrayWithObjects:@"Extra Clean",  
                                @"Clean",  
                                @"Average",  
                                @"Rough",  
                                nil];
    
    
}

-(void) stopLoadingView
{
    [progressView.activityIndicator stopAnimating];
    // searchView.activityLabel.hidden = YES;
    [progressView removeFromSuperview];
}

- (void)advSearchError:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}

-(void) handleResponseForQuery:(NSMutableDictionary *)response
{
    
    if([[response objectForKey:@"response"] objectForKey:@"years"])
    {
        NSLog(@"in to years");
        arrayOfdataProviderYears = [[response objectForKey:@"response"] objectForKey:@"years"];
        [self stopLoadingView];
        NSLog(@"%@",arrayOfdataProviderYears);
        
    }
    else if([[response objectForKey:@"response"] objectForKey:@"makes"])
    {
        NSLog(@"in to years");
        arrayOfdataProviderMakes = [[response objectForKey:@"response"] objectForKey:@"makes"];
        [self stopLoadingView];
        
        
        
    }
    else if([[response objectForKey:@"response"] objectForKey:@"models"])
    {
        NSLog(@"in to years");
        arrayOfdataProviderModels = [[response objectForKey:@"response"] objectForKey:@"models"];
        [self stopLoadingView];
        
        
        
    }
    else if([[response objectForKey:@"response"] objectForKey:@"trims"])
    {
        NSLog(@"in to years");
        arrayOfdataProviderTrims = [[response objectForKey:@"response"] objectForKey:@"trims"];
        [self stopLoadingView];
        
        
        
    }
    else if([[response objectForKey:@"response"] objectForKey:@"styles"])
    {
        NSLog(@"in to styles");
        arrayOfdataProviderStyles = [[response objectForKey:@"response"] objectForKey:@"styles"];
        [self stopLoadingView];
        
        
        
    }
    
    else
    {
        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    arrayOfdataProvidersDetails = [[response objectForKey:@"response"] objectForKey:@"dataproviderdetailnada"];
    arrayOfdataProvidersDetailsOptions = [[response objectForKey:@"response"] objectForKey:@"dataproviderdetailnada1"];
    dataProviderDetails = [arrayOfdataProvidersDetails objectAtIndex:0];
    dataProviderDetailsOptions = [arrayOfdataProvidersDetailsOptions objectAtIndex:0];
    
    NSString *szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"providertype"]];
    if ([szTemp length]>0) {
        NSLog(@"ProviderType: %@",szTemp);
        providerType=szTemp;

    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"year"]];
    if ([szTemp length]>0) {
        NSLog(@"year: %@",szTemp);
        [txt_Year setText:szTemp];
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"make"]];
    if ([szTemp length]>0) {
        NSLog(@"Make: %@",szTemp);
        [txt_make setText:szTemp];
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"model"]];
    if ([szTemp length]>0) {
        NSLog(@"Model: %@",szTemp);
        [txt_model setText:szTemp];
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"style"]];
    if ([szTemp length]>0) {
        NSLog(@"Style: %@",szTemp);
        [txt_style setText:szTemp];
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"mileage"]];
    if ([szTemp length]>0) {
        NSLog(@"Mileage: %@",szTemp);
        [txt_mileage setText:[NSString stringWithFormat:@"%@ mi",[numberFormatter stringFromNumber:[NSNumber numberWithInt:[szTemp intValue]]]]];
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"providercode"]];
    if ([szTemp length]>0) {
        NSLog(@"providercode: %@",szTemp);
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"vehicleappraisalproviderkey"]];
    if ([szTemp length]>0) {
        NSLog(@"VehicleAppraisalProviderKey: %@",szTemp);
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"vehicleappraisalkey"]];
    if ([szTemp length]>0) {
        NSLog(@"vehicleappraisalkey: %@",szTemp);
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"vehiclevaluationcondition"]];
    if ([szTemp length]>0) {
        NSLog(@"vehiclevaluationcondition: %@",szTemp);
        [txt_edmundsoptions setText: szTemp];
    }
    szTemp =   [ NSString stringWithString: [dataProviderDetails objectForKey:@"trim"]];
    if ([szTemp length]>0) {
        NSLog(@"trim: %@",szTemp);
        [txt_trim setText: szTemp];
    }
    
    for (int i=0; i<[arrayOfdataProvidersDetailsOptions count]; i++) {
        dataProviderDetailsOptions = [arrayOfdataProvidersDetailsOptions objectAtIndex:i];
        szTemp =   [ NSString stringWithString: [dataProviderDetailsOptions objectForKey:@"optionname"]];
        if ([szTemp length]>0) {
            NSLog(@"optionname: %@",szTemp);
            //[txt_trim setText: szTemp];
        }
        
    }
    
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:12],@"reqtype", providerType,@"providerType", self,@"delegate", nil];
        
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
        
    }

}

/*// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad {
 [super viewDidLoad];
 }*/
// To load the Scroll View
- (void)viewWillAppear:(BOOL)animated {
   	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter] addObserver: self 
											 selector: @selector(keyboardWasShown:)
												 name: UIKeyboardDidShowNotification 
											   object: nil];
	
    [[NSNotificationCenter defaultCenter] addObserver: self
											 selector: @selector(keyboardWasHidden:)
												 name: UIKeyboardDidHideNotification 
											   object: nil];
	
	//keyboardShown = NO; // 1
	
   	scrollView.frame = CGRectMake(0, 0, 320, 460);
	scrollView.contentSize = CGSizeMake(320, 500);
	
}

-(void) viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]
	 removeObserver:self];
}

-(void) keyboardWasShown: (NSNotification *)notif {
    //    if (displayKeyboard) {
    //        return;
    //	}
    return;
}

-(void) keyboardWasHidden: (NSNotification *)notif {
    //        if (displayKeyboard) {
    //            return;
    //        }
    return;
}




/*// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}*/

- (void)search:(id)sender{
	searchObj = ((EdmundsView*)self.view).searchObject;

	if (searchObj.dealerLot == 0) {
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Invalid DealerLot"
															message:@"Please Pick a Dealer Lot."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		
		return;
	}
/*
	if([searchObj.make length] < 1)
	{
		[(AdvancedSearchView*)self.view promptMakesAndModels];
		return;
	}
*/    
	[[appDelegate currentInstance] saveSearch:searchObj];
	SearchResultsController *src = [SearchResultsController new];
	[self.navigationController pushViewController:src animated:YES];
	[src startSearch:searchObj];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
#pragma mark UIPickerView delegate methods

// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    if([pickerView isEqual: pickerYear]) {  
        return 1;
    }
    return 0;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if([pickerView isEqual: pickerYear]) { 
        return oneDataSource.count ;
    }
    return 0;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if([pickerView isEqual: pickerYear]) {
        return [oneDataSource objectAtIndex:row] ;
    }
    return 0;
}
- (void)pickerView:(UIPickerView *)thePickerView 
      didSelectRow:(NSInteger)row 
       inComponent:(NSInteger)component {
    [latsetTextField  setText:[oneDataSource objectAtIndex:row]] ;
    if((UITextField*)latsetTextField == txt_Year)
    {
        [self loadingView];
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:13],@"reqtype", providerType,@"providerType",txt_Year.text,@"year", self,@"delegate", nil];
        
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
    }
    else if((UITextField*)latsetTextField == txt_make)
    {
        [self loadingView];
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:14],@"reqtype", providerType,@"providerType",txt_Year.text,@"year",txt_make.text,@"make", self,@"delegate", nil];
        
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
    }
    else if((UITextField*)latsetTextField == txt_model)
    {
        [self loadingView];
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:15],@"reqtype", providerType,@"providerType",txt_Year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", self,@"delegate", nil];
        
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
    }
    else if((UITextField*)latsetTextField == txt_trim)
    {
        [self loadingView];
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:16],@"reqtype", providerType,@"providerType",txt_Year.text,@"year",txt_make.text,@"make",txt_model.text,@"model", txt_trim.text,@"trim",self,@"delegate", nil];
        
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
    }
    
    
    
}
- (void)showPicker:(id)sender{
    
	if(sender == txt_Year)
	{
        
        oneDataSource = arrayOfdataProviderYears ;
    }  
    else if(sender == txt_make)
    {
        oneDataSource = arrayOfdataProviderMakes ;
    }
    else if(sender == txt_model)
    {
        oneDataSource = arrayOfdataProviderModels ;
    }
    else if(sender == txt_trim)
    {
        oneDataSource = arrayOfdataProviderTrims ;
    }
    else if(sender == txt_style)
    {
        oneDataSource = arrayOfdataProviderStyles ;
    }
    else if(sender == txt_edmundsoptions)
    {
        oneDataSource = arrayOfdataProviderClean ;
    }
    [latsetTextField setText:[oneDataSource objectAtIndex:0]];
    
    [pickerYear reloadComponent:0];
    
    
    int row1 = 0;
    
    
    
    [pickerYear selectRow:row1 inComponent:0 animated:NO];
    
    ;
    _pickerYearDone.hidden = NO;
    pickerYear.hidden = NO;
    
    [self.view bringSubviewToFront:pickerYear];
    [self.view bringSubviewToFront:_pickerYearDone];
    
    [UIView beginAnimations:@"FadeIn" context:nil];
    [UIView setAnimationDuration:0.7];
    _pickerYearDone.alpha = 1.0;
    pickerYear.alpha = 1.0;
    [UIView commitAnimations];
	
    
}
- (void)pickerCancel:(id)sender{
    //	_priorityView.hidden = YES;
    //	[self sendSubviewToBack:_priorityView];
	[UIView beginAnimations:@"FadeOut" context:nil];
	[UIView setAnimationDuration:0.7];
	_pickerYearDone.alpha = 0.0;
	pickerYear.alpha = 0.0;
	[UIView commitAnimations];
    
}
- (void)pickerDone:(id)sender{
    //	_priorityView.hidden = YES;
    //	[self sendSubviewToBack:_priorityView];
	[UIView beginAnimations:@"FadeOut" context:nil];
	[UIView setAnimationDuration:0.7];
	_pickerYearDone.alpha = 0.0;
	pickerYear.alpha = 0.0;
	[UIView commitAnimations];
    NSLog(@"%@",latsetTextField);
    
    
}
#pragma mark UITextField delegate methods

- (BOOL)textFieldShouldClear:(UITextField *)textField {
	return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    latsetTextField = textField;
    if (textField == txt_Year || textField == txt_make || textField == txt_model || textField == txt_trim || textField == txt_style || textField == txt_edmundsoptions) {
        [latsetTextField resignFirstResponder];
        [self showPicker:textField];
        //txt_Year.text = [oneDataSource objectAtIndex:0];
        
        return NO;
    }
    //else if(textField == txt_make) {
    // [txt_make resignFirstResponder];
    //[self showPicker:textField];
    //txt_make.text = [oneDataSource objectAtIndex:0];
    
    //return NO;
    //}
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    latsetTextField = textField;
}




- (void)dealloc {
	searchObj = nil;
}

@end
