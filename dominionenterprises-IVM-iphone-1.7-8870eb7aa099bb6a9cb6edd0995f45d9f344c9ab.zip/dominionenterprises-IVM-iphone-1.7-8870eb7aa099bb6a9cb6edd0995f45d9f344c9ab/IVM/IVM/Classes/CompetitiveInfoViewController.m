//
//  CompetitiveInfoViewController.m
//  CompetitiveInfoViewController
//
//  Created by Raja Sekhar Nerella on 28/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CompetitiveInfoViewController.h"
#import "NSObject+DelayedBlock.h"


#define ROWS 100
@interface CompetitiveInfoViewController ()

- (void)handleDoubleTap:(UITapGestureRecognizer *)recognizer;

@end

@implementation CompetitiveInfoViewController
- (id) init
{
	self = [super init];
	if (self != nil) {
        details =[[NSMutableArray alloc]init];
        Names=[[NSMutableArray alloc]init];
        Price=[[NSMutableArray alloc]init];
        Milage=[[NSMutableArray alloc]init];
        Age=[[NSMutableArray alloc]init];
        Distance=[[NSMutableArray alloc]init];
	
	}
	return self;
}


-(void)loadView
{
   UIView *view=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 460)];
    
    
       self.view=view;
    
    //view.backgroundColor=[UIColor magentaColor];
  /*  details =[[NSMutableArray alloc]initWithObjects:@"2008 GMC Yukon XL\nVin:IGKFK66868J245237",@"2008 GMC Yukon XL\nVin:IGKFK66868J178746 ",@"2008 GMC Yukon XL\nVin:IGKFK66868R173427",@"2008 GMC Yukon XL\nVin:IGKFK66868J179891",@"2008 GMC Yukon XL\nVin:IGKFK66868J161571",@"2008 GMC Yukon XL\nVin:IGKFK66868J222998",@"2008 GMC Yukon XL\nVin:IGKFK66868J239957",@"2008 GMC Yukon XL\nVin:IGKFK66868J113184",@"2008 GMC Yukon XL\nVin:IGKFK66868J158984", nil];
    subdetails=[[NSMutableArray alloc]initWithObjects:@"Vin:IGKFK66868J245237",@"Vin:IGKFK66868J178746",@"Vin:IGKFK66868R173427",@"Vin:IGKFK66868J179891",@"Vin:IGKFK66868J161571",@"Vin:IGKFK66868J222998",@"Vin:IGKFK66868J239957",@"Vin:IGKFK66868J113184",@"Vin:IGKFK66868J158984", nil];
    
    Names=[[NSMutableArray alloc]initWithObjects:@"Beechmont Subaru",@"Studebaker Buick GMC",@"Dave Kehl Chevrolet",@"Mark Sweeney Buick GMC",@"Jaguar Land Rover Cincinnati",@"Kings Ford",@"Studebaker Buick GMC",@"Mark Sweeney Pontiac Buick GMC", @"Lawrenceburg Chevrolet",nil];
    
    Price=[[NSMutableArray alloc]initWithObjects:@"$33,495",@"$41,997",@"$29,680",@"$33,995",@"$30,758",@"$28,119",@"$33,997",@"$0",@"$36,990", nil];
    
    
    Milage=[[NSMutableArray alloc]initWithObjects:@"67,365",@"45,564",@"65,635",@"59,815",@"78,947",@"58,877",@"48,718",@"0",@"66,649", nil];
    
    Age=[[NSMutableArray alloc]initWithObjects:@"6",@"15",@"16",@"18",@"18", @"21",@"21",@"40",@"70",nil];
    Distance=[[NSMutableArray alloc]initWithObjects:@"27",@"38",@"60",@"19",@"14",@"12",@"38",@"19",@"34", nil];*/

    
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        srand(time(0));
    }
    
    return self;
}

- (void)viewDidLoad
{
    
        [super viewDidLoad];
        numberOfColumns = 6;
        numberOfSections = 1;
        
        colWidth = 220.0f;
 
        tblView = [[EWMultiColumnTableView alloc] initWithFrame:CGRectInset(self.view.bounds, 5.0f, 5.0f)];
        tblView.sectionHeaderEnabled = YES;
        tblView.cellWidth = 100.0f;
        tblView.boldSeperatorLineColor = [UIColor blackColor];
        tblView.normalSeperatorLineColor = [UIColor blackColor];
        tblView.boldSeperatorLineWidth = 0.5f;
       tblView.normalSeperatorLineWidth = 1.0f;
        tblView.dataSource = self;
        tblView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    
        [self.view addSubview:tblView];
       
    //Popup the loading view
    progressView = [[SearchResultsView alloc] initWithFrame:CGRectMake(100.0f, 50.0f, 0.0f, 0.0f)];
    //progressView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    
    [self.view addSubview:progressView];

    [progressView.activityIndicator startAnimating];
    progressView.activityLabel.text = @"Loading...";
    progressView.activityLabel.hidden = NO;

        
       [self performBlock:^{
            
            [tblView scrollToColumn:0 position:EWMultiColumnTableViewColumnPositionMiddle animated:YES];
        } afterDelay:0.5];
    }
    
    
    - (void)viewDidUnload
    {
//        [super viewDidUnload];
        // Release any retained subviews of the main view.
        
        // e.g. self.myOutlet = nil;
        //[tblView release];
        tblView = nil;
    }
    
    - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
    {
        // Return YES for supported orientations
        return YES;
    }

-(void) handleResponseForQuery:(NSMutableDictionary *)response
{
    NSLog(@"Competitive Info Web service response has to handled here");
    
    
    arrayOfCompetitiveData = [[response objectForKey:@"response"] objectForKey:@"competitiveinfo"];
    NSLog(@"%@",arrayOfCompetitiveData);
    if ([arrayOfCompetitiveData count]>0) {
       
        NSLog(@"reload Data %d",[arrayOfCompetitiveData count]);
        
       // [progressView.activityIndicator stopAnimating];
        // searchView.activityLabel.hidden = YES;
    //    [progressView removeFromSuperview];
//        
//        [[[n elementsForName:@"Year"] objectAtIndex:0] stringValue],@"year", 
//        [[[n elementsForName:@"Make"] objectAtIndex:0] stringValue],@"make", 
//        [[[n elementsForName:@"Model"] objectAtIndex:0] stringValue],@"model", 
//        [[[n elementsForName:@"Trim"] objectAtIndex:0] stringValue],@"trim",
//        [[[n elementsForName:@"Age"] objectAtIndex:0] stringValue],@"age", 
//        [[[n elementsForName:@"DealerName"] objectAtIndex:0] stringValue],@"dealername", 
//        [[[n elementsForName:@"Distance"] objectAtIndex:0] stringValue],@"distance", 
//        [[[n elementsForName:@"Mileage"] objectAtIndex:0] stringValue],@"mileage",
//        [[[n elementsForName:@"Price"] objectAtIndex:0] stringValue],@"price",
//        [[[n elementsForName:@"Vin"] objectAtIndex:0] stringValue],@"vin", 
        
        [progressView.activityIndicator stopAnimating];
        progressView.activityIndicator.color = [UIColor blackColor];
        progressView.activityLabel.hidden = YES;
        [progressView removeFromSuperview];
 
    }
    for (int i=0; i<[arrayOfCompetitiveData count]; i++) {
    
        NSString *szDetails = [NSString stringWithFormat:@"%@ %@ %@ %@\nVin: %@", [[arrayOfCompetitiveData objectAtIndex:i ] objectForKey:@"year"],[[arrayOfCompetitiveData objectAtIndex:i ] objectForKey:@"make"],[[arrayOfCompetitiveData objectAtIndex:i ] objectForKey:@"model"],[[arrayOfCompetitiveData objectAtIndex:i ]objectForKey:@"trim"],[[arrayOfCompetitiveData objectAtIndex:i ] objectForKey:@"vin"]] ;
        [details addObject:szDetails];
        NSString *szName = [[arrayOfCompetitiveData objectAtIndex:i ] objectForKey:@"dealername"];
        if([szName length] > 0)
        {
            [Names addObject:szName]; 
        }else {
            [Names addObject:@"n/a"]; 
        }
         NSString *szprice = [[arrayOfCompetitiveData objectAtIndex:i ] objectForKey:@"price"];
        if([szprice length]>0)
        {
            [Price addObject:szprice]; 
        }else 
        {
            szprice = @"n/a";
            [Price addObject:szprice]; 
        }
        NSString *szMileage = [[arrayOfCompetitiveData objectAtIndex:i ] objectForKey:@"mileage"];
        if([szMileage length]>0)
        {
            [Milage addObject:szMileage]; 
        }else 
        {
            szMileage = @"n/a";
            [Milage addObject:szMileage]; 
        }
        
        NSString *szAge = [[arrayOfCompetitiveData objectAtIndex:i ] objectForKey:@"age"];
        if([szAge length]>0)
        {
           [ Age addObject:szAge]; 
        }else 
        {
            szAge = @"n/a";
            [Age addObject:szAge]; 
        }
        NSString *szDistance = [[arrayOfCompetitiveData objectAtIndex:i ] objectForKey:@"distance"];
        if([szDistance length]>0)
        {
            [ Distance addObject:szDistance]; 
        }else 
        {
            szDistance = @"n/a";
            [Distance addObject:szDistance]; 
        }

      

       
//        [ Price addObject:[[arrayOfCompetitiveData objectAtIndex:i ]objectForKey:@"price"]];
//        [ Milage addObject:[[arrayOfCompetitiveData objectAtIndex:i ]objectForKey:@"mileage"]];
//        [ Age addObject:[[arrayOfCompetitiveData objectAtIndex:i ]objectForKey:@"age"]];
//        [ Distance addObject:[[arrayOfCompetitiveData objectAtIndex:i ]objectForKey:@"distance"]];
          NSLog(@"details %@",details);
    
       //   NSLog(@"year %@",[[arrayOfCompetitiveData objectAtIndex:i ] objectForKey:@"year"]);
        }
     [ tblView reloadData];

}
    
#pragma mark - EWMultiColumnTableViewDataSource
    
    - (NSInteger)numberOfSectionsInTableView:(EWMultiColumnTableView *)tableView
    {
        return numberOfSections;
    }
    
    - (UIView *)tableView:(EWMultiColumnTableView *)tableView cellForIndexPath:(NSIndexPath *)indexPath column:(NSInteger)col
    {
        l = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, colWidth, 40.0f)] ;
        l.numberOfLines = 0;
        l.lineBreakMode = UILineBreakModeWordWrap;
        
        return l;
    }
    
    
    - (void)tableView:(EWMultiColumnTableView *)tableView setContentForCell:(UIView *)cell indexPath:(NSIndexPath *)indexPath column:(NSInteger)col{
        l = (UILabel *)cell;
        
        switch (col)
        {
            case 0:
                l.text=[details objectAtIndex:indexPath.row];
                l.textAlignment = UITextAlignmentCenter;
                l.font = [UIFont boldSystemFontOfSize:13.0];
                l.textColor=[UIColor grayColor];
                
                
                break;
            case 1:
                l.text=[Names objectAtIndex:indexPath.row];
                l.textAlignment = UITextAlignmentCenter;
                l.font = [UIFont boldSystemFontOfSize:13.0];
                 l.textColor=[UIColor grayColor];
                break;
            case 2:
                l.text=[Price objectAtIndex:indexPath.row];
                l.textAlignment = UITextAlignmentCenter;
                l.font = [UIFont boldSystemFontOfSize:13.0];
                 l.textColor=[UIColor grayColor];
                break;

            case 3:
                l.text=[Milage objectAtIndex:indexPath.row];
                l.textAlignment = UITextAlignmentCenter;
                l.font = [UIFont boldSystemFontOfSize:13.0];
                 l.textColor=[UIColor grayColor];
                break;

            case 4:
                l.text=[Age objectAtIndex:indexPath.row];
                l.textAlignment = UITextAlignmentCenter;
                l.font = [UIFont boldSystemFontOfSize:13.0];
                 l.textColor=[UIColor grayColor];
                break;
          default:
                l.text=[Distance objectAtIndex:indexPath.row];
                l.textAlignment = UITextAlignmentCenter;
                l.font = [UIFont boldSystemFontOfSize:13.0];
                 l.textColor=[UIColor grayColor];
                break;
        }
        
       // l.text = [[[details objectAtIndex:indexPath.section] objectAtIndex:indexPath.row] objectAtIndex:col];
      //  l.text=[details objectAtIndex:indexPath.row];
        
        CGRect f = l.frame;
        f.size.width = [self tableView:tableView widthForColumn:col];
        l.frame = f;
        
        //[l sizeToFit];
    }
    
    - (CGFloat)tableView:(EWMultiColumnTableView *)tableView heightForCellAtIndexPath:(NSIndexPath *)indexPath column:(NSInteger)col
    {
//        switch (col)
//        {
//            case 0:
//                NSString *str = [details objectAtIndex:0];
//                CGSize s = [str sizeWithFont:[UIFont systemFontOfSize:[UIFont systemFontSize]]
//                           constrainedToSize:CGSizeMake([self tableView:tableView widthForColumn:col], MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
//
//                break;
//            case 1:
//                l.text=[Names objectAtIndex:indexPath.row];
//                break;
//            case 2:
//                l.text=[Price objectAtIndex:indexPath.row];
//                break;
//                
//            case 3:
//                l.text=[Milage objectAtIndex:indexPath.row];
//                break;
//                
//            case 4:
//                l.text=[Age objectAtIndex:indexPath.row];
//                break;
//            default:
//                l.text=[Age objectAtIndex:indexPath.row];
//                break;
//        }

        
        
        NSString *str = [details objectAtIndex:0];
        CGSize s = [str sizeWithFont:[UIFont systemFontOfSize:[UIFont systemFontSize]]
                   constrainedToSize:CGSizeMake([self tableView:tableView widthForColumn:col], MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
        
        return s.height + 20.0f;
    }
    
    - (CGFloat)tableView:(EWMultiColumnTableView *)tableView widthForColumn:(NSInteger)column
    {
       return colWidth;
    }
    
    - (NSInteger)tableView:(EWMultiColumnTableView *)tableView numberOfRowsInSection:(NSInteger)section
    {
      //  return [details count];
        return [arrayOfCompetitiveData count];
       // return 1;
    }
    
    - (UIView *)tableView:(EWMultiColumnTableView *)tableView sectionHeaderCellForSection:(NSInteger)section column:(NSInteger)col
    {
        
        //    switch (section)
        //    {
        //        case 0:
        //            UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, [self tableView:tableView widthForColumn:col], 40.0f)] ;
        //            l.backgroundColor = [UIColor grayColor];
        //            return l;
        //            break;
        //            
        //            
        //        case 0:
        //            UILabel *l1 = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, [self tableView:tableView widthForColumn:col], 40.0f)] ;
        //            l1.backgroundColor = [UIColor grayColor];
        //            return l1;
        //            break;
        //            
        //            
        //        case 0:
        //            UILabel *l2 = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, [self tableView:tableView widthForColumn:col], 40.0f)] ;
        //            l2.backgroundColor = [UIColor grayColor];
        //            return l2;
        //            break;
        //            
        //            
        //        default:
        //            break;
        //    }
        
        l = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, [self tableView:tableView widthForColumn:col], 40.0f)] ;
        l.backgroundColor = [UIColor whiteColor];
        return l;
        
        
        //    UILabel *l1 = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, [self tableView:tableView widthForColumn:col], 40.0f)] ;
        //    l1.backgroundColor = [UIColor grayColor];
        //    return l1;
        
    }
    
    - (void)tableView:(EWMultiColumnTableView *)tableView setContentForSectionHeaderCell:(UIView *)cell section:(NSInteger)section column:(NSInteger)col
    {
        l = (UILabel *)cell;
        l1= (UILabel *)cell;
        l2= (UILabel *)cell;
        l3= (UILabel *)cell;
        l4= (UILabel *)cell;
       
        
        switch (col)
        {
            case 0:
                l.text = [NSString stringWithFormat:@"Details",  col];
                CGRect f = l.frame;
                f.size.width = [self tableView:tableView widthForColumn:col];
                l.frame = f;
                //[l sizeToFit];
               //  [l setFont:[UIFont fontWithName:@"Century Gothic-Bold" size:46]]; 
                l.font = [UIFont boldSystemFontOfSize:17.0];
                l.textAlignment = UITextAlignmentCenter;
                break;
            case 1:
                l1.text = [NSString stringWithFormat:@" Dealer Name",  col];
                CGRect f1 = l1.frame;
                f.size.width = [self tableView:tableView widthForColumn:col];
                l1.frame = f1;
                 l1.font = [UIFont boldSystemFontOfSize:17.0];
                l.textAlignment = UITextAlignmentCenter;
                //[l1 sizeToFit];
                
                break;
            case 2:
                l.text = [NSString stringWithFormat:@"Price",  col];
                CGRect f2 = l2.frame;
                f.size.width = [self tableView:tableView widthForColumn:col];
                l2.frame = f2;
                 l.font = [UIFont boldSystemFontOfSize:17.0];
                l.textAlignment = UITextAlignmentCenter;
                //[l2 sizeToFit];
                
                break;
                
            case 3:
                l.text = [NSString stringWithFormat:@"Mileage", col];
                CGRect f3 = l3.frame;
                f.size.width = [self tableView:tableView widthForColumn:col];
                l3.frame = f3;
                 l1.font = [UIFont boldSystemFontOfSize:17.0];
                l.textAlignment = UITextAlignmentCenter;
               // [l3 sizeToFit];
                
                break;
            case 4:
                l.text = [NSString stringWithFormat:@"Age", col];
                CGRect f4 = l4.frame;
                f.size.width = [self tableView:tableView widthForColumn:col];
                l4.frame = f4;
                 l1.font = [UIFont boldSystemFontOfSize:17.0];
                l.textAlignment = UITextAlignmentCenter;
                //[l4 sizeToFit];
                
                break;
                
            default:
                l.text = [NSString stringWithFormat:@"Distance",  col];
                CGRect f5 = l5.frame;
                f.size.width = [self tableView:tableView widthForColumn:col];
                l5.frame = f5;
                 l1.font = [UIFont boldSystemFontOfSize:17.0];
                l.textAlignment = UITextAlignmentCenter;
               // [l5 sizeToFit];
                
                break;
        }    
           }
    
    - (NSInteger)numberOfColumnsInTableView:(EWMultiColumnTableView *)tableView
    {
        return numberOfColumns;
    }
    
#pragma mark Header Cell
    
    - (UIView *)tableView:(EWMultiColumnTableView *)tableView headerCellForIndexPath:(NSIndexPath *)indexPath
    {
        return [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 0.0f, 0.0f)] ;
    }
    
    //- (void)tableView:(EWMultiColumnTableView *)tableView setContentForHeaderCell:(UIView *)cell atIndexPath:(NSIndexPath *)indexPath
    //{
    //    UILabel *l = (UILabel *)cell;
    //    l.text = [NSString stringWithFormat:@"Line: (%d, %d)", indexPath.section, indexPath.row];
    //}
    
    - (CGFloat)tableView:(EWMultiColumnTableView *)tableView heightForHeaderCellAtIndexPath:(NSIndexPath *)indexPath
    {
        return 40.0f;
    }
    
    - (CGFloat)tableView:(EWMultiColumnTableView *)tableView heightForSectionHeaderCellAtSection:(NSInteger)section column:(NSInteger)col
    {
        return 40.0f;
    }
    
//    - (UIView *)tableView:(EWMultiColumnTableView *)tableView headerCellInSectionHeaderForSection:(NSInteger)section
//    {
//        UILabel *l = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, [self widthForHeaderCellOfTableView:tableView], 30.0f)];
//        l.backgroundColor = [UIColor orangeColor];
//        return l;
//        
//    }
//    
//    - (void)tableView:(EWMultiColumnTableView *)tableView setContentForHeaderCellInSectionHeader:(UIView *)cell AtSection:(NSInteger)section
//    {
//        UILabel *l = (UILabel *)cell;
//    l.text = [NSString stringWithFormat:@"Section %d", section];
//    }
    
    - (CGFloat)widthForHeaderCellOfTableView:(EWMultiColumnTableView *)tableView
    {
        return 0.0f;
    }
    
    
    - (UIView *)tableView:(EWMultiColumnTableView *)tableView headerCellForColumn:(NSInteger)col
    {
      l =  [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 200.0f, 250.0f, 300.0f)];
        l.text = [NSString stringWithFormat:@"Column: %d", col];
    l.userInteractionEnabled = YES;
        
        l.tag = col;
        UITapGestureRecognizer *recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleDoubleTap:)];
        recognizer.numberOfTapsRequired = 2;
        [l addGestureRecognizer:recognizer];
        
        return l;
    }
    
    - (UIView *)topleftHeaderCellOfTableView:(EWMultiColumnTableView *)tableView
    {
    l =  [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 250.0f, [self heightForHeaderCellOfTableView:tableView])];
        l.text = @"Products";
        
        return l;
    }
    
    - (CGFloat)heightForHeaderCellOfTableView:(EWMultiColumnTableView *)tableView
    {
        return 20.0f;
    }
    
    - (void)tableView:(EWMultiColumnTableView *)tableView swapDataOfColumn:(NSInteger)col1 andColumn:(NSInteger)col2
    {
        for (int i = 0; i < [self numberOfSectionsInTableView:tableView]; i++) {
            NSMutableArray *section = [details objectAtIndex:i];
            for (int j = 0; j < [self tableView:tableView numberOfRowsInSection:i]; j++) {
                NSMutableArray *a = [section objectAtIndex:j];
                id tmp = [a objectAtIndex:col2];
                
                [a replaceObjectAtIndex:col2 withObject:[a objectAtIndex:col1]];
                [a replaceObjectAtIndex:col1 withObject:tmp];
                //[tmp release];
            }
        }
    }
    
    - (void)handleDoubleTap:(UITapGestureRecognizer *)recognizer
    {
        int col = [recognizer.view tag];
        for (NSMutableArray *array in details) {
            [array removeObjectAtIndex:col];
            //        [array addObject:@""];
        }
        
        for (NSMutableArray *section in details) {
            for (NSMutableArray *row in section) {
                [row removeObjectAtIndex:col];
                //            [row addObject:@""];
            }
        }
        
        numberOfColumns--;
        
        [tblView reloadData];
        
    }
- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:message
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}
 
    @end
