//
//  SearchAppraisalsViewController.h
//  IVM
//
//  Created by Raja Sekhar Nerella on 07/06/12.

//
#import <UIKit/UIKit.h>

@class AppraisalSearchResultsController;
@interface SearchAppraisalsViewController : UIViewController
{
  @public AppraisalSearchResultsController *rvController;
}
@property (nonatomic, retain) AppraisalSearchResultsController *rvController;
@end
