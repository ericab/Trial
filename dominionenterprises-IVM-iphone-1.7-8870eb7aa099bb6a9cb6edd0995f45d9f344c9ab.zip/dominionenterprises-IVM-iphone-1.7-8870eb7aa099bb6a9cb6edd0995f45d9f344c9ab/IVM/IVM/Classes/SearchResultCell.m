//
//  SearchResultCell.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/25/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//

#import "SearchResultCell.h"
#import "NetImageView.h"


@implementation SearchResultCell

//@synthesize netImage, vehicle, price, mileage, bodytype, colors, distance, mlsNumber, certifiedLogo;
@synthesize netImage, vehicle, price, mileage, bodytype, colors, mlsNumber, certifiedLogo;

//- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier {
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
	self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
	if (self != nil) {
        // Initialization code
		self.clipsToBounds = YES;
		self.backgroundColor = [UIColor colorWithRed:RedMake(kResultBackground) green:GreenMake(kResultBackground) blue:BlueMake(kResultBackground) alpha:1.0];
		
		vehicle = [[UILabel alloc] initWithFrame:CGRectMake(5.0f, 2.0f, 280.0f, 18.0f)];
		netImage = [[NetImageView alloc] initWithFrame:CGRectMake(5.0f, 18.0f, 100.0f, 75.0f) andUrl:nil andCache:nil];
		price = [[UILabel alloc] initWithFrame:CGRectMake(120.0f, 25.0f, 150.0f, 16.0f)];
		mileage = [[UILabel alloc] initWithFrame:CGRectMake(120.0f, 40.0f, 150.0f, 16.0f)];
		bodytype = [[UILabel alloc] initWithFrame:CGRectMake(120.0f, 55.0f, 130.0f, 14.0f)];
		colors = [[UILabel alloc] initWithFrame:CGRectMake(120.0f, 70.0f, 170.0f, 14.0f)];
		mlsNumber = [[UILabel alloc] initWithFrame:CGRectMake(120.0f, 85.0f, 200.0f, 14.0f)];
/*		distance = [[UILabel alloc] initWithFrame:CGRectMake(220.0f, 77.0f, 60.0f, 14.0f)];
		certifiedLogo = [[NetImageView alloc] initWithFrame:CGRectMake(110.0f, 56.0f, 100.0f, 38.0f) andUrl:nil andCache:nil];
		
		certifiedLogo.noImage = nil;
		certifiedLogo.loadingImage = nil;
		certifiedLogo.image = nil;
		certifiedLogo.contentMode = UIViewContentModeBottom | UIViewContentModeLeft;
*/		
		UIFont *defont = [UIFont fontWithName:kDefaultFont size:kDefaultFontSize];
		
		vehicle.font = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0];
		vehicle.textColor = [UIColor colorWithRed:RedMake(kSCAddressRGB) green:GreenMake(kSCAddressRGB) blue:BlueMake(kSCAddressRGB) alpha:1.0];
		vehicle.backgroundColor = [UIColor clearColor];
		price.font = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize];
		price.textColor = [UIColor colorWithRed:RedMake(kSCPriceRGB) green:GreenMake(kSCPriceRGB) blue:BlueMake(kSCPriceRGB) alpha:1.0];
		price.backgroundColor = [UIColor clearColor];
		mileage.font = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize];
		mileage.backgroundColor = [UIColor clearColor];
//		mileage.textAlignment = UITextAlignmentRight;
		bodytype.font = defont;
		bodytype.backgroundColor = [UIColor clearColor];
		colors.font = defont;
		colors.backgroundColor = [UIColor clearColor];
//		distance.font = defont;
//		distance.textAlignment = UITextAlignmentRight;
//		distance.backgroundColor = [UIColor clearColor];
//		distance.textColor = [UIColor grayColor];
		mlsNumber.font = defont;
		mlsNumber.backgroundColor = [UIColor clearColor];
//		mlsNumber.textAlignment = UITextAlignmentRight;
		
		[self.contentView addSubview:netImage];
		[self.contentView addSubview:vehicle];
		[self.contentView addSubview:price];
		[self.contentView addSubview:mileage];
		[self.contentView addSubview:bodytype];
		[self.contentView addSubview:colors];
//		[self.contentView addSubview:distance];
		[self.contentView addSubview:mlsNumber];
//		[self.contentView addSubview:certifiedLogo];
    }
    return self;
}

- (void)dealloc {
//	[distance release];
	
//	NSLog(@"SearchResultCell Dealloc");
}

@end
