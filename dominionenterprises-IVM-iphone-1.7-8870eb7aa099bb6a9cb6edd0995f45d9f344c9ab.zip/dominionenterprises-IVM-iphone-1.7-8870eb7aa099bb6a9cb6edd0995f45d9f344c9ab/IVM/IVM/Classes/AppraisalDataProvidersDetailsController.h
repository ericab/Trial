//
//  AppraisalDataProvidersDetailsController.h
//  IVM
//
//  Created by Raja Sekhar Nerella on 16/05/12.
//  
// Appraisal Data Provider  View Controller

#import <UIKit/UIKit.h>
#import "IVMMobileServices.h"
#import "SearchResultsView.h"
#import "AppraisalDetailsController.h"
#import "LoadingView.h"
@interface AppraisalDataProvidersDetailsController : UIViewController<UITextFieldDelegate,UIPickerViewDelegate,
UIPickerViewDataSource,
IVMMobileServicesDelegate,
UIAlertViewDelegate>
{
     UIScrollView		*scrollView;
     UITextField *txt_marketsize;
     UITextField *txt_marketaverageprice;
     UITextField *txt_marketaveragemileage;
     UITextField *txt_recommendedprice;
     UITextField *txt_pricerank;
     UITextField *txt_dayssupply;  
     UITextField *txt_dataproviders;
    
     NSMutableArray		*oneDataSource;
     NSMutableArray		*isMappedArray;
     NSMutableArray		*dataProviders;
     NSString            *isMapped;
     NSMutableArray *arrayOfdataProvidersList;
     NSDictionary    *dataProviderDetails;
     NSMutableArray  *arrayOfdataProviders;
     UIPickerView		*pickerOne;
     UIToolbar			*_pickerDone;
     id latsetTextField;
    
     @public NSString *str_marketsize;
     @public NSString *str_marketaverageprice;
     @public NSString *str_marketaveragemileage;
     @public NSString *str_recommendedprice;
     @public NSString *str_pricerank;
     @public NSString *str_dayssupply;
     @public NSString *str_appraisalid;
    NSString *dataProvider;
    LoadingView				*loadingView;
}
@property(nonatomic,assign) int reqType;
- (void)showPicker:(id)sender;
@property(nonatomic,strong) AppraisalDetailsController *appraisalDetailsController;
@property(nonatomic,assign) BOOL isAppraisal;
@end
