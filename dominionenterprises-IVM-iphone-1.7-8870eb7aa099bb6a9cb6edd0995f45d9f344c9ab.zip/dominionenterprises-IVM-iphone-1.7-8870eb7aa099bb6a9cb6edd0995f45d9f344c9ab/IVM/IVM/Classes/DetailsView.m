//
//  DetailsView.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/19/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "DetailsView.h"


@implementation DetailsView


- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self != nil) {
        // Initialization code
		
    }
    return self;
}


@end
