//
//  DetailActions.h
//  GetAuto.com
//
//  Created by Shaofeng Tu on 7/19/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import <Foundation/Foundation.h>

enum {
	_BROCHURE = 1,
	_VIDEO = 2,
	_TWITTER = 3
};

@interface DetailActions : NSObject {
	int			actionNumber;
	int			vehicleKey;
	NSString	*usrToken;
	NSString	*email;
	NSString	*comments;
}

@property(assign)	int			actionNumber;
@property(assign)	int			vehicleKey;
@property(copy)		NSString	*usrToken;
@property(copy)		NSString	*email;
@property(copy)		NSString	*comments;

@end
