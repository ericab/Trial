//
//  AnalyzerController.m
//  GetAuto.com
//
//  Created by Shaofeng Tu on 06/09/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import "AnalyzerController.h"
#import "AnalyzerView.h"
#import "appDelegate.h"
#import <QuartzCore/CoreAnimation.h>
#import "LoginViewController.h"

//#define kAdvancedSearchSearcher @"searcher"

@implementation AnalyzerController

- (id) init
{
	self = [super init];
	if (self != nil) {
		self.title = @"Analyzer";
		[appDelegate track:@"Analyzer"];
	}
	return self;
}


- (id)initWithRestore:(NSDictionary*)data{
	self = [self init];
	if (self != nil)
	{
		[self.view class];//Ensure that the view gets loaded
	}
	return self;
}
- (NSDictionary*)getRestoreData{
	NSMutableDictionary* dict = [NSMutableDictionary dictionaryWithCapacity:1];
/*
 if(searchObj == nil)
	{
		//Attempt to get it
		searchObj = [((AdvancedSearchView*)self.view).searchObject retain];
	}
	if(searchObj != nil)
	{
		searchObj.firstListing = 1;
		[dict setValue:searchObj forKey:kAdvancedSearchSearcher];
	}
*/
	return dict;
}

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	AnalyzerView *asv = [[AnalyzerView alloc] initWithFrame:CGRectZero];
	asv.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
//	asv.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
	[asv.btn_Analyzer addTarget:self action:@selector(analyzeVehicle:) forControlEvents:UIControlEventTouchUpInside];
	asv.target = self;
//	asv.errorCallback = @selector(analyzerError:);
	self.view = asv;
}

- (void)analyzerError:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}

/*// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}*/

- (void)analyzeVehicle:(id)sender{
/*	[searchObj release];
	searchObj = [((AnalyzerView*)self.view).searchObject retain];
	if([make length] < 1)
	{
		[(AnalyzerView*)self.view promptMakesAndModels];
		return;
	}
	[[appDelegate currentInstance] saveSearch:searchObj];
	SearchResultsController *src = [SearchResultsController new];
	[self.navigationController pushViewController:src animated:YES];
	[src startSearch:searchObj andGetLocation:searchObj.zip == nil];
	[src release];
*/
}


@end
