//
//  SettingsController.m
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//

#import "SearchResultsController.h"
#import "appDelegate.h"
#import <QuartzCore/CoreAnimation.h>
#import "SettingsController.h"
#import "SettingsView.h"

#define kAdvancedSearchSearcher @"searcher"

@implementation SettingsController

- (id) init
{
	self = [super init];
	if (self != nil) {
		self.title = @"Settings";
		[appDelegate track:@"Settings"];
	}
    
	return self;
}


- (id)initWithRestore:(NSDictionary*)data{
	self = [self init];
	if (self != nil)
	{
		searchObj = [data objectForKey:kAdvancedSearchSearcher];
		[self.view class];//Ensure that the view gets loaded
	}
    
	return self;
}

- (NSDictionary*)getRestoreData{
	NSMutableDictionary* dict = [NSMutableDictionary dictionaryWithCapacity:1];
	if(searchObj == nil)
	{
		//Attempt to get it
		searchObj = ((SettingsView*)self.view).searchObject;
	}
    
	if(searchObj != nil)
	{
		searchObj.firstListing = 1;
		[dict setValue:searchObj forKey:kAdvancedSearchSearcher];
	}
    
	return dict;
}

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	SettingsView *asv = [[SettingsView alloc] initWithFrame:CGRectZero searchObject:searchObj filterMode:NO];
	asv.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
//	asv.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
	asv.target = self;
//	asv.errorCallback = @selector(advSearchError:);
	self.view = asv;
}

- (void)advSearchError:(id)sender{
	[self.navigationController popViewControllerAnimated:YES];
}

/*// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}*/

- (void)search:(id)sender{
	searchObj = ((SettingsView*)self.view).searchObject;

	if (searchObj.dealerLot == 0) {
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Invalid DealerLot"
															message:@"Please Pick a Dealer Lot."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		
		return;
	}
/*
	if([searchObj.make length] < 1)
	{
		[(AdvancedSearchView*)self.view promptMakesAndModels];
		return;
	}
*/    
	[[appDelegate currentInstance] saveSearch:searchObj];
	SearchResultsController *src = [SearchResultsController new];
	[self.navigationController pushViewController:src animated:YES];
	[src startSearch:searchObj];
}

- (void)dealloc {
	searchObj = nil;
}

@end
