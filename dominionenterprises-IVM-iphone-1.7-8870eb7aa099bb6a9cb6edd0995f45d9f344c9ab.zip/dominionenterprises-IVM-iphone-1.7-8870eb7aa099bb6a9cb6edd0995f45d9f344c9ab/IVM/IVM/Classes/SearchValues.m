//
//  SearchValues.m
//  GetAuto.com
//
//  Created by Shaofeng Tu on 6/30/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import "SearchValues.h"

@implementation SearchValues

@synthesize	year;
@synthesize	make;
@synthesize	model;


@end
