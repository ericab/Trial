//
//  VehicleDetails.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/18/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "VehicleDetails.h"


@implementation VehicleDetails

@synthesize	dealerName;
@synthesize	dealerLotKey;
@synthesize	address;
@synthesize	address2;
@synthesize	city;
@synthesize	state;
@synthesize	postal_code;
@synthesize	vin;
@synthesize	vehicle_key;
@synthesize	stockNumber;
@synthesize	titaniumID;
@synthesize	year;
@synthesize	mileage;
@synthesize	price;
@synthesize	make;
@synthesize	model;
@synthesize	body;
@synthesize	transmission;
@synthesize	engine;
@synthesize	options;
@synthesize	trimLevel;
@synthesize	externalColor;
@synthesize internalColor;
@synthesize regularPhotos;
@synthesize	thumbPhotos;
@synthesize	dealerEmail;
@synthesize	dealerPhone;
@synthesize	dealerWebUrl;
@synthesize	certifiedLogoUrl;
@synthesize autoVinUrl;
@synthesize time_created;
@synthesize type;
@synthesize	status;
@synthesize	time_updated;
@synthesize	isNew;


@end
