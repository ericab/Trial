//
//  MarketControlAnalysisController.h
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//
#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"

@class VehicleSearchObject;

@interface MarketControlAnalysisController : UIViewController<UITextFieldDelegate, UIPickerViewDelegate, ItemRestore> {
	VehicleSearchObject *searchObj;
    UIScrollView		*scrollView;
    UITextField *txt_marketsize;
    UITextField *txt_marketaverageprice;
    UITextField *txt_marketaveragemileage;
    UITextField *txt_recommendedprice;
    UITextField *txt_pricerank;
    UITextField *txt_dayssupply;  
    UITextField *txt_dataproviders;
        
@public NSString *str_marketsize;
@public NSString *str_marketaverageprice;
@public NSString *str_marketaveragemileage;
@public NSString *str_recommendedprice;
@public NSString *str_pricerank;
@public NSString *str_dayssupply;
@public NSString *str_appraisalid;
}
@property (nonatomic, strong)   NSMutableArray	*marketPriceTitleArray;
@property (nonatomic, strong)   NSMutableArray	*marketPriceLabelArray;

- (void)advSearchError:(id)sender;
@end
