//
//  AppraisalCustomerDetailsController.m
//  IVM
//
//  Created by Raja Sekhar Nerella on 16/05/12.
//  
//

#import "AppraisalCustomerDetailsController.h"
#import "appDelegate.h"

@implementation AppraisalCustomerDetailsController
@synthesize isAppraisal;
@synthesize appraisalDetailsController;
@synthesize reqType;

static const CGFloat KEYBOARD_ANIMATION_DURATION = 0.3;
static const CGFloat MINIMUM_SCROLL_FRACTION = 0.2;
static const CGFloat MAXIMUM_SCROLL_FRACTION = 0.8;
static const CGFloat PORTRAIT_KEYBOARD_HEIGHT = 216;
static const CGFloat LANDSCAPE_KEYBOARD_HEIGHT = 162;

static const CGFloat EMAIL_MAX_LENGTH = 200;
static const CGFloat MOBILE_MAX_LENGTH = 14;
static const CGFloat PHONE_MAX_LENGTH = 14;
static const CGFloat CITY_MAX_LENGTH = 50;
static const CGFloat ADDRESS_MAX_LENGTH = 250;
static const CGFloat NAME_MAX_LENGTH = 100;
static const CGFloat ZIP_MAX_LENGTH = 6;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
#pragma mark - View lifecycle
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
    stateNames = [NSMutableArray array];
    stateCodes = [NSMutableArray array];
    
     phoneNumberFormatter = [[PhoneNumberFormatter alloc] init];
    
    //set up the reject character set
    NSMutableCharacterSet *numberSet = [[NSCharacterSet decimalDigitCharacterSet] mutableCopy];
    [numberSet formUnionWithCharacterSet:[NSCharacterSet whitespaceCharacterSet]];
    nonNumberSet = [numberSet invertedSet];
    nonCharacterSet = [[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLKMNOPQRSTUVWXYZ0123456789 .,-"] invertedSet];
    
    [self buildStatesList];
    
    UIView *view = [[UIView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    [view setAutoresizingMask:UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth];
   [view setBackgroundColor:[UIColor whiteColor]];
    UIImageView *backgroundImage=  [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];;
    [view addSubview:backgroundImage];
    [view sendSubviewToBack:backgroundImage];
    
    scrollView = [[UIScrollView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    scrollView.scrollEnabled = YES;
    [view addSubview:scrollView];
    
    UIColor *textColor = [UIColor blackColor];
    UIFont *lblFont = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0];
    
    float yOffset = 10.0f;
    
    //Customer
    UILabel *tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Name";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    txt_customer = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_customer.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_customer.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_customer.placeholder = @"Name";
    txt_customer.returnKeyType = UIReturnKeyDone;
    txt_customer.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_customer.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_customer.delegate = self;
    txt_customer.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
   
    [scrollView addSubview:txt_customer];
    
    yOffset += 30.0f;
    
    //Address
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Address";
    [scrollView addSubview:tmpLabel];
   
    yOffset += 20.0f;
    
    txt_customerAddress = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_customerAddress.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_customerAddress.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_customerAddress.placeholder = @"Address";
    txt_customerAddress.returnKeyType = UIReturnKeyDone;
    txt_customerAddress.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_customerAddress.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_customerAddress.delegate = self;
    txt_customerAddress.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_customerAddress];
    
    yOffset += 30.0f;

    //City
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"City";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_city = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_city.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_city.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_city.placeholder = @"City";
    txt_city.returnKeyType = UIReturnKeyDone;
    txt_city.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_city.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_city.delegate = self;
    txt_city.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_city];
    
    yOffset += 30.0f;
    
    //State
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"State";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_state = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_state.borderStyle = UITextBorderStyleRoundedRect;
    txt_state.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_state.placeholder = @"State";
    txt_state.returnKeyType = UIReturnKeyDone;
    txt_state.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_state.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_state.delegate = self;
    txt_state.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    
    [scrollView addSubview:txt_state];
    
    yOffset += 30.0f;

    //Zip
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Zip";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_zip = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_zip.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_zip.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_zip.placeholder = @"Zip";
    txt_zip.returnKeyType = UIReturnKeyDone;
    txt_zip.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_zip.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_zip.delegate = self;
    txt_zip.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_zip.keyboardType=UIKeyboardTypeNumberPad;
    
    [scrollView addSubview:txt_zip];
    
    yOffset += 30.0f;
    
    //Phone
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Phone";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_phone = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_phone.borderStyle = UITextBorderStyleRoundedRect;
    txt_phone.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_phone.placeholder = @"Phone";
    txt_phone.returnKeyType = UIReturnKeyDone;
    txt_phone.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_phone.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_phone.delegate = self;
    txt_phone.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_phone.keyboardType=UIKeyboardTypeNumberPad;
    [scrollView addSubview:txt_phone];
    
    yOffset += 30.0f;
    //Mobile
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Mobile";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_mobile = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_mobile.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_mobile.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_mobile.placeholder = @"Mobile";
    txt_mobile.returnKeyType = UIReturnKeyDone;
    txt_mobile.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_mobile.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_mobile.delegate = self;
    txt_mobile.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_mobile.keyboardType=UIKeyboardTypeNumberPad;
    [scrollView addSubview:txt_mobile];
    
    yOffset += 30.0f;
    
    //Email
    tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
    tmpLabel.font = lblFont;
    tmpLabel.textColor = textColor;
    tmpLabel.backgroundColor = [UIColor clearColor];
    tmpLabel.text = @"Email";
    [scrollView addSubview:tmpLabel];
    
    yOffset += 20.0f;
    
    txt_email = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
    txt_email.borderStyle = UITextBorderStyleRoundedRect;
    
    txt_email.font = [UIFont systemFontOfSize:kDefaultFontSize];
    txt_email.placeholder = @"Email";
    txt_email.returnKeyType = UIReturnKeyDone;
    txt_email.clearButtonMode = UITextFieldViewModeWhileEditing;
    txt_email.autocorrectionType = UITextAutocorrectionTypeNo;
    txt_email.delegate = self;
    txt_email.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    txt_email.keyboardType=UIKeyboardTypeEmailAddress;
    [scrollView addSubview:txt_email];
    
    txt_customer.text = [str_customer isEqualToString:@"n/a"] && isAppraisal ? @"":str_customer;
    txt_customerAddress.text = [str_customerAddress isEqualToString:@"n/a"] && isAppraisal ? @"":str_customerAddress;
    txt_city.text = [str_city isEqualToString:@"n/a"] && isAppraisal ? @"":str_city;
    txt_state.text = [str_state isEqualToString:@"n/a"] && isAppraisal ? @"":str_state;
    txt_zip.text = [str_zip isEqualToString:@"n/a"] && isAppraisal ? @"":str_zip;
    txt_phone.text = [str_phone isEqualToString:@"n/a"] && isAppraisal ? @"":[phoneNumberFormatter format:str_phone withLocale:@"us"];
    txt_mobile.text = [str_mobile isEqualToString:@"n/a"] && isAppraisal ? @"":[phoneNumberFormatter format:str_mobile withLocale:@"us"];
    txt_email.text = [str_email isEqualToString:@"n/a"] && isAppraisal ? @"":str_email;

    //Picker View Creation		
    _pickerOneDone = [UIToolbar new];
    [_pickerOneDone sizeToFit];
    _pickerOneDone.frame = CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 215.0f - 42.0f, [UIScreen mainScreen].applicationFrame.size.width, _pickerOneDone.frame.size.height);
    _pickerOneDone.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
    _pickerOneDone.barStyle = UIBarStyleBlack;
    _pickerOneDone.contentMode = UIViewContentModeRight;
    UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(pickerDone:)];
    UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [_pickerOneDone setItems:[NSArray arrayWithObjects:spacer, done, nil] animated:NO];

    //DealerLot/Year Picker
    pickerOne = [[UIPickerView alloc] initWithFrame:CGRectMake(0.0f, [UIScreen mainScreen].applicationFrame.size.height - 215.0f, [UIScreen mainScreen].applicationFrame.size.width, 0.0f)];
    pickerOne.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    pickerOne.showsSelectionIndicator = YES;
    pickerOne.delegate = self;
    pickerOne.dataSource = self;
    
    txt_state.inputView = pickerOne;
    txt_state.inputAccessoryView = _pickerOneDone;
    
    self.view = view;
    if(isAppraisal)
    {
      UIBarButtonItem *saveBtn = [[UIBarButtonItem alloc] initWithTitle:@"Save" style:UIBarButtonItemStyleDone target:self action:@selector(saveCustomer)];
      saveBtn.style = UIBarButtonItemStyleBordered;
    
      self.navigationItem.rightBarButtonItem = saveBtn;
    }
}
// To load the Scroll View
- (void)viewWillAppear:(BOOL)animated {
   	[super viewWillAppear:animated];
	
	[[NSNotificationCenter defaultCenter] addObserver: self 
											 selector: @selector(keyboardWasShown:)
												 name: UIKeyboardDidShowNotification 
											   object: nil];
	
    [[NSNotificationCenter defaultCenter] addObserver: self
											 selector: @selector(keyboardWasHidden:)
												 name: UIKeyboardDidHideNotification 
											   object: nil];
	
   	scrollView.frame = CGRectMake(0, 0, 320, 460);
	scrollView.contentSize = CGSizeMake(320, 500);
	
}
-(void) viewWillDisappear:(BOOL)animated {
	[[NSNotificationCenter defaultCenter]
	 removeObserver:self];
}

-(void) keyboardWasShown: (NSNotification *)notif {
    return;
}

-(void) keyboardWasHidden: (NSNotification *)notif {
        return;
    }
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    // add observer for the respective notifications (depending on the os version)
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(keyboardDidShow:) 
                                                     name:UIKeyboardDidShowNotification 
                                                   object:nil];		
    } else {
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(keyboardWillShow:) 
                                                     name:UIKeyboardWillShowNotification 
                                                   object:nil];
    }
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
#pragma mark UITextField delegate methods
- (BOOL)textFieldShouldClear:(UITextField *)textField {
	return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if(isAppraisal)
    {
    if (textField == txt_state)
        [self showPicker:textField];
    return YES;
    }
    return NO;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [latsetTextField resignFirstResponder];
    latsetTextField=nil;
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if(isAppraisal)
    {
        if ((latsetTextField != nil) && (textField.keyboardType == UIKeyboardTypeNumberPad)) {
            // Add the Done button to keyboard
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
                if(doneButton)
                {
                    [doneButton removeFromSuperview];
                    doneButton = nil;
                }
                [self addButtonToKeyboard];
            }
        }
        else {
            [doneButton removeFromSuperview];
            doneButton = nil;
        }
    
    latsetTextField = textField;
    
    CGRect textFieldRect = [scrollView convertRect:textField.bounds fromView:textField];
    CGRect viewRect = [scrollView convertRect:scrollView.bounds fromView:scrollView];
	
    CGFloat midline = textFieldRect.origin.y + 0.5 * textFieldRect.size.height;
    CGFloat numerator =
	midline - viewRect.origin.y
	- MINIMUM_SCROLL_FRACTION * viewRect.size.height;
    CGFloat denominator =
	(MAXIMUM_SCROLL_FRACTION - MINIMUM_SCROLL_FRACTION)
	* viewRect.size.height;
    CGFloat heightFraction = numerator / denominator;
	
    if (heightFraction < 0.0)
    {
        heightFraction = 0.0;
    }
    else if (heightFraction > 1.0)
    {
        heightFraction = 1.0;
    }
	
    UIInterfaceOrientation orientation =
	[[UIApplication sharedApplication] statusBarOrientation];
    if (orientation == UIInterfaceOrientationPortrait ||
        orientation == UIInterfaceOrientationPortraitUpsideDown)
    {
        animatedDistance = floor(PORTRAIT_KEYBOARD_HEIGHT * heightFraction);
    }
    else
    {
        animatedDistance = floor(LANDSCAPE_KEYBOARD_HEIGHT * heightFraction);
    }
	
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y -= animatedDistance;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [scrollView setFrame:viewFrame];
    [UIView commitAnimations];
    }
    latsetTextField=textField;
}
-(void) textFieldDidEndEditing:(UITextField *)textField
{
    CGRect viewFrame = scrollView.frame;
    viewFrame.origin.y += animatedDistance;
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:KEYBOARD_ANIMATION_DURATION];
    [scrollView setFrame:viewFrame];
    [UIView commitAnimations];
}
- (void)addButtonToKeyboard {
	// create custom button
	doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
	doneButton.frame = CGRectMake(0, 163, 106, 53);
	doneButton.adjustsImageWhenHighlighted = NO;
	if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.0) {
		[doneButton setImage:[UIImage imageNamed:@"DoneUp3.png"] forState:UIControlStateNormal];
		[doneButton setImage:[UIImage imageNamed:@"DoneDown3.png"] forState:UIControlStateHighlighted];
	} else {        
		[doneButton setImage:[UIImage imageNamed:@"DoneUp.png"] forState:UIControlStateNormal];
		[doneButton setImage:[UIImage imageNamed:@"DoneDown.png"] forState:UIControlStateHighlighted];
	}
	[doneButton addTarget:self action:@selector(doneButton:) forControlEvents:UIControlEventTouchUpInside];
	
    // locate keyboard view
	UIWindow* tempWindow = [[[UIApplication sharedApplication] windows] objectAtIndex:1];
	UIView* keyboard;
	for(int i=0; i<[tempWindow.subviews count]; i++) {
		keyboard = [tempWindow.subviews objectAtIndex:i];
		// keyboard found, add the button
		if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
			if([[keyboard description] hasPrefix:@"<UIPeripheralHost"] == YES)
				[keyboard addSubview:doneButton];
		} else {
			if([[keyboard description] hasPrefix:@"<UIKeyboard"] == YES)
				[keyboard addSubview:doneButton];
		}
	}
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
	BOOL result = NO; //default to reject
        
    if (textField == txt_state) {
        NSString* newText = [textField.text stringByReplacingCharactersInRange:range withString:string];
         if([stateCodes containsObject:newText])
         {
            result = YES;
         }
    }
    else
    {
    if (textField.keyboardType == UIKeyboardTypeNumberPad ) {
        if(textField == txt_zip)
        {
            if([string length] == 0){ //backspace
                result = YES;
            }
            else{
                if([[string componentsSeparatedByCharactersInSet:nonNumberSet] componentsJoinedByString: @""].length == string.length){
                    NSString* newText = [textField.text stringByReplacingCharactersInRange:range withString:string];
                    if(textField == txt_zip && newText.length<=ZIP_MAX_LENGTH)
                    {
                        result = YES;
                    }
                    else
                        result = NO;
                }
            }
        }
        else if(textField == txt_phone || textField == txt_mobile)
        {
            if([string length] == 0){ //backspace
                result = YES;
            }
            else{
                if([[string componentsSeparatedByCharactersInSet:nonNumberSet] componentsJoinedByString: @""].length == string.length){
                    NSLog(@"%@",[phoneNumberFormatter strip:textField.text ]);
                    
                    NSString* newText = [textField.text stringByReplacingCharactersInRange:range withString:string];
                    if(textField == txt_phone && newText.length<=PHONE_MAX_LENGTH)
                    {
                        NSLog(@"%@%@",[phoneNumberFormatter format:newText withLocale:@"us"],newText);
                        [textField setText:[phoneNumberFormatter format:newText withLocale:@"us"]];
                    }
                    else if(textField == txt_mobile && newText.length<=MOBILE_MAX_LENGTH)
                    {
                        NSLog(@"%@",[phoneNumberFormatter format:newText withLocale:@"us"]);
                        [textField setText:[phoneNumberFormatter format:newText withLocale:@"us"]];
                    }
                }
            }
        }
         else 
            result=YES;
    }
    else
    {
        result=NO;
        if(textField == txt_email)
        {
            if([string length] == 0){ //backspace
                result = YES;
            }
            else{
                if ([[txt_email.text componentsSeparatedByString:@"@"] count] > 1) {
                    if([[string componentsSeparatedByCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:[ALPHA_NUMERIC stringByAppendingString:@".-"]] invertedSet]] componentsJoinedByString: @""].length == string.length){
                        result = YES;
                    }
                    
                } else {
                    if([[string componentsSeparatedByCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:[ALPHA_NUMERIC stringByAppendingString:@".!#$%&'*+-/=?^_`{|}~@"]] invertedSet]] componentsJoinedByString: @""].length ==string.length){
                        result = YES;
                    }
                }
                if(result)
                {
                    NSString* newText = [txt_email.text stringByReplacingCharactersInRange:range withString:string];
                    if (newText.length<=EMAIL_MAX_LENGTH )
                        result = YES;
                    else
                        result =NO;

                }
            }
        }
        else
        {
        if([string length] == 0){ //backspace
            result = YES;
        }
        else{
            if([[string componentsSeparatedByCharactersInSet:nonCharacterSet] componentsJoinedByString: @""].length == string.length){
                
                if(textField == txt_customer || textField == txt_customerAddress || textField == txt_city)
                {
                    NSString* newText = [textField.text stringByReplacingCharactersInRange:range withString:string];
                if(textField == txt_customer && newText.length<=NAME_MAX_LENGTH)
                {
                   result = YES; 
                }
                else if(textField == txt_customerAddress && newText.length<=ADDRESS_MAX_LENGTH)
                {
                    result = YES;
                }
                else if(textField == txt_city && newText.length<=CITY_MAX_LENGTH)
                {
                    result = YES;
                }
                else
                    result = NO;
                }
                else
                    result = YES;
            }
        }
        }
    }
    }
    //always return no since we are manually changing the text field
	return result;
}
- (void)keyboardWillShow:(NSNotification *)note {
	// if clause is just an additional precaution, you could also dismiss it
    if (((UITextField *)(latsetTextField)).keyboardType == UIKeyboardTypeNumberPad) {
        if ([[[UIDevice currentDevice] systemVersion] floatValue] < 3.2) {
            if(doneButton)
            {
                [doneButton removeFromSuperview];
                doneButton = nil;
            }
            [self addButtonToKeyboard];
        }
    }
}
- (void)keyboardDidShow:(NSNotification *)note {
    
    if(doneButton)
    {
        [doneButton removeFromSuperview];
        doneButton = nil;
    }
	// if clause is just an additional precaution, you could also dismiss it
	if (((UITextField *)(latsetTextField)).keyboardType == UIKeyboardTypeNumberPad) {
        // Add the Done button in keyboard
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 3.2) {
            [self addButtonToKeyboard];
        }
    }
}
- (void)doneButton:(id)sender {
    if(doneButton)
    {
    [doneButton removeFromSuperview];
    doneButton = nil;
    }
    [latsetTextField resignFirstResponder];
    latsetTextField=nil;
}
- (void)pickerDone:(id)sender{
	[latsetTextField resignFirstResponder];
    latsetTextField = nil;
}
-(void) handleResponseForQuery:(NSMutableDictionary *)response
{
    appraisalDetailsController->asv->str_appraisalid = [response objectForKey:@"responseString"];
    [self alertUser:@"" title:[NSString stringWithFormat: @"Appraisal updated successfully."]];
}
-(void) saveCustomer
{
    [latsetTextField resignFirstResponder];
    str_customer = txt_customer.text;
    str_customerAddress = txt_customerAddress.text;
    str_city = txt_city.text  ;
    str_state = txt_state.text  ;
    str_zip = txt_zip.text  ;
    str_phone = [phoneNumberFormatter strip:txt_phone.text] ;
    str_mobile = [phoneNumberFormatter strip:txt_mobile.text]  ;
    str_email = txt_email.text  ;
    BOOL emailVaild=YES;
    if(![str_email isEqualToString:@""])
    {
        emailVaild=[self validateEmailWithString:str_email];
    }
    if(!emailVaild)
    {
        [self alertUser:@"Email-id is Invaild." title:[NSString stringWithFormat: @"Invaild"]];
    }
    else
    {
    if (loadingView == nil) {
        loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
    }
    reqType=10;
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                                [NSNumber numberWithInt:reqType],@"reqtype",
                                appraisalDetailsController->asv->str_appraisalid,@"appraisalid",
                                @"Active",@"status",
                                str_customer,@"customer",
                                str_customerAddress,@"customeraddress",
                                str_city,@"city",
                                str_state,@"state",
                                str_zip,@"zip",
                                str_phone,@"phone",
                                str_mobile,@"mobile",
                                str_email,@"email",
                                appraisalDetailsController->asv->str_vin,@"vin",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_year intValue]],@"year",
                                appraisalDetailsController->asv->str_make,@"make",
                                appraisalDetailsController->asv->str_model,@"model",
                                appraisalDetailsController->asv->str_trim,@"trim",
                                appraisalDetailsController->asv->str_style,@"style",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_mileage intValue]] ,@"mileage",
                                appraisalDetailsController->asv->str_titianiumKey,@"titaniumid",
                                appraisalDetailsController->asv->str_exteriorcolor,@"exteriorcolor",
                                appraisalDetailsController->asv->str_interiorcolor,@"interiorcolor",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_appraisedvalue intValue]] ,@"appraisedvalue",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_expectedsaleprice intValue]],@"expectedsaleprice",
                                appraisalDetailsController->asv->str_notes,@"notes",
                                appraisalDetailsController->asv->str_profitobective,@"profitobjective",
                                appraisalDetailsController->asv->str_recondtioning,@"reconditioning",
                                appraisalDetailsController->asv->str_datasalesperson,@"salesperson",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_daysupply intValue]] ,@"dayssupply",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_marketaveragemileage intValue]] ,@"marketaveragemileage",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_marketaverageprice intValue]] ,@"marketaverageprice",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_marketsize intValue]] ,@"marketsize",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_pricerank intValue]],@"pricerank",
                                [NSNumber numberWithInt:[appraisalDetailsController->asv->str_recommendedprice intValue]] ,@"recommendedprice",
                                self,@"delegate",
                                nil];
    
    IVMMobileServices *ws = [[IVMMobileServices alloc] init];
    [ws initialize:dic];
    [ws callWSWithQuery:dic];
    }
}
- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:message
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}
#pragma mark alertview delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if([alertView.title isEqualToString:@"Invaild"])
    {
        [alertView dismissWithClickedButtonIndex:buttonIndex animated:YES];
    }
    else
    {
    if(reqType == 10 && ![alertView.title isEqualToString:@"Error"]) 
    {
        if (loadingView != nil) {
            [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
            loadingView = nil;
        }
        reqType=0;
        
        self.appraisalDetailsController.refreshDataOn=YES;
        [self.navigationController popToViewController:appraisalDetailsController animated:YES];
    }
    else {
    if (loadingView != nil) {
        [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
        loadingView = nil;
    }
    }
    }
}

- (void)buildStatesList
{
    // static arrays of states , exterior colors and interior colors as web services are not available
    stateNames = [NSMutableArray arrayWithObjects:@"Alabama",  
                  @"Alaska",  
                  @"Arizona",  
                  @"Arkansas",  
                  @"California",  
                  @"Colorado",  
                  @"Connecticut",  
                  @"Delaware",  
                  @"District Of Columbia",  
                  @"Florida",  
                  @"Georgia",  
                  @"Hawaii",  
                  @"Idaho",  
                  @"Illinois",  
                  @"Indiana",  
                  @"Iowa",  
                  @"Kansas",  
                  @"Kentucky",  
                  @"Louisiana",  
                  @"Maine",  
                  @"Maryland",  
                  @"Massachusetts",  
                  @"Michigan",  
                  @"Minnesota",  
                  @"Mississippi",  
                  @"Missouri",  
                  @"Montana",
                  @"Nebraska",
                  @"Nevada",
                  @"New Hampshire",
                  @"New Jersey",
                  @"New Mexico",
                  @"New York",
                  @"North Carolina",
                  @"North Dakota",
                  @"Ohio",  
                  @"Oklahoma",  
                  @"Oregon",  
                  @"Pennsylvania",  
                  @"Rhode Island",  
                  @"South Carolina",  
                  @"South Dakota",
                  @"Tennessee",  
                  @"Texas",  
                  @"Utah",  
                  @"Vermont",  
                  @"Virginia",  
                  @"Washington",  
                  @"West Virginia",  
                  @"Wisconsin",  
                  @"Wyoming", nil];
    
    stateCodes = [NSMutableArray arrayWithObjects:@"AL",  
                  @"AK",  
                  @"AZ",  
                  @"AR",  
                  @"CA",  
                  @"CO",  
                  @"CT",  
                  @"DE",  
                  @"DC",  
                  @"FL",  
                  @"GA",  
                  @"HI",  
                  @"ID",  
                  @"IL",  
                  @"IN",  
                  @"IA",  
                  @"KS",  
                  @"KY",  
                  @"LA",  
                  @"MEe",  
                  @"MD",  
                  @"MA",  
                  @"MI",  
                  @"MN",  
                  @"MS",  
                  @"MO",  
                  @"MT",
                  @"NE",
                  @"NV",
                  @"NH",
                  @"NJ",
                  @"NM",
                  @"NY",
                  @"NC",
                  @"ND",
                  @"OH",  
                  @"OK",  
                  @"OR",  
                  @"PA",  
                  @"RI",  
                  @"SC",  
                  @"SD",
                  @"TN",  
                  @"TX",  
                  @"UT",  
                  @"VT",  
                  @"VA",  
                  @"WA",  
                  @"WV",  
                  @"WI",  
                  @"WY", nil];
}

#pragma mark UIPickerView delegate methods

// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    if([pickerView isEqual: pickerOne]) {  
        return 1;
    }
    return 0;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if([pickerView isEqual: pickerOne]) { 
        return oneDataSource.count ;
    }
    return 0;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if([pickerView isEqual: pickerOne]) {
        return [oneDataSource objectAtIndex:row] ;
    }
    return 0;
}
- (void)pickerView:(UIPickerView *)thePickerView 
      didSelectRow:(NSInteger)row 
       inComponent:(NSInteger)component {
        if(row > 0)
                [latsetTextField  setText:[stateCodes objectAtIndex:row-1]] ;
            else
                [latsetTextField setText:@""];
            //If the user selected the state as "District Of Columbia", the city should be "Washington".
            if ([txt_state.text isEqualToString:@"DC"]) {
                txt_city.text = @"Washington";
            }
}
- (void)showPicker:(id)sender{
    int row1 = 0;
    oneDataSource =[NSMutableArray arrayWithArray:stateNames] ;
    [oneDataSource insertObject:@" " atIndex:0];
    if([txt_state.text length] > 0)
       row1=[stateCodes indexOfObject:txt_state.text]+1;
    [pickerOne reloadComponent:0];
    [pickerOne selectRow:row1 inComponent:0 animated:NO];
    [UIView beginAnimations:@"FadeIn" context:nil];
    [UIView setAnimationDuration:0.7];
    _pickerOneDone.alpha = 1.0;
    pickerOne.alpha = 1.0;
    [UIView commitAnimations];
}
- (void)pickerCancel:(id)sender{
	[UIView beginAnimations:@"FadeOut" context:nil];
	[UIView setAnimationDuration:0.7];
	_pickerOneDone.alpha = 0.0;
	pickerOne.alpha = 0.0;
	[UIView commitAnimations];
    latsetTextField=nil;
}
- (BOOL)validateEmailWithString:(NSString*)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}
@end
