//
//  WebViewController.m
//  TraderOnline
//
//  Created by Raja Sekhar Nerella  on 9/14/09.
//  
//
//  Modified by Raja Sekhar Nerella on 04/12/12.
//  Changes: 1. Meaningful alert message responses for Brochure, Video, Twitter webservices instead of generic repsonse.
//           2. Ok changed to OK in alert message

#import "WebViewController.h"
#import <QuartzCore/CoreAnimation.h>
#import "appDelegate.h"
#import "DetailActions.h"


@implementation WebViewController
@synthesize webView, _url, _html, _adId, _usrToken;


- (id)initWithString:(NSString *)url
{
    self = [super init]; 
    if (self != nil) 
    {
		 _url = url;
		 
		 webView.delegate = self;
		 mData = [NSMutableData data];

		 _mobileServices = [[IVMMobileServices alloc] init];
		 _mobileServices.delegate = self;
		 
		 _usrToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];
		 _actData = [DetailActions new];
    }
    return self;
}

- (id)initWithHTML:(NSString *)html adId:(NSString *)adId
{
    self = [super init]; 
    if (self != nil) 
	{
		self._html = html;
		self._adId = adId;
		conn = nil;
		webView.delegate = self;
		mData = [NSMutableData data];

		_mobileServices = [[IVMMobileServices alloc] init];
		_mobileServices.delegate = self;
		
		_usrToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];
		_actData = [DetailActions new];
	}
	return self;
}

/*
- (void)viewDidLoad {
	
	NSString *urlAddress = @"http://www.google.com";
	
	//Create a URL object.
	NSURL *url = [NSURL URLWithString:urlAddress];
	
	//URL Requst Object
	NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
	
	//Load the request in the UIWebView.
	[webView loadRequest:requestObj];
}
*/
- (void)loadView
{
	
	// the base view for this view controller
	UIView *contentView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	
	contentView.backgroundColor = [UIColor blueColor];
	
	// important for view orientation rotation
	contentView.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
	self.view = contentView;
	self.view.autoresizesSubviews = YES;

	//create a frame that will be used to size and place the web view
	CGRect webFrame = [[UIScreen mainScreen] applicationFrame];
	
	webFrame.origin.y -= 20.0; // shift the display up so that it covers the default open space from the content view
	UIWebView *aWebView = [[UIWebView alloc] initWithFrame:webFrame];
	self.webView = aWebView;

	aWebView.scalesPageToFit = YES;
	aWebView.autoresizesSubviews = YES;
	aWebView.autoresizingMask=(UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth);
	aWebView.dataDetectorTypes = UIDataDetectorTypeNone; 

	//set the web view and acceleration delagates for the web view to be itself
	[aWebView setDelegate:self];

	if (_url)
	{
		NSURL *urld = [NSURL URLWithString:_url];
		
		//URL Requst Object
		NSURLRequest *aRequest = [NSURLRequest requestWithURL:urld];

		//load the index.html file into the web view.
		[aWebView loadRequest:aRequest];
			
		//add the web view to the content view
		[contentView addSubview:webView];

	}
	if (_html)
	{
		NSString *path = [[NSBundle mainBundle] bundlePath];
		NSURL *baseURL = [NSURL fileURLWithPath:path];

        aWebView.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
//        aWebView.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
		
		//add the web view to the content view
		[contentView addSubview:webView];

		aWebView.scalesPageToFit = NO;
		aWebView.autoresizesSubviews = NO;
		
		[webView loadHTMLString:_html baseURL:baseURL];  
	}
	
	CGRect frame = CGRectMake(150.0, 210.0, 25.0, 25.0);
	progressView = [[UIActivityIndicatorView alloc] initWithFrame:frame];
	progressView.activityIndicatorViewStyle = UIActivityIndicatorViewStyleGray;
	progressView.autoresizingMask = (UIViewAutoresizingFlexibleLeftMargin |
                                     UIViewAutoresizingFlexibleRightMargin |
                                     UIViewAutoresizingFlexibleTopMargin |
                                     UIViewAutoresizingFlexibleBottomMargin);

	[contentView addSubview:progressView];
	aWebView = nil;
	contentView = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations.
	return YES;
}
- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation
{
	
	if(fromInterfaceOrientation == UIInterfaceOrientationPortrait)
	{
		NSString* result = [webView stringByEvaluatingJavaScriptFromString:@"rotate(0)"];
		//NSString a = *result;
		NSLog(@"%@",result);
		
	}
	else
	{
		[webView stringByEvaluatingJavaScriptFromString:@"rotate(1)"];
	}
	
	//[self.webView sizeToFit];
	//CGRect curBounds = [[UIScreen mainScreen] bounds];
	//[self.webView setBounds:self.origViewRectangle];
	//[[UIScreen mainScreen] bounds]]
	//NSLog(@"orienting");
}

- (void) accelerometer:(UIAccelerometer*)accelerometer didAccelerate:(UIAcceleration*)acceleration
{
	
	NSString* javaScriptCall = [NSString stringWithFormat:@"accelerate(%f, %f, %f)", acceleration.x, acceleration.y, acceleration.z];
	
	[webView stringByEvaluatingJavaScriptFromString:javaScriptCall];
	//Use a basic low-pass filter to only keep the gravity in the accelerometer values
	//_accelerometer[0] = acceleration.x * kFilteringFactor + _accelerometer[0] * (1.0 - kFilteringFactor);
	//_accelerometer[1] = acceleration.y * kFilteringFactor + _accelerometer[1] * (1.0 - kFilteringFactor);
	//_accelerometer[2] = acceleration.z * kFilteringFactor + _accelerometer[2] * (1.0 - kFilteringFactor);
}

- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview.
	// Release anything that's not essential, such as cached data.
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
	NSLog(@"XXXXXXXXXXXX An error happened during load");
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
//	NSLog(@"loading started");

	[progressView startAnimating];
	progressView.hidden = NO;
	
//	self.navigationItem.leftBarButtonItem.enabled = NO;
//	[dismissButton release];

	
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
//	NSLog(@"finished loading");
    
	[progressView stopAnimating];
	progressView.hidden = YES;
	
	self.navigationItem.leftBarButtonItem.enabled = YES;

}

- (BOOL)webView:(UIWebView *)webbyView shouldStartLoadWithRequest:(NSURLRequest *)request 
 navigationType:(UIWebViewNavigationType)navigationType 
{
	
//	NSLog(@"debug in webView 00");
	
	NSString *requestString = [[request URL] absoluteString];
	NSArray *components = [requestString componentsSeparatedByString:@":"];
	
//	NSLog(@"debug in webView 00 [components count] = %d", [components count]);
	
	if ([components count] > 1 && 
		[(NSString *)[components objectAtIndex:0] isEqualToString:@"objc"]) 
	{
//		NSLog(@"debug in webView 01 [components count] = %d", [components count]);
//		NSLog(@"debug in webView 01 [components count 1] = %@", [components objectAtIndex:1]);
		
		if([(NSString *)[components objectAtIndex:1] isEqualToString:@"submit"]) 
		{
//			NSLog(@"debug in webView 01 [components count 1] = %@", [components objectAtIndex:1]);
//			NSLog(@"debug in webView 01 [components count 2] = %@", [components objectAtIndex:2]);
			
			if([(NSString *)[components objectAtIndex:2] isEqualToString:@"brochure"]) 
			{
				_actData.email = [[components objectAtIndex:3] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
				_actData.comments = [[components objectAtIndex:4] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
				_actData.vehicleKey = [_adId intValue];
				_actData.usrToken = _usrToken;
				_actData.actionNumber = _BROCHURE;
				
				[_mobileServices actionWebServices:_actData];
			}
			else if([(NSString *)[components objectAtIndex:2] isEqualToString:@"video"])
			{
				_actData.email = [[components objectAtIndex:3] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
				_actData.vehicleKey = [_adId intValue];
				_actData.usrToken = _usrToken;
				_actData.actionNumber = _VIDEO;
				[_mobileServices actionWebServices:_actData];
			}
			else 
			{
				_actData.comments = [[components objectAtIndex:3] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
				_actData.vehicleKey = [_adId intValue];
				_actData.usrToken = _usrToken;
				_actData.actionNumber = _TWITTER;
				[_mobileServices actionWebServices:_actData];
			}

		}

		if([(NSString *)[components objectAtIndex:1] isEqualToString:@"reset"]) 
		{
			// reload with default data
			NSString *path = [[NSBundle mainBundle] bundlePath];
			NSURL *baseURL = [NSURL fileURLWithPath:path];
			
			[webbyView loadHTMLString:_html baseURL:baseURL];  
			
		}
	
		return NO;
	}
	
	return YES; // Return YES to make sure regular navigation works as expected.
}

- (void)sendDataToWebService:(NSString *)name email:(NSString *)email phone:(NSString *)phone subject:(NSString *)subj body:(NSString *)comments
{
	NSString *ABASEURL;
	NSMutableString *postData;
	
		[appDelegate track:@"Email Seller"];
		ABASEURL = @"http://api.traderonline.com/ad/emailSeller?xml=";
		
		postData = [NSMutableString stringWithString:@"<TOLData><adId>"];
		
		[postData appendString:_adId];
		
		[postData appendString:@"</adId><customerName>"];
	
		[postData appendString:name];
	
		[postData appendString:@"</customerName><customerEmail>"];
		[postData appendString:email];
		[postData appendString:@"</customerEmail><customerPhone>"];
		[postData appendString:phone];
		[postData appendString:@"</customerPhone><emailSubject>"];
		[postData appendString:subj];
		[postData appendString:@"</emailSubject><emailBody>"];
		[postData appendString:comments];
		[postData appendString:@"</emailBody></TOLData>"];
		

			
	// build properly formatted URL
	CFStringRef preprocessedStr = CFURLCreateStringByReplacingPercentEscapesUsingEncoding(kCFAllocatorDefault, (__bridge CFStringRef)postData, CFSTR(""), kCFStringEncodingUTF8);
	CFStringRef urlString = CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, preprocessedStr, NULL, CFSTR("/"), kCFStringEncodingUTF8);

	NSString *url = [ABASEURL stringByAppendingString:(__bridge NSString *)urlString];
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
	
	// log to console to help testing...
	NSLog(@"%@",url);
	NSLog(@"%@%@",ABASEURL,postData);	
	
	[request setValue:@"gzip" forHTTPHeaderField:@"Accept-Encoding"];
	[request setValue:@"iPhone" forHTTPHeaderField:@"USER AGENT"];
		
	
	conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	NSLog(@"************ connection HTTP Request %@", (NSString *)[request allHTTPHeaderFields]);

	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Email Sent"
														message:@"Email was successfully sent to the seller!" 
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	
	
	[alertView show];
		
	NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
	NSLog(@"XML Contents:\r\n%@", contents);
	CFRelease(preprocessedStr);
	CFRelease(urlString);
}
- (void)alertView:(UIAlertView *)inAlertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	inAlertView.delegate = nil; //Changed Apr-12-2011

	[self.navigationController popViewControllerAnimated:YES];
}

- (void)dismissAction:(id)sender
{
//	UIViewController *caller;
	self.navigationItem.leftBarButtonItem.enabled = YES;
	[self.navigationController popViewControllerAnimated:YES];
}

#pragma mark NSURLConnection delegate methods
- (void) connection:(NSURLConnection *)urlconn didReceiveResponse:(NSURLResponse *)response 
{
	NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
	NSDictionary *httpResponseHeaderFields = [httpResponse
											  allHeaderFields];
	NSLog(@"Connection did receive response: %@", httpResponseHeaderFields);
	
	[mData setLength:0];
}

- (void) connection:(NSURLConnection *)urlconn didReceiveData:(NSData *)data 
{

    [mData appendData:data];
	NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];

	
	NSLog(@"Connection did receive data: %@", contents);
	
}

- (void) connectionDidFinishLoading:(NSURLConnection *)urlconn 
{
//	[self performSelector:complete];
	
}

- (void) connection:(NSURLConnection*)urlconn didFailWithError:(NSError*)error
{
	NSString *errorString = [error localizedFailureReason];
	NSLog(@"Connection did Fail With Error: %@", errorString);
	
	NSString *contents = [[NSString alloc] initWithData:mData encoding:NSUTF8StringEncoding];
	NSLog(@"XML Contents:\r\n%@", contents);
	
//	[self performSelector:complete];
	
}

#pragma mark MobileSearch
- (void) ActionWebServicesComplete:(NSString*)actResult {
//	if(![actResult isEqualToString:@"Success"])
	{
        if(_actData.actionNumber == _BROCHURE)
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Sending Brochure..."
															message:actResult 
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
           [alertView show];
        }
        else if (_actData.actionNumber == _VIDEO) //_actData.actionNumber = _VIDEO
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Sending Video..."
															message:actResult 
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
           [alertView show];            
        }
        else if (_actData.actionNumber == _TWITTER)
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Posting to Twitter..."
															message:actResult 
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
           [alertView show];
        }
		return;
	}
}

- (void)dealloc
{
	webView.delegate = nil;
	
	mData = nil;
	progressView = nil;
}

@end