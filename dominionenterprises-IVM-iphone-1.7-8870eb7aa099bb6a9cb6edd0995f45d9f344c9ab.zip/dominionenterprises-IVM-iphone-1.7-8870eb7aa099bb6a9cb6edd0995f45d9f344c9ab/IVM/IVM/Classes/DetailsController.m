//
//  DetailsController.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 12/1/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//
//  Modified by Raja Sekhar Nerella on 04/12/12.
//  Changes: 1. Changed the default text and notes box text for Brochure, Video, Twitter pages.

#import "DetailsController.h"
#import "appDelegate.h"
#import "IVM.h"
//#import "SlideShowViewController.h"
#import "SlideViewController.h"
#import "NetImageView.h"
//#import "LocationController.h"
#import "DetailsCell.h"
#import <QuartzCore/CoreAnimation.h>
#import "ModifyViewController.h"
#import "WebViewController.h"
#import "CameraViewController.h"


#define kVKey		@"vk"
#define kHasPhoto	@"hasPhoto"

@interface DetailsController()
- (void) populateFields;
- (void) prePopulateFields;
//- (void)sendVideo:(id)sender;
//- (void)emailAgent:(id)sender;
- (id) objectFrom:(NSArray*)obj atIndex:(NSUInteger)index;
@end


@implementation DetailsController

@synthesize actionSheet;
@synthesize zoominoutModalViewController;
@synthesize imageFrame;


const static NSString* emailFriend =	@"Email A Friend";
const static NSString* sendVideo =		@"Send Video";
const static NSString* sendBrochure =	@"Send Brochure";
const static NSString* postTwitter =	@"Post to Twitter";
//const static NSString* viewMap =		@"View on Map";

-(id)initWithRestore:(NSDictionary*)data{
//	if(self = [self initWithListing:nil andImage:nil andPhotos:NO])
	self = [self initWithListing:nil andImage:nil andPhotos:YES];
	if(self != nil)
	{
		[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
		activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
		activity.hidesWhenStopped = YES;
		activity.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
		[activity startAnimating];
		
		_preListing = [[VehicleResult alloc] init];
		_preListing.vehicle_key = [(NSNumber*)[data valueForKey:kVKey] intValue];
//		_preListing.latitude = [(NSNumber*)[data valueForKey:@"lat"] floatValue];
//		_preListing.longitude = [(NSNumber*)[data valueForKey:@"lon"] floatValue];

		hasPhotos = [(NSNumber*)[data valueForKey:kHasPhoto] boolValue];;

		[_mobileServices getVehicleDetailsByToken:_preListing.vehicle_key withToken:_userToken];
	}
	
	return self;
}

-(id)initWithListing:(VehicleResult*)listing andImage:(UIImage*)image andPhotos:(bool)hasPhoto {
	self = [super init];
	if(self != nil)
	{
		_preListing = listing;
		_preImage = image;
		hasData = _preListing != nil;
		
		_slideImages = [NSMutableArray array];
		_options = [NSMutableArray arrayWithCapacity:5];
		_mobileServices = [[IVMMobileServices alloc] init];
		_mobileServices.delegate = self;
		
		_vOptionsHeight = 0.0f;
		viewLoaded = NO;
		hasPhotos = hasPhoto;
		
		_userToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];
		
		self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(styleAction:)];
		self.navigationItem.rightBarButtonItem.enabled = NO;
		self.title = @"Vehicle Details";
		
		if(hasData)
		{
			[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
			[_mobileServices getVehicleDetailsByToken:_preListing.vehicle_key withToken:_userToken];
		}
		
		[appDelegate track:@"Details"];
	}
	return self;
}

-(id)initWithDetailsListing:(VehicleDetails*)listing andImage:(UIImage*)image andPhotos:(bool)hasPhoto {
	self = [super init];
	if(self != nil)
	{
		_listing = listing;
		_preImage = image;
//		hasData = _preListing != nil;
		
		_slideImages = [NSMutableArray array];
		_options = [NSMutableArray arrayWithCapacity:5];
		_mobileServices = [[IVMMobileServices alloc] init];
		_mobileServices.delegate = self;
		
		_vOptionsHeight = 0.0f;
		viewLoaded = NO;
		hasPhotos = hasPhoto;
		attemptedLoad = (_listing != nil);
		
		_userToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];
		
		self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(styleAction:)];
		self.navigationItem.rightBarButtonItem.enabled = NO;
		self.title = @"Details";
		
//		if(hasData)
//		{
//			[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
//			[_mobileServices getVehicleDetailsByToken:_preListing.vehicle_key withToken:_userToken];
//		}
		
		[appDelegate track:@"Details"];
	}
	return self;
}

- (void) setView:(UIView*)view{

	if(!view)
	{
		tableView.dataSource = nil;
		tableView.delegate = nil;
		tableView = nil;
		_detailsCell = nil;
		_vOptionsCell = nil;
		[_slideImages removeAllObjects];
		[_options removeAllObjects];
	}
	[super setView:view];
}

// Implement loadView to create a view hierarchy programmatically.
- (void)loadView {
	//	[_options addObject:emailFriend];
	viewLoaded = NO;
	self.view = [UIView new];
	self.view.backgroundColor = [UIColor colorWithRed:RedMake(kResultBackground) green:GreenMake(kResultBackground) blue:BlueMake(kResultBackground) alpha:1.0];
	self.view.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
//	self.view.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
	
	tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
	tableView.backgroundColor = [UIColor clearColor];
	tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	tableView.delegate = self;
	tableView.dataSource = self;
	[self.view addSubview:tableView];

	_detailsCell = [[DetailsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
	[_detailsCell.btn_slideShow addTarget:self action:@selector(startSlideShow:) forControlEvents:UIControlEventTouchUpInside];
	_detailsCell.btn_slideShow.hidden = YES;
	[_detailsCell.btn_modify addTarget:self action:@selector(modifyVehicle:) forControlEvents:UIControlEventTouchUpInside];

	[_detailsCell.btn_linkPictures addTarget:self action:@selector(linkButtonTapped) forControlEvents:UIControlEventTouchUpInside];

	[_detailsCell.seg_sort addTarget:self action:@selector(segmentTouchhed:) forControlEvents:UIControlEventValueChanged];
	[_detailsCell.seg_sort setEnabled:NO forSegmentAtIndex:0];
	
    _detailsCell.netImage.layer.borderWidth = 1;
    _detailsCell.netImage.layer.borderColor = [UIColor lightGrayColor].CGColor;		
    _detailsCell.netImage.layer.shadowOffset = CGSizeMake(4.0, 4.0);
    _detailsCell.netImage.layer.shadowOpacity = 0.6;
    _detailsCell.netImage.layer.shadowColor = [UIColor grayColor].CGColor;
    
	
	if(!hasPhotos) {
//		_detailsCell.btn_linkPictures.hidden = YES;
		_detailsCell.btn_linkPictures.enabled = NO;
		[_detailsCell.seg_sort setEnabled:NO forSegmentAtIndex:2];
	}
	
	_vOptionsCell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
	_vOptionsCell.selectionStyle = UITableViewCellSelectionStyleNone;
	_vOptionsCell.backgroundColor = [UIColor colorWithRed:RedMake(kResultBackground) green:GreenMake(kResultBackground) blue:BlueMake(kResultBackground) alpha:1.0];

	activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
	activity.hidesWhenStopped = YES;
	activity.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;

	if(activity)
	{
		[activity sizeToFit];
		activity.frame = CGRectMake(self.view.frame.size.width / 2.0 - activity.frame.size.width / 2.0, 
									self.view.frame.size.height / 2.0 - activity.frame.size.width / 2.0, 
									activity.frame.size.width, activity.frame.size.height);
		[self.view addSubview:activity];
	}
}

// Implement viewDidLoad to do additional setup after loading the view.
- (void)viewDidLoad {
    [super viewDidLoad];
	viewLoaded = YES;	

    self.imageFrame = CGRectMake(20.0, 80.0, 100.0, 80.0);

	//In case somehow service already returned
	if(attemptedLoad || nil != _listing)
	{
		[self populateFields];

		_preImage = nil;
	}
	else if(_preListing != nil)
	{
		[self prePopulateFields];
	}
}


-(void)viewDidAppear:(BOOL)animated {
//	NSLog(@"viewDidAppear");

	if (refreshView) {
		[_slideImages removeAllObjects];
		[_options removeAllObjects];

		//Re-load the vehicle data after upload more vehicle photos
		[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
		[_mobileServices getVehicleDetailsByToken:_listing.vehicle_key withToken:_userToken];
	}
	
	refreshView = NO;
}

//Populate details with information from previous screen
- (void) prePopulateFields{
	@synchronized(_detailsCell){
		NSNumberFormatter *frm = [NSNumberFormatter new];
		_detailsCell.lbl_MakeModel.text = [NSString stringWithFormat:@"%d %@ %@ %@", _preListing.year , _preListing.make, _preListing.model, _preListing.trimLevel];
		_detailsCell.lbl_Engine.text = _preListing.transmission;
		_detailsCell.lbl_VIN.text = [NSString stringWithFormat:@"VIN: %@", _preListing.vin];
		_detailsCell.lbl_ExtColor.text = [NSString stringWithFormat:@"Exterior: %@", _preListing.externalColor ? _preListing.internalColor : @"N/A"];
		_detailsCell.lbl_IntColor.text = [NSString stringWithFormat:@"Interior: %@", _preListing.internalColor ? _preListing.internalColor : @"N/A"];
		[frm setNumberStyle:NSNumberFormatterDecimalStyle];
        NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
        [frm setLocale:usLocale];
        
		_detailsCell.lbl_Miles.text  = [NSString stringWithFormat:@"%@ Miles", [frm stringFromNumber:[NSNumber numberWithInt:_preListing.mileage]]];
		
		_detailsCell.lbl_Stock.text = [NSString stringWithFormat:@"Stock #:%@", _preListing.stockNumber];
		
		if(_preListing.price > 0)
		{
			[frm setNumberStyle:NSNumberFormatterCurrencyStyle];
			[frm setMaximumFractionDigits:0];
			_detailsCell.lbl_price.text = [frm stringFromNumber:[NSNumber numberWithInt:_preListing.price]];
		}
		else
			_detailsCell.lbl_price.text = @"Call For Price";
		
		//remove image references
		_preImage = nil;
	}
}

//Populate fields with full details
- (void) populateFields{
	attemptedLoad = !viewLoaded;    //Changed Apr-12-2011
	if(attemptedLoad)
		return;
	
	[_slideImages removeAllObjects];
	[_options removeAllObjects];
	
	//Make sure prePopulation is done
	@synchronized(_detailsCell){
		//Handle slideshow button
		_detailsCell.btn_slideShow.hidden = NO;
		_detailsCell.btn_slideShow.enabled = YES;
			
		_detailsCell.lbl_MakeModel.text = [NSString stringWithFormat:@"%d %@ %@ %@", _listing.year, _listing.make, _listing.model, _listing.trimLevel];
		_detailsCell.lbl_Engine.text = _listing.transmission;
		_detailsCell.lbl_VIN.text = [NSString stringWithFormat:@"VIN: %@", _listing.vin];
		_detailsCell.lbl_ExtColor.text = [NSString stringWithFormat:@"Exterior: %@", _listing.externalColor? _listing.externalColor : @"N/A"];
		_detailsCell.lbl_IntColor.text = [NSString stringWithFormat:@"Interior: %@", _listing.internalColor ? _listing.internalColor : @"N/A"];
		NSNumberFormatter *frmt = [NSNumberFormatter new];
		[frmt setNumberStyle:NSNumberFormatterDecimalStyle];
        
        NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
        [frmt setLocale:usLocale];
        
		_detailsCell.lbl_Miles.text  = [NSString stringWithFormat:@"%@ Miles", [frmt stringFromNumber:[NSNumber numberWithInt:_listing.mileage]]];
		_detailsCell.lbl_Stock.text = [NSString stringWithFormat:@"Stock #:%@", _listing.stockNumber];
		
		if([_listing.regularPhotos count] > 0)
		{
			//Set loading image to low quality image
//			_detailsCell.netImage.loadingImage = _detailsCell.netImage.image;
//			_detailsCell.netImage.imageURL = [_listing.regularPhotos objectAtIndex:0] == nil ? nil : [NSURL URLWithString:[_listing.regularPhotos objectAtIndex:0]];
            
            _detailsCell.netImage.cache = nil;
            [_detailsCell.netImage setImageURL:[_listing.regularPhotos objectAtIndex:0] == nil ? nil : [NSURL URLWithString:[_listing.regularPhotos objectAtIndex:0]] cache:nil];

			//Get url's ready for slideshow
			for(int i = 0; i < [_listing.regularPhotos count]; i++)
			{
				if([_listing.regularPhotos objectAtIndex:i] == nil) continue;
				[_slideImages addObject:[NSURL URLWithString:[_listing.regularPhotos objectAtIndex:i]]];
			}
			
			//Update slide show button
//			[_detailsCell.btn_slideShow  setTitle:[NSString stringWithFormat:@"  %d Photo%@", [_slideImages count], [_slideImages count] != 1 ? @"s" : @""] forState:UIControlStateNormal];
			[_detailsCell.btn_slideShow  setTitle:[NSString stringWithFormat:@"%d Photo%@     ", [_slideImages count], [_slideImages count] != 1 ? @"s" : @""] forState:UIControlStateNormal];
			_detailsCell.btn_slideShow.enabled = YES;
			[_detailsCell.seg_sort setTitle:[NSString stringWithFormat:@"%d Photo%@", [_slideImages count], [_slideImages count] != 1 ? @"s" : @""] forSegmentAtIndex:0];
			[_detailsCell.seg_sort setEnabled:YES forSegmentAtIndex:0];
		} else {
			_detailsCell.btn_slideShow.enabled = NO;
			[_detailsCell.seg_sort setEnabled:NO forSegmentAtIndex:0];
		}

		if(_listing.price > 0)
		{
			NSNumberFormatter *frm = [[NSNumberFormatter alloc] init];
			[frm setNumberStyle:NSNumberFormatterCurrencyStyle];
			[frm setMaximumFractionDigits:0];
            NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
            [frm setLocale:usLocale];
            
			_detailsCell.lbl_price.text = [frm stringFromNumber:[NSNumber numberWithInt:_listing.price]];
			frm = nil;
		}
		else
			_detailsCell.lbl_price.text = @"Call For Price";
		
		//Dealer Information
//		_detailsCell.lbl_dealer.text = [NSString stringWithFormat:@"Stock #:%@\nTitaniumID: %@\n%@", _listing.stockNumber, _listing.titaniumID, _listing.status];
		_detailsCell.lbl_Stock.text = [NSString stringWithFormat:@"Stock #:%@", _listing.stockNumber];
		
		//Check if the vehicle has been SOLD
		if ([_listing.status isEqualToString:@"Sold"]) {
			[_detailsCell.seg_sort setEnabled:NO];
			
			UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"sold.png"]]; 
			
			//Add image view
			[_detailsCell addSubview:imageView];
		} else {
			self.navigationItem.rightBarButtonItem.enabled = YES;
		}


        [_options addObject:sendBrochure];
        [_options addObject:sendVideo];
        [_options addObject:postTwitter];
		
		if(_listing.certifiedLogoUrl) [_detailsCell.certifiedLogo setImageURL:[NSURL URLWithString:_listing.certifiedLogoUrl]];
		
		//Vehicle Options
		if([_listing.options count] > 0)
		{
			UILabel *tmpLabel = nil;
			UIFont *defont = [UIFont fontWithName:kDefaultFont size:kDefaultFontSize + 2];
			CGSize tmpSize;
			float cellWidth = 280.0f;
			float offset = 10.0f;
			_vOptionsHeight = 10.0f;
			
			tmpSize = [@"Vehicle Options" sizeWithFont:[UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 3.0f] constrainedToSize:CGSizeMake(cellWidth, FLT_MAX) lineBreakMode:UILineBreakModeTailTruncation];
			tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(offset, (float)_vOptionsHeight, cellWidth, tmpSize.height)];
			tmpLabel.lineBreakMode = UILineBreakModeTailTruncation;
			tmpLabel.font = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 3.0f];
			tmpLabel.textColor = [UIColor colorWithRed:RedMake(kSCAddressRGB) green:GreenMake(kSCAddressRGB) blue:BlueMake(kSCAddressRGB) alpha:1.0];
			tmpLabel.text = @"Vehicle Options";
			tmpLabel.textAlignment = UITextAlignmentCenter;
			tmpLabel.backgroundColor = [UIColor clearColor];
			
			[_vOptionsCell.contentView addSubview:tmpLabel];
			
			_vOptionsHeight += tmpSize.height + 5.0f;
			
			for(NSString *optn in _listing.options)
			{
				tmpSize = [optn sizeWithFont:defont constrainedToSize:CGSizeMake(cellWidth, FLT_MAX) lineBreakMode:UILineBreakModeWordWrap];
				tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(offset, (float)_vOptionsHeight, cellWidth, tmpSize.height)];
				tmpLabel.lineBreakMode = UILineBreakModeWordWrap;
				tmpLabel.font = defont;
				tmpLabel.text = [NSString stringWithFormat:@"- %@", optn];
				tmpLabel.backgroundColor = [UIColor clearColor];
				[_vOptionsCell.contentView addSubview:tmpLabel];
				_vOptionsHeight += tmpSize.height;
			}
			_vOptionsHeight += 10.0f;
		}

		[tableView reloadData];
	}

//	self.navigationItem.rightBarButtonItem.enabled = YES;
}

- (void)startSlideShow:(id)sender
{
//	SlideShowViewController *slideShow = [[SlideShowViewController alloc] initWithImages:_slideImages];
//	[self.navigationController pushViewController:slideShow animated:YES];

    
    SlideViewController *slideController = [[SlideViewController alloc] initWithNibName:@"SlideViewController_iPhone" bundle:nil data:_listing];
    
    [self presentZoomInOutModalViewController:slideController frame:self.imageFrame animated:YES withAlpha:1.0];
}

- (void)saveBookmark:(id)sender{
	[[appDelegate currentInstance] saveBookmark:_preListing];
//	_detailsCell.btn_bookMark.enabled = NO;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
}

#pragma mark UITableView delegates
/*
- (UITableViewCellAccessoryType)tableView:(UITableView *)tableView accessoryTypeForRowWithIndexPath:(NSIndexPath *)indexPath{
	return UITableViewCellAccessoryNone;
}
*/
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	switch (indexPath.row) {
		case 0:
//			return _listing != nil ? 230.0f : 200.0f;
			return 230.0f;
			break;
		case 1:
			return _vOptionsHeight;
			break;
		default:
			return 0.0;
			break;
	}
}
#pragma mark UITableView datasource methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if(!hasData) return 0;
	
	return _vOptionsHeight > 0 ? 2 : 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	switch (indexPath.row) {
		case 0:
			_detailsCell.accessoryType = UITableViewCellAccessoryNone;
			return _detailsCell;
			break;
		case 1:
			_vOptionsCell.accessoryType = UITableViewCellAccessoryNone;
			return _vOptionsCell;
			break;
	}
	return nil;
}

#pragma mark Action

- (void)styleAction:(id)sender
{
	actionSheet = [[UIActionSheet alloc] initWithTitle:@"Select An Option" 
								delegate:self 
					   cancelButtonTitle:@"Cancel" 
				  destructiveButtonTitle:nil 
					   otherButtonTitles:[self objectFrom:_options atIndex:0], 
										 [self objectFrom:_options atIndex:1],
										 [self objectFrom:_options atIndex:2],
										 [self objectFrom:_options atIndex:3],
										 [self objectFrom:_options atIndex:4],
										 nil];
	
	// use the same style as the nav bar
//	styleAlert.actionSheetStyle = self.navigationController.navigationBar.barStyle;
	actionSheet.actionSheetStyle = UIActionSheetStyleBlackTranslucent;
	
	[actionSheet showInView:self.parentViewController.tabBarController.view];

    UIButton	*tmpButton;
    for (int i = 0; i < [_options count]; i++) {
        tmpButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [tmpButton setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
        tmpButton.frame = CGRectMake(23.0f, 45.0 +(54.0*i), 274.0f, 42.0f);
		[tmpButton setTitle:[_options objectAtIndex:i] forState:UIControlStateNormal];
        [tmpButton addTarget:self action:@selector(actionCallback:) forControlEvents:UIControlEventTouchUpInside];
        [tmpButton setTag:i];
        
        [actionSheet addSubview:tmpButton];
    }
}

- (id) objectFrom:(NSArray*)obj atIndex:(NSUInteger)index
{
	return index >= [obj count] ? nil : [obj objectAtIndex:index];
}
/*
- (void)actionSheet:(UIActionSheet *)modalView clickedButtonAtIndex:(NSInteger)buttonIndex
{
//	RMViewController *rmc = nil;
	UIAlertView *alertView = nil;
	if(buttonIndex >= [_options count]) return;
	NSString* value = (NSString*)[_options objectAtIndex:buttonIndex];
	
	if(value == emailFriend)
	{
		[appDelegate track:@"Friend Emailed"];
		if(![[UIApplication sharedApplication] openURL:[NSURL URLWithString:
														[@"mailto:?subject=Vehicle%20found%20using%20GetAuto.com's%20iPhone%20App&body=" stringByAppendingString:
														 [[NSString stringWithFormat:@"Hello, I think you may be interested in this vehicle %@", _listing.autoVinUrl] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]]])
		{
			alertView = [[UIAlertView alloc] initWithTitle:@"Error"
																message:@"Failed To Launch Email Application!" 
															   delegate:nil
													  cancelButtonTitle:@"Ok"
													  otherButtonTitles:nil];
			[alertView show];
		}
	}
	else if(value == sendVideo)
	{
		// XXX Make Web Service call here
		[appDelegate track:@"Send Video"];
		
		NSString *leadForm = [NSString stringWithFormat: @"<html>\
							  <head>\
							  <title>Feedback Form</title>\
							  <script type=\"text/javascript\">\
							  function CallObjC()\
							  {\
							  var email = document.getElementById('eMail').value; if(!email.match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]+$/i)) { alert('Invalid email address.'); return false; }\
							  document.location = 'objc:submit:video:' + email;\
							  }\
							  </script>\
							  </head>\
							  \
							  <body background=\"background.png\" style=\"color:white;\" >\
							  <font face=\"arial, verdana\" color=\"#ffffff\" size=2>\
							  \
							  <p><font color=\"white\">Enter customer e-mail addree there about a specific vehicle in Dealer Specialties database you found. <br><br>Click <i>Submit</i> to send out the video. <br>To clear the form, click <i>Reset</i>.</font></p>\
							  \
							  <!-- Form starts -->\
							  <form name=\"Feedback_form\" action=\"mailto:email@server.com\" method=\"POST\">\
							  <font face=\"arial, verdana\" color=\"#ffffff\" size=2>\
							  \
							  <table width=\"100%\" border=\"0\">\
							  <tr>\
							  <tr>\
							  <tr>\
							  <td width=\"40\"><font size=2>E-mail Address</font></td>\
							  <td><input id=\"eMail\" size=\"30\"></td>\
							  </tr>\
							  <tr>\
							  <tr>\
							  </tr>\
							  <td>\
							  </td>\
							  <td>\
							  <input type=\"button\" name=\"Submit\" value=\"Submit\" onclick='CallObjC();'>&nbsp;<input type=\"reset\" name=\"Reset\" value=\"Reset\">\
							  </td>\
							  </tr>\
							  </table>\
							  </form>\
							  <!-- Form ends -->\
							  <br>\
							  \
							  </body>\
							  \
							  </html>"];
		
		NSString *adId = [NSString stringWithFormat:@"%d", _listing.vehicle_key];
		WebViewController *emailController = [[WebViewController alloc] initWithHTML:leadForm adId:(NSString *)adId];
		[self.navigationController pushViewController:emailController animated:YES];
		
	}
	else if(value == sendBrochure)
	{
		// XXX Make Web Service call here
		[appDelegate track:@"Send Brochure"];
		
		NSString *leadForm = [NSString stringWithFormat: @"<html>\
							  <head>\
							  <title>Feedback Form</title>\
							  <script type=\"text/javascript\">\
							  function CallObjC()\
							  {\
							  var email = document.getElementById('eMail').value; if(!email.match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]+$/i)) { alert('Invalid email address.'); return false; }\
							  var comments = document.getElementById('Comments').value;\
							  document.location = 'objc:submit:brochure:' + email + ':' + comments;\
							  }\
							  </script>\
							  </head>\
							  \
							  <body background=\"background.png\" style=\"color:white;\" >\
							  <font face=\"arial, verdana\" color=\"#ffffff\" size=2>\
							  \
							  <p><font color=\"white\">Enter customer e-mail and put some notes there about a specific vehicle in Dealer Specialties database you found. <br><br>Click <i>Submit</i> to send out the brochure. <br>To clear the form, click <i>Reset</i>.</font></p>\
							  \
							  <!-- Form starts -->\
							  <form name=\"Feedback_form\" action=\"mailto:email@server.com\" method=\"POST\">\
							  <font face=\"arial, verdana\" color=\"#ffffff\" size=2>\
							  \
							  <table width=\"100%\" border=\"0\">\
							  <tr>\
							  <tr>\
							  <tr>\
							  <td width=\"40\"><font size=2>E-mail Address</font></td>\
							  <td><input id=\"eMail\" size=\"30\"></td>\
							  </tr>\
							  <tr>\
							  <tr>\
							  </tr>\
							  <tr>\
							  <td width=\"40\" valign=\"top\"><font size=2>Notes</font></td>\
							  <td><textarea id=\"Comments\" rows=\"7\" cols=\"30\">%@</textarea></td>\
							  </tr>\
							  <tr>\
							  <tr>\
							  </tr>\
							  <td>\
							  </td>\
							  <td>\
							  <input type=\"button\" name=\"Submit\" value=\"Submit\" onclick='CallObjC();'>&nbsp;<input type=\"reset\" name=\"Reset\" value=\"Reset\">\
							  </td>\
							  </tr>\
							  </table>\
							  </form>\
							  <!-- Form ends -->\
							  <br>\
							  \
							  </body>\
							  \
							  </html>", 
							  
							  [NSString stringWithFormat:@"Hello, the following vehicle:\n%d %@ %@\nStock number %@ you maybe interested", 
							   _listing.year, _listing.make, _listing.model, _listing.stockNumber]];
		
		NSString *adId = [NSString stringWithFormat:@"%d", _listing.vehicle_key];
		WebViewController *emailController = [[WebViewController alloc] initWithHTML:leadForm adId:(NSString *)adId];
		[self.navigationController pushViewController:emailController animated:YES];
		
	}
	else if(value == postTwitter)
	{
		// XXX Make Web Service call here
		[appDelegate track:@"Post to Twitter"];
		
		NSString *leadForm = [NSString stringWithFormat: @"<html>\
							  <head>\
							  <title>Feedback Form</title>\
							  <script type=\"text/javascript\">\
							  function CallObjC()\
							  {\
							  var comments = document.getElementById('Comments').value;\
							  document.location = 'objc:submit:twitter:' + comments;\
							  }\
							  </script>\
							  </head>\
							  \
							  <body background=\"background.png\" style=\"color:white;\" >\
							  <font face=\"arial, verdana\" color=\"#ffffff\" size=2>\
							  \
							  <p><font color=\"white\">Enter some message there about a specific vehicle in Dealer Specialties database you found. <br><br>Click <i>Submit</i> to send out the brochure. <br>To clear the form, click <i>Reset</i>.</font></p>\
							  \
							  <!-- Form starts -->\
							  <form name=\"Feedback_form\" action=\"mailto:email@server.com\" method=\"POST\">\
							  <font face=\"arial, verdana\" color=\"#ffffff\" size=2>\
							  \
							  <table width=\"100%\" border=\"0\">\
							  <tr>\
							  <tr>\
							  <tr>\
							  <tr>\
							  <td width=\"40\" valign=\"top\"><font size=2>Message</font></td>\
							  <td><textarea id=\"Comments\" rows=\"7\" cols=\"30\">%@</textarea></td>\
							  </tr>\
							  <tr>\
							  <tr>\
							  </tr>\
							  <td>\
							  </td>\
							  <td>\
							  <input type=\"button\" name=\"Submit\" value=\"Submit\" onclick='CallObjC();'>&nbsp;<input type=\"reset\" name=\"Reset\" value=\"Reset\">\
							  </td>\
							  </tr>\
							  </table>\
							  </form>\
							  <!-- Form ends -->\
							  <br>\
							  \
							  </body>\
							  \
							  </html>", 
							  
							  [NSString stringWithFormat:@"Hello, the following vehicle:\n%d %@ %@\nStock number %@ you maybe interested", 
							   _listing.year, _listing.make, _listing.model, _listing.stockNumber]];
		
		NSString *adId = [NSString stringWithFormat:@"%d", _listing.vehicle_key];
		WebViewController *emailController = [[WebViewController alloc] initWithHTML:leadForm adId:(NSString *)adId];
		[self.navigationController pushViewController:emailController animated:YES];
		
	}
}
*/
- (void)actionCallback:(id)sender
{
	//Dismiss the Action Sheet
	[self.actionSheet dismissWithClickedButtonIndex:0 animated:YES];

	UIAlertView *alertView = nil;
    
    NSInteger   buttonIndex = ((UIButton*)sender).tag;
	if(buttonIndex >= [_options count]) return;
	NSString* value = (NSString*)[_options objectAtIndex:buttonIndex];
	
	if(value == emailFriend)
	{
		[appDelegate track:@"Friend Emailed"];
		if(![[UIApplication sharedApplication] openURL:[NSURL URLWithString:
														[@"mailto:?subject=Vehicle%20found%20using%20GetAuto.com's%20iPhone%20App&body=" stringByAppendingString:
														 [[NSString stringWithFormat:@"Hello, I think you may be interested in this vehicle %@", _listing.autoVinUrl] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]]]])
		{
			alertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                   message:@"Failed To Launch Email Application!" 
                                                  delegate:nil
                                         cancelButtonTitle:@"Ok"
                                         otherButtonTitles:nil];
			[alertView show];
		}
	}
	else if(value == sendVideo)
	{
		// XXX Make Web Service call here
		[appDelegate track:@"Send Video"];
		
		NSString *leadForm = [NSString stringWithFormat: @"<html>\
							  <head>\
							  <title>Feedback Form</title>\
							  <script type=\"text/javascript\">\
							  function CallObjC()\
							  {\
							  var email = document.getElementById('eMail').value; if(!email.match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]+$/i)) { alert('Invalid email address.'); return false; }\
							  var comments = document.getElementById('Comments').value;\
							  document.location = 'objc:submit:video:' + email + ':' + comments;\
							  }\
							  </script>\
							  </head>\
							  \
							  <body background=\"background.png\" style=\"color:white;\" >\
							  <font face=\"arial, verdana\" color=\"#ffffff\" size=2>\
							  \
							  <p><font color=\"white\">To send a vehicle video, enter a valid email address and (optionally) edit or remove the standard email message.<br><br> </font></p>\
							  \
							  <!-- Form starts -->\
							  <form name=\"Feedback_form\" action=\"mailto:email@server.com\" method=\"POST\">\
							  <font face=\"arial, verdana\" color=\"#ffffff\" size=2>\
							  \
							  <table width=\"100%\" border=\"0\">\
							  <tr>\
							  <tr>\
							  <tr>\
							  <td width=\"40\"><font size=2>Email Address</font></td>\
							  <td><input id=\"eMail\" size=\"30\"></td>\
							  </tr>\
							  <tr>\
							  <tr>\
							  </tr>\
							  <tr>\
							  <td width=\"40\" valign=\"top\"><font size=2>Note</font></td>\
							  <td><textarea id=\"Comments\" rows=\"7\" cols=\"30\">%@</textarea></td>\
							  </tr>\
							  <tr>\
							  <tr>\
							  </tr>\
							  <td>\
							  </td>\
							  <td>\
							  <input type=\"button\" name=\"Submit\" value=\"Submit\" onclick='CallObjC();'>&nbsp;<input type=\"reset\" name=\"Reset\" value=\"Reset\">\
							  </td>\
							  </tr>\
							  </table>\
							  </form>\
							  <!-- Form ends -->\
							  <br>\
							  \
							  </body>\
							  \
							  </html>", 
							  
							  /*[NSString stringWithFormat:@"Hello, the following vehicle:\n%d %@ %@\nStock number %@  may be of interest to you...", 
							   _listing.year, _listing.make, _listing.model, _listing.stockNumber]];*/
                              [NSString stringWithFormat:@"This %d %@ %@ may be of interest to you...", 
							   _listing.year, _listing.make, _listing.model]];

		
		NSString *adId = [NSString stringWithFormat:@"%d", _listing.vehicle_key];
		WebViewController *emailController = [[WebViewController alloc] initWithHTML:leadForm adId:(NSString *)adId];
		[self.navigationController pushViewController:emailController animated:YES];
		
	}
	else if(value == sendBrochure)
	{
		// XXX Make Web Service call here
		[appDelegate track:@"Send Brochure"];
		
		NSString *leadForm = [NSString stringWithFormat: @"<html>\
							  <head>\
							  <title>Feedback Form</title>\
							  <script type=\"text/javascript\">\
							  function CallObjC()\
							  {\
							  var email = document.getElementById('eMail').value; if(!email.match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]+$/i)) { alert('Invalid email address.'); return false; }\
							  var comments = document.getElementById('Comments').value;\
							  document.location = 'objc:submit:brochure:' + email + ':' + comments;\
							  }\
							  </script>\
							  </head>\
							  \
							  <body background=\"background.png\" style=\"color:white;\" >\
							  <font face=\"arial, verdana\" color=\"#ffffff\" size=2>\
							  \
							  <p><font color=\"white\">To send a vehicle brochure, enter a valid email address and (optionally) edit or remove the standard email message.<br><br> </font></p>\
							  \
							  <!-- Form starts -->\
							  <form name=\"Feedback_form\" action=\"mailto:email@server.com\" method=\"POST\">\
							  <font face=\"arial, verdana\" color=\"#ffffff\" size=2>\
							  \
							  <table width=\"100%\" border=\"0\">\
							  <tr>\
							  <tr>\
							  <tr>\
							  <td width=\"40\"><font size=2>Email Address</font></td>\
							  <td><input id=\"eMail\" size=\"30\"></td>\
							  </tr>\
							  <tr>\
							  <tr>\
							  </tr>\
							  <tr>\
							  <td width=\"40\" valign=\"top\"><font size=2>Note</font></td>\
							  <td><textarea id=\"Comments\" rows=\"7\" cols=\"30\">%@</textarea></td>\
							  </tr>\
							  <tr>\
							  <tr>\
							  </tr>\
							  <td>\
							  </td>\
							  <td>\
							  <input type=\"button\" name=\"Submit\" value=\"Submit\" onclick='CallObjC();'>&nbsp;<input type=\"reset\" name=\"Reset\" value=\"Reset\">\
							  </td>\
							  </tr>\
							  </table>\
							  </form>\
							  <!-- Form ends -->\
							  <br>\
							  \
							  </body>\
							  \
							  </html>", 
							  
							  /*[NSString stringWithFormat:@"Hello, the following vehicle:\n%d %@ %@\nStock number %@  may be of interest to you...", 
							   _listing.year, _listing.make, _listing.model, _listing.stockNumber]];*/
                              [NSString stringWithFormat:@"This %d %@ %@ may be of interest to you...", 
							   _listing.year, _listing.make, _listing.model]];
		
		NSString *adId = [NSString stringWithFormat:@"%d", _listing.vehicle_key];
		WebViewController *emailController = [[WebViewController alloc] initWithHTML:leadForm adId:(NSString *)adId];
		[self.navigationController pushViewController:emailController animated:YES];
		
	}
	else if(value == postTwitter)
	{
		// XXX Make Web Service call here
		[appDelegate track:@"Post to Twitter"];
		
		NSString *leadForm = [NSString stringWithFormat: @"<html>\
							  <head>\
							  <title>Feedback Form</title>\
							  <script type=\"text/javascript\">\
							  function CallObjC()\
							  {\
							  var comments = document.getElementById('Comments').value;\
							  document.location = 'objc:submit:twitter:' + comments;\
							  }\
							  </script>\
							  </head>\
							  \
							  <body background=\"background.png\" style=\"color:white;\" >\
							  <font face=\"arial, verdana\" color=\"#ffffff\" size=2>\
							  \
							  <p><font color=\"white\">Post a message about this vehicle to your Twitter account.<br><br></font></p>\
							  \
							  <!-- Form starts -->\
							  <form name=\"Feedback_form\" action=\"mailto:email@server.com\" method=\"POST\">\
							  <font face=\"arial, verdana\" color=\"#ffffff\" size=2>\
							  \
							  <table width=\"100%\" border=\"0\">\
							  <tr>\
							  <tr>\
							  <tr>\
							  <tr>\
							  <td width=\"40\" valign=\"top\"><font size=2>Message</font></td>\
							  <td><textarea id=\"Comments\" rows=\"7\" cols=\"30\">%@</textarea></td>\
							  </tr>\
							  <tr>\
							  <tr>\
							  </tr>\
							  <td>\
							  </td>\
							  <td>\
							  <input type=\"button\" name=\"Submit\" value=\"Submit\" onclick='CallObjC();'>&nbsp;<input type=\"reset\" name=\"Reset\" value=\"Reset\">\
							  </td>\
							  </tr>\
							  </table>\
							  </form>\
							  <!-- Form ends -->\
							  <br>\
							  \
							  </body>\
							  \
							  </html>", 
							  
							  /*[NSString stringWithFormat:@"Hello, the following vehicle:\n%d %@ %@\nStock number %@ you maybe interested", 
							   _listing.year, _listing.make, _listing.model, _listing.stockNumber]];*/
                              [NSString stringWithFormat:@""]];
		
		NSString *adId = [NSString stringWithFormat:@"%d", _listing.vehicle_key];
		WebViewController *emailController = [[WebViewController alloc] initWithHTML:leadForm adId:(NSString *)adId];
		[self.navigationController pushViewController:emailController animated:YES];
		
	}
}

#pragma mark MobileSearch
- (void) VehicleDetailsComplete:(VehicleDetails*)vehicle withStatus:(NSString*)inResult{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	
//	[_listing release];
//	_listing = vehicle;

	[activity stopAnimating];

	if(![inResult isEqualToString:@"Success"])
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"The Web Services Failed"
														message:inResult 
														delegate:self
													  cancelButtonTitle:@"Ok"
													  otherButtonTitles:nil];
		[alertView show];

		return;
	}

	_listing = vehicle;

	if(!_listing)
	{
		if(!hasData)
		{
			UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Listing Unavailable"
																message:@"This Listing is no longer available" 
															   delegate:self
													  cancelButtonTitle:@"Ok"
													  otherButtonTitles:nil];
			[alertView show];
		}
		return;
	}
	else if(_listing.vehicle_key == -1)
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Listing Unavailable"
														 message:@"This Listing is no longer available" 
														delegate:self
											   cancelButtonTitle:@"Ok"
											   otherButtonTitles:nil];
		[alertView show];
		
	}
	
	hasData = YES;
//	attemptedLoad = YES;
	[self populateFields];
}

#pragma mark UIAlertViewDelegate methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
	[self.navigationController popViewControllerAnimated:YES];
}

#pragma mark RestoreProtocol  methods
- (NSDictionary*)getRestoreData{
	NSMutableDictionary *data = [NSMutableDictionary dictionary];
	[data setValue:[NSNumber numberWithInt:_preListing.vehicle_key] forKey:kVKey];
	[data setValue:[NSNumber numberWithBool:hasPhotos] forKey:kHasPhoto];
//	[data setValue:[NSNumber numberWithFloat:_preListing.latitude] forKey:@"lat"];
//	[data setValue:[NSNumber numberWithFloat:_preListing.longitude] forKey:@"lon"];
	return data;
}

// ADD: Open the Camera Roll to select and upload photos
- (IBAction) linkButtonTapped
{
	refreshView = YES;

	//Open the Camera Roll
	CameraViewController* cvc = [[CameraViewController alloc] initWithKey:_listing.vehicle_key withType:NO];
	[self.navigationController pushViewController:cvc animated:YES];
}


// Modify the Vehicle Price and Status
- (void) modifyVehicle:(id)sender
{
	modController = [[ModifyViewController alloc] initWithKey:_listing.vehicle_key withValue:_listing.price];
	modController.delegate = self;
	
	[self showModal:modController.view];
}


- (void)showModal:(UIView*) modalView {
	UIWindow* mainWindow = (((appDelegate*) [UIApplication sharedApplication].delegate).window);
	
	CGPoint middleCenter = modalView.center;
	CGSize offSize = [UIScreen mainScreen].bounds.size;
	CGPoint offScreenCenter = CGPointMake(offSize.width / 2.0, offSize.height * 1.5);
	modalView.center = offScreenCenter; // we start off-screen
	[mainWindow addSubview:modalView];
	
	// Show it with a transition effect
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.4]; // animation duration in seconds
	modalView.center = middleCenter;
	[UIView commitAnimations];
}

- (void)segmentTouchhed:(id)sender{
	
	switch (_detailsCell.seg_sort.selectedSegmentIndex) {
		case 0:
			[self startSlideShow:sender];
			break;
		case 1:
			[self modifyVehicle:sender];
			break;
		case 2:
			[self linkButtonTapped];
			break;
		default:
			break;
	}
}

- (void)updateVehiclePrice:(int)newPrice {
	[activity startAnimating];

	[_mobileServices updatePriceByToken:_listing.vehicle_key withToken:_userToken withValue:newPrice];
}

- (void)updateVehicleStatus {
	[activity startAnimating];

	[_mobileServices updateStatusByToken:_listing.vehicle_key withToken:_userToken];
}


#pragma mark - Zoom In/Out View
- (void) presentZoomInOutModalViewController:(UIViewController *)aViewController frame:(CGRect)newRect animated:(BOOL)isAnimated withAlpha:(CGFloat)anAlpha {
    
    self.zoominoutModalViewController = aViewController;
    UIView *view = aViewController.view;
    
    view.opaque = NO;
    view.alpha = anAlpha;
    [view.subviews enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        UIView *each = obj;
        each.opaque = NO;
        each.alpha = anAlpha;
    }];
    
    [self.view addSubview:view];
    
    CGRect frameRect = view.frame;
    frameRect.origin.y = -44.0;
    frameRect.origin.x = 0.0;
    view.frame = frameRect;
    
    [UIView beginAnimations:nil context:nil];
    view.transform = CGAffineTransformMakeScale(0.1f, 0.1f);
    [UIView commitAnimations];
    
    [self.navigationItem setHidesBackButton:YES];
    [self.navigationItem setTitle:@"Photos"];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Close" style:UIBarButtonItemStyleBordered target:self action:@selector(closePhotoView:)];
    
    if (isAnimated) {
        //Animated
        [UIView beginAnimations:nil context:nil];
        view.transform = CGAffineTransformMakeScale(1.0f, 1.0f);
        [UIView commitAnimations];
    } else {
        view.frame = [[UIScreen mainScreen] bounds];
        [self.view addSubview:view];
    }
}

- (void) dismissZoomInOutModalViewController:(CGRect)newRect animated:(BOOL)animated {
//    self.showSlide = NO;
    
    if (animated) {
        [UIView beginAnimations:nil context:nil];
        self.zoominoutModalViewController.view.transform = CGAffineTransformMakeScale(0.1f, 0.1f);
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(animationDidStop:finished:context:)];
        [UIView commitAnimations];
    } else {
        [self.zoominoutModalViewController.view removeFromSuperview];
        self.zoominoutModalViewController = nil;
    }
}


- (void)animationDidStop:(NSString*)animationID finished:(BOOL)finished context:(void *)context {
	/*Do stuff*/
    [self.navigationItem setHidesBackButton:NO];
    [self.navigationItem setTitle:@"Details"];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAction target:self action:@selector(styleAction:)];

    [self.zoominoutModalViewController.view removeFromSuperview];
    self.zoominoutModalViewController = nil;
}

- (void)closePhotoView:(id)sender {
    [self dismissZoomInOutModalViewController:self.imageFrame animated:YES];
}


- (void)dealloc{
	[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
	tableView.dataSource = nil;
	tableView.delegate = nil;
	_mobileServices.delegate = nil;
	[_mobileServices cancel];
	
	_mobileServices = nil;
	_preListing = nil;
	_listing = nil;
	_detailsCell = nil;
	_preImage = nil;
	_slideImages = nil;
	tableView = nil;
	_options = nil;
	
	modController.delegate = nil;
//	[modController release];
//	modController = nil;
	
	activity = nil;
	
}

@end
