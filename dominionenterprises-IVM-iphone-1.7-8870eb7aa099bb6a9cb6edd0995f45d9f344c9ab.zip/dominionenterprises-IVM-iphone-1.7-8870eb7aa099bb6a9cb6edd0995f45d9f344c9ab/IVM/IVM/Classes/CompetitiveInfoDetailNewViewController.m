//
//  CompetitiveInfoDetailNewViewController.m
//  IVM
//
//  Created by Sehaswaran Mayilerum on 6/21/12.

//
#import "CompetitiveInfoDetailNewViewController.h"

@interface CompetitiveInfoDetailNewViewController ()
@end

@implementation CompetitiveInfoDetailNewViewController
@synthesize competitiveInfoDetail;
- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)initalize
{
    frm = [[NSNumberFormatter alloc] init];
    [frm setNumberStyle:NSNumberFormatterCurrencyStyle];
    [frm setMaximumFractionDigits:0];
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    [frm setLocale:usLocale];
    numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    [numberFormatter setLocale:usLocale];
    competitiveInfoDetailLabelArray=[[NSMutableArray alloc]initWithObjects:@"Vehicle",@"VIN",@"Dealer",@"Price",@"Mileage",@"Age",@"Distance", nil];
    competitiveInfoDetailValueArray=[[NSMutableArray alloc]initWithObjects:[NSString stringWithFormat:@"%@ %@ %@ %@",[competitiveInfoDetail objectForKey:@"year"],[competitiveInfoDetail objectForKey:@"make"],[competitiveInfoDetail objectForKey:@"model"],[competitiveInfoDetail objectForKey:@"trim"]],[competitiveInfoDetail objectForKey:@"vin"],[competitiveInfoDetail objectForKey:@"dealername"],[competitiveInfoDetail objectForKey:@"price"],[competitiveInfoDetail objectForKey:@"mileage"],[competitiveInfoDetail objectForKey:@"age"],[competitiveInfoDetail objectForKey:@"distance"],nil];
    self.tableView.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;                                 
    self.tableView.userInteractionEnabled=NO;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initalize];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [competitiveInfoDetailLabelArray count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"CellIndentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] ;
        [cell setBackgroundColor:[UIColor colorWithRed:RedMake(kNavTintColor) green:GreenMake(kNavTintColor) blue:BlueMake(kNavTintColor) alpha:1.0]];
        cell.userInteractionEnabled=NO;
        cell.textLabel.textColor=[UIColor whiteColor];
        [self createCustomCellUI:cell indexpath:indexPath];
    }
    [self updateDataCustomCellUI:cell indexpath:indexPath];
    return cell;
}
-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGSize constraint = CGSizeMake(150.0f - (6.0f * 2), 20000.0f);
    CGSize size = [[competitiveInfoDetailValueArray objectAtIndex:indexPath.row ] sizeWithFont:[UIFont systemFontOfSize:12] constrainedToSize:constraint lineBreakMode:UILineBreakModeWordWrap];
    CGFloat height = MAX(size.height, 20.0f);
    return  height + (12.0f);
}
-(void)createCustomCellUI:(UITableViewCell*)cell indexpath:(NSIndexPath*)indexPath{
    UIColor *textColor = [UIColor whiteColor];
    UIFont *lblFont = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0];
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(15,5,100,20)];
    label.font=lblFont;
    label.backgroundColor=[UIColor clearColor];
    label.textAlignment=UITextAlignmentLeft;
    label.tag=1;
    label.textColor=textColor;
    label.numberOfLines=0;
    [cell.contentView addSubview:label];
    UILabel *labelOne=[UILabel alloc];
    labelOne=[labelOne initWithFrame:CGRectMake(115,5,180,20)];
    labelOne.font=lblFont;
    labelOne.textAlignment=UITextAlignmentLeft;
    labelOne.textColor=textColor;
    labelOne.backgroundColor=[UIColor clearColor];
    labelOne.numberOfLines=0;
    labelOne.tag=2;
    [cell.contentView addSubview:labelOne];
    cell.textLabel.backgroundColor=[UIColor clearColor];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;   
}
-(void)updateDataCustomCellUI:(UITableViewCell*)cell indexpath:(NSIndexPath*)indexPath{
    UILabel *label=(UILabel*)[cell.contentView viewWithTag:1];
    label.text=[competitiveInfoDetailLabelArray objectAtIndex:indexPath.row];
    UILabel *labelOne=(UILabel*)[cell.contentView viewWithTag:2];
    if(indexPath.row==3)
        labelOne.text=[NSString stringWithFormat:@": %@",[frm stringFromNumber:[NSNumber numberWithInt:[[competitiveInfoDetailValueArray objectAtIndex:indexPath.row] intValue]]]];
    else if(indexPath.row == 4 || indexPath.row == 6)
            labelOne.text=[NSString stringWithFormat:@": %@ mi",[numberFormatter stringFromNumber:[NSNumber numberWithInt:[[competitiveInfoDetailValueArray objectAtIndex:indexPath.row] intValue]]]]; 
    else
         labelOne.text=[NSString stringWithFormat:@": %@",[competitiveInfoDetailValueArray objectAtIndex:indexPath.row]];
    [labelOne sizeToFit];
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
@end
