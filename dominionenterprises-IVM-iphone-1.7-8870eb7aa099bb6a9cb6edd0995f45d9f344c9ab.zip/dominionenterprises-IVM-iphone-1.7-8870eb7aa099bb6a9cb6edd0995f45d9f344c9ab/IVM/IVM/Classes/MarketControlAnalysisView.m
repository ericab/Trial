//
//  MarketControlAnalysisView.m
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//


#import "IVM.h"
#import "appDelegate.h"
#import "SearchResultsController.h"
#import "IVMMobileServices.h"
#import "SearchValues.h"
#import "SearchValuesResults.h"
#import "SearchResultsView.h"
#import "MarketControlAnalysisView.h"
#import "MarketControlAnalysisController.h"

@interface MarketControlAnalysisView()

- (void)registerForKeyboardNotifications;
- (void)unregisterForKeyboardNotifications;
@end

enum{
	MODE_MAKEMODEL = 1,
	MODE_PRICE = 2,
	MODE_YEAR = 3,
	MODE_MILES = 4,
	MODE_DEALERLOT = 5
};

@implementation MarketControlAnalysisView

@synthesize searchObject, target, btn_Search;
@synthesize dealerList;


- (id)initWithFrame:(CGRect)frame {
    return [self initWithFrame:frame searchObject:nil filterMode:NO];
}

- (id)initWithFrame:(CGRect)frame searchObject:(VehicleSearchObject*)searchObj filterMode:(BOOL)filter {
	self = [super initWithFrame:frame];
	if(self != nil)
	{
		[UIView setAnimationsEnabled:NO];
		frm_money = [NSNumberFormatter new];	
		[frm_money setNumberStyle:NSNumberFormatterCurrencyStyle];
		[frm_money setMaximumFractionDigits:0];
		
		frm_decimal = [NSNumberFormatter new];
		[frm_decimal setNumberStyle:NSNumberFormatterDecimalStyle];
		[frm_decimal setMaximumFractionDigits:0];
		
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		
		self.searchObject = searchObj == nil ? [VehicleSearchObject new] : searchObj;
	
		scrollView = [[UIScrollView alloc] initWithFrame:frame];
		scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		[self addSubview:scrollView];
		
		UIColor *textColor = [UIColor blackColor];
		UIFont *lblFont = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0];
		
		float yOffset = 10.0f;
		
		//Market Size
		UILabel *tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Market Size";
		[scrollView addSubview:tmpLabel];
		
		yOffset += 20.0f;

		btn_DealerLot = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
		btn_DealerLot.borderStyle = UITextBorderStyleRoundedRect;

		btn_DealerLot.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_DealerLot.placeholder = @"Market Size";
		btn_DealerLot.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_DealerLot.delegate = self;
        btn_DealerLot.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
		[scrollView addSubview:btn_DealerLot];

		yOffset += 30.0f;

		//Market Average Price
		tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 135.0f, 20.0)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Market Average Price";
		[scrollView addSubview:tmpLabel];
		
		yOffset += 20.0f;

		btn_Year = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
		btn_Year.borderStyle = UITextBorderStyleRoundedRect;
		btn_Year.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Year.placeholder = @"Market Average Price";
 		btn_Year.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_Year.delegate = self;
        btn_Year.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;

		[scrollView addSubview:btn_Year];
		
		yOffset += 30.0f;
		
		//Market Average Mileage
		tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 155.0f, 20.0f)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Market Average Mileage";
		[scrollView addSubview:tmpLabel];
		
		yOffset += 20.0f;

		
		btn_MakeModel = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
		btn_MakeModel.borderStyle = UITextBorderStyleRoundedRect;
		btn_MakeModel.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_MakeModel.placeholder = @"Market Average Mileage";
 		btn_MakeModel.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_MakeModel.delegate = self;
        btn_MakeModel.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_MakeModel];
		
		yOffset += 30.0f;
		
		//Recommended Price
		tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 130.0f, 20.0)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Recommended Price";
		[scrollView addSubview:tmpLabel];
		
		yOffset += 20.0f;

		
		btn_Price = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
		btn_Price.borderStyle = UITextBorderStyleRoundedRect;
		btn_Price.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Price.placeholder = @"Recommended Price";
 		btn_Price.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_Price.delegate = self;
        btn_Price.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_Price];
		
		yOffset += 30.0f;
	
		//Price Rank
		tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 90.0f, 20.0)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Price Rank";
		[scrollView addSubview:tmpLabel];
		
		yOffset += 20.0f;
		
		btn_Mileage = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
		btn_Mileage.borderStyle = UITextBorderStyleRoundedRect;
		btn_Mileage.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Mileage.placeholder = @"Price Rank";
 		btn_Mileage.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_Mileage.delegate = self;
        btn_Mileage.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_Mileage];

		yOffset += 30.0f;
        

		//Days’ Supply
		tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 90.0f, 20.0)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Days’ Supply";
		[scrollView addSubview:tmpLabel];
		
		yOffset += 20.0f;
		
		btn_Mileage = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
		btn_Mileage.borderStyle = UITextBorderStyleRoundedRect;
		btn_Mileage.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Mileage.placeholder = @"Days’ Supply";
 		btn_Mileage.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_Mileage.delegate = self;
        btn_Mileage.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_Mileage];
        
		yOffset += 30.0f;
        
		//Graph
		tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 90.0f, 20.0)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Graph";
		[scrollView addSubview:tmpLabel];
		
		yOffset += 20.0f;
		
		btn_Search = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		[btn_Search setTitle:@"" forState:UIControlStateNormal];
		[btn_Search setBackgroundImage:[UIImage imageNamed:@"keyboard.png"] forState:UIControlStateNormal];
		[btn_Search setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btn_Search.titleLabel.font = [UIFont boldSystemFontOfSize:20];
		[btn_Search setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		btn_Search.frame = CGRectMake(10.0f, yOffset, 300.0f, 30.0f);
		[scrollView addSubview:btn_Search];		
		
		//Picker View Creation		
		_pickerDone = [UIToolbar new];
		[_pickerDone sizeToFit];
//		_pickerDone.frame = CGRectMake(0.0f, frame.size.height - 215.0f - 42.0f, frame.size.width, _pickerDone.frame.size.height);
		_pickerDone.frame = CGRectMake(0.0f, 480.0, frame.size.width, _pickerDone.frame.size.height);
		//[[UIToolbar alloc] initWithFrame:CGRectMake(0.0f, frame.size.height - 215.0f - 40.0f, frame.size.width, 44.0f)];
		_pickerDone.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
		_pickerDone.barStyle = UIBarStyleBlack;
		_pickerDone.contentMode = UIViewContentModeRight;
		UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(pickerDone:)];
		UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
		[_pickerDone setItems:[NSArray arrayWithObjects:spacer, done, nil] animated:NO];
		

		scrollView.contentSize = CGSizeMake(320.0f, yOffset);

		
        [UIView setAnimationsEnabled:YES];

		_userToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];
		
		years = [NSMutableArray array];
		makes = [NSMutableArray array];
		models = [NSMutableArray array];
		
        self.dealerList = [[appDelegate currentInstance] getDealerList];
        dealerLots = [NSMutableArray array];
        dealerNameKeys = [NSMutableArray array];
        
        for(int i = 0; i < [self.dealerList count]; i++) {
            [dealerLots addObject:[NSString stringWithFormat:@"%d", ((Dealer*)[self.dealerList objectAtIndex:i]).lotKey]];
            [dealerNameKeys addObject:[NSString stringWithFormat:@"%@", ((Dealer*)[self.dealerList objectAtIndex:i]).name]];
        }
	}

	return self;
}


- (void)alertView:(UIAlertView *)inAlertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
//	[target performSelector:errorCallback withObject:self];
    [target advSearchError:nil];
}


#pragma mark UITextField delegate methods

- (BOOL)textFieldShouldClear:(UITextField *)textField {
	return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
	//[self showPicker:textField];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    latsetTextField = textField;
}


- (void)registerForKeyboardNotifications 
{ 
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(keyboardWasShown:) 
												 name:UIKeyboardDidShowNotification object:nil]; 
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(keyboardWasHidden:) 
												 name:UIKeyboardDidHideNotification object:nil]; 
}

- (void)unregisterForKeyboardNotifications
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark UIPickerView delegate methods

// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
	if([pickerView isEqual: pickerOne]) {
		return 1;
	} else if([pickerView isEqual: pickerTwo]) {
		return 2;
	}
	
	return 0;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
	if([pickerView isEqual: pickerOne]) {
		return [(NSArray*)[oneDataSource objectAtIndex:component] count];
	} else if([pickerView isEqual: pickerTwo]) {
		return [(NSArray*)[twoDataSource objectAtIndex:component] count];
	}

	return 0;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
	if([pickerView isEqual: pickerOne]) {
		return [(NSArray*)[oneDataSource objectAtIndex:component] objectAtIndex:row];
	} else if([pickerView isEqual: pickerTwo]) {
		return [(NSArray*)[twoDataSource objectAtIndex:component] objectAtIndex:row];
	}
	
	return 0;
}


- (void) MakesAndModelsComplete:(MakesAndModels*)makesModels{
	if(makesModels == nil)
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Unable to update Makes"
															message:@"Please ensure you have a network connection and try again."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}
	mAndm = makesModels;
//	_priorityView.hidden = YES;
//	[loadingView removeFromSuperview];
//	[loadingView release];
//	loadingView = nil;
}

- (void) SearchValuesComplete:(SearchValuesResults*)svResults withStatus:dResult{
	if(![dResult isEqualToString:@"Success"])
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"The Web Services Failed"
															message:dResult 
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		
		return;
	}
	
	if(svResults == nil)
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Unable to get Makes/Models"
															message:@"Please ensure you have a network connection and try again."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}

	searchValuesResults = svResults;
	
	[searchView.activityIndicator stopAnimating];
	searchView.activityLabel.hidden = YES;
	[searchView removeFromSuperview];
	
}

- (void)dealloc {
	[self unregisterForKeyboardNotifications];
//	[[appDelegate currentInstance] cancelMakesAndModels];
	
	
//	[loadingView release];
	
}

@end
