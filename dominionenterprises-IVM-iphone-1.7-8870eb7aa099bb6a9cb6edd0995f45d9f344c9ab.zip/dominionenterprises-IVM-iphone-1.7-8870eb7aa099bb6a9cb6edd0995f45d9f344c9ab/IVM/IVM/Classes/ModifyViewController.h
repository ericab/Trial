//
//  ModifyViewController.h
//  GetAuto.com
//
//  Created by Shaofeng Tu on 11/5/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ModifyViewControllerDelegate <NSObject>
@optional
- (void)updateVehiclePrice:(int)newPrice;
- (void)updateVehicleStatus;

@end

@interface ModifyViewController : UIViewController< UITextFieldDelegate, UIPickerViewDataSource, UIPickerViewDelegate > {

	UIToolbar		*_pickerDone;
	UIPickerView	*pickerView;
	NSMutableArray	*arrayItems;

	UIButton		*btn_items;
	UIButton		*btn_modify;

	int				_selectedIndex;
	int				_preIndex;
	int				_currentPrice;
	int				_vehicleKey;
	int				_price;

	NSNumberFormatter		*currencyFormatter;
	NSCharacterSet	*nonNumberSet;
	CGFloat					animatedDistance;

	UIView			*priceLayout;
	UILabel			*priceLabel;
	UITextField		*txt_price;
	UILabel			*stsLabel;
	UILabel			*newLabel;

	id <ModifyViewControllerDelegate> __unsafe_unretained delegate;
}

@property (nonatomic, unsafe_unretained) id <ModifyViewControllerDelegate> delegate;

- (id)initWithKey:(int)vehicleKey withValue:(int)price;
- (void)hideModal:(UIView*) modalView;
- (void)hideModalEnded:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context;
- (void) switchModifyViews;

@end
