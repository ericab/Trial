/*
 * Copyright (c), MM Weiss
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *     1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer.
 *     
 *     2. Redistributions in binary form must reproduce the above copyright notice, 
 *     this list of conditions and the following disclaimer in the documentation 
 *     and/or other materials provided with the distribution.
 *     
 *     3. Neither the name of the MM Weiss nor the names of its contributors 
 *     may be used to endorse or promote products derived from this software without 
 *     specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 * SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
/*
 *  common-digest-bridge.c
 *  common-digest-bridge
 *
 */

#include "common-digest-bridge.h"

unsigned char *cdb_hash_bytes(const void *bytes, CC_LONG byteslen, int hashtype, CC_LONG *hash_byteslen)
{
	unsigned char *(*CC_XXX)(const void *, CC_LONG, unsigned char *);
	CC_LONG CC_XXX_DIGEST_LEN;
	unsigned char *md = NULL;
	
	switch (hashtype) {
		case CDB_MD5_DIGEST:
			CC_XXX = CC_MD5;
			CC_XXX_DIGEST_LEN = CC_MD5_DIGEST_LENGTH;
		break;
		case CDB_SHA1_DIGEST:
			CC_XXX = CC_SHA1;
			CC_XXX_DIGEST_LEN = CC_SHA1_DIGEST_LENGTH;
		break;
		case CDB_SHA256_DIGEST:
			CC_XXX = CC_SHA256;
			CC_XXX_DIGEST_LEN = CC_SHA256_DIGEST_LENGTH;
		break;
		case CDB_SHA512_DIGEST:
			CC_XXX = CC_SHA512;
			CC_XXX_DIGEST_LEN = CC_SHA512_DIGEST_LENGTH;
		break;
		default:
			return NULL;
	}
	
	if((md = malloc(CC_XXX_DIGEST_LEN * sizeof(unsigned char) + 1))) {
		memset(md, 0, CC_XXX_DIGEST_LEN + 1); // assigns 0 to the block
		if (NULL != hash_byteslen) {
			*hash_byteslen = CC_XXX_DIGEST_LEN;
		}
		CC_XXX(bytes, byteslen, md);
	}
	
	return md;
}

char *cdb_bytes_to_hexa(unsigned char *hash_bytes, CC_LONG hash_byteslen, CC_LONG *hexa_byteslen)
{
	int i;
	char *buffer = NULL;
	char hex[3];
	
	if((buffer = malloc(hash_byteslen * 2 * sizeof(char) + 1))) {
		strcpy(buffer, "");	
		for (i = 0; i < hash_byteslen; ++i) {
			sprintf(hex, "%02x", (CC_LONG)hash_bytes[i]);
			strcat(buffer, hex);
		}
		if (NULL != hexa_byteslen) {
			*hexa_byteslen = hash_byteslen * 2;
		}
	}
	
	return buffer;
}

char *cdb_hash_hexa(const void *bytes, CC_LONG byteslen, int hashtype, CC_LONG *hexa_byteslen)
{
	unsigned char *hash_bytes = NULL;
	CC_LONG hash_byteslen, hex_byteslen;
	char *hash_hexa = NULL;
	
	if((hash_bytes = cdb_hash_bytes(bytes, byteslen, hashtype, &hash_byteslen))) {
		hash_hexa = cdb_bytes_to_hexa(hash_bytes, hash_byteslen, &hex_byteslen);
		if (NULL != hexa_byteslen) {
			*hexa_byteslen = hex_byteslen;
		}
		free(hash_bytes);
	}
	
	return hash_hexa;
}

/* EOF */