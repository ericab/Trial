/*
 * Copyright (c), MM Weiss
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 *     1. Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer.
 *     
 *     2. Redistributions in binary form must reproduce the above copyright notice, 
 *     this list of conditions and the following disclaimer in the documentation 
 *     and/or other materials provided with the distribution.
 *     
 *     3. Neither the name of the MM Weiss nor the names of its contributors 
 *     may be used to endorse or promote products derived from this software without 
 *     specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 * SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
/*
 *  DataCommonDigestAddition.m
 *  common-digest-bridge
 *
 */
  
#import "DataCommonDigestAddition.h"

@implementation NSData (DataCommonDigestAddition)

#include "common-digest-bridge.h"

- (NSData *)dataWithSha256
{
	unsigned char *hash_bytes;
	CC_LONG hash_byteslen;
	NSData *data = nil;
	
	if((hash_bytes = cdb_hash_bytes([self bytes], 
			[self length], CDB_SHA256_DIGEST, &hash_byteslen))) {
		data = [NSData dataWithBytes:hash_bytes length:hash_byteslen];
		free(hash_bytes);
	}
  
 	return data;
}

- (NSData *)dataWithSha1
{
	unsigned char *hash_bytes;
	CC_LONG hash_byteslen;
	NSData *data = nil;
	
	if((hash_bytes = cdb_hash_bytes([self bytes], 
			[self length], CDB_SHA1_DIGEST, &hash_byteslen))) {
		data = [NSData dataWithBytes:hash_bytes length:hash_byteslen];
		free(hash_bytes);
	}
  
 	return data;
}

- (NSString *)hexaWithData
{
	char *bytes_to_hexa = NULL;
	CC_LONG hexa_byteslen;
	NSString *string = nil;
	
	if((bytes_to_hexa = cdb_bytes_to_hexa((unsigned char *)
			[self bytes], [self length], &hexa_byteslen))) {
//		string = [NSString stringWithCString:bytes_to_hexa length:hexa_byteslen];
		string = [NSString stringWithCString:bytes_to_hexa encoding:NSASCIIStringEncoding];
		free(bytes_to_hexa);
	}
	
	return string;	
}

- (NSString *)hexaWithSha1
{
	char *hash_hexa = NULL;
	CC_LONG hexa_byteslen;
	NSString *string = nil;
	
	if((hash_hexa = cdb_hash_hexa([self bytes], 
			[self length], CDB_SHA1_DIGEST, &hexa_byteslen))) {
		string = [NSString stringWithCString:hash_hexa encoding:NSASCIIStringEncoding];
//		string = [NSString stringWithCString:hash_hexa length:hexa_byteslen];
		free(hash_hexa);
	}
	
	return string;
}

@end

/* EOF */