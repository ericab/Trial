//
//  Dealer.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/19/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <Foundation/Foundation.h>

/*<DSDataSet>
 <DEALERLIST 
 dealer_lot_key="3737" 
 latitude="36.8421" 
 longitude="-76.0932" 
 name="Rk Chevrolet" 
 address="2661 Virginia Beach Blvd." 
 address2="" 
 city="Virginia Beach" 
 state="VA" 
 postal_code="23452" 
 distance="2.4714" />
 </DSDataSet>*/
@interface Dealer : NSObject {
	int			lotKey;
	NSString	*name;
//	NSString	*address;
//	NSString	*address2;
//	NSString	*city;
//	NSString	*comments;
//	NSString	*contactName;
//	NSString	*state;
//	NSString	*zip;
//	NSString	*email;
//	NSString	*fax;
//	NSString	*phone;
//	NSString	*webSite;
//	NSMutableArray		*photos;
//	NSString	*result;
//	NSString	*execeptionText;
}

@property(assign)	int			lotKey;
@property(copy)		NSString	*name;
//@property(copy)		NSString	*address;
//@property(copy)		NSString	*address2;
//@property(copy)		NSString	*city;
//@property(copy)		NSString	*comments;
//@property(copy)		NSString	*contactName;
//@property(copy)		NSString	*state;
//@property(copy)		NSString	*zip;
//@property(copy)		NSString	*email;
//@property(copy)		NSString	*fax;
//@property(copy)		NSString	*phone;
//@property(copy)		NSString	*webSite;
//@property(retain)		NSMutableArray	*photos;
//@property(copy)		NSString	*result;
//@property(copy)		NSString	*execeptionText;

@end
