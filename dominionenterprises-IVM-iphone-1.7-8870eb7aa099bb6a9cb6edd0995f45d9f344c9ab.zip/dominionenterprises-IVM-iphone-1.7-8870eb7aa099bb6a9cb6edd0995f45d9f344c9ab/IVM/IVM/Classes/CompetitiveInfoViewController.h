//
//  CompetitiveInfoViewController.h
//  CompetitiveInfoViewController
//
//  Created by Pardha IT Solutions on 28/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchResultsView.h"
#import "EWMultiColumnTableView.h"
@interface CompetitiveInfoViewController : UIViewController<EWMultiColumnTableViewDataSource>
{
    NSMutableArray *details,*subdetails;
    NSMutableArray *Names;
    
    NSMutableArray *Price;
    NSMutableArray *Milage;
    NSMutableArray *Age;
    NSMutableArray *Distance;


    
    CGFloat colWidth;
    NSInteger numberOfSections;
    NSInteger numberOfColumns;
    EWMultiColumnTableView *tblView;
    UILabel *l,*l1,*l2,*l3,*l4,*l5;
     NSMutableArray                      *arrayOfCompetitiveData;  
     SearchResultsView                 *progressView;

}

@end
