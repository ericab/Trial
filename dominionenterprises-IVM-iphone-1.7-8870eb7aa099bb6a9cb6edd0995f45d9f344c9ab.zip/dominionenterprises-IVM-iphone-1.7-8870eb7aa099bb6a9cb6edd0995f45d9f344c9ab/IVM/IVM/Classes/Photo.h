//
//  Photo.h
//  GetAuto.com
//
//  Created by Shaofeng Tu on 7/16/09.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Photo : NSObject {
	int			lotKey;
	int			vehicleKey;
	NSString	*c640Image;
	NSString	*m200Image;
	NSString	*s1024Image;
	NSString	*t100Image;
}

@property(assign)	int			lotKey;
@property(assign)	int			vehicleKey;
@property(copy)		NSString	*c640Image;
@property(copy)		NSString	*m200Image;
@property(copy)		NSString	*s1024Image;
@property(copy)		NSString	*t100Image;

@end
