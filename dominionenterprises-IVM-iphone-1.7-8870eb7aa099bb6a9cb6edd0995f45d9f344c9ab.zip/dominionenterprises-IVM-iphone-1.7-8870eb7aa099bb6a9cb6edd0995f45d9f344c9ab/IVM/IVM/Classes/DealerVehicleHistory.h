//
//  DealerVehicleHistory.h
//  IVM
//
//  Created by Sehaswaran Mayilerum on 6/27/12.

//

#import <Foundation/Foundation.h>

@interface DealerVehicleHistory : NSObject
@property(nonatomic,assign) BOOL hasCarfax;
@property(nonatomic,assign) BOOL hasAutoCheck;
@end
