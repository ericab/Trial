//
//  HomeViewController.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 1/28/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//
//  Updated by Raja Sekhar Nerella on 3/20/12.

#import "HomeViewController.h"
#import "SearchResultsController.h"
#import "AdvancedSearchController.h"
#import <QuartzCore/CoreAnimation.h>
#import "appDelegate.h"
#import <objc/runtime.h>
#import "IVM.h"
#import "AddToInventoryController.h"
#import "LoginViewController.h"
#import "AppraisalSearchResultsController.h"
#import "IVM.h"

@implementation HomeViewController

@synthesize homeTable;
@synthesize listings;
@synthesize reqType;
@synthesize loadingView;

- (id) init
{
	self = [super init];
	if (self != nil) {
		[appDelegate track:@"Home"];
	}
    self.listings = [NSArray arrayWithObjects: @"View Inventory", @"Add to Inventory", @"Appraisal", /*@"Data Providers", @"Settings",*/ nil ];
	return self;
}
-(void) refreshData
{
    dealerList=[[appDelegate currentInstance]getDealerList];
    [SimplePickerInputTableViewCell initialize];
    [homeTable scrollsToTop];
    [homeTable reloadData];
}
-(void) stopLoadingView
{
     reqType=0;
    if (loadingView != nil)
    {
        [loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
        loadingView = nil;
    }
   
}
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
    
    dealerList=[[NSMutableArray alloc]init];
	float yOffset = 120.0f;
	UIView *vw = [[UIView alloc] initWithFrame:CGRectZero];
	vw.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
	self.view = vw;
	//Create header image
	UIImageView *header = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DSP_logo.png"]];
	header.frame = CGRectMake(30.0f, 0.0f, 240.0f, yOffset);
	header.contentMode = UIViewContentModeScaleAspectFit;
	[self.view addSubview:header];
    header.layer.shadowOffset = CGSizeMake(3.0, 3.0);
    header.layer.shadowOpacity = 0.6;
    header.layer.shadowColor = [UIColor darkGrayColor].CGColor;

	homeTable = [[UITableView alloc] initWithFrame:CGRectMake(10.0f, yOffset - 10.0, 300.0f, 230.0f) style:UITableViewStyleGrouped];
	homeTable.backgroundColor = [UIColor clearColor];
	homeTable.delegate = self;
	homeTable.dataSource = self;
    homeTable.scrollEnabled=NO;
	[self.view addSubview:homeTable];
	self.navigationItem.title = @"Home";
}
- (void)viewWillAppear:(BOOL)animated
{
    dealerList=[[appDelegate currentInstance] getDealerList];
    if(![appDelegate currentInstance].vehicleHistoryStatus)
    {
    reqType=20;
    if (loadingView == nil) {
        loadingView = [LoadingView loadingViewInView:[[[UIApplication sharedApplication] windows] objectAtIndex:0]];
    }
    }
	//Enable the Right Navigator Button
    NSUserDefaults *prefs =[NSUserDefaults standardUserDefaults];
    checkboxSelected = [prefs boolForKey:kKeepLoggedIn];
		if (self.navigationItem.rightBarButtonItem == nil) {
			self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Logout" style:UIBarButtonItemStyleBordered  target:self action:@selector(logoutButton:)];
		}
}
- (void) performSearch:(VehicleSearchObject*)vso{
	SearchResultsController *searchController = [SearchResultsController new];
	[[self navigationController] pushViewController:searchController animated:YES];
	[searchController startSearch:vso];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}
- (NSArray*)getRestoreData{
	//Create an array of child view controllers
	NSMutableArray *children = [NSMutableArray array];
	for(int i = [self.navigationController.viewControllers indexOfObject:self] + 1; i < [self.navigationController.viewControllers count]; i++)
	{
		UIViewController *vc = [self.navigationController.viewControllers objectAtIndex:i];
		//Store the information for the child in the array
		if([vc conformsToProtocol:@protocol(ItemRestore)])
			[children addObject:[NSDictionary dictionaryWithObject:[vc performSelector:@selector(getRestoreData)] forKey:NSStringFromClass([vc class])]];
	}
	return children;
}
- (void)restore:(NSArray*)data{
	//Loop through child data
	for(NSDictionary* child_data in data)
	{
		if([[child_data allKeys] count] < 1) continue;
		NSString *clss = [[child_data allKeys] objectAtIndex:0];
		//Create a class from the key
		Class controller = [[NSBundle mainBundle] classNamed:clss];
		//Make sure the class is the correct type
		if(class_conformsToProtocol(controller, @protocol(ItemRestore)))
		{
			id<ItemRestore> tmp = [[controller alloc] initWithRestore:[child_data objectForKey:clss]];
			if([tmp isKindOfClass:[UIViewController class]])
				[self.navigationController pushViewController:(UIViewController*)tmp animated:NO];
		}
	}
}
- (void)doFunctions:(id)sender{
	AdvancedSearchController *advancedSearch = nil;
	AddToInventoryController *addinventory = nil;
	AppraisalSearchResultsController *appraisalsearchresults = nil; 
    int t = [sender tag];  // not getTag
	switch (t) {
		case 1:
			addinventory = [AddToInventoryController new];
			[self.navigationController pushViewController:addinventory animated:YES];
			break;
		case 2:
			advancedSearch = [AdvancedSearchController new];
			[[self navigationController] pushViewController:advancedSearch animated:YES];
			break;
		case 3:
			appraisalsearchresults = [AppraisalSearchResultsController new];
			[[self navigationController] pushViewController:appraisalsearchresults animated:YES];
			break; 
    case 6:
			;UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil
																 message:@"Coming Soon ..."
																delegate:nil
													   cancelButtonTitle:@"Ok"
													   otherButtonTitles:nil];
			
			[alertView show];
			
			break;
	}
}
- (void)logoutButton:(id)sender{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Confirm Logout"
														message:@"Are you sure want to logout?"
													   delegate:self
											  cancelButtonTitle:@"NO"
											  otherButtonTitles:nil];
	
	[alertView addButtonWithTitle:@"YES"];
	[alertView show];
}
- (void)tableViewCell:(SimplePickerInputTableViewCell *)simplePickerInputTableViewCellcell didEndEditingWithValue:(NSString *)value {
    simplePickerInputTableViewCellcell.textLabel.text=value;
}
#pragma mark -
#pragma mark Rest Web Service (Apprasial ) Call back method
-(void) handleResponseForQuery:(NSMutableDictionary *)response
{
    if([[response objectForKey:@"responseString"] isEqualToString:@"Permission"])
    {
        [appDelegate currentInstance].vehicleHistoryStatus=YES;
        selectedDealerHasAccessAppraisal=YES;
        [self refreshData];
        reqType=20;
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:reqType],@"reqtype", [appDelegate currentInstance],@"delegate", nil];
        IVMMobileServices *ws = [[IVMMobileServices alloc] init];
        [ws initialize:dic];
        [ws callWSWithQuery:dic];
        
    }
    else
    {
        selectedDealerHasAccessAppraisal=NO;
        [appDelegate currentInstance].vehicleHistoryStatus=YES;
        [self stopLoadingView];
        [self refreshData];
        
    }
}
#pragma mark -
#pragma mark alertView methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    selectedDealerHasAccessAppraisal=FALSE;
    if(reqType==20 || reqType==28)
    {
        [[appDelegate currentInstance] clearVehicleMapping];
		//Delete the Current User Token
		[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserToken];
		[[NSUserDefaults standardUserDefaults] synchronize];
        
        [self stopLoadingView];
        [[self navigationController] popViewControllerAnimated:YES];
    }
    else if (buttonIndex != alertView.cancelButtonIndex) {
        [self stopLoadingView];
        [[appDelegate currentInstance] clearVehicleMapping];
		//Delete the Current User Token
		[[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserToken];
		[[NSUserDefaults standardUserDefaults] synchronize];
		//Display LoginView
		LoginViewController* lvc = [LoginViewController new];
		lvc.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
		[self presentModalViewController:lvc animated:YES];
    }
}  
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    int noOfRows=0;
    if(section==0)
        noOfRows= 1;
    else
    {
        int dealerLot = [[NSUserDefaults standardUserDefaults] integerForKey:kDefaultDealerLot];
        if(dealerLot > 0) {
            BOOL isMatchDealerLot=FALSE;
            for (Dealer *tdealer in dealerList) {
                if (tdealer.lotKey == dealerLot) {
                    isMatchDealerLot=TRUE;
                    break;
                }
            }
            if(isMatchDealerLot)
            {
                //NSLog(@"%dFirst",selectedDealerHasAccessAppraisal);
                if(selectedDealerHasAccessAppraisal)
                {
                    noOfRows=[self.listings count];
                }
                else
                {
                    noOfRows=[self.listings count]-1;
                }
            }
            else
            {
                noOfRows=[self.listings count];
            }
		}
        else
        {
            noOfRows=[self.listings count];
        }
    
    }
    return noOfRows;
}
/*- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if(section==0)
    {
        int dealerLot = [[NSUserDefaults standardUserDefaults] integerForKey:kDefaultDealerLot];
        if(dealerLot > 0)
         return @"Change Dealer";
         return @"Select Dealer";
    }
    return @"";
}*/
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	AdvancedSearchController *advancedSearch = nil;
	AddToInventoryController *addinventory = nil;
    AppraisalSearchResultsController *appraisalsearchresults = nil;
    if(indexPath.section)
    {
	switch (indexPath.row) {
        case 0:
			advancedSearch = [AdvancedSearchController new];
			[[self navigationController] pushViewController:advancedSearch animated:YES];
			break;
		case 1:
			addinventory = [AddToInventoryController new];
			[self.navigationController pushViewController:addinventory animated:YES];
			break;
		case 2:
                  appraisalsearchresults = [AppraisalSearchResultsController new];
			[[self navigationController] pushViewController:appraisalsearchresults animated:YES];
            appraisalsearchresults.reqType=26;
            {
                   NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithInt:appraisalsearchresults.reqType],@"reqtype", appraisalsearchresults,@"delegate", nil];
                IVMMobileServices *ws = [[IVMMobileServices alloc] init];
                [ws initialize:dic];
                 [ws callWSWithQuery:dic];
            }
			break;
        default:
            break;
	}
    }
    else
    {
        [cell setValue:cell.textLabel.text];
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifierCustom = @"CustomCell";
    if(indexPath.section==0)
    {
    cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifierCustom];
    if (cell == nil) {
        cell = [[SimplePickerInputTableViewCell alloc] initWithFrame:CGRectZero]; //reuseIdentifier:CellIdentifierCustom] ;
        cell.delegate=self;
        cell.homeViewController=self;
        
    }
   int dealerLot = [[NSUserDefaults standardUserDefaults] integerForKey:kDefaultDealerLot];
        if(dealerLot > 0) {
            BOOL isMatchDealerLot=FALSE;
            for (Dealer *tdealer in dealerList) {
                if (tdealer.lotKey == dealerLot) {
                    isMatchDealerLot=TRUE;
                     cell.textLabel.text = tdealer.name;
                        [cell setValue:tdealer.name];
                    break;
                }
            }
            if(!isMatchDealerLot)
            {
                cell.textLabel.text = @"Select Dealer";
            }
		}
        else
        {
           cell.textLabel.text = @"Select Dealer";
        }
        
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
    }
    else
    {
    UITableViewCell *uitableviewcell = [tableView dequeueReusableCellWithIdentifier:nil];
    if (uitableviewcell == nil) {
        uitableviewcell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }
    uitableviewcell.textLabel.text = [NSString stringWithFormat:@"%@", [self.listings objectAtIndex:indexPath.row]];
    uitableviewcell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    int dealerLot = [[NSUserDefaults standardUserDefaults] integerForKey:kDefaultDealerLot];
        if(dealerLot > 0)
        {
                BOOL isMatchDealerLot=FALSE;
                for (Dealer *tdealer in dealerList) {
                    if (tdealer.lotKey == dealerLot) {
                        isMatchDealerLot=TRUE;
                        uitableviewcell.userInteractionEnabled = YES;
                        break;
                    }
                }
                if(!isMatchDealerLot)
                {
                    uitableviewcell.userInteractionEnabled = NO;
                }
        }
        else
            uitableviewcell.userInteractionEnabled = NO;
	return uitableviewcell;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 40.0;
}
- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title														message:message											delegate:self											  cancelButtonTitle:@"Ok"									otherButtonTitles:nil];
	[alertView show];
}
@end
