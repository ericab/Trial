//
//  SearchAppraisalsViewController.m
//  IVM
//
//  Created by Raja Sekhar Nerella on 07/06/12.

//
#import "SearchAppraisalsViewController.h"
#import "AppraisalSearchResultsController.h"
@interface SearchAppraisalsViewController ()
@end

@implementation SearchAppraisalsViewController
@synthesize rvController;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void) loadView
{
    UIView *vw = [[UIView alloc] initWithFrame:CGRectZero];
    self.view = vw;
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
@end
