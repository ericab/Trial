//
//  AddAppraisalViewController.h
//  IVM
//
//  Created by Raja Sekhar Nerella on 29/05/12.
//  
// Add or Re-appraise controller

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "RestoreProtocols.h"
#import "IVMMobileServices.h"
#import "DecodeData.h"
#import "LoadingView.h"
#import "SearchResultsView.h"
#import "AppraisalSearchResultsController.h"
#import "PhoneNumberFormatter.h"

// Define some constants:
#define ALPHA                   @"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
#define NUMERIC                 @"1234567890"
#define ALPHA_NUMERIC           ALPHA NUMERIC

@interface AddAppraisalViewController : UIViewController<UITextFieldDelegate,UIAlertViewDelegate, 
IVMMobileServicesDelegate, ZBarReaderDelegate, ItemRestore,UIPickerViewDelegate,UIPickerViewDataSource>
{
    UIScrollView		*scrollView;
    UITextField        *txt_status;
    UITextField        *txt_vin;
    UITextField        *txt_year;
    UITextField        *txt_make;
    UITextField        *txt_model;
    UITextField        *txt_trim;
    UITextField        *txt_style;
    UITextField        *txt_mileage;
    UITextField        *txt_exteriorcolor;
    UITextField        *txt_interiorcolor;
    UITextField        *txt_appraisalid;
    UITextField        *txt_dealerlotkey;
    
    NSString        *str_dealerlotkey;
    NSString        *str_appraisalid;
    
    NSString        *str_vin;
    NSString        *str_year;
    NSString        *str_make;
    NSString        *str_model;
    NSString        *str_style;
    NSString        *str_trim;
    
    NSString        *str_mileage;
    NSString        *str_exteriorcolor;
    NSString        *str_interiorcolor;
    
    UIView *backgroundView01;
    UIView              *backgroundView02;
    UIImageView         *vinView;
    UILabel             *orLabel;
    UILabel             *vinLabel;
    UILabel             *priceLabel;
    
    
    UIButton			*btn_vinDecode;
    UIButton			*btn_calculate;
    
    UIButton			*btn_update;
    
    IVMMobileServices		*mobileServices;
	VehicleDetails			*_vehicleDetail;
    
	LoadingView				*loadingView;
    
    NSDictionary	*restore_data;
	
	DecodeData		*decData;
	NSString		*_userToken;
    
    BOOL     decodingSelected;
    NSString			*vinCode;
    NSNumberFormatter   *currencyFormatter;
    NSCharacterSet      *nonNumberSet;
	NSCharacterSet      *nonVINCodeCharactersSet;
    NSCharacterSet      *nonCharacterSet;
    
    
    UITextField *txt_customer;
    UITextField *txt_customerAddress;
    UITextField *txt_city;
    UITextField *txt_state;
    UITextField *txt_zip;
    UITextField *txt_phone;
    UITextField *txt_mobile;
    UITextField *txt_email;
    
    NSString *str_customer;
    NSString *str_customerAddress;
    NSString *str_city;
    NSString *str_state;
    NSString *str_zip;
    NSString *str_phone;
    NSString *str_mobile;
    NSString *str_email;
    
    
    UITextField * txt_expectedsaleprice;
    UITextField * txt_profitobective;
    UITextField * txt_datasalesperson;
    UITextField * txt_appraisedvalue;
    UITextField * txt_notes;
    UITextField * txt_recondtioning;
    UITextField * txt_recommendedprice;
    UITextField * txt_marketaveragemileage;
    UITextField * txt_marketaverageprice;
    UITextField * txt_marketsize;
     UITextField * txt_pricerank;
    UITextField * txt_dayssupply;
     UITextField        *txt_titaniumid;
     NSString  * str_expectedsaleprice;
     NSString * str_profitobective;
     NSString * str_datasalesperson;
     NSString * str_appraisedvalue;
     NSString * str_notes;
     NSString * str_recondtioning;
    NSString * str_recommendedprice;
    NSString * str_marketaveragemileage;
    NSString * str_marketaverageprice;
    NSString * str_marketsize;
    NSString * str_pricerank;
    NSString * str_dayssupply;
    NSString * str_status;
    NSString * str_titaniumid;
    
    BOOL bReappraisalSelected;
    float yOffset;
    
    UIButton			*btn_VinCodeScan;
    
    NSMutableArray		*statuses;
    NSMutableArray		*years;
	NSMutableArray		*makes;
	NSMutableArray		*models;
	NSMutableArray		*styles;
	NSMutableArray		*trims;
    NSMutableArray		*exteriorColors;
	NSMutableArray		*interiorColors;
    NSMutableArray		*stateNames;
	NSMutableArray		*stateCodes;
    NSMutableArray		*titaniumIds;
    
    UIPickerView		*pickerOne;
    UIToolbar			*_pickerOneDone;
    id latsetTextField;
    NSMutableArray		*oneDataSource;
    
    //SearchResultsView                 *progressView;
    UIButton *doneButton;
    
    NSNumberFormatter *numberFormatter;
    NSString *newAppraisalId;
    NSMutableArray *providerSummary;
    NSDictionary    *providerSummaryDetails;
    CGFloat				animatedDistance;
    int selectedRow;
    BOOL calculateApprasial;
    BOOL saveApprasial;
    
    NSString        *str_year_old;
    NSString        *str_make_old;
    NSString        *str_model_old;
    NSString        *str_style_old;
    NSString        *str_trim_old;
    
    NSString        *str_mileage_old;
    
    PhoneNumberFormatter *phoneNumberFormatter;
    
}
@property (nonatomic, strong)	UIButton	*btn_VinCodeScan;
// Interger 1 = add , 2=reappraise
@property(nonatomic,assign) NSInteger apprasialStatus;
@property(nonatomic,retain) AppraisalSearchResultsController *appraisalSearchResultsController;
@property(nonatomic,assign) int reqType;
-(void) reappraisalData:(NSDictionary *)appraisalDetails;
- (void)buildStatesList;

@end
