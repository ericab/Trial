//
//  WebViewController.h
//  TraderOnline
//
//  Created by Raja Sekhar Nerella on 9/14/09.
// 
//

#import <Foundation/Foundation.h>
#import "IVMMobileServices.h"

#define kAccelerometerFrequency .001 //Hz

@class DetailActions;

@interface WebViewController : UIViewController<IVMMobileServicesDelegate, UIWebViewDelegate> 
{
	
	UIWebView				*webView;
	NSString				*_url;
	NSString				*_html;
	UIActivityIndicatorView *progressView;
	NSURLConnection			*conn;

	NSString				*_adId;
	NSMutableData			*mData;

	IVMMobileServices		*_mobileServices;
	DetailActions			*_actData;
	NSString				*_usrToken;
}

@property (nonatomic, strong) UIWebView *webView;
@property(copy)				NSString		*_url;
@property(copy)				NSString		*_html;
@property(copy)				NSString		*_adId;
@property(copy)				NSString		*_usrToken;


// initWithURL causes warnings...
- (id)initWithString:(NSString *)url;
- (id)initWithHTML:(NSString *)html adId:(NSString *)adId;
- (void)sendDataToWebService:(NSString *)name email:(NSString *)email phone:(NSString *)phone subject:(NSString *)subj body:(NSString *)comments;


- (void)dismissAction:(id)sender;

@end