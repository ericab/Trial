//
//  CarfaxReportController.m
//  IVM
//
//  Created by Sehaswaran Mayilerum on 6/18/12.

//
#import "CarfaxReportController.h"
#import "appDelegate.h"
@implementation CarfaxReportController
@synthesize carfaxReportWebView;
@synthesize webUrl;
@synthesize loadingView;
@synthesize reqType;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        dealerInfo=[[NSMutableArray alloc]init];
    }
    //Omniture Track Call
    [appDelegate track:@"Vehicle History  View"];
    return self;
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
#pragma mark - View lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if (self.loadingView == nil) {
		self.loadingView = [LoadingView loadingViewInView:self.carfaxReportWebView];
	}
}
- (void)viewDidUnload
{
    [self setCarfaxReportWebView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (void)webViewDidStartLoad:(UIWebView *)webView
{
	//Turn on loading view
	if (self.loadingView == nil) {
		self.loadingView = [LoadingView loadingViewInView:self.carfaxReportWebView];
	}
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
	//Turn off loading view
	if (loadingView != nil) {
		[loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
		loadingView = nil;
	}
}
-(void) handleResponseForQuery:(NSMutableDictionary *)response
{
    if([response objectForKey:@"responseString"])
    {
     if(reqType==17)
     {
        reqType=0;
    NSURL *candidateURL = [NSURL URLWithString:[response objectForKey:@"responseString"]];
    // WARNING > "test" is an URL according to RFCs, being just a path
    // so you still should check scheme and all other NSURL attributes you need
    if (candidateURL && candidateURL.scheme && candidateURL.host) {
        // candidate is a well-formed url with:
        //  - a scheme (like http://)
        //  - a host (like stackoverflow.com)
        webUrl = [response objectForKey:@"responseString"] ;
        NSURL   *urlLocation = [NSURL URLWithString:webUrl];  
        [carfaxReportWebView loadRequest:[NSURLRequest requestWithURL:urlLocation]];
    }
    else{
        [self alertUser:@"Invaild data from the server." title:@"Status"];
    }
    }else if(reqType==18) {
        reqType=0;
        [carfaxReportWebView loadHTMLString:[response objectForKey:@"responseString"] baseURL:[NSURL URLWithString:@""]];
    }
    }
}
- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:message
													   delegate:self
											  cancelButtonTitle:@"Ok"
											  otherButtonTitles:nil];
	[alertView show];
}
#pragma mark alertview delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [[self navigationController] popViewControllerAnimated:YES];
}
@end

