//
//  CompetitiveInfoNewViewController.h
//  IVM
//
//  Created by Sehaswaran Mayilerum on 6/21/12.

// Competitive Info Main View Controller
#import <UIKit/UIKit.h>
#import "LoadingView.h"
#import <QuartzCore/QuartzCore.h>
@interface CompetitiveInfoNewViewController : UITableViewController
{
    NSNumberFormatter *frm;
    NSNumberFormatter *numberFormatter;
     NSMutableArray   *arrayOfCompetitiveInfo;
    NSMutableArray   *arrayOfCompetitiveInfoLabel;
    LoadingView   *loadingView;
}
@property(nonatomic,assign) int reqType;
@end
