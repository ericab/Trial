//
//  AppraisalCustomerDetailsController.h
//  IVM
//
//  Created by Raja Sekhar Nerella on 16/05/12.
//  
//

#import <UIKit/UIKit.h>
#import "LoadingView.h"
#import "AppraisalDetailsController.h"
#import "PhoneNumberFormatter.h"
// Define some constants:
#define ALPHA                   @"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
#define NUMERIC                 @"1234567890"
#define ALPHA_NUMERIC           ALPHA NUMERIC

@interface AppraisalCustomerDetailsController : UIViewController<UITextFieldDelegate,UIAlertViewDelegate,UIPickerViewDelegate,UIPickerViewDataSource>
{
    UIScrollView		*scrollView;
    UITextField *txt_customer;
     UITextField *txt_customerAddress;
     UITextField *txt_city;
     UITextField *txt_state;
    UITextField *txt_zip;
     UITextField *txt_phone;
    UITextField *txt_mobile;
      UITextField *txt_email;
    
  @public NSString *str_customer;
   @public NSString *str_customerAddress;
   @public  NSString *str_city;
   @public  NSString *str_state;
   @public  NSString *str_zip;
   @public NSString *str_phone;
   @public  NSString *str_mobile;
   @public  NSString *str_email;
   
    LoadingView	*loadingView;
    id latsetTextField;
   
    NSMutableArray		*stateNames;
	NSMutableArray		*stateCodes;
   
    UIPickerView		*pickerOne;
    UIToolbar			*_pickerOneDone;
   
    NSMutableArray		*oneDataSource;
    
    UIButton *doneButton;

    CGFloat	animatedDistance;
    
    NSCharacterSet      *nonNumberSet;
    NSCharacterSet      *nonCharacterSet;
    NSString *str_appraisalid_new;
    
    
    PhoneNumberFormatter *phoneNumberFormatter;
    
}
@property(nonatomic,assign) BOOL isAppraisal;
@property (nonatomic,assign) AppraisalDetailsController *appraisalDetailsController;
- (void)buildStatesList;
@property(nonatomic,assign) int reqType;

@end
