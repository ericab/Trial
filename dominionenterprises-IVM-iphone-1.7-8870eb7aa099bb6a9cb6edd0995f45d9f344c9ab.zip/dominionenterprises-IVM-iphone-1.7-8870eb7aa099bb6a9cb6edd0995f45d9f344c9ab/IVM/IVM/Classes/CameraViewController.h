#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"
#import "IVMMobileServices.h"
#import "LoadingView.h"
#import "MBProgressHUD.h"

@interface CameraViewController : UIViewController <UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIAlertViewDelegate, MBProgressHUDDelegate, IVMMobileServicesDelegate, AppRestore> 
{
    BOOL    pickerLoaded;
	BOOL    isCamera;
    BOOL    fileSaved;
	UIImagePickerController *picker;

	LoadingView				*loadingView;
	IVMMobileServices		*mobileServices;
	int						_vehicleKey;
	NSString				*_userToken;

	UIImage					*pickedImage;
	NSString				*base64Image;

	MBProgressHUD			*HUD;
}

@property (nonatomic, strong)	UIImagePickerController *picker;
@property(nonatomic,strong)		MBProgressHUD			*HUD;
@property(nonatomic, strong)	UIImage					*pickedImage;
@property(nonatomic, strong)	NSString				*base64Image;

- (IBAction)cameraButtonTouchAction;
- (BOOL)startCameraPickerFromViewController;
- (id)initWithKey:(int)inKey withType:(BOOL)isCam;
- (id)initWithType:(BOOL)isCam;

@end