//
//  AdvancedSearchView.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 1/19/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//
#import "AdvancedSearchView.h"
#import "IVM.h"
#import "appDelegate.h"
#import "AdvancedSearchController.h"
#import "SearchResultsController.h"
#import "IVMMobileServices.h"
#import "SearchValues.h"
#import "SearchValuesResults.h"
#import "SearchResultsView.h"


@interface AdvancedSearchView()

- (void)registerForKeyboardNotifications;
- (void)unregisterForKeyboardNotifications;
- (void)showPicker:(id)sender;
- (void)pickerDone:(id)sender;
@end

enum{
	MODE_MAKEMODEL = 1,
	MODE_PRICE = 2,
	MODE_YEAR = 3,
	MODE_MILES = 4,
	MODE_DEALERLOT = 5
};

@implementation AdvancedSearchView

@synthesize searchObject, target, btn_Search;

- (id)initWithFrame:(CGRect)frame {
    return [self initWithFrame:frame searchObject:nil filterMode:NO];
}

- (id)initWithFrame:(CGRect)frame searchObject:(VehicleSearchObject*)searchObj filterMode:(BOOL)filter {
	self = [super initWithFrame:frame];
	if(self != nil)
	{
		[UIView setAnimationsEnabled:NO];
		frm_money = [NSNumberFormatter new];	
		[frm_money setNumberStyle:NSNumberFormatterCurrencyStyle];
		[frm_money setMaximumFractionDigits:0];
        NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
        [frm_money setLocale:usLocale];
		frm_decimal = [NSNumberFormatter new];
		[frm_decimal setNumberStyle:NSNumberFormatterDecimalStyle];
		[frm_decimal setMaximumFractionDigits:0];
        [frm_decimal setLocale:usLocale];
        
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		self.searchObject = searchObj == nil ? [VehicleSearchObject new] : searchObj;
		scrollView = [[UIScrollView alloc] initWithFrame:frame];
		scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		[self addSubview:scrollView];
		
		UIColor *textColor = [UIColor blackColor];
		UIFont *lblFont = [UIFont fontWithName:kDefaultFontBold size:kDefaultFontSize + 2.0];
		
		float yOffset = 10.0f;
		
        //Year
		UILabel *tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Year";
		[scrollView addSubview:tmpLabel];
		
		yOffset += 20.0f;
		btn_Year = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
		btn_Year.borderStyle = UITextBorderStyleRoundedRect;
		btn_Year.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Year.placeholder = @"Any";
 		btn_Year.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_Year.delegate = self;
        btn_Year.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;

		[scrollView addSubview:btn_Year];
		
		yOffset += 35.0f;
		
		//Make/Model
		tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0f)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Make/Model";
		[scrollView addSubview:tmpLabel];
		
		yOffset += 20.0f;

		btn_MakeModel = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
		btn_MakeModel.borderStyle = UITextBorderStyleRoundedRect;
		btn_MakeModel.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_MakeModel.placeholder = @"All";
 		btn_MakeModel.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_MakeModel.delegate = self;
        btn_MakeModel.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_MakeModel];
		
		yOffset += 35.0f;
		
		//Price
		tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Price Range";
		[scrollView addSubview:tmpLabel];
		
		yOffset += 20.0f;

		btn_Price = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
		btn_Price.borderStyle = UITextBorderStyleRoundedRect;
		btn_Price.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Price.placeholder = @"Any";
 		btn_Price.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_Price.delegate = self;
        btn_Price.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_Price];
		
		yOffset += 35.0f;
	
		//Mileage
		tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(15.0f, yOffset, 110.0f, 20.0)];
		//tmpLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Mileage";
		[scrollView addSubview:tmpLabel];
		
		yOffset += 20.0f;

		btn_Mileage = [[UITextField alloc] initWithFrame:CGRectMake(10.0f, yOffset, 300.0f, 25.0)];
		btn_Mileage.borderStyle = UITextBorderStyleRoundedRect;
		btn_Mileage.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Mileage.placeholder = @"Any";
 		btn_Mileage.autocorrectionType = UITextAutocorrectionTypeNo;
		btn_Mileage.delegate = self;
        btn_Mileage.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        
        [scrollView addSubview:btn_Mileage];

		yOffset += 55.0f;
        
        yOffset += 55.0f;
		
		btn_Search = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		[btn_Search setTitle:@"Search" forState:UIControlStateNormal];
		[btn_Search setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
		[btn_Search setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btn_Search.titleLabel.font = [UIFont boldSystemFontOfSize:20];
		[btn_Search setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted) green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		btn_Search.frame = CGRectMake(20.0f, yOffset, 280.0f, 45.0f);
		[scrollView addSubview:btn_Search];

		//Picker View Creation		
		_pickerDone = [UIToolbar new];
		[_pickerDone sizeToFit];
		_pickerDone.frame = CGRectMake(0.0f, 480.0, frame.size.width, _pickerDone.frame.size.height);
		_pickerDone.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
		_pickerDone.barStyle = UIBarStyleBlack;
		_pickerDone.contentMode = UIViewContentModeRight;
		UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(pickerDone:)];
		UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
		[_pickerDone setItems:[NSArray arrayWithObjects:spacer, done, nil] animated:NO];
		
		//DealerLot/Year Picker
		pickerOne = [[UIPickerView alloc] initWithFrame:CGRectMake(0.0f, 480.0, frame.size.width, 0.0f)];
		pickerOne.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
		pickerOne.showsSelectionIndicator = YES;
		pickerOne.delegate = self;
		pickerOne.dataSource = self;
		[self addSubview:pickerOne];

		//Make/Model Picker
		pickerTwo = [[UIPickerView alloc] initWithFrame:CGRectMake(0.0f, 480.0, frame.size.width, 0.0f)];
		pickerTwo.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
		pickerTwo.showsSelectionIndicator = YES;
		pickerTwo.delegate = self;
		pickerTwo.dataSource = self;
		[self addSubview:pickerTwo];
				
		[self addSubview:_pickerDone];
        btn_Year.inputView = pickerOne;
        btn_Year.inputAccessoryView = _pickerDone;
        btn_Mileage.inputView = pickerTwo;
        btn_Mileage.inputAccessoryView = _pickerDone;
        btn_Price.inputView = pickerTwo;
        btn_Price.inputAccessoryView = _pickerDone;
        btn_MakeModel.inputView = pickerTwo;
        btn_MakeModel.inputAccessoryView = _pickerDone;

		scrollView.contentSize = CGSizeMake(320.0f, yOffset);
        [UIView setAnimationsEnabled:YES];
		_userToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];
		years = [NSMutableArray array];
		makes = [NSMutableArray array];
		models = [NSMutableArray array];
        searchObject.dealerLot = [[NSUserDefaults standardUserDefaults] integerForKey:kDefaultDealerLot];
        
		if(searchObject.dealerLot > 0) {
          [self reloadMakesAndModels];
		}
	}
	return self;
}

- (void)alertView:(UIAlertView *)inAlertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [target advSearchError:nil];
}
- (void) rebuildYearMakeModel:(id)sender inComponent:(int)componentId{
	//Rebuild the Years, Makes amd Models for Pickers
	if(sender == btn_Year)
	{
		if ([years count]) {
			[years removeAllObjects];
		}

		if(searchObject.make == nil || [searchObject.make isEqualToString:@"All"])
		{
			for(int i = 0; i < searchValuesResults.totalCount; i++)
			{
				if (![years containsObject:[NSString stringWithFormat:@"%d", 
						((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).year]])
				{
					[years addObject:[NSString stringWithFormat:@"%d", ((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).year]];
				}
			}
		}
		else
		{
			for(int i = 0; i < searchValuesResults.totalCount; i++)
			{
				if (![years containsObject:[NSString stringWithFormat:@"%d", 
						((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).year]])
				{
					if ([searchObject.make isEqualToString:((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).make])
					{
						[years addObject:[NSString stringWithFormat:@"%d", ((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).year]];
					}
				}
			}
		
		}
		
		[years insertObject:@"Any" atIndex:0];
	}
	else if(sender == btn_MakeModel)
	{
		if ([makes count]) {
			[makes removeAllObjects];
			[models removeAllObjects];
		}
		
		if( searchObject.year > 0 )
		{
			for(int i = 0; i < searchValuesResults.totalCount; i++)
			{
				if (![makes containsObject:((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).make] 
					&& searchObject.year == ((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).year)
				{
					[makes addObject:((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).make];
				}
			}
		}
		else
		{
			for(int i = 0; i < searchValuesResults.totalCount; i++)
			{
				if (![makes containsObject:((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).make])
				{
					[makes addObject:((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).make];
				}
			}
		}

		[makes insertObject:@"All" atIndex:0];
		[models insertObject:@"All" atIndex:0];

		if(searchObject.make)
		{
			if(![searchObject.make isEqualToString:@"All"])
			{
				if ([models count]) {
					[models removeAllObjects];
				}
				
				NSString *tmp_model = nil;
				for(int i = 0; i < searchValuesResults.totalCount; i++)
				{
					if ([searchObject.make isEqualToString:((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).make]
							&& ((searchObject.year == 0) || (searchObject.year == ((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).year)))
					{
						if (![tmp_model isEqualToString:((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).model])
						{
							tmp_model = ((SearchValues*)[searchValuesResults.listings objectAtIndex:i]).model;
							if (tmp_model != nil) {
								[models addObject:tmp_model];
							}
						}								
					}
				}

				[models insertObject:@"All" atIndex:0];
			}
		}
	}
}

- (void) clearMakesAndModels{
	//Cleaning the Year, Make, and Model
	[searchValuesResults.listings removeAllObjects];
	searchValuesResults.totalCount = 0;
	
	if(years) {
		searchObject.year = 0;
		[btn_Year setText:[NSString stringWithFormat:@"%@", searchObject.year > 0 ? [NSString stringWithFormat:@"%d", searchObject.year] : @""]];

		[years removeAllObjects];
	}
	
	if(makes) {
		[makes removeAllObjects];
		[models removeAllObjects];
		searchObject.make = nil;
		searchObject.model = nil;
		
		[btn_MakeModel setText:@""];
	}
}

- (void) reloadMakesAndModels {
	//Reloading the Year, Make, and Model
	searchObject.year = 0;
	[btn_Year setText:[NSString stringWithFormat:@"%@", searchObject.year > 0 ? [NSString stringWithFormat:@"%d", searchObject.year] : @""]];
	
	if(makes) {
		[makes removeAllObjects];
		[models removeAllObjects];
		searchObject.make = nil;
		searchObject.model = nil;
		
		[btn_MakeModel setText:@""];
	}
	
	IVMMobileServices *mobileServices = [[IVMMobileServices alloc] init];
	mobileServices.delegate = self;
	
	mobileServices.baseResults = nil;
	
	//Popup the loading view
	searchView = [[SearchResultsView alloc] initWithFrame:CGRectMake(100.0f, 50.0f, 0.0f, 0.0f)];
	[self addSubview:searchView];
	
	[searchView.activityIndicator startAnimating];
	searchView.activityLabel.hidden = NO;
	searchView.activityLabel.text = @"Updating Makes And Models..";
	
//	int dealerLotKey = 1990;
	[mobileServices getSearchValuesByToken:searchObject.dealerLot withToken:_userToken];
}

- (void) promptMakesAndModels{
	[self showPicker:btn_MakeModel];
}

- (void)showPicker:(id)sender{
	if(sender == btn_MakeModel) {
		if ([makes count] == 0) {
			[self rebuildYearMakeModel:sender inComponent:0];
		}

		twoDataSource = [NSMutableArray arrayWithObjects:makes, models, nil];
		if(!searchObject.make)
		{
			searchObject.make = [makes objectAtIndex:0];
			[btn_MakeModel setText:searchObject.make];
		}
			
		pickerTwo.tag = MODE_MAKEMODEL;
		int row1 = 0, row2 = 0;
			
		if([searchObject.make length] > 0)
		{
			row1 = [makes indexOfObject:searchObject.make];
		}
			
		if([searchObject.model length] > 0)
			row2 = [models indexOfObject:searchObject.model];
			
		[pickerTwo reloadComponent:0];
		[pickerTwo reloadComponent:1];
		[pickerTwo selectRow:row1 inComponent:0 animated:NO];
		[pickerTwo selectRow:row2 inComponent:1 animated:NO];
	} else if(sender == btn_Price) {
		if(!prices)
		{
			prices = [NSMutableArray array];
			for(int i = 1000; i <= 100000; i += (i < 10000 ? 1000 : 5000))
			{
				[prices addObject:[frm_money stringFromNumber:[NSNumber numberWithInt:i]]];
			}
		}
		
		NSMutableArray *min = [NSMutableArray arrayWithArray:prices];
		[min insertObject:@"Any" atIndex:0];
		NSMutableArray *max = [NSMutableArray arrayWithArray:prices];
		[max insertObject:@"Any" atIndex:0];
		twoDataSource = [NSMutableArray arrayWithObjects:min, max, nil];
			
		[pickerTwo reloadComponent:0];
		[pickerTwo reloadComponent:1];
			
		pickerTwo.tag = MODE_PRICE;
		int row1 = 0, row2 = 0;
			
		if(searchObject.minPrice > 0)
			row1 = [min indexOfObject:[frm_money stringFromNumber:[NSNumber numberWithInt:searchObject.minPrice]]];
		if(searchObject.maxPrice > 0)
			row2 = [max indexOfObject:[frm_money stringFromNumber:[NSNumber numberWithInt:searchObject.maxPrice]]];
			
		[pickerTwo selectRow:row1 inComponent:0 animated:NO];
		[pickerTwo selectRow:row2 inComponent:1 animated:NO];
	} else if(sender == btn_Year) {
		if([years count] == 0)
		{
			[self rebuildYearMakeModel:sender inComponent:0];
		}

		oneDataSource = [NSMutableArray arrayWithObjects:years, nil];
			
		[pickerOne reloadComponent:0];
		
		pickerOne.tag = MODE_YEAR;
		int row1 = 0;
		
		if(searchObject.year > 0)
			row1 = [years indexOfObject:[NSString stringWithFormat:@"%d", searchObject.year]];
		
		[pickerOne selectRow:row1 inComponent:0 animated:NO];
	} else if(sender == btn_Mileage) {
		if(!mileages)
		{
			mileages = [NSMutableArray arrayWithObjects: 
					[frm_decimal stringFromNumber:[NSNumber numberWithInt:5000]], 
					[frm_decimal stringFromNumber:[NSNumber numberWithInt:10000]], 
					[frm_decimal stringFromNumber:[NSNumber numberWithInt:15000]], 
					[frm_decimal stringFromNumber:[NSNumber numberWithInt:20000]], 
					[frm_decimal stringFromNumber:[NSNumber numberWithInt:25000]], 
					[frm_decimal stringFromNumber:[NSNumber numberWithInt:50000]], 
					[frm_decimal stringFromNumber:[NSNumber numberWithInt:75000]], 
					[frm_decimal stringFromNumber:[NSNumber numberWithInt:100000]], 
					[frm_decimal stringFromNumber:[NSNumber numberWithInt:125000]], 
					[frm_decimal stringFromNumber:[NSNumber numberWithInt:150000]], 
					[frm_decimal stringFromNumber:[NSNumber numberWithInt:175000]], 
					[frm_decimal stringFromNumber:[NSNumber numberWithInt:200000]], nil];
		}
		
		NSMutableArray *min = [NSMutableArray arrayWithArray:mileages];
		[min insertObject:@"Any" atIndex:0];
		NSMutableArray *max = [NSMutableArray arrayWithArray:mileages];
		[max insertObject:@"Any" atIndex:0];
		twoDataSource = [NSMutableArray arrayWithObjects:min, max, nil];
			
		[pickerTwo reloadComponent:0];
		[pickerTwo reloadComponent:1];
			
		pickerTwo.tag = MODE_MILES;
		int row1 = 0, row2 = 0;
			
		if(searchObject.minMileage > 0)
			row1 = [min indexOfObject:[frm_decimal stringFromNumber:[NSNumber numberWithInt:searchObject.minMileage]]];
		if(searchObject.maxMileage > 0)
			row2 = [max indexOfObject:[frm_decimal stringFromNumber:[NSNumber numberWithInt:searchObject.maxMileage]]];
			
		[pickerTwo selectRow:row1 inComponent:0 animated:NO];
		[pickerTwo selectRow:row2 inComponent:1 animated:NO];
	}
}

- (void)pickerDone:(id)sender{
	[latsetTextField resignFirstResponder];
    latsetTextField = nil;
}

#pragma mark UITextField delegate methods

- (BOOL)textFieldShouldClear:(UITextField *)textField {
	return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
	[self showPicker:textField];
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    latsetTextField = textField;
}

- (void)registerForKeyboardNotifications 
{ 
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(keyboardWasShown:) 
												 name:UIKeyboardDidShowNotification object:nil]; 
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(keyboardWasHidden:) 
												 name:UIKeyboardDidHideNotification object:nil]; 
}

- (void)unregisterForKeyboardNotifications
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark UIPickerView delegate methods
// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
	if([pickerView isEqual: pickerOne]) {
		return 1;
	} else if([pickerView isEqual: pickerTwo]) {
		return 2;
	}
	
	return 0;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
	if([pickerView isEqual: pickerOne]) {
		return [(NSArray*)[oneDataSource objectAtIndex:component] count];
	} else if([pickerView isEqual: pickerTwo]) {
		return [(NSArray*)[twoDataSource objectAtIndex:component] count];
	}

	return 0;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
	if([pickerView isEqual: pickerOne]) {
		return [(NSArray*)[oneDataSource objectAtIndex:component] objectAtIndex:row];
	} else if([pickerView isEqual: pickerTwo]) {
		return [(NSArray*)[twoDataSource objectAtIndex:component] objectAtIndex:row];
	}
	
	return 0;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
	if([pickerView isEqual: pickerTwo]){
		switch (pickerTwo.tag) {
			case MODE_MAKEMODEL:
				
				if(component == 0)
				{
					if((searchObject.make == [(NSArray*)[twoDataSource objectAtIndex:0] objectAtIndex:row]) ||
					   ((searchObject.make == @"") && (row == 0)))
						break;//Nothings Changed
				
					searchObject.make = [(NSArray*)[twoDataSource objectAtIndex:0] objectAtIndex:row];

					[self rebuildYearMakeModel:btn_MakeModel inComponent:1];
					[self rebuildYearMakeModel:btn_Year inComponent:0];
					
					[twoDataSource replaceObjectAtIndex:1 withObject:models];
					[pickerTwo selectRow:0 inComponent:1 animated:NO];
					[pickerTwo reloadComponent:1];
					searchObject.model = [(NSArray*)[twoDataSource objectAtIndex:1] objectAtIndex:0];
				}
				else
					searchObject.model = [(NSArray*)[twoDataSource objectAtIndex:1] objectAtIndex:row];
			
				if([searchObject.model isEqualToString:@"All"])
					searchObject.model = @"";
			
				[btn_MakeModel setText:[NSString stringWithFormat:@"%@ %@", searchObject.make, searchObject.model]];

				break;
			case MODE_PRICE:
				if(component == 0)
				{
					searchObject.minPrice = row > 0 ? [[frm_money numberFromString:[(NSArray*)[twoDataSource objectAtIndex:0] objectAtIndex:row]] intValue] : 0;
					if(row > 0 && [pickerTwo selectedRowInComponent:1] > 0 && [pickerTwo selectedRowInComponent:1] < row)
					{
						[pickerTwo selectRow:row + 1 inComponent:1 animated:YES];
						searchObject.maxPrice = (row + 1) >= [(NSArray*)[twoDataSource objectAtIndex:1] count] ? 0 : [[frm_money numberFromString:[(NSArray*)[twoDataSource objectAtIndex:1] objectAtIndex:row + 1]] intValue];
					}
				}
				else if(component == 1)
				{
					searchObject.maxPrice = row > 0 ? [[frm_money numberFromString:[(NSArray*)[twoDataSource objectAtIndex:1] objectAtIndex:row]] intValue] : 0;
					if(row > 0 && [pickerTwo selectedRowInComponent:0] > 0 && [pickerTwo selectedRowInComponent:0] > row)
					{
						[pickerTwo selectRow:MAX(row - 1, 0) inComponent:0 animated:YES];
						searchObject.minPrice = (row - 1) == 0 ? 0 : [[frm_money numberFromString:[(NSArray*)[twoDataSource objectAtIndex:0] objectAtIndex:row - 1]] intValue];
					}
				}
			
                if ((searchObject.minPrice > 0) || (searchObject.maxPrice > 0)) {
                    [btn_Price setText:[NSString stringWithFormat:@"%@ - %@", 
                                          searchObject.minPrice > 0 ? [frm_money stringFromNumber:[NSNumber numberWithInt:searchObject.minPrice]] : @"", 
                                          searchObject.maxPrice > 0 ? [frm_money stringFromNumber:[NSNumber numberWithInt:searchObject.maxPrice]] : @""]];
                } else {
                    [btn_Price setText:@""];
                }
                
				break;
			case MODE_MILES:
				if(component == 0)
				{
					searchObject.minMileage = row > 0 ? [[frm_decimal numberFromString:[[twoDataSource objectAtIndex:0] objectAtIndex:row]] intValue] : 0;
					if(row > 0 && [pickerTwo selectedRowInComponent:1] > 0 && [pickerTwo selectedRowInComponent:1] < row)
					{
						[pickerTwo selectRow:row + 1 inComponent:1 animated:YES];
						searchObject.maxMileage = (row + 1) >= [(NSArray*)[twoDataSource objectAtIndex:1] count] ? 0 : [[frm_decimal numberFromString:[(NSArray*)[twoDataSource objectAtIndex:1] objectAtIndex:row + 1]] intValue];
					}
				}
				else if(component == 1)
				{
					searchObject.maxMileage = row > 0 ? [[frm_decimal numberFromString:[[twoDataSource objectAtIndex:1] objectAtIndex:row]] intValue] : 0;
					if(row > 0 && [pickerTwo selectedRowInComponent:0] > 0 && [pickerTwo selectedRowInComponent:0] > row)
					{
						[pickerTwo selectRow:MAX(row - 1, 0) inComponent:0 animated:YES];
						searchObject.minMileage = (row - 1) == 0 ? 0 : [[frm_decimal numberFromString:[(NSArray*)[twoDataSource objectAtIndex:1] objectAtIndex:row - 1]] intValue];
					}
				}
			
                if ((searchObject.minMileage > 0) || (searchObject.maxMileage > 0)) {
                    [btn_Mileage setText:[NSString stringWithFormat:@"%@ - %@", 
                                            searchObject.minMileage > 0 ? [frm_decimal stringFromNumber:[NSNumber numberWithInt:searchObject.minMileage]] : @"", 
                                            searchObject.maxMileage > 0 ? [frm_decimal stringFromNumber:[NSNumber numberWithInt:searchObject.maxMileage]] : @""]];
                } else {
                    [btn_Mileage setText:@""];
                }
				break;
			default:
				break;
		}
	} else if([pickerView isEqual: pickerOne]) {
		switch (pickerOne.tag) {
			case MODE_YEAR:
				searchObject.year = row > 0 ? [[(NSArray*)[oneDataSource objectAtIndex:0] objectAtIndex:row] intValue] : 0;
	
				[self rebuildYearMakeModel:btn_MakeModel inComponent:0];
				
				[btn_Year setText:[NSString stringWithFormat:@"%@", searchObject.year > 0 ? [NSString stringWithFormat:@"%d", searchObject.year] : @""]];
				break;
			default:
				break;
		}
	}
}
- (void) MakesAndModelsComplete:(MakesAndModels*)makesModels{
	if(makesModels == nil)
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Unable to update Makes"
															message:@"Please ensure you have a network connection and try again."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}
	mAndm = makesModels;
}
- (void) SearchValuesComplete:(SearchValuesResults*)svResults withStatus:dResult{
	if(![dResult isEqualToString:@"Success"])
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"The Web Services Failed"
															message:dResult 
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		
		return;
	}
	if(svResults == nil)
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Unable to get Makes/Models"
															message:@"Please ensure you have a network connection and try again."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}
	searchValuesResults = svResults;
	[searchView.activityIndicator stopAnimating];
	searchView.activityLabel.hidden = YES;
	[searchView removeFromSuperview];
	[self rebuildYearMakeModel:btn_Year inComponent:0];
}

- (void)dealloc {
	[self unregisterForKeyboardNotifications];
}
@end
