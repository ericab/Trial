//
//  AnalyzerView.m
//  GetAuto.com
//
//  Created by Shaofeng Tu on 06/09/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import "AnalyzerView.h"
#import "IVM.h"
#import "appDelegate.h"
#import "AnalyzerController.h"

#define YEARS_TO_DISPLAY	30

@interface AnalyzerView()

@property(readonly) int currentYear;

- (void)registerForKeyboardNotifications;
- (void)unregisterForKeyboardNotifications;
- (void)showPicker:(id)sender;
- (void)pickerDone:(id)sender;
@end

@implementation AnalyzerView

//@dynamic currentYear;
@synthesize target, btn_Analyzer;

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	if(self != nil)
	{
		[UIView setAnimationsEnabled:NO];
		
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		
		_priorityView = [[UIView alloc] initWithFrame:frame];
		_priorityView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		_priorityView.backgroundColor = [UIColor blackColor];
		_priorityView.exclusiveTouch = YES;
		_priorityView.alpha = 0.6;
		_priorityView.hidden = YES;
		[self addSubview:_priorityView];
		
		scrollView = [[UIScrollView alloc] initWithFrame:frame];
		scrollView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		[self addSubview:scrollView];
		
		UIColor *textColor = [UIColor lightGrayColor];
		UIFont *lblFont = [UIFont fontWithName:kDefaultFont size:kDefaultFontSize + 3.0];
		
		currencyFormatter = [[NSNumberFormatter alloc] init];
		[currencyFormatter setFormatterBehavior:NSNumberFormatterBehavior10_4];
		[currencyFormatter setGeneratesDecimalNumbers:YES];
		[currencyFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
		[currencyFormatter setCurrencySymbol:@""];
		[currencyFormatter setAllowsFloats:YES];
		[currencyFormatter setMaximumFractionDigits:0];
		[currencyFormatter setLocale:[NSLocale currentLocale]];
		
		//set up the reject character set
		NSMutableCharacterSet *numberSet = [[NSCharacterSet decimalDigitCharacterSet] mutableCopy];
		[numberSet formUnionWithCharacterSet:[NSCharacterSet whitespaceCharacterSet]];
		nonNumberSet = [numberSet invertedSet];
		
		float yOffset = 30.0f;
		
		//Year
		UILabel *tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 110.0f, 30.0)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Year";
		[scrollView addSubview:tmpLabel];
		
		btn_Year = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		btn_Year.contentMode = UIViewContentModeCenter;
		[btn_Year setTitle:[NSString stringWithFormat:@"%@",
							year < 1 ? @"None" : [[NSNumber numberWithInt:year] stringValue]]  forState:UIControlStateNormal];
		btn_Year.titleLabel.font = [UIFont systemFontOfSize:kDefaultFontSize];
		btn_Year.frame = CGRectMake(120.0f, yOffset, 185.0f, 30.0);
		[btn_Year addTarget:self action:@selector(showPicker:) forControlEvents:UIControlEventTouchUpInside];
		[scrollView addSubview:btn_Year];
		
		yOffset += 50.0f;
		
		//Make/Model
		tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 110.0f, 30.0f)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Make & Model*";
		[scrollView addSubview:tmpLabel];
		
		btn_MakeModel = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		btn_MakeModel.frame = CGRectMake(120.0f, yOffset, 185.0f, 30.0f);
		if(make)
			[btn_MakeModel setTitle: [NSString stringWithFormat:@"%@ %@", make, model ? model : @""] 
						   forState: UIControlStateNormal];
		else
			[btn_MakeModel setTitle:@"Select Make & Model" forState: UIControlStateNormal];
		btn_MakeModel.titleLabel.font = [UIFont systemFontOfSize:kDefaultFontSize];
		[btn_MakeModel addTarget:self action:@selector(showPicker:) forControlEvents:UIControlEventTouchUpInside];
		[scrollView addSubview:btn_MakeModel];
		
		yOffset += 50.0f;
		
		//Mileage
		tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, yOffset, 110.0f, 30.0f)];
		tmpLabel.font = lblFont;
		tmpLabel.textColor = textColor;
		tmpLabel.backgroundColor = [UIColor clearColor];
		tmpLabel.text = @"Mileage";
		[scrollView addSubview:tmpLabel];
		
		txt_Mileage = [[UITextField alloc] initWithFrame:CGRectMake(120.0f, yOffset, 185.0f, 30.0f)];
		txt_Mileage.borderStyle = UITextBorderStyleRoundedRect;
		txt_Mileage.returnKeyType = UIReturnKeyDone;
		txt_Mileage.clearButtonMode = UITextFieldViewModeWhileEditing;
		txt_Mileage.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
		txt_Mileage.placeholder = @"Required";
		if(mileage > 0)
			txt_Mileage.text = [NSString stringWithFormat:@"%d", mileage];
		[txt_Mileage addTarget:self action:@selector(getValue:) forControlEvents:UIControlEventEditingDidEnd];
		txt_Mileage.delegate = self;
		[scrollView addSubview:txt_Mileage];
		
		yOffset += 120.0f;
		
		btn_Analyzer = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		[btn_Analyzer setTitle:@"Evaluation" forState:UIControlStateNormal];
		[btn_Analyzer setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
		[btn_Analyzer setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		btn_Analyzer.titleLabel.font = [UIFont systemFontOfSize: 20];
		[btn_Analyzer setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted)  green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
		btn_Analyzer.frame = CGRectMake(20.0f, yOffset, 280.0f, 40.0f);
		[scrollView addSubview:btn_Analyzer];

		//Picker View Creation		
		_pickerDone = [UIToolbar new];
		[_pickerDone sizeToFit];
		_pickerDone.frame = CGRectMake(0.0f, frame.size.height - 215.0f - 42.0f, frame.size.width, _pickerDone.frame.size.height);
		_pickerDone.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
		_pickerDone.barStyle = UIBarStyleBlackTranslucent;
		_pickerDone.contentMode = UIViewContentModeRight;
		UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(pickerDone:)];
		UIBarButtonItem *spacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
		[_pickerDone setItems:[NSArray arrayWithObjects:spacer, done, nil] animated:NO];
		
		//Year Picker
		pickerYear = [[UIPickerView alloc] initWithFrame:CGRectMake(0.0f, frame.size.height - 215.0f, frame.size.width, 0.0f)];
		pickerYear.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
		pickerYear.showsSelectionIndicator = YES;
		pickerYear.delegate = self;
		pickerYear.dataSource = self;
		pickerYear.alpha = 0.0;
		pickerYear.hidden = YES;
		[self addSubview:pickerYear];
				
		//Make/Model Picker
		picker = [[UIPickerView alloc] initWithFrame:CGRectMake(0.0f, frame.size.height - 215.0f, frame.size.width, 0.0f)];
		picker.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
		picker.showsSelectionIndicator = YES;
		picker.delegate = self;
		picker.dataSource = self;
		picker.alpha = 0.0;
		picker.hidden = YES;
		[self addSubview:picker];
		
		_pickerDone.alpha = 0.0;
		_pickerDone.hidden = YES;
		[self addSubview:_pickerDone];

		scrollView.contentSize = CGSizeMake(320.0f, yOffset);
		
		[btn_MakeModel addTarget:self action:@selector(controlTouched:) forControlEvents:UIControlEventTouchDown];
		[btn_Year addTarget:self action:@selector(controlTouched:) forControlEvents:UIControlEventTouchDown];
		
		[self registerForKeyboardNotifications];
		 
		int mmstatus;
		mAndm = [[appDelegate currentInstance] MakesAndModels:&mmstatus target:self callback:@selector(MakesAndModelsComplete:)];
		if(mmstatus == -1)//No Internet Connection
		{
			return self;
		}
		if(mAndm == nil || mmstatus != 0)
		{		
			[self bringSubviewToFront:_priorityView];
			_priorityView.hidden = NO;
			
			loadingView = [[UIView alloc] initWithFrame:frame];
			loadingView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
			UIActivityIndicatorView *act = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
			act.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
			[act sizeToFit];
			act.frame = CGRectMake(frame.size.width / 2.0f - act.frame.size.width / 2.0f, 
								   frame.size.height / 2.0f - act.frame.size.height / 2.0f + 1.0f,
								   act.frame.size.width, act.frame.size.height);
			act.autoresizingMask = UIViewAutoresizingFlexibleTopMargin  | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
			[act startAnimating];
			[loadingView addSubview:act];
			UILabel *loadingText = [[UILabel alloc] initWithFrame:CGRectMake(frame.size.width / 2.0f,
																			 frame.size.height / 2.0f - 11.0f, self.frame.size.width, 20.0f)];
			loadingText.autoresizingMask =UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleWidth;
			loadingText.textAlignment = UITextAlignmentCenter;
			loadingText.text = @"Updating Makes And Models..";
			loadingText.textColor = [UIColor whiteColor];
			loadingText.backgroundColor = [UIColor clearColor];
			[loadingView addSubview:loadingText];
			[self addSubview:loadingView];
		}
		[UIView setAnimationsEnabled:YES];
	}
	return self;
}

- (void)alertView:(UIAlertView *)inAlertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
//	[target performSelector:errorCallback withObject:self];
	[target analyzerError:nil];
}

- (int) currentYear{
	if(_currentYear) return _currentYear;
	NSDateComponents *components = [[NSCalendar currentCalendar] components:NSYearCalendarUnit fromDate:[NSDate date]];
	_currentYear = [components year];
	return _currentYear;
}

- (void) promptMakesAndModels{
	[self showPicker:btn_MakeModel];
}
- (void)showPicker:(id)sender{
	if(sender == btn_MakeModel)
	{
		makemodelDataSource = [NSMutableArray arrayWithObjects:mAndm.makes, [mAndm.models objectAtIndex:0], nil];
		if(!make)
		{
			make = [mAndm.makes objectAtIndex:0];
			[btn_MakeModel setTitle:make forState:UIControlStateNormal];
		}

		int row1 = 0, row2 = 0;
			
		if([make length] > 0)
		{
			row1 = [mAndm indexOfMake:make];
			[makemodelDataSource replaceObjectAtIndex:1 withObject:[mAndm.models objectAtIndex:row1]];
		}

		if([model length] > 0)
			row2 = [mAndm indexOfModel:model atIndex:row1];
			
		[picker reloadComponent:0];
		[picker reloadComponent:1];
		[picker selectRow:row1 inComponent:0 animated:NO];
		[picker selectRow:row2 inComponent:1 animated:NO];

		_priorityView.hidden = NO;
		_pickerDone.hidden = NO;
		picker.hidden = NO;
		pickerYear.hidden = YES;
		[self bringSubviewToFront:_priorityView];
		[self bringSubviewToFront:picker];
		[self bringSubviewToFront:_pickerDone];
		
		[UIView beginAnimations:@"FadeIn" context:nil];
		[UIView setAnimationDuration:0.7];
		_pickerDone.alpha = 1.0;
		picker.alpha = 1.0;
		[UIView commitAnimations];
	}
	else if(sender == btn_Year)
	{
		if(!years)
		{
			years = [NSMutableArray array];
			for(int i = 0; i < YEARS_TO_DISPLAY; i++)
				[years addObject:[NSString stringWithFormat:@"%d", self.currentYear + 1 - i]];

			[years insertObject:@"None" atIndex:0];
			yearDataSource = [NSMutableArray arrayWithObjects:years, nil];

			[pickerYear reloadComponent:0];
		}

		int row1 = 0;
			
		if(year > 0)
			row1 = [years indexOfObject:[NSString stringWithFormat:@"%d", year]];
			
		[pickerYear selectRow:row1 inComponent:0 animated:NO];

		_priorityView.hidden = NO;
		_pickerDone.hidden = NO;
		pickerYear.hidden = NO;
		picker.hidden = YES;
		[self bringSubviewToFront:_priorityView];
		[self bringSubviewToFront:pickerYear];
		[self bringSubviewToFront:_pickerDone];
		
		[UIView beginAnimations:@"FadeIn" context:nil];
		[UIView setAnimationDuration:0.7];
		_pickerDone.alpha = 1.0;
		pickerYear.alpha = 1.0;
		[UIView commitAnimations];
	}
}

- (void)pickerDone:(id)sender{
	_priorityView.hidden = YES;
	[self sendSubviewToBack:_priorityView];
	[UIView beginAnimations:@"FadeOut" context:nil];
	[UIView setAnimationDuration:0.7];
	_pickerDone.alpha = 0.0;
	picker.alpha = 0.0;
	pickerYear.alpha = 0.0;
	[UIView commitAnimations];
}

#pragma mark Keyboard stuff
- (BOOL)textFieldShouldClear:(UITextField *)textField{
	return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
	return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{

}
- (void)registerForKeyboardNotifications 
{ 
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(keyboardWasShown:) 
												 name:UIKeyboardDidShowNotification object:nil]; 
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(keyboardWasHidden:) 
												 name:UIKeyboardDidHideNotification object:nil]; 
}

- (void)unregisterForKeyboardNotifications
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}
// Called when the UIKeyboardDidShowNotification is sent. 
- (void)keyboardWasShown:(NSNotification*)aNotification 
{ 
	NSDictionary* info = [aNotification userInfo]; 
	// Get the size of the keyboard. 
	NSValue* aValue = [info objectForKey:UIKeyboardBoundsUserInfoKey]; 
	CGSize keyboardSize = [aValue CGRectValue].size; 
	if (keyboardShown) return; 
	
	// Resize the scroll view (which is the root view of the window) 
	CGRect viewFrame = [scrollView frame]; 
	viewFrame.size.height -= keyboardSize.height - 50.0f;
	scrollView.frame = viewFrame;
	// Scroll the active text field into view. 
	CGRect textFieldRect = [txt_Mileage frame];
	[scrollView scrollRectToVisible:textFieldRect animated:YES]; 
	keyboardShown = YES; 
}

// Called when the UIKeyboardDidHideNotification is sent 
- (void)keyboardWasHidden:(NSNotification*)aNotification 
{ 
	NSDictionary* info = [aNotification userInfo]; 
	// Get the size of the keyboard. 
	NSValue* aValue = [info objectForKey:UIKeyboardBoundsUserInfoKey]; 
	CGSize keyboardSize = [aValue CGRectValue].size; 
	// Reset the height of the scroll view to its original value 
	CGRect viewFrame = scrollView.frame; 
	viewFrame.size.height += keyboardSize.height - 50.0f; 
	scrollView.frame = viewFrame; 
	keyboardShown = NO; 
}

- (BOOL)textFieldShouldReturn:(UITextField *)textfield {
	mileage = [txt_Mileage.text intValue];

	[textfield resignFirstResponder];
	textfield.textColor = [UIColor blackColor];
	[textfield resignFirstResponder];

	//Enable search here
	return YES;
}

- (IBAction) controlTouched:(id)sender{
	if(keyboardShown)
		if(![self textFieldShouldReturn:txt_Mileage])
		{
			[scrollView scrollRectToVisible:txt_Mileage.frame animated:YES];
			[(UIControl*)sender cancelTrackingWithEvent:nil];
		}
}

- (void)getValue:(id)sender {
	if( ((UITextField *)sender) == txt_Mileage ){
		mileage = [[currencyFormatter numberFromString:((UITextField *)sender).text] floatValue];
	}
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
	BOOL result = NO; //default to reject
	
	//Handle the Mileage text by using formater
	if (textField == txt_Mileage) {
		
		if([string length] == 0){ //backspace
			result = YES;
		}else{
			if([string stringByTrimmingCharactersInSet:nonNumberSet].length > 0){
				result = YES;
			}
		}
		
		//here we deal with the UITextField on our own
		if(result){
			//grab a mutable copy of what's currently in the UITextField
			NSMutableString* mstring = [[textField text] mutableCopy];
			if([mstring length] == 0){
				//now append the replacement string
				[mstring appendString:string];
			}else{
				//adding a char or deleting?
				if([string length] > 0){
					[mstring insertString:string atIndex:range.location];
				}else {
					//delete case - the length of replacement string is zero for a delete
					[mstring deleteCharactersInRange:range];
				}
			}
			
			//To get the grouping separators number properly
			NSNumber* number = [currencyFormatter numberFromString:mstring];
			
			//Now format the number back to the proper currency string
			[textField setText:[currencyFormatter stringFromNumber:number]];
		}
	} else {
		//always return YES for any other text fields
		return YES;
	}
	
	//always return no since we are manually changing the text field
	return NO;
}

#pragma mark UIPickerView delegate methods

// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
	if([pickerView isEqual: pickerYear]) {
		return 1;
	} else if([pickerView isEqual: picker]) {
		return 2;
	}
	
	return 0;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
	if([pickerView isEqual: pickerYear]) {
		return [(NSArray*)[yearDataSource objectAtIndex:component] count];
	} else if([pickerView isEqual: picker]) {
		return [(NSArray*)[makemodelDataSource objectAtIndex:component] count];
	}

	return 0;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
	if([pickerView isEqual: pickerYear]) {
		return [(NSArray*)[yearDataSource objectAtIndex:component] objectAtIndex:row];
	} else if([pickerView isEqual: picker]) {
		return [(NSArray*)[makemodelDataSource objectAtIndex:component] objectAtIndex:row];
	}
	
	return 0;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
	
	if([pickerView isEqual: picker])
	{
		if(component == 0)
		{
			if(make == [(NSArray*)[makemodelDataSource objectAtIndex:0] objectAtIndex:row])
				return;//Nothings Changed
				
			[makemodelDataSource replaceObjectAtIndex:1 withObject:[mAndm.models objectAtIndex:row]];
			[picker selectRow:0 inComponent:1 animated:NO];
			[picker reloadComponent:1];
			make = [(NSArray*)[makemodelDataSource objectAtIndex:0] objectAtIndex:row];
			model = [(NSArray*)[makemodelDataSource objectAtIndex:1] objectAtIndex:0];
		}
		else
			model = [(NSArray*)[makemodelDataSource objectAtIndex:1] objectAtIndex:row];
			
		if([model isEqualToString:@"All Models"])
			model = @"";
			
		[btn_MakeModel setTitle: [NSString stringWithFormat:@"%@ %@", make, model] 
					forState: UIControlStateNormal];
	}
	else if([pickerView isEqual: pickerYear])
	{
		year = row > 0 ? [[(NSArray*)[yearDataSource objectAtIndex:0] objectAtIndex:row] intValue] : 0;
			
		[btn_Year setTitle: [NSString stringWithFormat:@"%@", 
					year > 0 ? [NSString stringWithFormat:@"%d", year] : @"None"]
					forState: UIControlStateNormal];
	}
}

- (void) MakesAndModelsComplete:(MakesAndModels*)makesModels{
	if(makesModels == nil)
	{
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Unable to update Makes"
															message:@"Please ensure you have a network connection and try again."
														   delegate:self
												  cancelButtonTitle:@"Ok"
												  otherButtonTitles:nil];
		[alertView show];
		return;
	}
	mAndm = makesModels;
	_priorityView.hidden = YES;
	[loadingView removeFromSuperview];
//	[loadingView release];
	loadingView = nil;
}

- (void)dealloc {
	[self unregisterForKeyboardNotifications];
	[[appDelegate currentInstance] cancelMakesAndModels];
	
	txt_Mileage.delegate = nil;
	
	
//	[loadingView release];
	loadingView = nil;
	
}

@end
