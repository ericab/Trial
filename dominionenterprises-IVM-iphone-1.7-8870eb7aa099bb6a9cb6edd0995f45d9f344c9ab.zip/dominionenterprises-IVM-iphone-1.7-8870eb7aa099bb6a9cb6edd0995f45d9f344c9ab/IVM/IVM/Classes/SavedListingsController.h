//
//  SavedListingsController.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 1/23/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"

@interface SavedListingsController : UIViewController<UITableViewDelegate, UITableViewDataSource, AppRestore> {
	NSArray *listings;
	UITableView *listingTable;
	NSMutableDictionary *imgCache;
}

@property(nonatomic, strong) UITableView	*listingTable;

-(void)load;
-(void)clear;

@end
