//
//  AdvancedSearchView.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 1/19/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "IVMMobileServices.h"

@class VehicleSearchObject, MakesAndModels, SearchValuesResults, SearchResultsView;

@interface AdvancedSearchView : UIView<
UITextFieldDelegate, 
UIPickerViewDelegate,
UIPickerViewDataSource,
IVMMobileServicesDelegate,
UIAlertViewDelegate> {
	
	VehicleSearchObject		*searchObject;
	MakesAndModels			*mAndm;
	SearchValuesResults		*searchValuesResults;
	SearchResultsView		*searchView;
	
	UIScrollView		*scrollView;
	UITextField			*btn_MakeModel;
	UITextField			*btn_Price;
	UITextField			*btn_Year;
	UITextField			*btn_Mileage;
	UIButton			*btn_Search;
	UISegmentedControl  *seg_sort;
	UIPickerView		*pickerOne;
	UIPickerView		*pickerTwo;
	UIToolbar			*_pickerDone;
	NSMutableArray		*years;
	NSMutableArray		*makes;
	NSMutableArray		*models;
	NSMutableArray		*prices;
	NSMutableArray		*mileages;
	NSNumberFormatter	*frm_money;
	NSNumberFormatter	*frm_decimal;
	NSMutableArray		*twoDataSource;
	NSMutableArray		*oneDataSource;
	BOOL				keyboardShown;
	id					__unsafe_unretained target;
    id latsetTextField;
	NSString			*_userToken;
}

@property(strong)			VehicleSearchObject		*searchObject;
@property(unsafe_unretained)			id				target;
@property (nonatomic, strong)	UIButton	*btn_Search;

- (id)initWithFrame:(CGRect)frame searchObject:(VehicleSearchObject*)searchObj filterMode:(BOOL)filter;
- (void) promptMakesAndModels;	//This is for the view controller to call if the user tries to search without first selecting a make
- (void) rebuildYearMakeModel:(id)sender inComponent:(int)componentId;
- (void) reloadMakesAndModels;
- (void) clearMakesAndModels;

@end
