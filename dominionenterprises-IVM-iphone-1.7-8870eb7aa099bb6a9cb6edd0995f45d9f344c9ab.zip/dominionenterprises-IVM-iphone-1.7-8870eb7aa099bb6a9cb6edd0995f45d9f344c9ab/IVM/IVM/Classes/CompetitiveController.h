//
//  CompetitiveController.h
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//

#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"

@class VehicleSearchObject;

@interface CompetitiveController : UIViewController<UITextFieldDelegate, UIPickerViewDelegate, ItemRestore> {
	VehicleSearchObject *searchObj;
}

- (void)advSearchError:(id)sender;

@end
