//
//  LocationController.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/26/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LocationControllerDelegate <NSObject>
@required
-(void)locationUpdated:(CLLocationManager *)manager withLocation:(CLLocation *)location;
-(void)locationFailed:(CLLocationManager *)manager withError:(NSError *)error;
@end

@interface LocationController : NSObject<CLLocationManagerDelegate> {
	CLLocationManager *locationManager;
	id delegate;
}

@property (nonatomic, readonly) CLLocationManager *locationManager;
@property (nonatomic, assign) id <LocationControllerDelegate> delegate;

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation;

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error;

+ (LocationController *)sharedInstance;

@end
