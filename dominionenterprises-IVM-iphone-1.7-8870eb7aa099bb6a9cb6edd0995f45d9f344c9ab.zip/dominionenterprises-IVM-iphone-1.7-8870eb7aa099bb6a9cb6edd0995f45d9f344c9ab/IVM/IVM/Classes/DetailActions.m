//
//  DetailActions.m
//  GetAuto.com
//
//  Created by Shaofeng Tu on 7/19/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import "DetailActions.h"


@implementation DetailActions

@synthesize		actionNumber;
@synthesize		vehicleKey;
@synthesize		usrToken;
@synthesize		email;
@synthesize		comments;


@end
