//
//  NetDataOperation.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/26/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NetDataOperation : NSOperation {
	NSURL					*__unsafe_unretained _url;
	NSData					*_data;
	id						__unsafe_unretained target;
	SEL						action;
}

@property(unsafe_unretained,readonly) NSURL				*url;
@property(readonly) NSData				*data;
@property(unsafe_unretained)	id					target;
@property			SEL					action;

- (id) initWithUrl:(NSURL*)url;

@end
