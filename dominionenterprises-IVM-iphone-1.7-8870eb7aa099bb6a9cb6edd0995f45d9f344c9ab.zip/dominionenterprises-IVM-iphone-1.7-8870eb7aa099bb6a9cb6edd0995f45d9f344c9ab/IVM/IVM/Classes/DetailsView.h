//
//  DetailsView.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/19/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DetailsView : UIView {

}

@end
