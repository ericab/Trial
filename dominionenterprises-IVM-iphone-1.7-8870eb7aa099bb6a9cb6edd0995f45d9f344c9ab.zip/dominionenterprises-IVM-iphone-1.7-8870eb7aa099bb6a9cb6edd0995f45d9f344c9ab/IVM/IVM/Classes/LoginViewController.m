//
//  LoginViewController.m
//  GetAuto.com
//
//  Created by Shaofeng Tu on 6/10/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//
#import "LoginViewController.h"
#import <QuartzCore/CoreAnimation.h>
#import "appDelegate.h"
#import <objc/runtime.h>
#import "HMACSHA256.h"

@implementation LoginViewController

- (id) init
{
	self = [super init];
	if (self != nil)
	{
		_mobileServices = [[IVMMobileServices alloc] init];
		_mobileServices.delegate = self;
		[appDelegate track:@"Login"];
	}
	return self;
}
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	float yOffset = 20.0f;
	NSMutableCharacterSet *alphanumericCharactersSet = [[NSCharacterSet alphanumericCharacterSet] mutableCopy];
	nonUserIDCharactersSet = [alphanumericCharactersSet invertedSet];
	
	UIView *vw = [[UIView alloc] initWithFrame:CGRectZero];
	vw.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
	self.view = vw;
	//Create header image
	UIImageView *header = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"DSP_logo.png"]];
	header.contentMode = UIViewContentModeScaleAspectFit;
	CGRect cframe = CGRectMake(0.0f, yOffset, 280.0f, 125.0f);
	cframe.origin.x = [UIScreen mainScreen].bounds.size.width / 2.0f - cframe.size.width / 2.0f;
	header.frame = cframe;
    header.layer.shadowOffset = CGSizeMake(4.0, 4.0);
    header.layer.shadowOpacity = 0.6;
    header.layer.shadowColor = [UIColor darkGrayColor].CGColor;
	[self.view addSubview:header];
	
	yOffset += 140.0f;
	
	UILabel *tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, yOffset, 100.0f, 30.0)];
	tmpLabel.textColor = [UIColor blackColor];
	tmpLabel.backgroundColor = [UIColor clearColor];
	tmpLabel.text = @"User ID";
	[self.view addSubview:tmpLabel];
	
	txt_userID = [[UITextField alloc] initWithFrame:CGRectMake(120.0f, yOffset, 180.0f, 30.0f)];
	txt_userID.borderStyle = UITextBorderStyleRoundedRect;
	txt_userID.returnKeyType = UIReturnKeyDone;
	txt_userID.clearButtonMode = UITextFieldViewModeWhileEditing;
	txt_userID.keyboardType = UIKeyboardTypeDefault;
	txt_userID.autocorrectionType = UITextAutocorrectionTypeNo;
	txt_userID.autocapitalizationType = UITextAutocapitalizationTypeNone;
	txt_userID.delegate = self;
	[self.view addSubview:txt_userID];
	
	yOffset += 40.0f;
	
	tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, yOffset, 100.0f, 30.0)];
	tmpLabel.textColor = [UIColor blackColor];
	tmpLabel.backgroundColor = [UIColor clearColor];
	tmpLabel.text = @"Password";
	[self.view addSubview:tmpLabel];
	
	txt_password = [[UITextField alloc] initWithFrame:CGRectMake(120.0f, yOffset, 180.0f, 30.0f)];
	txt_password.borderStyle = UITextBorderStyleRoundedRect;
	txt_password.returnKeyType = UIReturnKeyDone;
	txt_password.clearButtonMode = UITextFieldViewModeWhileEditing;
	txt_password.keyboardType = UIKeyboardTypeDefault;
	txt_password.autocorrectionType = UITextAutocorrectionTypeNo;
	txt_password.autocapitalizationType = UITextAutocapitalizationTypeNone;
	txt_password.secureTextEntry = YES;
	txt_password.delegate = self;
	[self.view addSubview:txt_password];
	
	yOffset += 40.0f;
	
	btn_checkbox = [UIButton buttonWithType:UIButtonTypeCustom];
	[btn_checkbox setBackgroundImage:[UIImage imageNamed:@"checkbox.png"] forState:UIControlStateNormal];
	[btn_checkbox setBackgroundImage:[UIImage imageNamed:@"checkbox-pressed.png"] forState:UIControlStateHighlighted];
	[btn_checkbox setBackgroundImage:[UIImage imageNamed:@"checkbox-checked.png"] forState:UIControlStateSelected];
	btn_checkbox.frame = CGRectMake(120.0f, yOffset, 20.0f, 20.0f);
	[btn_checkbox addTarget:self action:@selector(checkboxButton:) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_checkbox];
   
    NSUserDefaults *prefs =[NSUserDefaults standardUserDefaults];
    checkboxSelected = [prefs boolForKey:kKeepLoggedIn];
    
	[btn_checkbox setSelected:checkboxSelected];
	
	tmpLabel = [[UILabel alloc] initWithFrame:CGRectMake(150.0f, yOffset, 150.0f, 20.0)];
	tmpLabel.textColor = [UIColor blackColor];
	tmpLabel.backgroundColor = [UIColor clearColor];
	tmpLabel.text = @"Keep me logged in";
	[self.view addSubview:tmpLabel];
	
	yOffset += 50.0f;
	
	btn_login = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	[btn_login setTitle:@"Login" forState:UIControlStateNormal];
	[btn_login setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[btn_login setBackgroundImage:[UIImage imageNamed:@"btn_background.png"] forState:UIControlStateNormal];
	[btn_login setTitleColor:[UIColor colorWithRed:RedMake(kButtonHighlighted)  green:GreenMake(kButtonHighlighted) blue:BlueMake(kButtonHighlighted) alpha:1.0] forState:UIControlStateHighlighted];
	btn_login.frame = CGRectMake(120.0f, yOffset, 100.0f, 40.0f);
	[btn_login addTarget:self action:@selector(selected:) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:btn_login];
	
	self.navigationItem.hidesBackButton = YES;
}
- (void) selected:(id)sender{
	if(sender == btn_login){
        if([txt_userID.text length] > 0 && [txt_password.text length] >0)
        {
		_userID = txt_userID.text;
		_userPwd = txt_password.text;

		[[appDelegate currentInstance]  setUserIdPwd:_userID andData:_userPwd];
		[[appDelegate currentInstance]  setLoginStatus:FALSE];
        }
        else
        {
            if(![txt_userID.text length] > 0 && ![txt_password.text length] >0)
            {
              [self alertUser:@"User ID and Password are Empty." title:[NSString stringWithFormat: @"Empty"]];
            }
            else if([txt_userID.text length] > 0)
            {
             [self alertUser:@"Password is Empty." title:[NSString stringWithFormat: @"Empty"]];
            }
            else
            {
                [self alertUser:@"User ID is Empty." title:[NSString stringWithFormat: @"Empty"]];
            }
        }

	}
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}
#pragma mark UITextField delegates
- (BOOL)textFieldShouldClear:(UITextField *)textField{
	return YES;
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
	return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
}
- (BOOL)textFieldShouldReturn:(UITextField *)textfield {
	[textfield resignFirstResponder];
	textfield.textColor = [UIColor blackColor];
	[textfield resignFirstResponder];
	//Enable search here
	return YES;
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
	//always return YES for any text fields
	return YES;
}
- (NSArray*)getRestoreData{
	//Create an array of child view controllers
	NSMutableArray *children = [NSMutableArray array];
	return children;
}
- (void)restore:(NSArray*)data{
}
- (void)checkboxButton:(id)sender{
	if (checkboxSelected == NO){
		checkboxSelected = YES;
	} else {
		checkboxSelected = NO;
	}
	[btn_checkbox setSelected:checkboxSelected];
	//Set the KeepLoggedIn setting
	[[NSUserDefaults standardUserDefaults] setBool:checkboxSelected forKey:kKeepLoggedIn];
	[[NSUserDefaults standardUserDefaults] synchronize];
}
- (void)dealloc {	
	_generatedToken = nil;
	_hashedString = nil;
	_userID = nil;
	_userPwd = nil;
}
- (void)alertUser:(NSString*)message title:(NSString*)title{
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title														message:message											delegate:self											  cancelButtonTitle:@"Ok"									otherButtonTitles:nil];
	[alertView show];
}
@end
