//
//  AnalyzerView.h
//  GetAuto.com
//
//  Created by Shaofeng Tu on 06/09/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MakesAndModels;

@interface AnalyzerView : UIView<
UITextFieldDelegate, 
UIPickerViewDelegate,
UIPickerViewDataSource,
UIAlertViewDelegate> {
	
	MakesAndModels			*mAndm;
	
	UIScrollView		*scrollView;
	UIButton			*btn_MakeModel;
	UIButton			*btn_Year;
	UITextField			*txt_Mileage;
	UIButton			*btn_Analyzer;
	UIPickerView		*picker;
	UIPickerView		*pickerYear;
	UIToolbar			*_pickerDone;

	NSMutableArray		*years;

	NSString			*make;
	NSString			*model;
	int					year;
	int					mileage;
	UIView				*_priorityView;
	UIView				*loadingView;
	NSMutableArray		*makemodelDataSource;
	NSMutableArray		*yearDataSource;
	BOOL				keyboardShown;
	int					_currentYear;
	id					__unsafe_unretained target;
//	SEL					errorCallback;

	NSNumberFormatter   *currencyFormatter;
	NSCharacterSet      *nonNumberSet;
}

@property(unsafe_unretained)			id				target;
//@property(assign)			SEL				errorCallback;
@property (nonatomic, strong)	UIButton	*btn_Analyzer;

- (void) promptMakesAndModels;	//This is for the view controller to call if the user tries to search without first selecting a make

@end
