//
//  NetImage.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/26/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoadingView.h"

@interface NetImageView : UIImageView  {
//	NSURL				*imageURL;
//	NSMutableDictionary	*cache;
//	UIImage				*noImage;
	LoadingView			*loadingView;

@private	
//	NSURL				*_realUrl;
	NSURLConnection		*_con;
}

@property(strong, nonatomic)	NSURL				*imageURL;
@property(strong, nonatomic)	NSMutableDictionary	*cache;
@property(strong, nonatomic)	UIImage				*noImage;
@property(strong, nonatomic)	NSMutableData		*imageData;

//Statics
+ (id) netImageWithStringUrl:(NSString *)url andCache:(NSMutableDictionary*)inCache;
+ (UIImage*) imageForURL:(NSURL *)inURL withSize:(CGSize)inSize inCache:(NSDictionary*)inCache;
//Instance
- (id) initWithFrame:(CGRect)inFrame andUrl:(NSURL *)url andCache:(NSMutableDictionary*)inCache;

- (void) setImageURL:(NSURL*)url cache:(NSMutableDictionary*)inCache;

- (UIImage *) getImageFromCache:(NSURL*)url;
- (void) clearDownload;

@end