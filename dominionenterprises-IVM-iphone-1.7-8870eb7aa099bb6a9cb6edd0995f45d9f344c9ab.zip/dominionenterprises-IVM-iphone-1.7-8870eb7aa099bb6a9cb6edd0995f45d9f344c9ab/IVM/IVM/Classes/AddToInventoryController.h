//
//  AddToInventoryController.h
//  GetAuto.com
//
//  Created by Shaofeng Tu on 6/1/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"
//#import <zbar/ZBarReaderViewController.h>
//#import <ZBarReaderViewController.h>
#import "IVMMobileServices.h"
#import "DecodeData.h"
#import "LoadingView.h"

@class AddToInventory;

@interface AddToInventoryController : UIViewController<UINavigationControllerDelegate, 
		IVMMobileServicesDelegate, ZBarReaderDelegate, ItemRestore> {
//		IVMMobileServicesDelegate, ZBarReaderDelegate, ZBarReaderViewDelegate, ItemRestore> {
	AddToInventory	*addToInventoryView;
	NSDictionary	*restore_data;
	
	DecodeData		*decData;
	NSString		*_userToken;
	IVMMobileServices		*mobileServices;
	VehicleDetails			*_vehicleDetail;

	LoadingView				*loadingView;
}

// ADD: text view outlet
//@property (nonatomic, retain) IBOutlet UITextView *resultText;

// ADD: action for scan button
- (IBAction) scanButtonTapped;

@end
