//
//  UIButton+Underline.h
//  GetAuto.com
//
//  Created by Rakesh on 9/3/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIButton(Underline)

- (void) underline;

@end
