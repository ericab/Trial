//
//  RecentSearchController.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/9/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import "RecentSearchController.h"
#import "VehicleSearchObject.h"
#import "HomeViewController.h"
#import "appDelegate.h"
#import <QuartzCore/CoreAnimation.h>
#import <objc/runtime.h>

@interface RecentSearchController()
- (void)clearHistory:(id)sender;
@end

@implementation RecentSearchController

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

- (id) init
{
	self = [super init];
	if (self != nil) {
		self.title = @"Recent Searches";
		self.navigationItem.leftBarButtonItem = [self editButtonItem];
		[appDelegate track:@"Recent Searches"];
	}
	return self;
}

// Invoked when the user touches Edit.
- (void)setEditing:(BOOL)editing animated:(BOOL)animated {
	// Updates the appearance of the Edit|Done button as necessary.
	[super setEditing:editing animated:animated];
	[table setEditing:editing animated:YES];
	// Disable the add button while editing.
	if (editing) {
		self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Clear All" style:UIBarButtonItemStyleBordered target:self action:@selector(clearHistory:)];
	} else {
		self.navigationItem.rightBarButtonItem = nil;
	}
}

- (void) clearHistory:(id)sender{
	[[appDelegate currentInstance] clearRecent];
	[self load];
}

- (void) setView:(UIView*)view
{
	if(!view)
	{
		table = nil;
	}
	[super setView:view];
}

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	UIView *vw = [[UIView alloc] initWithFrame:CGRectZero];
	vw.layer.contents = (id)[[appDelegate currentInstance] viewBackground].CGImage;
//	vw.backgroundColor = [UIColor colorWithRed:RedMake(kMainBackground) green:GreenMake(kMainBackground) blue:BlueMake(kMainBackground) alpha:1.0];
	self.view = vw;

	table = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
	table.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	table.backgroundColor = [UIColor clearColor];
//	table.layer.contents = (id)[appDelegate viewBackground].CGImage;
//	table.backgroundColor = [UIColor colorWithPatternImage:[appDelegate viewBackground]];
	table.delegate = self;
	table.dataSource = self;
//	self.view = table;

	[self.view addSubview:table];
}

- (void)load{
	[self setEditing:NO];
	searches = [[appDelegate currentInstance] getSearches];
	[table reloadData];
}

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

#pragma mark TableView DataSource and Delegate
- (void)tableView:(UITableView *)tv commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    // If row is deleted, remove it from the list.
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [[appDelegate currentInstance] deleteSearch:[(VehicleSearchObject*)[searches objectAtIndex:indexPath.row] pk]];
		[(NSMutableArray*)searches removeObjectAtIndex:indexPath.row];
        // Animate the deletion from the table.
        [table deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] 
							withRowAnimation:UITableViewRowAnimationFade];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [searches count];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	self.tabBarController.selectedIndex = 0;
	[(UINavigationController*)self.tabBarController.selectedViewController popToRootViewControllerAnimated:NO];
	[(HomeViewController*)[(UINavigationController*)self.tabBarController.selectedViewController visibleViewController] performSearch:[searches objectAtIndex:indexPath.row]];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	VehicleSearchObject *search = [searches objectAtIndex:indexPath.row];
	UITableViewCell	*cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
	cell.clipsToBounds = YES;
	UILabel *cellText = [[UILabel alloc] initWithFrame:CGRectMake(60.0f, 5.0f, 250.0f, 70.0f)];
	cellText.backgroundColor = [UIColor clearColor];
	cellText.numberOfLines = 0;
	cellText.font = [UIFont fontWithName:kDefaultFont size:kDefaultFontSize];
	
	cell.imageView.image = [UIImage imageNamed:@"marker.png"];
	cellText.lineBreakMode = UILineBreakModeTailTruncation;
		
	cellText.text = [NSString stringWithFormat:@"Dealer Lot:            %@\nYear:                      %@\nMake/Model:          %@ %@\nMin/Max Price:      %@ / %@\nMin/Max Mileage: %@ / %@", 
					 search.dealerLot > 0 ? [NSString stringWithFormat:@"%d",search.dealerLot] : @"None",
					 search.year > 0 ? [NSString stringWithFormat:@"%d",search.year] : @"None",
					 search.make, search.model,
					 search.minPrice > 0 ? [NSString stringWithFormat:@"$%d",search.minPrice] : @"None", 
					 search.maxPrice > 0 ? [NSString stringWithFormat:@"$%d",search.maxPrice] : @"None",
					 search.minMileage > 0 ? [NSString stringWithFormat:@"%d",search.minMileage] : @"None", 
					 search.maxMileage > 0 ? [NSString stringWithFormat:@"%d",search.maxMileage] : @"None"];

	cell.backgroundColor = [UIColor colorWithRed:RedMake(kResultBackground) green:GreenMake(kResultBackground) blue:BlueMake(kResultBackground) alpha:1.0];
	[cell.contentView addSubview:cellText];
	return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 80.0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}

- (NSArray*)getRestoreData{
	//Return default array
	return [NSArray array];
/*
	NSMutableArray *children = [NSMutableArray array];
	for(int i = [self.navigationController.viewControllers indexOfObject:self] + 1; i < [self.navigationController.viewControllers count]; i++)
	{
		UIViewController *vc = [self.navigationController.viewControllers objectAtIndex:i];
		if([vc conformsToProtocol:@protocol(ItemRestore)])
			[children addObject:[NSDictionary dictionaryWithObject:[vc performSelector:@selector(getRestoreData)] forKey:NSStringFromClass([vc class])]];
	}

	return children;
*/
}

- (void)restore:(NSArray*)data{
/*
	for(NSDictionary* child_data in data)
	{
		if([[child_data allKeys] count] < 1) continue;
		NSString *clss = [[child_data allKeys] objectAtIndex:0];
		Class controller = [[NSBundle mainBundle] classNamed:clss];
		if(class_conformsToProtocol(controller, @protocol(ItemRestore)))
		{
			id<ItemRestore> tmp = [[controller alloc] initWithRestore:[child_data objectForKey:clss]];
			if([tmp isKindOfClass:[UIViewController class]])
				[self.navigationController pushViewController:(UIViewController*)tmp animated:NO];
			[tmp release];
		}		
	}
*/	
	//Reload the RecentSearch data
	[self load];
}

- (void)dealloc {
	table = nil;
	searches = nil;
	
}

@end
