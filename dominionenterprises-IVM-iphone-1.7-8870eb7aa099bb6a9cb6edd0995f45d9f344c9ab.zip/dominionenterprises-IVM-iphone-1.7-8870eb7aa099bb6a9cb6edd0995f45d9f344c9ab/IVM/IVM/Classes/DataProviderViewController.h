//
//  SettingsViewController.m
//
//  Created by Raja Sekhar Nerella on 3/23/12.
//


#import <UIKit/UIKit.h>
#import "RestoreProtocols.h"

@class VehicleSearchObject;

@interface DataProviderViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate, UIAlertViewDelegate, AppRestore>
{
}

@property(nonatomic, strong) UITableView    *dataproviderTable;

@property(nonatomic, strong) NSArray    *listings;

-(void) performSearch:(VehicleSearchObject*)vso;

@end
