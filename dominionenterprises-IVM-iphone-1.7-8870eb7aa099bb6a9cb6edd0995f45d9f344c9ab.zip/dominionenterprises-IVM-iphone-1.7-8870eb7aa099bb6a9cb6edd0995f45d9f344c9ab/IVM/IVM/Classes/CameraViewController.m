#import "CameraViewController.h"
#import "HMACSHA256.h"
#import "appDelegate.h"
#import "Photo.h"


@implementation CameraViewController

@synthesize picker, HUD, pickedImage, base64Image;

- (id)init
{
    self = [super init];
    if (self != nil) {
        self.title = @"Camera";
        pickerLoaded = NO;

		mobileServices = [[IVMMobileServices alloc] init];
		mobileServices.delegate = self;
	}

	return self;
}

- (id)initWithType:(BOOL)isCam
{
    self = [super init];
    if (self != nil) {
        self.title = @"Camera";
        pickerLoaded = NO;
		isCamera = isCam;
		
		mobileServices = [[IVMMobileServices alloc] init];
		mobileServices.delegate = self;
	}
	
	return self;
}

- (id)initWithKey:(int)inKey withType:(BOOL)isCam
{
    self = [super init];
    if (self != nil) {
		isCamera = isCam;
        pickerLoaded = NO;
		
        if (isCamera) {
			self.title = @"Camera";
		} else {
			self.title = @"Photos Library";
		}
		
		mobileServices = [[IVMMobileServices alloc] init];
		mobileServices.delegate = self;
		_vehicleKey = inKey;
		_userToken = [[NSUserDefaults standardUserDefaults] stringForKey:kUserToken];

	}
	
	return self;
}

- (void)loadView
{
    UIView *homeView = [[UIView alloc] initWithFrame:CGRectZero];
    homeView.autoresizesSubviews = YES;
	self.view = homeView;

	if(!pickerLoaded)
    {
        [self startCameraPickerFromViewController];
        pickerLoaded = YES;
    }
}

-(void)viewDidAppear:(BOOL)animated {
}

- (void)doit {
	[self startCameraPickerFromViewController];
}

- (void)uploadPhoto {
	pickedImage = nil;

	if (loadingView == nil) {
		loadingView = [LoadingView loadingViewInView:self.view loadingText:@"Photo Uploading ..."];
	}
	
	[mobileServices addVehiclePhotoByToken:_vehicleKey withToken:_userToken inImage:base64Image];

	base64Image = nil;
}

- (void)processPhoto {
	//Upload the image to Web Server of Dealer Specialties
	NSData *imageData = UIImageJPEGRepresentation(pickedImage, 1.0);
	
	base64Image = [HMACSHA256 base64forData:imageData];
	
	imageData = nil;
	
    [self performSelectorOnMainThread:@selector(uploadPhoto) withObject:nil waitUntilDone:NO];
}


- (void)imagePickerController:(UIImagePickerController *)currentPicker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    pickerLoaded = NO;
//	[[currentPicker parentViewController] dismissModalViewControllerAnimated:YES];
	[currentPicker  dismissModalViewControllerAnimated:YES];

	pickedImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
	
	if (isCamera) {
		UIImageWriteToSavedPhotosAlbum(pickedImage, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);

		loadingView = [LoadingView loadingViewInView:self.view loadingText:@"Photo Saving ..."];
		return;
	}

	// Setup the Preview image 
	UIImageView *previewImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0.0f, -55.0f, 320.0f, 480.0f)];
	previewImageView.contentMode = UIViewContentModeScaleAspectFit;
	[previewImageView setImage:pickedImage]; 
	[self.view addSubview:previewImageView]; 
	
	// The hud will dispable all input on the view
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
	
    // Add HUD to screen
    [self.view addSubview:HUD];
	
    // Regisete for HUD callbacks so we can remove it from the window at the right time
    HUD.delegate = self;
	
    HUD.labelText = @"Processing ...";
	
    // Show the HUD while the provided method executes in a new thread
    [HUD showWhileExecuting:@selector(processPhoto) onTarget:self withObject:nil animated:YES];

}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)currentPicker
{
    pickerLoaded = NO;
    
//	[[currentPicker parentViewController] dismissModalViewControllerAnimated:YES];
	[currentPicker dismissModalViewControllerAnimated:YES];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    NSString *title;  

	if (loadingView != nil) {
		[loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
		loadingView = nil;
	}
	
    if (!error) {  
        title = @"Save Success";  
		fileSaved = YES;
    } else {  
        title = @"Save Failed";  
		fileSaved = NO;
	}  

	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
											message:@"Take More Photos?"
											delegate:self
											cancelButtonTitle:@"NO"
											otherButtonTitles:nil];
	
	[alertView addButtonWithTitle:@"YES"];
	[alertView show];
}


- (BOOL)startCameraPickerFromViewController
{
	if (mobileServices == nil) {
		mobileServices = [[IVMMobileServices alloc] init];
		mobileServices.delegate = self;
	}

	if (self.picker == nil) 
	{
		self.picker = [[UIImagePickerController alloc] init];
	
		self.picker.allowsEditing = YES;
		self.picker.delegate = self;
	}
	
	if( !isCamera || ![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
		self.picker.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
		[self presentModalViewController:self.picker animated:YES];
	} else {
		self.picker.sourceType = UIImagePickerControllerSourceTypeCamera;
	
		self.picker.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:self.picker.sourceType];
	
		self.picker.showsCameraControls = YES;
	
		[self cameraButtonTouchAction];
	}

	return YES;
}

- (IBAction)cameraButtonTouchAction
{
	if (self.picker != nil) 
	{
		self.picker.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
		[self presentModalViewController:self.picker animated:YES];
	}
}

-(BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSArray*)getRestoreData{
	NSMutableArray *children = [NSMutableArray array];
	return children;
}

- (void)restore:(NSArray*)data{
}

- (void) AddVehiclePhotoComplete:(Photo*)photoData inResult:(NSString*)inResult{
	
	if (loadingView != nil) {
		[loadingView performSelector:@selector(removeView) withObject:nil afterDelay:0.0];
		loadingView = nil;
	}

	NSString	*msgTemp = nil;
	if ([inResult isEqualToString:@"Success" ]) {
		msgTemp = [NSString stringWithFormat:@"%@, Upload More?", inResult];

		NSMutableString* t100String =  [NSMutableString stringWithFormat:@"%@", photoData.t100Image];
		NSRange characterRange = [t100String rangeOfString:@"-1t.jpg"];
		if (characterRange.location != NSNotFound) {
			[[appDelegate currentInstance] updateBookmark:photoData];
		}

	} else {
		if (inResult == nil) {
			msgTemp = [NSString stringWithFormat:@"%@", @"Failed, Retry?"];
		} else {
			msgTemp = [NSString stringWithFormat:@"%@, Retry?", inResult];
		}
	}

	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil
							message:msgTemp
							delegate:self
							cancelButtonTitle:@"NO"
							otherButtonTitles:nil];

	[alertView addButtonWithTitle:@"YES"];
	[alertView show];
}

#pragma mark -
#pragma mark MBProgressHUDDelegate methods

- (void)hudWasHidden {
    // Remove HUD from screen when the HUD was hidded
    [HUD removeFromSuperview];
}


#pragma mark -
#pragma mark alertView methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == alertView.cancelButtonIndex){
		//cancel button clicked.
		if (fileSaved) {
			//Back to the HOME
			fileSaved = NO;
			[[appDelegate currentInstance] switchBackHome];
		} else {
			[self.navigationController popViewControllerAnimated:YES];
		}
    } else {
		//other button indexes clicked
		if(!pickerLoaded)
		{
			[self performSelector:@selector(doit) withObject:nil afterDelay:0.0];
//			[self performSelector:@selector(doit) withObject:nil afterDelay:0.5];
			pickerLoaded = YES;
		}
    }
}  


- (void)didReceiveMemoryWarning {
	if (base64Image != nil) {
		base64Image = nil;
	}

	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
}

- (void)dealloc
{
	mobileServices.delegate = nil;
	pickerLoaded = NO;
	
	//cancel operations
	[mobileServices cancel];
	mobileServices = nil;

}

@end