//
//  NetImage.m
//  GetAuto.com
//
//  Created by Joseph Humphrey on 11/26/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//
/*
#import "NetImageView.h"
#import "NetDataOperation.h"

static NSOperationQueue *_internalQueue = nil;
static NSString *resizeUrl = @"http://www.dhmiservices.com/iphoneimages.ashx?w=%d&h=%d&path=%@";
static UIImage *missingPhoto = nil;
static UIImage *loadingPhoto = nil;

@interface NetImageView()
- (UIImage *) getImageFromCache:(NSURL*)url;
- (void) netDataOperationComplete:(NetDataOperation*)sender;
- (void) clearNDO;
@end


@implementation NetImageView

@synthesize imageURL, cache, noImage, loadingImage;

#pragma mark initialization
//default constructor for this class
- (id) initWithFrame:(CGRect)inFrame andUrl:(NSURL *)url andCache:(NSMutableDictionary*)inCache{
	self = [super initWithImage:nil];
	if(self) {
		if(!missingPhoto)
			missingPhoto = [[UIImage imageNamed:@"no_photo.png"] retain];
		if(!loadingPhoto)
			loadingPhoto = [[UIImage imageNamed:@"img_loading.png"] retain];
			
		self.noImage = missingPhoto;
		self.loadingImage = loadingPhoto;
		self.contentMode = UIViewContentModeScaleAspectFit;
		self.frame = inFrame;
		self.cache = inCache;
		self.imageURL = url;
	}
	return self;
}

#pragma mark Static Methods

+ (id) netImageWithStringUrl:(NSString *)url andCache:(NSMutableDictionary*)inCache
{
	NSURL  *rurl = nil;
	if(url != nil)
		rurl = [NSURL URLWithString:url];
	return [[[self alloc] initWithFrame:CGRectMake(0,0,[UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width) andUrl:rurl andCache:inCache] autorelease];
}
+ (UIImage*) imageForURL:(NSURL *)inURL withSize:(CGSize)inSize inCache:(NSDictionary*)inCache{
	return (UIImage*)[inCache objectForKey:[NSString stringWithFormat:resizeUrl, (int)inSize.width, (int)inSize.height, [inURL absoluteString]]];
}
#pragma mark Instance Methods

- (void) setImageURL:(NSURL*)url{
	[url retain];
	[imageURL release];
	imageURL = url;
	
	[_realUrl release];
	_realUrl = imageURL == nil ? nil : 
		[[NSURL URLWithString:[NSString stringWithFormat:resizeUrl, 
			(int)self.frame.size.width, (int)self.frame.size.height, [imageURL absoluteString]]] retain];
	//Cancel operation if necessary	
	[self clearNDO];
	
	//Set No Photo
	if(imageURL == nil)
		self.image = self.noImage;
	else{
		UIImage *cachedImg = [self getImageFromCache:_realUrl];
		//Return if cached image
		if(cachedImg){
			self.image = cachedImg;
			return;
		}
		
		//Begin async download
		self.image = self.loadingImage;
		
		_ndo = [[NetDataOperation alloc] initWithUrl:_realUrl];
		_ndo.target = self;
		_ndo.action = @selector(netDataOperationComplete:);
		
		if(!_internalQueue) _internalQueue = [[NSOperationQueue alloc] init];
		
		[_internalQueue addOperation:_ndo];
	}
}
- (void) netDataOperationComplete:(NetDataOperation*)sender{
	//Ignore old operation its already released
	if(sender != _ndo) return;
	
	if(_ndo.data == nil)
		self.image = noImage;
	else
	{
		UIImage *myImage = [UIImage imageWithData:_ndo.data];
		if(myImage){						
			self.image = myImage;
		}
		else
		{
			self.image = noImage;
#if CONFIG_Debug
			NSLog(@"Image Data Invalid For : %@", _ndo.url);
#endif
		}
	}
	[self clearNDO];
}
- (void) setImage:(UIImage*)inImage{
	//Alwasy No Image
	if(inImage == nil)
	{
		[self clearNDO];
		inImage = noImage;
	}
	
	[super setImage:inImage];
	
	//Cache Image
	if(inImage != loadingImage && _realUrl != nil)
		[cache setValue:inImage forKey:[_realUrl absoluteString]];
}

- (UIImage *) getImageFromCache:(NSURL*)url{
	return (UIImage*)[cache objectForKey:[url absoluteString]];
}
- (void) clearNDO{
	_ndo.target = nil;
	_ndo.action = nil;
	[_ndo cancel];
	[_ndo release];
	_ndo = nil;
}
- (void) dealloc
{
	[self clearNDO];
	[cache release];
	[_realUrl release];
	[loadingImage release];
	[noImage release];
	[imageURL release];
	[super dealloc];
#if CONFIG_Debug
	NSLog(@"Net Image View Dealloced");
#endif
}

@end*/

#import "NetImageView.h"

static NSString *resizeUrl = @"http://www.dhmiservices.com/iphoneimages.ashx?w=%d&h=%d&path=%@";
static UIImage *missingPhoto = nil;
static UIImage *loadingPhoto = nil;

@interface NetImageView()
- (UIImage *) getImageFromCache:(NSURL*)url;
- (void) clearDownload;
@end


@implementation NetImageView

@synthesize imageURL, cache, noImage, loadingImage;

#pragma mark initialization
//default constructor for this class
- (id) initWithFrame:(CGRect)inFrame andUrl:(NSURL *)url andCache:(NSMutableDictionary*)inCache {
	self = [super initWithImage:nil];
	if(self) {
		if(!missingPhoto)
			missingPhoto = [UIImage imageNamed:@"no_photo.png"];
		if(!loadingPhoto)
			loadingPhoto = [UIImage imageNamed:@"img_loading.png"];
		
		_imageData = [NSMutableData data];
		self.noImage = missingPhoto;
		self.loadingImage = loadingPhoto;
		self.contentMode = UIViewContentModeScaleAspectFit;
		self.frame = inFrame;
		self.cache = inCache;
		self.imageURL = url;
	}
	return self;
}

#pragma mark Static Methods

+ (id) netImageWithStringUrl:(NSString *)url andCache:(NSMutableDictionary*)inCache
{
	NSURL  *rurl = nil;
	if(url != nil)
		rurl = [NSURL URLWithString:url];
	return [[self alloc] initWithFrame:CGRectMake(0,0,[UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width) andUrl:rurl andCache:inCache];
}

+ (UIImage*) imageForURL:(NSURL *)inURL withSize:(CGSize)inSize inCache:(NSDictionary*)inCache{
	return (UIImage*)[inCache objectForKey:[NSString stringWithFormat:resizeUrl, (int)inSize.width, (int)inSize.height, [inURL absoluteString]]];
}
#pragma mark Instance Methods

//- (void) setImageURL:(NSURL*)url cache:(NSMutableDictionary*)inCache {
- (void) setImageURL:(NSURL*)url {
	imageURL = url;
	
	_realUrl = imageURL == nil ? nil : 
	[NSURL URLWithString:[NSString stringWithFormat:resizeUrl, 
						   (int)self.frame.size.width, (int)self.frame.size.height, [imageURL absoluteString]]];
	//Cancel operation if necessary
	[self clearDownload];
	
	//Set No Photo
	if(imageURL == nil) {
		self.image = self.noImage;
	} else {
		UIImage *cachedImg = [self getImageFromCache:_realUrl];
		//Return if cached image
		if(cachedImg){
			self.image = cachedImg;
			return;
		}
		
		//Begin async download
		self.image = self.loadingImage;
		
		_con = [NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:_realUrl] delegate:self];
	}
}

- (void) setImage:(UIImage*)inImage{
	//Alwasy No Image
	if(inImage == nil)
	{
		//[self clearNDO];
		[self clearDownload];
		inImage = noImage;
	}
	
	[super setImage:inImage];
	
	//Cache Image
	if(inImage != loadingImage && _realUrl != nil)
		[cache setValue:inImage forKey:[_realUrl absoluteString]];
}

- (UIImage *) getImageFromCache:(NSURL*)url {
    NSLog(@"debug in getImageFromCache ...");
    
    return (UIImage*)[cache objectForKey:[url absoluteString]];
}

#pragma mark NSURLConnection delegate methods
- (void) connection:(NSURLConnection *)urlconn didReceiveResponse:(NSURLResponse *)response {
	[_imageData setLength:0];
}

- (void) connection:(NSURLConnection *)urlconn didReceiveData:(NSData *)data {
    [_imageData appendData:data];
}

- (void) connectionDidFinishLoading:(NSURLConnection *)urlconn {
	if(!_imageData)
		self.image = noImage;
	else
	{
		UIImage *myImage = [UIImage imageWithData:_imageData];
		if(myImage){						
			self.image = myImage;
		}
		else
		{
			self.image = noImage;
#if CONFIG_Debug
			NSLog(@"Image Data Invalid For : %@", _realUrl);
#endif
		}
	}
}

- (void) connection:(NSURLConnection*)urlconn didFailWithError:(NSError*)error{
	self.image = nil;
#if CONFIG_Debug
	NSLog(@"Image Error: %@", error);
#endif
}

- (void) clearDownload{
	[_con cancel];
	_con = nil;
	[_imageData setLength:0];
}

- (void) dealloc
{
	[self clearDownload];
	_imageData = nil;
	_realUrl = nil;
	imageURL = nil;
}

@end