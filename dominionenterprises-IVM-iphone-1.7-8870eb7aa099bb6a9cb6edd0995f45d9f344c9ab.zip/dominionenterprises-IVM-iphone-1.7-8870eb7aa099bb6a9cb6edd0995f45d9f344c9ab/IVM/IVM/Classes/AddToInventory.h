//
//  AddToInventory.h
//  GetAuto.com
//
//  Created by Shaofeng Tu on 6/1/2010.
//  Copyright 2010 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MakesAndModels;

@interface AddToInventory : UIView<UITextFieldDelegate, UIAlertViewDelegate> {
	UITextField			*txt_vinCode;
	UIButton			*btn_VinCodeScan;
	UIButton			*btn_linkPictures;
	UITextField			*txt_price;
	UITextField			*txt_mileage;
	UIButton			*btn_addVehicle;
    
    UIView              *backgroundView01;
    UIView              *backgroundView02;
    UIImageView         *vinView;
    UILabel             *orLabel;
    UILabel             *vinLabel;

	bool				viewScanning;
//	UILabel				*tapLabel;
//	UILabel				*backLabel;
	UILabel				*vehicleLabel;
	UILabel				*priceLabel;
	UILabel				*mileageLabel;

	float				price;
	float				mileage;
	NSString			*vinCode;

	NSNumberFormatter   *currencyFormatter;
	NSCharacterSet      *nonNumberSet;
	NSCharacterSet      *nonVINCodeCharactersSet;

//	UIActivityIndicatorView	*activityIndicator;
//	UILabel					*activityLabel;
	
	CGFloat				animatedDistance;
}

@property(copy)			NSString	*vinCode;
@property(assign)		float	price;
@property(assign)		float	mileage;
@property(assign)		bool	viewScanning;

@property (nonatomic, strong)	UIView	*backgroundView01;
@property (nonatomic, strong)	UIView	*backgroundView02;

@property (nonatomic, strong)	UILabel	*vehicleLabel;
@property (nonatomic, strong)	UILabel	*priceLabel;
@property (nonatomic, strong)	UILabel	*mileageLabel;

@property (nonatomic, strong)	UITextField	*txt_vinCode;
@property (nonatomic, strong)	UITextField	*txt_price;
@property (nonatomic, strong)	UITextField	*txt_mileage;
@property (nonatomic, strong)	UIButton	*btn_VinCodeScan;
@property (nonatomic, strong)	UIButton	*btn_linkPictures;
@property (nonatomic, strong)	UIButton	*btn_addVehicle;

//@property(nonatomic, retain)	UIActivityIndicatorView	*activityIndicator;
//@property(nonatomic, retain)	UILabel					*activityLabel;

- (void) refreshViews;
- (void) shiftUpButton;
- (void) shiftDownButton;

@end
