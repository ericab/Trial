//
//  constants.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 12/17/08.
//  Copyright 2008 GetAuto.com. All rights reserved.
//

//Futura Tahoma Geneva
//Fonts
#define kDefaultFontSize			11.0f
//#define kDefaultFont				@"ArialMT"
//#define kDefaultFontBold			@"Arial-BoldMT"
#define kDefaultFont				@"HelveticaNeue"
#define kDefaultFontBold			@"HelveticaNeue-Bold"

//StandarColors
//#define kSCAddressRGB				0x2b85d4
//#define kSCPriceRGB					0xee1c23
#define kSCAddressRGB				0x333333
#define kSCPriceRGB					0xFF9933
#define kMainBackground				0xAAB2BA

//#define kNavTintColor				0x333333
#define kNavTintColor				0x2b323c
#define	kActiveLabel				0xEFC43C
#define kButtonNormal				0x333333
#define kButtonDisabled				0xCCCCCC
#define kButtonHighlighted			0x0000FF
#define kMapBackground				0xF5F1E6
#define kButtonNormal2				0x003366
#define kResultBackground			0xE6E6E6

//ARGB functions for UIColor
#define AlphaMake(h)	(((h) & 0xFF000000) >> 32) / 255.0f
#define RedMake(h)		(((h) & 0xFF0000) >> 16) / 255.0f
#define GreenMake(h)	(((h) & 0xFF00) >> 8) / 255.0f
#define BlueMake(h)		((h) & 0xFF) / 255.0f

#define kLastExit @"IVM_LastExit"
#define kLastLaunch @"IVM_LastLaunch"
#if CONFIG_Debug
#define kMakeModelExperiation -60
#else
#define kMakeModelExperiation -86400
#endif

#define WaitNetworkTimerDuration	5.0

#define kMaxPageResults			25

#define kRestoreLocationKey @"IVM_RestoreLocation"
#define kMakesAndModels @"IVM_MakesAndModels"
#define kUserToken  @"IVM_UserToken"
#define kUserName  @"IVM_UserName"
#define kDealerLots  @"IVM_DealerLots"
#define kKeepLoggedIn  @"IVM_LoggedIn"
#define kDefaultDealerLot  @"IVM_DefaultDealerLot"

#define preHashString  @"iPhone"
#define hashKeyString  @"z49sYG_J3f"

#define kVehicleMappedDate @"VehicleMappedDate"
