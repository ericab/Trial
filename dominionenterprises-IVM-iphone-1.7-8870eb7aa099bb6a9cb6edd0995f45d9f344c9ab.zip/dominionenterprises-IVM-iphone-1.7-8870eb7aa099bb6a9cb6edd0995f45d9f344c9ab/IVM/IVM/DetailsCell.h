//
//  DetailsCell.h
//  GetAuto.com
//
//  Created by Joseph Humphrey on 2/4/09.
//  Copyright 2009 GetAuto.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NetImageView;

@interface DetailsCell : UITableViewCell {
	NetImageView		*netImage;
	UILabel				*lbl_MakeModel;
	UILabel				*lbl_price;
	UILabel				*lbl_Engine;
	UILabel				*lbl_Stock;
	UILabel				*lbl_Miles;
	UILabel				*lbl_ExtColor;
	UILabel				*lbl_IntColor;
	UILabel				*lbl_VIN;
	UIButton			*btn_linkPictures;
	UIButton			*btn_slideShow;
	UIButton			*btn_modify;
	NetImageView		*certifiedLogo;

	UISegmentedControl	*seg_sort;
}

@property(readonly, strong)		NetImageView		*netImage;
@property(readonly, strong)		UILabel				*lbl_MakeModel;
@property(readonly, strong)		UILabel				*lbl_price;
@property(readonly, strong)		UILabel				*lbl_Engine;
@property(readonly, strong)		UILabel				*lbl_Stock;
@property(readonly, strong)		UILabel				*lbl_Miles;
@property(readonly, strong)		UILabel				*lbl_ExtColor;
@property(readonly, strong)		UILabel				*lbl_IntColor;
@property(readonly, strong)		UILabel				*lbl_VIN;
@property(readonly, strong)		UIButton			*btn_linkPictures;
@property(readonly, strong)		UIButton			*btn_slideShow;
@property(readonly, strong)		UIButton			*btn_modify;
@property(readonly, strong)		NetImageView		*certifiedLogo;

@property(readonly, strong)		UISegmentedControl	*seg_sort;

@end